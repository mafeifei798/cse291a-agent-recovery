"""Independent v2 entry. Importing does not access credentials or networking."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from safety_reliability_live_v2.launch import main

if __name__ == "__main__":
    raise SystemExit(main())
