#!/usr/bin/env python3
"""Save socket-free acceptance for the independent v2 first-batch entry."""
from pathlib import Path
import argparse
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/"src"), str(ROOT/"scripts")]
from safety_reliability_live_v2.protocol import prepare, read, write, sha
from safety_reliability_live_v2.launch import run
from safety_reliability_live_v2.checker import check_batch


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=False)
    specs=[
        dict(name="clean", recipe={}, rows=10,calls=50,complete=10,repair=0,hard=False),
        dict(name="metadata_repair",recipe={"default":{"kind":"metadata_wrong"}},rows=10,calls=50,complete=4,repair=4,hard=False),
        dict(name="second_failure",recipe={"default":{"kind":"metadata_wrong","always":True}},rows=10,calls=42,complete=0,repair=4,hard=False),
        dict(name="resource_overage",recipe={"default":{"kind":"resource_over","step":"plan"}},rows=10,calls=46,complete=0,repair=0,hard=False),
        dict(name="unknown_usage",recipe={"default":{"kind":"missing_usage"}},rows=1,calls=1,complete=0,repair=0,hard=True),
        dict(name="quota_429",recipe={"default":{"kind":"http429"}},rows=1,calls=1,complete=0,repair=0,hard=True),
    ]
    write(output/"REGISTRATION.json",dict(kind="fake-http-mechanism-acceptance-not-real-model-evaluation",cases=specs,
        live_authorized=False,real_api_requests=0,training_or_prediction_calls=0))
    results=[]
    for spec in specs:
        campaign=output/spec["name"]
        prepare(campaign,"fake-http")
        recipe=output/(spec["name"]+"-recipe.json")
        write(recipe,spec["recipe"])
        state=run(campaign,mode="fake-http",recipe=recipe)
        check=check_batch(campaign)
        branches=[c["metrics"] for c in check["checks"]]
        got=dict(rows=len(check["slot_ids"]),calls=check["calls"],complete=sum(c.get("completed",False) for c in branches),
            repair=sum(c.get("repair_rounds",0) for c in branches),hard=state["status"]=="hard_stopped")
        expected={k:spec[k] for k in got}
        passed=check["passed"] and got==expected and check["real_api_requests"]==0
        if spec["hard"]:
            passed &= check["held_nano"]>0
        else:
            again=run(campaign,mode="fake-http")
            passed &= again.get("new_dispatches")==0 and again.get("reused_completed_batch") is True
        entry=read(campaign/"batches/B01/entry_receipt.json")
        passed &= entry["credential_received_count"]==0 and not entry["offline_fence"]["blocked"]
        result=dict(name=spec["name"],passed=bool(passed),expected=expected,actual=got,
            independent_check=check,entry=entry,authority_state=state["status"],
            historical_real_total_nano=state["historical_known_nano"]+state["historical_held_nano"],
            fake_known_nano=check["known_nano"],fake_held_nano=check["held_nano"],
            expansion_stop_reason=read(campaign/"batches/B01/report.json")["expansion_stop_reason"])
        write(output/(spec["name"]+".json"),result)
        results.append(result)
        print(spec["name"],"PASS" if passed else "FAIL",got,flush=True)
    live=output/"disabled_live_ready"
    prepare(live,"live")
    disabled=False
    try:
        run(live,mode="live",grant=live/"protocol/disabled-live-grant.json")
    except PermissionError:
        disabled=True
    passed=all(r["passed"] for r in results) and disabled and not (live/"authority.sqlite").exists()
    write(output/"SUMMARY.json",dict(passed=passed,cases=len(results),passed_cases=sum(r["passed"] for r in results),
        rows=sum(r["actual"]["rows"] for r in results),fake_http_calls=sum(r["actual"]["calls"] for r in results),
        real_api_requests=0,real_credentials_read=0,provider_debit_nano_usd=0,cloud_resources_started=0,
        training_or_prediction_calls=0,disabled_live_rejected_before_reservation=disabled,
        result_paths=[r["name"]+".json" for r in results],finished_unix=time.time()))
    return 0 if passed else 1


if __name__=="__main__":
    sys.exit(main())
