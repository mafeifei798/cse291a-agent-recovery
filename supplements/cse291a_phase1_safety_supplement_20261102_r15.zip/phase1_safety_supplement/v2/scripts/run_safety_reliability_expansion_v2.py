"""Independent B02-B06 launcher; preparation does not authorize live requests."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"scripts")]
from safety_reliability_expansion_v2.launch import main
if __name__=="__main__":
    raise SystemExit(main())
