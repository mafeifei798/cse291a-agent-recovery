"""Independent continuation entry; no automatic live authorization."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]
from safety_reliability_continuation_v2.launch import main
if __name__ == "__main__":
    raise SystemExit(main())
