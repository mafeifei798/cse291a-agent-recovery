#!/usr/bin/env python3
"""Offline continuation acceptance: fake HTTP with actual persistent 2 s pacing.

This exercises only the 18 unstarted identities in a fresh output namespace.
It does not modify or redispatch the old halted campaign or its failed row.
"""
from pathlib import Path
import argparse
import sys
import time
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'scripts')]
from safety_reliability_continuation_v2.protocol import prepare, read, write
from safety_reliability_continuation_v2.launch import run, LaunchStopped
from safety_reliability_continuation_v2.runtime import Session
from safety_reliability_continuation_v2.checker import check_batch, check_run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve(); output.mkdir(parents=True, exist_ok=False)
    results = []; campaign = output / 'matrix18'; frozen = prepare(campaign)
    for batch in frozen['registration']['batches']:
        bid = batch['batch_id']; state = run(campaign, mode='fake-http', batch_id=bid)
        checked = check_batch(campaign, bid)
        metrics = [c['metrics'] for c in checked['checks']]
        item = dict(name=bid, passed=checked['passed'] and len(checked['slot_ids'])==len(batch['slots'])
                    and state['status']!='hard_stopped', rows=len(metrics), calls=checked['calls'],
                    completed=sum(m['completed'] for m in metrics),
                    safe_stopped=sum(m['status']=='safe_stopped' for m in metrics), check=checked)
        results.append(item); write(output / (bid+'.json'), item)
        print(bid, item['passed'], item['calls'], flush=True)
        if not item['passed']:
            raise RuntimeError('MATRIX_ACCEPTANCE_FAILED:'+bid)
        again = run(campaign, mode='fake-http', batch_id=bid)
        if again.get('new_dispatches') != 0:
            raise RuntimeError('REENTRY_DISPATCH')
    if sum(r['rows'] for r in results)!=18:
        raise RuntimeError('ROWS')
    # Directed synthetic mechanism checks are separate from the formal matrix.
    edges = [
        ('executor_self_correct_guard', 'new_guard_repair',
         {'executor_behavior':'self_correct'}, 'completed', 7, 1),
        ('executor_self_correct_verify', 'new_verify_repair',
         {'executor_behavior':'self_correct'}, 'safe_stopped', 4, 0),
        ('mixed_metadata_self_correct', 'new_guard_repair',
         {'kind':'metadata_wrong','executor_behavior':'self_correct'}, 'completed', 8, 1),
    ]
    edge_results = []
    for name, arm, recipe, status, calls, rounds in edges:
        row = next(r for r in frozen['registration']['rows'] if r['scenario']=='S07' and r['arm']==arm)
        directory = output / 'edges' / name
        with Session(directory, row, frozen, recipe=recipe) as session:
            session.run(); session.export()
        checked = check_run(directory, frozen); m = checked.get('metrics', {})
        item = dict(name=name, passed=checked['passed'] and
                    (m.get('status'),m.get('physical_dispatches'),m.get('repair_rounds'))==(status,calls,rounds), check=checked)
        edge_results.append(item); write(output / (name+'.json'), item)
        print(name, item['passed'], flush=True)
    stops = []
    for name, recipe in [('unknown_usage', {'default':{'kind':'missing_usage'}}),
                         ('quota_429', {'default':{'kind':'http429'}})]:
        dest = output / name; prepare(dest)
        recipe_path = output / (name+'-recipe.json'); write(recipe_path, recipe)
        bid = 'B04'
        preceding = []
        if name == 'quota_429':
            # Carry the same persistent scheduler across two completed batches;
            # the next batch's 429 must fence the whole continuation campaign.
            for previous in ('B04', 'B05'):
                run(dest, mode='fake-http', batch_id=previous)
                prior_check = check_batch(dest, previous)
                if not prior_check['passed']:
                    raise RuntimeError('RATE_LIMIT_PREFIX_CHECK_FAILED')
                preceding.append(previous)
            bid = 'B06'
        state = run(dest, mode='fake-http', batch_id=bid, recipe=recipe_path)
        checked = check_batch(dest, bid); fenced = False; repeat_fenced = False
        try:
            run(dest, mode='fake-http', batch_id='B06')
        except LaunchStopped:
            fenced = True
        try:
            run(dest, mode='fake-http', batch_id=bid, recipe=recipe_path)
        except LaunchStopped:
            repeat_fenced = True
        item = dict(name=name, passed=checked['passed'] and state['status']=='hard_stopped'
                    and len(checked['slot_ids'])==1 and checked['calls']==1 and fenced and repeat_fenced,
                    later_or_current_batch_fenced=fenced, same_batch_fenced=repeat_fenced,
                    preceding_completed_batches=preceding, check=checked, authority=state)
        stops.append(item); write(output / (name+'.json'), item)
        print(name, item['passed'], flush=True)
    live = output / 'disabled_live'; prepare(live, 'live'); disabled = False
    try:
        run(live, mode='live', batch_id='B04', grant=live/'protocol/disabled-live-grant.json')
    except PermissionError:
        disabled = True
    final_state = read(campaign / 'STATUS.json')
    passed = all(item['passed'] for item in results+edge_results+stops) and disabled
    passed = passed and not (live/'authority.sqlite').exists()
    summary = dict(passed=passed, formal_rows=18,
        formal_fake_http_calls=sum(r['calls'] for r in results),
        formal_complete=sum(r['completed'] for r in results),
        formal_safe_stopped=sum(r['safe_stopped'] for r in results),
        directed_edge_cases=len(edges), stopping_cases=len(stops),
        disabled_live_rejected_before_reservation=disabled, real_api_requests=0,
        real_credentials_read=0, cloud_resources_started=0, training_or_prediction_calls=0,
        provider_debit_nano_usd=0, inherited_real_calls=2401,
        inherited_known_nano_usd=175247450, inherited_held_nano_usd=3252000,
        inherited_total_nano_usd=178499450, final_fake_authority=final_state,
        old_recorded_slots_not_redispatched=22, old_429_attempt_preserved=True,
        finished_unix=time.time())
    write(output / 'SUMMARY.json', summary); print(summary)
    return int(not passed)


if __name__ == '__main__':
    raise SystemExit(main())
