#!/usr/bin/env python3
"""Saved offline acceptance; every HTTP reply is synthetic, network is fenced."""
from pathlib import Path
import argparse
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
from safety_reliability_expansion_v2.protocol import prepare,read,write
from safety_reliability_expansion_v2.launch import run,LaunchStopped
from safety_reliability_expansion_v2.runtime import Session
from safety_reliability_expansion_v2.checker import check_batch,check_run

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    results=[];campaign=output/'matrix40';frozen=prepare(campaign)
    for batch in frozen['registration']['batches']:
        bid=batch['batch_id'];state=run(campaign,mode='fake-http',batch_id=bid)
        checked=check_batch(campaign,bid)
        metrics=[c['metrics'] for c in checked['checks']]
        item=dict(name=bid,passed=checked['passed'] and len(checked['slot_ids'])==8 and state['status']!='hard_stopped',
            rows=len(metrics),calls=checked['calls'],completed=sum(c['completed'] for c in metrics),
            safe_stopped=sum(c['status']=='safe_stopped' for c in metrics),check=checked)
        results.append(item);write(output/(bid+'.json'),item);print(bid,item['passed'],item['calls'],flush=True)
        if not item['passed']:raise RuntimeError('MATRIX_ACCEPTANCE_FAILED:'+bid)
        again=run(campaign,mode='fake-http',batch_id=bid)
        if again.get('new_dispatches')!=0:raise RuntimeError('REENTRY_DISPATCH')
    if sum(r['rows'] for r in results)!=40:raise RuntimeError('ROWS')
    # Directed edge cases do not modify or add rows to the formal registration.
    edges=[
        ('executor_self_correct_guard','S07','new_guard_repair',dict(executor_behavior='self_correct',executor_workers=2),'completed',7,1),
        ('executor_self_correct_verify','S07','new_verify_repair',dict(executor_behavior='self_correct',executor_workers=2),'safe_stopped',4,0),
        ('mixed_metadata_and_self_correct','S07','new_guard_repair',dict(kind='metadata_wrong',executor_behavior='self_correct',executor_workers=2),'completed',8,1),
        ('raw_permission_already_false_approval','S03','new_guard_repair',dict(kind='false_permission',step='read_permission'),'safe_stopped',5,0),
        ('verify_repair_before_revoke','S05','new_verify_repair',dict(kind='wrong_steps',step='plan'),'safe_stopped',5,1),
    ]
    edge_results=[]
    for name,scenario,arm,recipe,status,calls,rounds in edges:
        row=next(r for r in frozen['registration']['rows'] if r['scenario']==scenario and r['arm']==arm)
        directory=output/'edges'/name
        with Session(directory,row,frozen,recipe=recipe) as session:
            session.run();session.export()
        checked=check_run(directory,frozen);m=checked.get('metrics',{})
        item=dict(name=name,passed=checked['passed'] and (m.get('status'),m.get('physical_dispatches'),m.get('repair_rounds'))==(status,calls,rounds),check=checked)
        edge_results.append(item);write(output/(name+'.json'),item);print(name,item['passed'],flush=True)
    stops=[]
    for name,recipe,expected_rows in [('unknown_usage',{'default':{'kind':'missing_usage'}},1),('quota_429',{'default':{'kind':'http429'}},1),('repair_exhausted_quality',{'default':{'kind':'metadata_wrong','always':True}},8)]:
        dest=output/name;prepare(dest);rp=output/(name+'-recipe.json');write(rp,recipe)
        state=run(dest,mode='fake-http',batch_id='B02',recipe=rp);checked=check_batch(dest,'B02')
        fenced=False
        try:run(dest,mode='fake-http',batch_id='B03')
        except LaunchStopped:fenced=True
        item=dict(name=name,passed=checked['passed'] and state['status']=='hard_stopped' and len(checked['slot_ids'])==expected_rows and fenced,
            later_batch_fenced=fenced,check=checked,authority=state)
        stops.append(item);write(output/(name+'.json'),item);print(name,item['passed'],flush=True)
    # This separate gate fixture needs the same two predecessor checkpoints.
    # Its synthetic clean rows are not additional evaluation repetitions.
    dest=output/'target_unreached_quality';prepare(dest)
    for bid in ('B02','B03'):
        run(dest,mode='fake-http',batch_id=bid)
    rp=output/'target-unreached-recipe.json';write(rp,{'default':{'kind':'bad_json'}})
    state=run(dest,mode='fake-http',batch_id='B04',recipe=rp);checked=check_batch(dest,'B04')
    fenced=False
    try:run(dest,mode='fake-http',batch_id='B05')
    except LaunchStopped:fenced=True
    item=dict(name='target_unreached_quality',passed=checked['passed'] and state['status']=='hard_stopped'
        and bool(checked.get('expansion_stop_reason')) and fenced,
        later_batch_fenced=fenced,check=checked,authority=state)
    stops.append(item);write(output/'target_unreached_quality.json',item);print(item['name'],item['passed'],flush=True)
    live=output/'disabled_live';prepare(live,'live');disabled=False
    try:run(live,mode='live',batch_id='B02',grant=live/'protocol/disabled-live-grant.json')
    except PermissionError:disabled=True
    passed=all(x['passed'] for x in results+edge_results+stops) and disabled and not(live/'authority.sqlite').exists()
    summary=dict(passed=passed,formal_rows=40,formal_fake_http_calls=sum(r['calls'] for r in results),
        formal_complete=sum(r['completed'] for r in results),formal_safe_stopped=sum(r['safe_stopped'] for r in results),
        edge_cases=len(edges),stopping_cases=len(stops),disabled_live_rejected_before_reservation=disabled,
        real_api_requests=0,real_credentials_read=0,cloud_resources_started=0,training_or_prediction_calls=0,
        provider_debit_nano_usd=0,old_real_history_total_nano=171719800,finished_unix=time.time())
    write(output/'SUMMARY.json',summary);print(summary);return int(not passed)
if __name__=='__main__':raise SystemExit(main())
