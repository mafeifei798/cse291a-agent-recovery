"""Portable deployment configuration; the scientific registration is unchanged."""
from __future__ import annotations

from pathlib import Path
import time

from safety_real.protocol import (ROOT, STUDY, LIMITS, registration, history, binding_dict,
                                 HISTORY_PATHS, code_hashes as base_hashes, digest, read, write, sha)

REVISION = "safety-datahub-launch-v1"
LIVE_RELATIVE = "outputs/safety_datahub_v1_live"
KEY_VARIABLE = "OPENAI_API_KEY"
TARGET_FIELDS = dict(schema_version="safety-datahub-target-v1", target="ucsd-datahub",
    hub_origin="https://datahub.ucsd.edu", course_profile="CSE291A_FA26_003",
    cpus=2, memory_gib=8, gpus=0, credential_source="datahub_environment",
    credential_variable=KEY_VARIABLE, campaign_relative=LIVE_RELATIVE)


def validate_target(target):
    allowed=set(TARGET_FIELDS)|{"deployment_root","hub_user","service_prefix"}
    if (not isinstance(target, dict) or set(target)!=allowed
            or any(target.get(k) != v for k, v in TARGET_FIELDS.items())):
        raise PermissionError("DATAHUB_TARGET_SCOPE_MISMATCH")
    if target.get("deployment_root") != str(ROOT.resolve()):
        raise PermissionError("DATAHUB_DEPLOYMENT_ROOT_MISMATCH")
    user, prefix = target.get("hub_user"), target.get("service_prefix")
    if (not isinstance(user, str) or not user or "FILL" in user or len(user)>128
            or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.@" for c in user)
            or not isinstance(prefix, str) or not prefix.startswith("/user/" + user + "/")
            or not prefix.endswith("/") or ".." in prefix or "FILL" in prefix):
        raise PermissionError("DATAHUB_TARGET_IDENTIFIERS_REQUIRED")
    return True


def code_hashes():
    pins=base_hashes()
    paths=list((ROOT/"scripts/safety_datahub").glob("*.py"))
    paths += [ROOT/"scripts/run_safety_datahub.py", ROOT/"configs/safety_datahub/target.template.json",
              ROOT/"configs/safety_datahub/permission.template.json", ROOT/"configs/safety_datahub/requirements.lock"]
    pins.update({str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)})
    return pins


def disabled_grant(frozen, output):
    return dict(schema_version="safety-datahub-permit-v1", authorized=False, study_id=STUDY,
        launch_revision=REVISION, campaign_root=str(Path(output).resolve()),
        frozen_digest=digest(frozen), binding_digest=digest(frozen["binding"]),
        history_digest=digest(frozen["history"]), deployment_digest=digest(frozen["deployment"]),
        credential_source="datahub_environment", credential_variable=KEY_VARIABLE,
        limits=LIMITS, allowed_batches=["B01"], max_new_calls=60, expires_unix=0,
        authorization_reference="FUTURE_EXPLICIT_AUTHORIZATION_REQUIRED",
        pricing_and_model_confirmed=False, course_cpu_profile_confirmed=False)


def prepare(output, mode="fake-http", target=None):
    output=Path(output).resolve()
    if mode not in ("fake-http", "live"): raise ValueError("MODE")
    if mode=="live":
        validate_target(target)
        if output != ROOT/LIVE_RELATIVE: raise PermissionError("DATAHUB_LIVE_ROOT_IS_FIXED")
    elif target is not None:
        raise PermissionError("FAKE_CANNOT_ACCEPT_DATAHUB_TARGET")
    frozen=dict(registration=registration(), history=history(), binding=binding_dict(mode), mode=mode,
        code_hashes=code_hashes(), launch_revision=REVISION, deployment=target,
        live_authorized_by_preparation=False)
    if (output/"protocol/frozen.json").exists():
        if read(output/"protocol/frozen.json")!=frozen: raise ValueError("FROZEN_INPUT_CHANGED")
        return frozen
    output.mkdir(parents=True,exist_ok=True)
    for name,value in (("frozen",frozen),("registration",frozen["registration"]),
                       ("history",frozen["history"]),
                       ("prompt_spec",read(ROOT/"phase1/p0/contracts/prompt_spec.json")),
                       ("disabled-live-grant",disabled_grant(frozen,output))):
        write(output/"protocol"/(name+".json"),value)
    return frozen


def validate_grant(frozen, output, grant, batch_id=None, *, now=None):
    now=time.time() if now is None else now
    if frozen["mode"]!="live" or grant.get("authorized") is not True:
        raise PermissionError("DATAHUB_LIVE_DISABLED")
    validate_target(frozen.get("deployment"))
    batches=grant.get("allowed_batches")
    registered={b["batch_id"]:b for b in frozen["registration"]["batches"]}
    if (grant.get("schema_version")!="safety-datahub-permit-v1"
        or frozen.get("launch_revision")!=REVISION or grant.get("launch_revision")!=REVISION
        or Path(output).resolve()!=ROOT/LIVE_RELATIVE or grant.get("campaign_root")!=str(Path(output).resolve())
        or grant.get("study_id")!=STUDY or grant.get("frozen_digest")!=digest(frozen)
        or grant.get("binding_digest")!=digest(frozen["binding"])
        or grant.get("history_digest")!=digest(frozen["history"])
        or grant.get("deployment_digest")!=digest(frozen["deployment"])
        or grant.get("credential_source")!="datahub_environment"
        or grant.get("credential_variable")!=KEY_VARIABLE or grant.get("limits")!=LIMITS
        or grant.get("pricing_and_model_confirmed") is not True
        or grant.get("course_cpu_profile_confirmed") is not True
        or not isinstance(batches,list) or not batches or len(batches)!=len(set(batches))
        or any(b not in registered for b in batches)
        or type(grant.get("max_new_calls")) is not int
        or grant.get("max_new_calls")!=sum(registered[b]["call_cap"] for b in batches)
        or not isinstance(grant.get("expires_unix"),(int,float))
        or not now < grant["expires_unix"] <= now+86400
        or not isinstance(grant.get("authorization_reference"),str)
        or not grant["authorization_reference"].strip()):
        raise PermissionError("DATAHUB_LIVE_SCOPE_MISMATCH")
    if batch_id is not None and batch_id not in batches:
        raise PermissionError("DATAHUB_BATCH_NOT_PERMITTED")
    return True
