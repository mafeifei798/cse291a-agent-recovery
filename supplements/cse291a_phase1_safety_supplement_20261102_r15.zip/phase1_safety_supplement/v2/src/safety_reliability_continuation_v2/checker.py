"""Read-only continuation audit; producer protocol/runtime are never imported.

Historical and current SQLite rows, raw HTTP and persistent pacing events are
checked directly. Business validation deliberately reuses the unchanged,
independent expansion checker rather than introducing a different guard.
"""
from copy import deepcopy
import json
import math
from datetime import datetime
from pathlib import Path
import sqlite3

from safety_reliability_expansion_v2.checker import (
    load as legacy_load, check_loaded as legacy_check_loaded, branch_halt, readonly_tables, canonical, h,
    byte_hash, check_frozen as check_expansion_frozen,
    check_batch as check_expansion_batch, EXPECTED_LIMITS)

ROOT = Path(__file__).resolve().parents[2]
SAVED = Path("outputs/safety_reliability_expansion_v2_live_20261023/remote_evidence/outputs/safety_reliability_v2_expansion_live")
CONTINUATION_LIMITS = dict(EXPECTED_LIMITS, rows=18, calls=144)
PACING_POLICY = dict(min_interval_seconds=2.0, spacing_basis="previous_call_completion",
    automatic_retries=0, clock="wall_and_monotonic", pending_call_policy="hard_stop",
    rate_limit_policy="429_hard_stop_no_retry")

def check_pacing_snapshot(snapshot, *, frozen=None, calls=None, partial=False):
    """Check scheduler evidence without importing the scheduler or its helpers."""
    errors = []
    def need(ok, code):
        if not ok:
            errors.append(code)
    try:
        cfg, state, events = snapshot["config"], snapshot["state"], snapshot["events"]
        need(snapshot["schema_version"] == "continuation-pacing-v1"
             and cfg["policy"] == PACING_POLICY, "PACING_POLICY")
        need(cfg["clock_kind"] in ("system","injected_test_clock")
             and (cfg["simulated"] or cfg["clock_kind"] == "system"), "PACING_CLOCK_MODE")
        if frozen is not None:
            need(cfg["frozen_digest"] == h(frozen) and cfg["simulated"] == (frozen["mode"] == "fake-http"), "PACING_FROZEN_BINDING")
        seq = [e["sequence"] for e in events]
        need(seq == sorted(set(seq)) and (partial or seq == list(range(1,len(events)+1))), "PACING_SEQUENCE")
        ids = [e["call_id"] for e in events]
        need(len(ids) == len(set(ids)) <= 144, "PACING_SINGLE_ADMISSION")
        need(state["pending_call_id"] is None, "PACING_NO_PENDING_CALL")
        previous, last_429 = None, None
        for i,e in enumerate(events):
            status = e["status"]
            need(status in ("finished","denied"), "PACING_TERMINAL_EVENT")
            for suffix in ("monotonic","unix"):
                for prefix in ("requested_", "deadline_", "eligible_"):
                    value=e[prefix+suffix]
                    need(type(value) in (int,float) and math.isfinite(value), "PACING_FINITE_CLOCK")
                need(e["deadline_"+suffix] - e["requested_"+suffix] <= 120.05, "PACING_CALL_DEADLINE_CAP")
                if previous is not None:
                    need(e["requested_"+suffix]+.001 >= previous["finished_"+suffix], "PACING_SERIAL_CALLS")
                    need(e["eligible_"+suffix]+.001 >= previous["finished_"+suffix]+2.0, "PACING_GLOBAL_GAP")
            need(type(e["waited_seconds"]) in (int,float) and math.isfinite(e["waited_seconds"])
                 and e["waited_seconds"] >= 0, "PACING_WAIT_ACCOUNTING")
            if status == "finished":
                need(last_429 is None, "PACING_NO_DISPATCH_AFTER_429")
                for suffix in ("monotonic","unix"):
                    admitted, finished = e["admitted_"+suffix], e["finished_"+suffix]
                    need(type(admitted) in (int,float) and type(finished) in (int,float)
                         and math.isfinite(admitted) and math.isfinite(finished), "PACING_FINITE_CLOCK")
                    need(e["requested_"+suffix]-.001 <= admitted < e["deadline_"+suffix]
                         and admitted+.001 >= e["eligible_"+suffix] and finished+.001 >= admitted, "PACING_ADMISSION_BOUNDARY")
                need(abs(e["waited_seconds"]-(e["admitted_monotonic"]-e["requested_monotonic"])) <= .002, "PACING_WAIT_ACCOUNTING")
                previous = e
                if e["status_code"] == 429:
                    last_429 = e
            else:
                need("admitted_monotonic" not in e and "admitted_unix" not in e
                     and e["status_code"] is None and bool(e["error_code"]), "PACING_DENIAL_NO_DISPATCH")
                need(state["hard_stop_reason"] is not None, "PACING_DENIAL_FENCE")
            if calls is not None:
                need(e["call_id"] in calls, "PACING_NO_UNACCOUNTED_ADMISSION")
                if e["call_id"] not in calls:
                    continue
                c = calls[e["call_id"]]
                trace = (c.get("evidence") or {}).get("http_trace",{})
                need(e["status_code"] == trace.get("status"), "PACING_HTTP_STATUS_LINK")
                if c["dispatched"]:
                    dispatched = datetime.fromisoformat(c["dispatched_at"].replace("Z","+00:00")).timestamp()
                    need(status == "finished" and e["admitted_unix"]-.005 <= dispatched <= e["finished_unix"]+.005,
                         "PACING_REAL_DISPATCH_BOUNDARY")
                    cleanup = trace.get("cleanup_receipt",{})
                    need(e["finished_monotonic"]+.01 >= cleanup.get("finished_s",e["finished_monotonic"]), "PACING_WORKER_FINISH_BOUNDARY")
                    if trace.get("status") == 429:
                        need(c["status"] != "settled" and c["held_cost_nano_usd"] == c["reserved_cost_nano_usd"]
                             and c["known_cost_nano_usd"] == 0, "PACING_429_HOLD_NOT_RELEASED")
                elif status == "denied":
                    need(not c.get("dispatched_at") and not trace.get("response_body_b64"), "PACING_DENIED_RAW_HTTP")
                else:
                    need(bool(e["error_code"]) and e["status_code"] is None
                         and not c.get("dispatched_at") and not trace.get("response_body_b64"), "PACING_ADMITTED_BUT_NOT_SENT")
        if last_429 is not None:
            need(state["hard_stop_reason"] == "HTTP_429_NO_RETRY", "PACING_429_FENCE")
        if previous is not None and not partial:
            need(state["last_finished_monotonic"] == previous["finished_monotonic"]
                 and state["last_finished_unix"] == previous["finished_unix"], "PACING_DURABLE_LAST_FINISH")
        if calls is not None:
            physical = {cid for cid,c in calls.items() if c["dispatched"]}
            need(physical <= set(ids), "PACING_EVERY_DISPATCH_SCHEDULED")
        return dict(passed=not errors, errors=sorted(set(errors)), scheduled_calls=len(events),
            finished_calls=sum(e["status"]=="finished" for e in events),
            waited_seconds=sum(e["waited_seconds"] for e in events),
            hard_stop_reason=state["hard_stop_reason"], clock_kind=cfg["clock_kind"])
    except (KeyError,IndexError,TypeError,ValueError,OverflowError) as exc:
        return dict(passed=False,errors=sorted(set(errors+["MALFORMED_PACING:"+type(exc).__name__])))


def load(directory):
    data = legacy_load(directory)
    data["pacing"] = json.loads((Path(directory)/"pacing.json").read_text())
    return data


def check_loaded(data, frozen=None):
    checked = legacy_check_loaded(data, frozen)
    errors = list(checked["errors"])
    try:
        calls = {c["call_id"]:c for c in data["campaign"]["calls"]}
        paced = check_pacing_snapshot(data["pacing"],frozen=frozen,calls=calls,partial=True)
        errors += paced["errors"]
        report,row,ctl = data["report"],data["case"]["row"],data["snapshot"]["v2_control"]
        if not (report["dispatch_pacing_enabled"] is True
                and report["original_slot_id"] == row["original_slot_id"]
                and report["continuation_slot_id"] == row["continuation_slot_id"]
                and report["continuation_run_id"] == row["continuation_run_id"]
                and abs(report["pacing_wait_seconds"]-paced["waited_seconds"]) <= .000001):
            errors.append("BRANCH_PACING_EXPORT")
        for event in data["pacing"]["events"]:
            if event["slot_id"] != row["slot_id"] or event["batch_id"] != row["batch_id"]:
                errors.append("PACING_ROW_IDENTITY")
            if event["deadline_unix"] > ctl["deadline_unix"]+.01 or event["deadline_monotonic"] > ctl["deadline_monotonic"]+.01:
                errors.append("PACING_WITHIN_FLOW_DEADLINE")
    except (KeyError,IndexError,TypeError,ValueError) as exc:
        errors.append("MALFORMED_BRANCH_PACING:"+type(exc).__name__)
    checked.update(schema_version="safety-reliability-continuation-v2-independent-check",passed=not errors,errors=sorted(set(errors)))
    return checked


def check_run(directory, frozen=None):
    try:
        return check_loaded(load(directory),frozen)
    except (OSError,ValueError,sqlite3.DatabaseError,TypeError) as exc:
        return dict(schema_version="safety-reliability-continuation-v2-independent-check",passed=False,
                    errors=["UNREADABLE_EVIDENCE:"+type(exc).__name__],metrics={})


def check_pacing_prefix(saved, current):
    """A completed batch checkpoint must remain an exact scheduler prefix."""
    errors = []
    try:
        n = len(saved["events"])
        if saved["config"] != current["config"] or saved["events"] != current["events"][:n]:
            errors.append("PACING_BATCH_PREFIX_CHANGED")
        if n > len(current["events"]):
            errors.append("PACING_PRIOR_EVENTS_MISSING")
        if saved["state"]["pending_call_id"] is not None:
            errors.append("PACING_PRIOR_PENDING_INTENT")
        terminal = [e for e in saved["events"] if e["status"] == "finished"]
        if terminal and any(saved["state"]["last_finished_"+k] != terminal[-1]["finished_"+k] for k in ("monotonic","unix")):
            errors.append("PACING_PRIOR_LAST_FINISH")
        if saved["state"]["hard_stop_reason"] is not None and current["events"][n:]:
            errors.append("PACING_EVENTS_AFTER_PRIOR_STOP")
        if n == len(current["events"]) and saved["state"] != current["state"]:
            errors.append("PACING_LATEST_STATE_CHANGED")
    except (KeyError,TypeError,ValueError,IndexError) as exc:
        errors.append("MALFORMED_PACING_PREFIX:"+type(exc).__name__)
    return sorted(set(errors))


def check_pacing(output, frozen=None):
    output = Path(output).resolve()
    try:
        sql = readonly_tables(output/"pacing.sqlite")
        snapshot = dict(schema_version="continuation-pacing-v1",config=json.loads(sql["config"][0]["body"]),
            state=json.loads(sql["state"][0]["body"]),events=[json.loads(r["body"]) for r in sql["events"]])
        calls, branches, duplicate_ids = {}, {}, []
        for path in sorted((output/"batches").glob("*/*/ledger.sqlite")):
            db=readonly_tables(path)
            current=[json.loads(v["body"]) for v in db["p3_calls"]]
            duplicate_ids += [v["call_id"] for v in current if v["call_id"] in calls]
            calls.update({v["call_id"]:v for v in current})
            branches[path.parent.name]=path.parent
        checked=check_pacing_snapshot(snapshot,frozen=frozen,calls=calls)
        errors=list(checked["errors"])
        if duplicate_ids:
            errors.append("PACING_DUPLICATE_PHYSICAL_IDENTITIES")
        for raw,event in zip(sql["events"],snapshot["events"]):
            if raw["seq"] != event["sequence"] or raw["call_id"] != event["call_id"]:
                errors.append("PACING_SQL_EVENT_IDENTITY")
        for sid,path in branches.items():
            proof=json.loads((path/"pacing.json").read_text())
            expected=[v for v in snapshot["events"] if v["slot_id"]==sid]
            if proof["events"] != expected or proof["config"] != snapshot["config"]:
                errors.append("PACING_BRANCH_SQL_EXPORT")
        for path in sorted((output/"batches").glob("*/pacing.json")):
            proof=json.loads(path.read_text())
            errors += check_pacing_prefix(proof,snapshot)
            subset={e["call_id"]:calls[e["call_id"]] for e in proof["events"] if e["call_id"] in calls}
            errors += check_pacing_snapshot(proof,frozen=frozen,calls=subset)["errors"]
        checked.update(passed=not errors,errors=sorted(set(errors)))
        return checked
    except (OSError,KeyError,IndexError,TypeError,ValueError,sqlite3.DatabaseError) as exc:
        return dict(passed=False,errors=["UNREADABLE_PACING:"+type(exc).__name__])


def historical_evidence(root=None):
    """Derive old rows/costs directly, including the dispatched 429 failure."""
    root = Path(root or ROOT).resolve()
    saved = root / SAVED
    parent = json.loads((saved / "protocol/frozen.json").read_text())
    authority = readonly_tables(saved / "authority.sqlite")
    entries = [json.loads(v["body"]) for v in authority["batches"]]
    checkpoints = [json.loads(v["body"]) for v in authority["checkpoints"]]
    errors = ["PARENT_" + e for e in check_expansion_frozen(parent, root)]
    def need(ok, code):
        if not ok:
            errors.append(code)
    need(json.loads(authority["config"][0]["body"]) == parent, "HISTORY_AUTHORITY_CONFIG")
    need([v["batch_id"] for v in entries] == ["B02", "B03", "B04"]
         and [v["status"] for v in entries] == ["completed", "completed", "halted"], "HISTORY_HALTED_PREFIX")
    need(len(checkpoints) == 2 and len(authority["stop"]) == 1
         and authority["stop"][0]["reason"] == "BUDGET_OR_SETTLEMENT_FENCED", "HISTORY_429_STOP_PRESERVED")
    calls, excluded, batch_totals = [], [], {}
    fields = ("call_id", "status", "provider_request_id", "dispatched", "known_cost_nano_usd",
              "held_cost_nano_usd", "reserved_cost_nano_usd", "usage")
    for i, record in enumerate(entries):
        bid = record["batch_id"]
        saved_check = json.loads((saved / "checks" / (bid + ".json")).read_text())
        recomputed = check_expansion_batch(saved, bid)
        need(recomputed == saved_check and recomputed["passed"], "HISTORY_INDEPENDENT_BATCH_CHECK")
        need(record["check_digest"] == h(saved_check), "HISTORY_CHECK_DIGEST")
        predecessor = checkpoints[i-1] if i else parent["history"]
        need(record["predecessor_digest"] == h(predecessor), "HISTORY_PREDECESSOR")
        if i < 2:
            cp = checkpoints[i]
            need(cp["batch_record_digest"] == h(record) and cp["predecessor_digest"] == h(predecessor)
                 and cp["ordinal"] == i+1, "HISTORY_CHECKPOINT_CHAIN")
        raw = []
        batch = next(v for v in parent["registration"]["batches"] if v["batch_id"] == bid)
        slots = record["completed_slots"]
        need(slots == batch["slots"][:len(slots)], "HISTORY_REGISTERED_PREFIX")
        for sid in slots:
            path = saved / "batches" / bid / sid / "ledger.sqlite"
            need(byte_hash(path.read_bytes()) == record["ledger_hashes"][str(path.relative_to(saved))], "HISTORY_LEDGER_PIN")
            db = readonly_tables(path)
            need(json.loads(db["p3_campaign"][0]["config"])["binding"] == parent["binding"], "HISTORY_REAL_BINDING")
            part = [json.loads(r["body"]) for r in db["p3_calls"]]
            for c in part:
                need(c["simulated"] is False and c["dispatched"] is True, "HISTORY_REAL_DISPATCH")
                if c["status"] == "settled":
                    u = c["usage"]
                    need(c["known_cost_nano_usd"] == u["prompt_tokens"]*150+u["completion_tokens"]*500
                         and c["held_cost_nano_usd"] == 0, "HISTORY_RAW_USAGE_COST")
                    receipts = [r for r in db["p3_receipts"] if r["call_id"] == c["call_id"]]
                    need(len(receipts) == 1 and json.loads(receipts[0]["normalized_usage"]) == u
                         and receipts[0]["provider_request_id"] == c["provider_request_id"], "HISTORY_RAW_RECEIPT")
                else:
                    trace = c["evidence"]["http_trace"]
                    need(c["held_cost_nano_usd"] == c["reserved_cost_nano_usd"] == 984000
                         and c["known_cost_nano_usd"] == 0 and c["usage"] is None
                         and trace["status"] == 429, "HISTORY_429_UNKNOWN_NOT_RELEASED")
                raw.append(c)
        ids = [c["call_id"] for c in raw]
        providers = [c["provider_request_id"] for c in raw if c["status"] == "settled"]
        known = sum(c["known_cost_nano_usd"] for c in raw)
        held = sum(c["held_cost_nano_usd"] for c in raw)
        need(ids == record["call_ids"] == saved_check["call_ids"] and providers == record["provider_request_ids"], "HISTORY_RAW_IDENTITIES")
        need((known, held) == (record["known_nano"], record["held_nano"])
             == (saved_check["known_nano"], saved_check["held_nano"]), "HISTORY_RAW_TOTALS")
        batch_totals[bid] = dict(known_nano=known, held_nano=held, total_nano=known+held, generation_calls=len(raw))
        excluded += slots
        calls += [{k:c.get(k) for k in fields} for c in raw]
    need(len(calls) == 101 and len(excluded) == 22
         and sum(c["known_cost_nano_usd"] for c in calls) == 5795650
         and sum(c["held_cost_nano_usd"] for c in calls) == 984000
         and sum(c["status"] != "settled" for c in calls) == 1, "HISTORY_101_CALLS_ONE_UNKNOWN")
    unstarted = [r for r in parent["registration"]["rows"] if r["slot_id"] not in set(excluded)]
    need(len(unstarted) == 18 and unstarted[0]["ordinal"] == 23, "HISTORY_EXACT_UNSTARTED_18")
    return dict(parent=parent, entries=entries, checkpoints=checkpoints, calls=calls, excluded=excluded,
                unstarted=unstarted, batch_totals=batch_totals, errors=sorted(set(errors)))


def check_frozen(frozen, root=None):
    errors = []
    def need(ok, code):
        if not ok:
            errors.append(code)
    root = Path(root or ROOT).resolve()
    try:
        reg, history = frozen["registration"], frozen["history"]
        historical = historical_evidence(root)
        errors += historical["errors"]
        parent = historical["parent"]
        need(frozen["study_id"] == reg["study_id"] == "safety-reliability-v2-continuation", "STUDY_ID")
        need(frozen["mode"] in ("fake-http", "live") and frozen["live_authorized_by_preparation"] is False, "PREPARATION_NOT_AUTHORIZATION")
        need(frozen["pacing_policy"] == PACING_POLICY, "FROZEN_PACING_POLICY")
        need(reg["limits"] == CONTINUATION_LIMITS and reg["future_batches_authorized"] is False, "FROZEN_CAPS")
        rows, batches = reg["rows"], reg["batches"]
        need(len(rows) == 18 and len(batches) == 3 and len({r["slot_id"] for r in rows}) == 18, "REGISTRATION_SIZE")
        need([r["ordinal"] for r in rows] == list(range(1,19)), "REGISTRATION_ORDER")
        need([b["batch_id"] for b in batches] == ["B04","B05","B06"]
             and [b["call_cap"] for b in batches] == [16,64,64]
             and sum(r["call_cap"] for r in rows) == 144, "EIGHTEEN_SLOTS_144_CALLS")
        need([r["slot_id"] for r in rows] == [r["slot_id"] for r in historical["unstarted"]]
             and not set(r["slot_id"] for r in rows).intersection(historical["excluded"]), "NO_RECORDED_ROW_RESTART")
        for row, original in zip(rows, historical["unstarted"]):
            need(all(row[k] == v for k,v in original.items() if k != "ordinal"), "ORIGINAL_ROW_CONTENT_UNCHANGED")
            need(row["original_slot_id"] == original["slot_id"] and row["original_ordinal"] == original["ordinal"]
                 and row["continuation_slot_id"] == "safety-reliability-v2-continuation:"+original["slot_id"]
                 and bool(row["continuation_run_id"]), "SEPARATE_CONTINUATION_IDENTITY")
        need(len({r["continuation_slot_id"] for r in rows}) == 18
             and len({r["continuation_run_id"] for r in rows}) == 1, "CONTINUATION_ID_UNIQUENESS")
        for batch in batches:
            part = [r for r in rows if r["batch_id"] == batch["batch_id"]]
            need(batch["slots"] == [r["slot_id"] for r in part]
                 and batch["worst_reservation_nano"] == batch["call_cap"]*984000
                 and batch["call_cap"] == sum(r["call_cap"] for r in part), "BATCH_REGISTRATION")
        need(frozen["prompts"] == parent["prompts"] and frozen["prompt_specs"] == parent["prompt_specs"], "PRIOR_PROMPTS_UNCHANGED")
        need((history["generation_calls"],history["known_nano"],history["held_nano"],history["total_nano"])
             == (2401,175247450,3252000,178499450), "LATEST_2401_HISTORY_TOTAL")
        need((history["prior_v2_known_nano"],history["prior_v2_held_nano"],history["prior_v2_total_nano"])
             == (8749500,984000,9733500), "V2_HISTORY_HOLD_NOT_RESET")
        need((history["prior_safety_known_nano"],history["prior_safety_held_nano"],history["prior_safety_total_nano"])
             == (25350000,984000,26334000), "COMBINED_SAFETY_HISTORY")
        for bid in ("B04","B05","B06"):
            expected = historical["batch_totals"].get(bid,dict(known_nano=0,held_nano=0,total_nano=0,generation_calls=0))
            need(history["prior_batch_totals"][bid] == expected, "ORIGINAL_BATCH_BUDGET_CARRY")
        ids = parent["history"]["exposed_historical_call_ids"]+[c["call_id"] for c in historical["calls"]]
        providers = parent["history"]["exposed_historical_provider_ids"]+[c["provider_request_id"] for c in historical["calls"] if c["status"] == "settled"]
        need(history["exposed_historical_call_ids"] == ids and len(set(ids)) == len(ids) == 796
             and history["explicit_id_coverage"] == 796 and history["opaque_aggregate_calls"] == 1605, "HISTORY_FULL_ID_COVERAGE")
        need(history["exposed_historical_provider_ids"] == providers and len(providers) == len(set(providers)), "HISTORY_PROVIDER_ID_COVERAGE")
        need(history["parent_digest"] == h(parent["history"])
             and history["inherited_expansion_frozen_digest"] == h(parent), "HISTORY_PARENT_DIGEST")
        need(history["inherited_expansion_calls"] == historical["calls"]
             and history["inherited_expansion_batch_records"] == historical["entries"]
             and history["inherited_expansion_checkpoints"] == historical["checkpoints"], "HISTORY_RAW_EXPORTS")
        need(history["inherited_started_slot_ids"] == historical["excluded"]
             and history["unstarted_slot_ids"] == [r["slot_id"] for r in historical["unstarted"]], "HISTORY_STARTED_UNSTARTED_PARTITION")
        unknown = [c for c in historical["calls"] if c["status"] != "settled"]
        need(history["historical_429_call_id"] == unknown[0]["call_id"]
             and history["historical_429_hold_nano"] == 984000
             and history["inherited_expansion_stop_reason"] == "BUDGET_OR_SETTLEMENT_FENCED", "HISTORY_EXPLICIT_429")
        need((history["original_expansion_call_cap"],history["original_expansion_dispatched_calls"],history["original_expansion_remaining_call_cap"])
             == (296,101,195) and reg["original_generation_call_cap"] == 296
             and reg["original_generation_calls_already_dispatched"] == 101
             and reg["original_remaining_call_cap"] == 195, "ORIGINAL_CALL_CAP_NOT_RESET")
        need(reg["original_registration_digest"] == h(parent["registration"]), "ORIGINAL_REGISTRATION_PIN")
        saved = root / SAVED
        expected_paths = {str(p.relative_to(root)) for d in (saved/"protocol",saved/"checks",saved/"batches")
                          for p in d.rglob("*") if p.is_file() and p.name != "advance.lock"}
        expected_paths |= {str(p.relative_to(root)) for p in (saved/"controller").rglob("watchdog.json") if p.is_file()}
        expected_paths.add(str(SAVED/"authority.sqlite"))
        expected_paths |= set(parent["history"]["source_files"])
        need(set(history["source_files"]) == expected_paths, "HISTORY_COMPLETE_PIN_SET")
        required_code = set(parent["code_hashes"])
        required_code |= {str(p.relative_to(root)) for p in (root/"src/safety_reliability_continuation_v2").glob("*.py")}
        required_code |= {str(p.relative_to(root)) for p in (root/"scripts").glob("*safety_reliability_continuation_v2*.py")}
        need(set(frozen["code_hashes"]) == required_code, "CONTINUATION_CODE_PIN_SET")
        need(reg["historical_failed_rows_preserved"] is True and reg["original_registry_modified"] is False
             and reg["input_allowance_is_calibrated"] is False
             and reg["independent_heldout_generalization_claim"] is False, "REGISTRATION_SCOPE_BOUNDARY")
        binding = frozen["binding"]
        fake = frozen["mode"] == "fake-http"
        need(binding["binding_ref"] == "safety-reliability-v2-continuation/"+frozen["mode"]
             and binding["simulated"] == fake and binding["real_requests_authorized"] == (not fake)
             and binding["endpoint"] == "https://tritonai-api.ucsd.edu/v1"
             and binding["model"] == ("fixture-glm-5.3-flash" if fake else "api-glm-5.3-flash")
             and (binding["max_input_tokens"],binding["max_output_tokens"],binding["timeout_s"],binding["input_nano_usd_per_token"],binding["output_nano_usd_per_token"])
             == (4000,768,120,150,500) and binding["reasoning_effort"] == "low", "BINDING_SCOPE_PRICE_AND_LIMITS")
        need(history["provider_account_debit_verified"] is False and history["native_historical_databases_mutated"] is False, "HISTORY_CLAIM_BOUNDARY")
        for relative, sha in {**history["source_files"], **frozen["code_hashes"]}.items():
            path = (root / relative).resolve()
            need(path.is_relative_to(root) and path.is_file() and byte_hash(path.read_bytes()) == sha, "FROZEN_SOURCE_PIN")
    except (KeyError,IndexError,TypeError,ValueError,OSError,sqlite3.DatabaseError,StopIteration) as exc:
        errors.append("MALFORMED_FROZEN:"+type(exc).__name__)
    return sorted(set(errors))


def check_batch(output, batch_id="B04"):
    errors, metrics, ids, providers, slots = [], [], [], [], []
    known = held = dispatched = real = 0
    halt = None
    def need(value, code):
        if not value:
            errors.append(code)
    try:
        output = Path(output).resolve()
        frozen = json.loads((output/"protocol/frozen.json").read_text())
        errors += check_frozen(frozen)
        need(json.loads((output/"protocol/registration.json").read_text()) == frozen["registration"]
             and json.loads((output/"protocol/history.json").read_text()) == frozen["history"], "PROTOCOL_EXPORTS")
        batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
        rows = {r["slot_id"]:r for r in frozen["registration"]["rows"]}
        dest = output/"batches"/batch_id
        report, clock = (json.loads((dest/name).read_text()) for name in ("report.json", "clock.json"))
        need(clock["deadline_unix"]-clock["created_unix"] <= 1800.000001
             and clock["deadline_monotonic"]-clock["created_monotonic"] <= 1800.000001, "BATCH_FIXED_DEADLINE")
        dirs = {v.name for v in dest.iterdir() if v.is_dir()}
        need(dirs <= set(batch["slots"]), "UNREGISTERED_BRANCH")
        for sid in batch["slots"]:
            if not (dest/sid).exists():
                break
            need(halt is None, "NO_ROWS_AFTER_HARD_STOP")
            data = load(dest/sid)
            checked = check_loaded(data, frozen=frozen)
            metrics.append(checked)
            need(checked["passed"], "BRANCH_CHECK:"+sid+":"+",".join(checked["errors"]))
            slots.append(sid)
            need(data["case"]["fixture_id"] == sid, "SLOT_DIRECTORY")
            need(data["snapshot"]["v2_control"]["deadline_unix"] <= clock["deadline_unix"]+.05, "FLOW_WITHIN_BATCH_DEADLINE")
            calls = data["campaign"]["calls"]
            ids += [c["call_id"] for c in calls]
            providers += [c["provider_request_id"] for c in calls if c["status"] == "settled"]
            known += sum(c["known_cost_nano_usd"] for c in calls)
            held += sum(c["held_cost_nano_usd"] for c in calls)
            dispatched += sum(c["dispatched"] for c in calls)
            real += data["report"]["real_api_requests"]
            halt = halt or branch_halt(data, checked)
            saved = dest/(sid+".check.json")
            need(saved.exists() and json.loads(saved.read_text()) == checked, "SAVED_BRANCH_CHECK")
        need(dirs == set(slots) and slots == batch["slots"][:len(slots)], "REGISTERED_PREFIX")
        if halt is None and slots != batch["slots"]:
            # An exhausted deadline can precede the first branch; accept only
            # evidence that the controller really stopped at that fixed bound.
            if report["hard_stop_reason"] == "BATCH_DEADLINE" and (
                    report.get("finished_unix",0) >= clock["deadline_unix"]
                    or report.get("finished_monotonic",0) >= clock["deadline_monotonic"]):
                halt = "BATCH_DEADLINE"
            else:
                need(False, "PARTIAL_BATCH_WITHOUT_STOP")
        need(report["slot_ids"] == slots and report["checks"] == metrics and report["hard_stop_reason"] == halt,
             "BATCH_REPORT_RECONCILIATION")
        need(report["automatic_retries"] == 0 and report["simulated"] == (frozen["mode"] == "fake-http")
             and report["real_api_requests"] == real, "BATCH_MODE")
        repairs = [check["metrics"] for sid, check in zip(slots, metrics) if rows[sid]["repair_enabled"] and check["passed"]]
        expansion = None
        if batch_id in ("B02","B03") and len(repairs) == 4 and not any(v["completed"] for v in repairs):
            expansion = "NO_REPAIR_ARM_COMPLETION"
        elif batch_id in ("B04","B05","B06"):
            by_scene = {}
            for sid, checked in zip(slots,metrics):
                by_scene.setdefault(rows[sid]["scenario"], []).append(checked.get("metrics",{}))
            for scene in ("S02","S03","S05","S07"):
                group=by_scene.get(scene,[])
                if len(group)==2 and not any(v.get("target_reached") for v in group):
                    expansion="SCENARIO_TARGET_UNREACHED_BOTH_ARMS:"+scene
                    break
        need(report["expansion_stop_reason"] == expansion, "EXPANSION_STOP")
        history = frozen["history"]
        need(len(ids) == len(set(ids)) <= batch["call_cap"] and not set(ids).intersection(history["exposed_historical_call_ids"]), "CALL_ID_UNIQUENESS")
        need(len(providers) == len(set(providers)) and not set(providers).intersection(history["exposed_historical_provider_ids"]), "PROVIDER_ID_UNIQUENESS")
        need(known+held <= batch["worst_reservation_nano"] and frozen["history"]["prior_batch_totals"][batch_id]["total_nano"]+known+held <= 100_000_000, "ORIGINAL_BATCH_MONEY_CAP")
        need(not held or halt is not None, "UNKNOWN_HOLD_STOPS_BATCH")
        authority = readonly_tables(output/"authority.sqlite")
        need(json.loads(authority["config"][0]["body"]) == frozen, "AUTHORITY_CONFIG")
        entries = [json.loads(v["body"]) for v in authority["batches"]]
        checkpoints = [json.loads(v["body"]) for v in authority["checkpoints"]]
        registered = frozen["registration"]["batches"]
        need([v["batch_id"] for v in entries] == [v["batch_id"] for v in registered[:len(entries)]], "AUTHORITY_REGISTERED_PREFIX")
        record = next(v for v in entries if v["batch_id"] == batch_id)
        position = next(i for i,v in enumerate(entries) if v["batch_id"] == batch_id)
        previous = entries[:position]
        old_known = sum(v["known_nano"] for v in previous)
        old_held = sum(v["held_nano"] for v in previous)
        need(all(v["status"]=="completed" for v in previous), "NO_BATCH_AFTER_UNFINISHED_PREDECESSOR")
        need(len(checkpoints)>=position, "AUTHORITY_PREDECESSOR_CHECKPOINT")
        pred = checkpoints[position-1] if position else history
        for i,checkpoint in enumerate(checkpoints):
            er=entries[i]
            need(checkpoint["ordinal"]==i+1 and checkpoint["batch_id"]==er["batch_id"]
                 and checkpoint["batch_record_digest"]==h(er)
                 and checkpoint["predecessor_digest"]==er["predecessor_digest"]==h(checkpoints[i-1] if i else history), "CHECKPOINT_CHAIN")
        need(record["block_nano"] == batch["worst_reservation_nano"] and record["predecessor_digest"] == h(pred)
             and record["input_project_total_nano"] == history["total_nano"]+old_known+old_held
             and record["input_study_total_nano"] == history["prior_v2_total_nano"]+old_known+old_held
             and record["input_combined_safety_total_nano"] == history["prior_safety_total_nano"]+old_known+old_held, "AUTHORITY_LATEST_INHERITANCE")
        need(record["input_original_batch_total_nano"] == history["prior_batch_totals"][batch_id]["total_nano"], "ORIGINAL_BATCH_CARRY")
        previous_providers = []
        for earlier in previous:
            prior_calls = []
            for previous_slot in earlier["completed_slots"]:
                relative = str(Path("batches")/earlier["batch_id"]/previous_slot/"ledger.sqlite")
                expected_hash = earlier["ledger_hashes"][relative]
                path = (output/relative).resolve()
                need(path.is_relative_to(output) and byte_hash(path.read_bytes())==expected_hash,"PREVIOUS_LEDGER_PIN")
                prior_calls += [json.loads(v["body"]) for v in readonly_tables(path)["p3_calls"]]
            prior_ids=[v["call_id"] for v in prior_calls]
            prior_provider=[v["provider_request_id"] for v in prior_calls if v["status"]=="settled"]
            need(prior_ids==earlier["call_ids"] and prior_provider==earlier["provider_request_ids"],"PREVIOUS_RAW_IDENTITIES")
            need(sum(v["known_cost_nano_usd"] for v in prior_calls)==earlier["known_nano"]
                 and sum(v["held_cost_nano_usd"] for v in prior_calls)==earlier["held_nano"],"PREVIOUS_RAW_COST")
            previous_providers += prior_provider
        all_providers=history["exposed_historical_provider_ids"]+previous_providers+providers
        need(len(all_providers)==len(set(all_providers)),"CROSS_BATCH_PROVIDER_UNIQUENESS")
        all_ids = history["exposed_historical_call_ids"]+[cid for v in previous for cid in v.get("call_ids",[])]+ids
        need(len(all_ids)==len(set(all_ids)), "CROSS_BATCH_CALL_UNIQUENESS")
        need(len(all_ids)-len(history["exposed_historical_call_ids"]) <= 144, "GLOBAL_144_CALL_CAP")
        total_new=old_known+old_held+known+held
        need(history["prior_v2_total_nano"]+total_new<=300_000_000
             and history["total_nano"]+total_new<=5_000_000_000
             and history["prior_safety_total_nano"]+total_new<=600_000_000, "ALL_MONEY_CAPS")
        need(0 < record["deadline_unix"]-record["reserved_unix"] <= 1800.000001, "AUTHORITY_DEADLINE")
        need(clock["deadline_unix"] == record["deadline_unix"]
             and clock["deadline_monotonic"] == record["deadline_monotonic"]
             and clock["created_unix"] == record["reserved_unix"], "INHERITED_BATCH_DEADLINE")
        if record["status"] == "reserved":
            need(record["known_nano"] == 0 and record["held_nano"] == batch["worst_reservation_nano"], "FULL_PENDING_BLOCK_RETAINED")
        else:
            need(record["status"] == ("halted" if halt else "completed")
                 and (record["known_nano"], record["held_nano"]) == (known, held)
                 and record["completed_slots"] == slots and record["call_ids"] == ids
                 and record["provider_request_ids"] == providers, "FINALIZED_AUTHORITY")
            expected_hashes = {str((dest/sid/"ledger.sqlite").relative_to(output)):byte_hash((dest/sid/"ledger.sqlite").read_bytes()) for sid in slots}
            need(record["ledger_hashes"] == expected_hashes, "FINALIZED_LEDGER_PINS")
        watchdog_path = output/"controller"/batch_id/"watchdog.json"
        if watchdog_path.exists():
            watchdog = json.loads(watchdog_path.read_text())
            need(watchdog["process_group_gone"] is True, "WORKFLOW_PROCESS_GROUP_REAPED")
        pacing = check_pacing(output, frozen=frozen)
        errors += pacing["errors"]
    except (KeyError, IndexError, TypeError, ValueError, OSError, sqlite3.DatabaseError, StopIteration) as exc:
        errors.append("MALFORMED_BATCH:"+type(exc).__name__)
    return dict(schema_version="safety-reliability-continuation-v2-batch-check", passed=not errors,
        errors=sorted(set(errors)), batch_id=batch_id, slot_ids=slots, call_ids=ids, calls=len(ids),
        physical_dispatches=dispatched, known_nano=known, held_nano=held, hard_stop_reason=halt,
        real_api_requests=real, expansion_stop_reason=expansion if "expansion" in locals() else None, checks=metrics)


check = check_run
