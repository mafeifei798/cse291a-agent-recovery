"""Isolated, paced continuation; live execution is disabled by default."""
