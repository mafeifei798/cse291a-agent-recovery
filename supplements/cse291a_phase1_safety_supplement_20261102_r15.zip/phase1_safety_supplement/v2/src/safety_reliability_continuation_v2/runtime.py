"""A paced continuation of unstarted rows; the business workflow is unchanged.

All physical dispatches, including semantic repair calls, pass one campaign
scheduler. Waiting consumes the original request, flow and batch deadlines.
The previous expansion's 429 row is inherited evidence, never a retry target.
"""
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
import time

from agent_recovery.contracts import require
from agent_recovery.p3_transport import BoundTokenCounter, P3HTTPClient
from safety_reliability_expansion_v2.runtime import (
    Session as ExpansionSession, Client as ExpansionClient, fake_recipe,
)
from safety_reliability_live_v2.runtime import stop_from_branch
from .protocol import read, write, sha, LIMITS


class Client(ExpansionClient):
    """Use the existing HTTP implementation with a durable before-send gate."""
    def __init__(self, *args, session, scheduler, batch_clock=None, dispatch_guard=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.session, self.scheduler = session, scheduler
        self.batch_clock = batch_clock
        self.dispatch_guard = dispatch_guard

    def create(self, request, *, timeout_s, before_send=None, deadline_monotonic=None):
        now = time.monotonic()
        state = self.session.store.control()
        left = self.remaining()
        require(left > 0, "Fixed deadline expired", "V2_TOTAL_DEADLINE")
        # Reuse the gateway's original start, not a fresh deadline after pacing.
        deadline = min(deadline_monotonic or now + timeout_s,
                       now + left, state["deadline_monotonic"])
        wall_deadline = state["deadline_unix"]
        if self.batch_clock is not None:
            deadline = min(deadline, self.batch_clock["deadline_monotonic"])
            wall_deadline = min(wall_deadline, self.batch_clock["deadline_unix"])
        timeout = min(timeout_s, deadline - now)
        require(timeout > 0, "Fixed deadline expired", "V2_TOTAL_DEADLINE")
        reserved = [c for c in self.session.budget.calls() if c["status"] == "reserved"]
        require(len(reserved) == 1, "Exactly one new reservation is required", "CONTINUATION_CALL_RESERVATION")
        call = reserved[0]
        row = self.session.case["row"]

        admitted = []
        def paced_dispatch():
            self.scheduler.before_send(call_id=call["call_id"], batch_id=row["batch_id"],
                slot_id=row["slot_id"], deadline_monotonic=deadline,
                deadline_unix=min(wall_deadline, time.time() + max(0, deadline - time.monotonic())))
            admitted.append(True)
            if self.dispatch_guard is not None:
                self.dispatch_guard()
            # Durable intent remains immediately before bounded sender startup.
            if before_send is not None:
                before_send()

        if self.binding.simulated:
            step = json.loads(request["messages"][1]["content"])["step_id"]
            self.occurrences[step] = self.occurrences.get(step, 0) + 1
            self.sender._recipes.append(fake_recipe(request, self.occurrences[step], self.recipe or {}))
        try:
            return P3HTTPClient.create(self, request, timeout_s=timeout,
                                       before_send=paced_dispatch, deadline_monotonic=deadline)
        finally:
            if admitted:
                trace = self.traces[-1] if self.traces else {}
                self.scheduler.finish(call["call_id"], status_code=trace.get("status"),
                                      error_code=trace.get("error_code"))


class Session(ExpansionSession):
    """Keep the accepted injection, guard, verifier and one-repair semantics."""
    def __init__(self, directory, row, frozen, *, scheduler=None, batch_clock=None,
                 dispatch_guard=None, credential_provider=None, permit=None, recipe=None, flow_seconds=660):
        require(frozen["mode"] != "live" or callable(dispatch_guard),
                "Live dispatch must recheck admission after pacing", "CONTINUATION_DISPATCH_GUARD_REQUIRED")
        self.scheduler = scheduler
        self._owns_scheduler = scheduler is None
        super().__init__(directory, row, frozen, credential_provider=credential_provider,
                         permit=permit, recipe=recipe, flow_seconds=flow_seconds)
        try:
            if scheduler is None:
                # Directed fixtures can own a private paced ledger. Formal batch
                # execution always injects the campaign-wide persistent one.
                from .pacing import Scheduler
                scheduler = Scheduler(self.path.parent / (self.path.name + "-pacing.sqlite"), frozen)
                self.scheduler = scheduler
            counter = BoundTokenCounter(self.client.binding.token_admission_evidence, lambda request: 4000)
            self.client = Client(self.client.binding, self.sender, self.remaining,
                session=self, scheduler=scheduler, batch_clock=batch_clock, dispatch_guard=dispatch_guard,
                recipe=recipe, credential_provider=credential_provider,
                runtime_permit=permit, token_counter=counter)
            self.gateway.client = self.client
        except BaseException:
            self.close()
            raise

    def export(self):
        report = super().export()
        row = self.case["row"]
        proof = self.scheduler.snapshot(slot_id=row["slot_id"])
        report.update(continuation_run_id=row.get("continuation_run_id"),
                      original_slot_id=row.get("original_slot_id", row["slot_id"]),
                      continuation_slot_id=row.get("continuation_slot_id"),
                      dispatch_pacing_enabled=True,
                      pacing_wait_seconds=sum(e.get("waited_seconds", 0) for e in proof.get("events", [])))
        write(self.path / "pacing.json", proof)
        write(self.path / "report.json", report, replace=True)
        write(self.path / "artifacts.json", {p.name: dict(sha256=sha(p), bytes=p.stat().st_size)
            for p in sorted(self.path.iterdir()) if p.is_file() and p.name not in
            {"advance.lock", "artifacts.json", "pacing.sqlite-wal", "pacing.sqlite-shm"}}, replace=True)
        return report

    def close(self):
        try:
            super().close()
        finally:
            if self._owns_scheduler and self.scheduler is not None:
                self.scheduler.close()
                self.scheduler = None


def run_batch(output, batch_id, *, credential_provider=None, permit=None, fixture_recipe=None, dispatch_guard=None):
    from .checker import check_run
    from .pacing import Scheduler
    output = Path(output).resolve()
    frozen = read(output / "protocol/frozen.json")
    require(frozen["mode"] == "fake-http" or fixture_recipe is None,
            "Live run cannot receive a fixture recipe", "V2_LIVE_FIXTURE")
    batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
    dest = output / "batches" / batch_id
    dest.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    with sqlite3.connect((output / "authority.sqlite").as_uri() + "?mode=ro&immutable=1", uri=True) as con:
        saved = con.execute("SELECT body FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
        require(saved is not None, "Batch reservation missing", "V2_BATCH_NOT_RESERVED")
        reservation = json.loads(saved[0])
        require(reservation["status"] == "reserved" and not con.execute("SELECT 1 FROM stop").fetchone(),
                "Batch requires a live reservation", "V2_BATCH_NOT_RESERVED")
        require(reservation["block_nano"] == batch["call_cap"] * LIMITS["call_reservation_nano"],
                "Batch reservation differs from registered call cap", "CONTINUATION_BATCH_CAP")
    clock = dict(created_monotonic=reservation["deadline_monotonic"] - LIMITS["batch_seconds"],
        created_unix=reservation["reserved_unix"], deadline_monotonic=reservation["deadline_monotonic"],
        deadline_unix=reservation["deadline_unix"])
    write(dest / "clock.json", clock)
    rows = {r["slot_id"]: r for r in frozen["registration"]["rows"]}
    checks, reports, halt = [], [], None
    with Scheduler(output / "pacing.sqlite", frozen) as scheduler:
        for sid in batch["slots"]:
            left = min(clock["deadline_monotonic"] - time.monotonic(), clock["deadline_unix"] - time.time())
            if left <= 0:
                halt = "BATCH_DEADLINE"; break
            row = rows[sid]
            recipe = None
            if frozen["mode"] == "fake-http":
                conf = fixture_recipe or {}
                recipe = conf.get("rows", {}).get(sid, conf.get("arms", {}).get(row["arm"], conf.get("default", {})))
            with Session(dest / sid, row, frozen, credential_provider=credential_provider, permit=permit,
                         scheduler=scheduler, batch_clock=clock, recipe=recipe, dispatch_guard=dispatch_guard,
                         flow_seconds=min(LIMITS["flow_seconds"], left)) as branch:
                branch.run(); report = branch.export(); ledger = branch.budget.snapshot()
            checked = check_run(dest / sid, frozen)
            checks.append(checked); reports.append(report)
            write(dest / (sid + ".check.json"), checked)
            halt = stop_from_branch(report, ledger, checked)
            if halt:
                scheduler.halt(halt)
                break
        write(dest / "pacing.json", scheduler.snapshot())
    quality = None
    for scenario in ("S02", "S03", "S05", "S07"):
        pair = [r for r in reports if r["scenario"] == scenario]
        if len(pair) == 2 and all(not r["scenario_target_reached"] for r in pair):
            quality = "SCENARIO_TARGET_UNREACHED_BOTH_ARMS:" + scenario
            break
    report = dict(batch_id=batch_id, slot_ids=[r["fixture_id"] for r in reports], checks=checks,
        hard_stop_reason=halt, expansion_stop_reason=quality, elapsed_s=time.monotonic() - start,
        simulated=frozen["mode"] == "fake-http", finished_unix=time.time(), finished_monotonic=time.monotonic(),
        continuation=True, original_batch_id=batch_id,
        real_api_requests=sum(r["real_api_requests"] for r in reports), automatic_retries=0)
    write(dest / "report.json", report)
    return report
