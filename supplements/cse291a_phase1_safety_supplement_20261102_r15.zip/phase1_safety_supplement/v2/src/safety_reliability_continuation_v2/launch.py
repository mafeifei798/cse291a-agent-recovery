"""Explicit, independently reserved B04–B06 continuation launcher for live v2.

The public entry defaults to file preparation or socket-free HTTP fixtures.
Live execution requires a separate scoped grant and a pinned DataHub target.
The credential is read only after reservation and travels by anonymous stdin.
"""
from __future__ import annotations

import argparse
from contextlib import closing
import fcntl
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sqlite3
import sys
import threading
import time

from .budget import Authority, campaign_lock
from .protocol import ROOT, LIMITS, digest, prepare, read, validate_grant, write


class LaunchStopped(RuntimeError):
    """A fixed launcher code; arbitrary upstream exception text is never printed."""


def _load_frozen(output, mode=None):
    output = Path(output).resolve()
    frozen = read(output / "protocol/frozen.json")
    if mode is not None and frozen["mode"] != mode:
        raise LaunchStopped("MODE_MISMATCH")
    # Recompute source pins and read-only historical ledger reconciliation.
    return prepare(output, frozen["mode"], frozen.get("target_execution"))


def check_environment(frozen, output, grant, *, batch_id=None, environ=None, system=None):
    """Scope checks are not cryptographic resource attestation."""
    validate_grant(frozen, output, grant, time.time(), batch_id=batch_id)
    target = frozen["target_execution"]
    env = os.environ if environ is None else environ
    if ((platform.system() if system is None else system) != "Linux"
            or target["deployment_root"] != str(ROOT.resolve())
            or env.get("JUPYTERHUB_USER") != target["hub_user"]
            or env.get("JUPYTERHUB_SERVICE_PREFIX") != target["service_prefix"]):
        raise LaunchStopped("DATAHUB_ENVIRONMENT_MISMATCH")
    return dict(system="Linux", target="DataHub CSE291A", cpu_limit=2,
                memory_gib=8, gpu_count=0, resource_profile_operator_confirmed=True,
                markers_are_scope_checks_not_resource_attestation=True,
                credential_values_read=0)


def runtime_info():
    expected = {}
    for line in (ROOT / "configs/safety_datahub/requirements.lock").read_text().splitlines():
        if line.strip():
            name, version = line.split("==", 1)
            expected[name] = version
    installed = {}
    for name in expected:
        try:
            installed[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            installed[name] = None
    return dict(dependencies=installed, dependencies_match=installed == expected,
                python_supported=sys.version_info >= (3, 10),
                sqlite_supported=sqlite3.sqlite_version_info >= (3, 37),
                credential_values_read=0, real_api_requests=0)


def require_runtime():
    info = runtime_info()
    if not all(info[name] for name in ("dependencies_match", "python_supported", "sqlite_supported")):
        raise LaunchStopped("TARGET_RUNTIME_NOT_READY")
    return info


def require_reservation(output, frozen, *, batch_id, worker=False):
    """Prevent both direct internal-worker use and credential reads without admission."""
    output = Path(output).resolve()
    lock_path, authority_path = output / "campaign.lock", output / "authority.sqlite"
    if not lock_path.is_file() or not authority_path.is_file():
        raise LaunchStopped("OWNED_RESERVATION_REQUIRED")
    owner = os.getppid() if worker else os.getpid()
    if read(lock_path).get("pid") != owner:
        raise LaunchStopped("OWNED_RESERVATION_REQUIRED")
    with lock_path.open("r+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            fcntl.flock(lock, fcntl.LOCK_UN)
            raise LaunchStopped("ACTIVE_PARENT_LOCK_REQUIRED")
    with closing(sqlite3.connect(authority_path.as_uri() + "?mode=ro", uri=True)) as con:
        config = json.loads(con.execute("SELECT body FROM config WHERE singleton=1").fetchone()[0])
        rows = [json.loads(row[0]) for row in con.execute("SELECT body FROM batches ORDER BY rowid")]
        if config != frozen or con.execute("SELECT 1 FROM stop").fetchone():
            raise LaunchStopped("RESERVATION_AUTHORITY_FENCED")
    batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
    pending = [r for r in rows if r["status"] == "reserved"]
    registered_order = [b["batch_id"] for b in frozen["registration"]["batches"]]
    expected_prior = registered_order[:registered_order.index(batch_id)]
    if (len(pending) != 1 or pending[0]["batch_id"] != batch_id
            or [r["batch_id"] for r in rows[:-1]] != expected_prior
            or any(r["status"] != "completed" for r in rows[:-1])):
        raise LaunchStopped("RESERVATION_SEQUENCE")
    row = pending[0]
    if (row["owner_pid"] != owner or row["block_nano"] != batch["worst_reservation_nano"]
            or row["held_nano"] != batch["worst_reservation_nano"] or row["known_nano"] != 0
            or time.time() >= row["deadline_unix"] or time.monotonic() >= row["deadline_monotonic"]):
        raise LaunchStopped("RESERVATION_SCOPE_OR_DEADLINE")
    return row


def read_credential(output, frozen, grant, *, batch_id, environ=None, system=None):
    check_environment(frozen, output, grant, batch_id=batch_id, environ=environ, system=system)
    require_reservation(output, frozen, batch_id=batch_id)
    from safety_real.credentials import pipe_bytes
    env = os.environ if environ is None else environ
    try:
        value = env.get("OPENAI_API_KEY")
        pipe_bytes(value)
    except Exception:
        raise LaunchStopped("DATAHUB_CREDENTIAL_UNAVAILABLE") from None
    return value


def _child_environment(frozen):
    env = dict(PATH="/usr/bin:/bin:/usr/sbin:/sbin", LANG="en_US.UTF-8",
               PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1",
               OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", CUDA_VISIBLE_DEVICES="")
    if frozen["mode"] == "live":
        target = frozen["target_execution"]
        env.update(JUPYTERHUB_USER=target["hub_user"],
                   JUPYTERHUB_SERVICE_PREFIX=target["service_prefix"])
    return env


def install_fake_fence(output):
    """No socket/key-file access; only the bounded transport may spawn a worker."""
    root = Path(output).resolve()
    state = dict(installed=True, sockets_allowed=False, credential_provider_installed=False, blocked=[])

    def audit(event, args):
        blocked = event.startswith("socket.") or event == "http.client.connect"
        if event in {"subprocess.Popen", "os.system", "os.fork", "os.posix_spawn"}:
            from agent_recovery.p3_deadline import spawn_allowed
            blocked = not spawn_allowed()
        if event == "open" and args and isinstance(args[0], (str, bytes)):
            path = Path(os.fsdecode(args[0])).resolve()
            blocked |= path.name.startswith(".env") or path.name in {"credentials", "credentials.json"}
            blocked |= any(part in path.parts for part in (".ssh", ".aws"))
            mode, flags = args[1:3]
            writing = isinstance(mode, str) and any(c in mode for c in "wax+")
            writing |= isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
            if writing and path != root and root not in path.parents:
                blocked = True
        if blocked:
            state["blocked"].append(event)
            raise LaunchStopped("FAKE_HTTP_EXTERNAL_EFFECT_DENIED")
    sys.addaudithook(audit)
    return state


def _rss_observation():
    """Current Linux process-tree RSS; a labeled peak proxy on local macOS."""
    import resource
    if platform.system() != "Linux":
        scale = 1 if sys.platform == "darwin" else 1024
        observed = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        return dict(bytes=int(observed * scale),
                    scope="workflow_peak_plus_completed_child_peak_proxy", observed_processes=1,
                    active_descendant_rss_included=False)
    pending, seen, total = [os.getpid()], set(), 0
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        seen.add(pid)
        if len(seen) > 64:
            raise LaunchStopped("RSS_PROCESS_TREE_LIMIT")
        base = Path("/proc") / str(pid)
        try:
            fields = dict(line.split(":", 1) for line in (base / "status").read_text().splitlines() if ":" in line)
            if "VmRSS" in fields:
                amount, unit = fields["VmRSS"].strip().split()
                if unit != "kB":
                    raise LaunchStopped("RSS_OBSERVATION_UNIT")
                process_bytes = int(amount) * 1024
                if pid == os.getpid():
                    process_bytes = max(process_bytes, int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024))
                total += process_bytes
            child_ids = (base / "task" / str(pid) / "children").read_text().split()
            pending.extend(int(value) for value in child_ids)
        except FileNotFoundError:
            # HTTP workers may exit between the parent's two /proc reads.
            if pid == os.getpid():
                raise
    return dict(bytes=total, scope="linux_workflow_and_active_descendants_current_rss",
                observed_processes=len(seen), active_descendant_rss_included=True)


class MemoryMonitor:
    """Continuous RSS evidence consumed by the outer process-group watchdog."""
    def __init__(self, directory, *, interval=.05, limit=None):
        self.directory = Path(directory)
        self.interval = interval
        self.limit = LIMITS["rss_bytes"] if limit is None else limit
        self.stop = threading.Event()
        self.thread = None
        self.started = time.monotonic()
        self.peak = 0
        self.samples = 0
        self.summary = None

    def __enter__(self):
        self.directory.mkdir(parents=True, exist_ok=False)
        self.stream = (self.directory / "rss_samples.jsonl").open("x", buffering=1)
        self._sample()
        self.thread = threading.Thread(target=self._loop, name="v2-memory-monitor", daemon=True)
        self.thread.start()
        return self

    def _sample(self):
        try:
            observation = _rss_observation()
            self.peak = max(self.peak, observation.pop("bytes"))
            sample = dict(peak_rss_bytes=self.peak, elapsed_s=time.monotonic()-self.started,
                          monitor_scope="batch-resource-monitor", sample_unix=time.time(), **observation)
        except Exception:
            self.peak = max(self.peak, self.limit+1)
            sample = dict(peak_rss_bytes=self.peak, elapsed_s=time.monotonic()-self.started,
                          monitor_scope="batch-resource-monitor", sample_unix=time.time(), observation_failed=True)
        self.stream.write(json.dumps(sample, sort_keys=True)+"\n")
        self.stream.flush()
        self.samples += 1

    def _loop(self):
        while not self.stop.wait(self.interval):
            try:
                self._sample()
            except BaseException:
                # A dead sampler must not leave a live worker without its cap.
                os._exit(74)

    def __exit__(self, *args):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=2)
            if self.thread.is_alive():
                os._exit(74)
        self._sample()
        self.stream.close()
        self.summary = dict(joined=True, interval_seconds=self.interval, samples=self.samples,
                            peak_rss_bytes=self.peak, scope="batch-resource-monitor",
                            branch_clock_checked_by_runtime=True)


def worker(output, *, batch_id, grant_path=None, recipe_path=None):
    """Internal subprocess. No API key lookup is performed here."""
    output = Path(output).resolve()
    frozen = _load_frozen(output)
    reservation = require_reservation(output, frozen, batch_id=batch_id, worker=True)
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (LIMITS["batch_seconds"], LIMITS["batch_seconds"]))
    if hasattr(os, "sched_setaffinity"):
        os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    permit, secret = None, []
    recipe = None
    if frozen["mode"] == "fake-http":
        if grant_path is not None:
            raise LaunchStopped("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
        if recipe_path is not None:
            recipe = read(recipe_path)
        fence = install_fake_fence(output)
    else:
        if grant_path is None or recipe_path is not None:
            raise LaunchStopped("LIVE_REQUIRES_GRANT_AND_NO_FIXTURE")
        grant = read(grant_path)
        check_environment(frozen, output, grant, batch_id=batch_id)
        require_runtime()
        from safety_real.credentials import consume_parent_pipe
        from agent_recovery.p3_transport import LiveRuntimePermit
        secret.append(consume_parent_pipe(sys.stdin.buffer))
        permit = LiveRuntimePermit(True, digest(frozen["binding"]), grant["authorization_reference"])
        fence = dict(installed=False, credential_received_via_anonymous_pipe=True,
                     worker_reads_key_environment=False, worker_reads_key_file=False)
    try:
        def provider():
            validate_grant(frozen, output, grant, time.time(), batch_id=batch_id)
            require_reservation(output, frozen, batch_id=batch_id, worker=True)
            return secret[0]
        def dispatch_guard():
            # No credential access here. A grant can expire or be disabled while
            # pacing sleeps; re-read it immediately before durable dispatch.
            from agent_recovery.contracts import ContractError
            try:
                current = read(grant_path)
                validate_grant(frozen, output, current, time.time(), batch_id=batch_id)
                require_reservation(output, frozen, batch_id=batch_id, worker=True)
            except Exception:
                raise ContractError("CONTINUATION_DISPATCH_AUTHORIZATION",
                                    "Dispatch admission expired or was withdrawn") from None
        from .runtime import run_batch
        with MemoryMonitor(output / f"controller/{batch_id}/resource") as monitor:
            report = run_batch(output, batch_id=batch_id, credential_provider=provider if secret else None,
                               permit=permit, fixture_recipe=recipe, dispatch_guard=dispatch_guard if secret else None)
        write(output / f"batches/{batch_id}/entry_receipt.json", dict(mode=frozen["mode"], offline_fence=fence,
              worker_key_environment_reads=0, credential_received_count=len(secret),
              reservation_deadline_unix=reservation["deadline_unix"], http_retries=0,
              resource_monitor=monitor.summary))
        return dict(batch_id=batch_id, worker_finished=True, mode=frozen["mode"])
    finally:
        secret.clear()


def _recipe(output, mode, recipe, batch_id):
    if recipe is None:
        return None
    if mode != "fake-http":
        raise LaunchStopped("LIVE_FIXTURES_FORBIDDEN")
    source = Path(recipe)
    if source.stat().st_size > 65536:
        raise LaunchStopped("FIXTURE_TOO_LARGE")
    value = read(source)
    if not isinstance(value, dict):
        raise LaunchStopped("FIXTURE_OBJECT_REQUIRED")
    path = Path(output) / f"protocol/fixture-{batch_id}.json"
    if path.exists():
        if read(path) != value:
            raise LaunchStopped("FIXTURE_CHANGED")
    else:
        write(path, value)
    return path


def run(output, *, mode, batch_id, grant=None, recipe=None, environ=None, system=None):
    """Run exactly one registered batch. Never redispatch an ambiguous attempt."""
    output = Path(output).resolve()
    frozen = _load_frozen(output, mode)
    if batch_id not in {b["batch_id"] for b in frozen["registration"]["batches"]}:
        raise LaunchStopped("UNREGISTERED_BATCH")
    if mode == "live":
        if grant is None:
            raise LaunchStopped("V2_LIVE_DISABLED")
        if recipe is not None:
            raise LaunchStopped("LIVE_FIXTURES_FORBIDDEN")
        grant = Path(grant).resolve()
        permission = read(grant)
        check_environment(frozen, output, permission, batch_id=batch_id, environ=environ, system=system)
        require_runtime()
    elif grant is not None:
        raise LaunchStopped("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
    with campaign_lock(output):
        with Authority(output, frozen) as authority:
            state = authority.snapshot()
            previous = next((b for b in state["batches"] if b["batch_id"] == batch_id), None)
            if previous and previous["status"] == "completed":
                from .checker import check_batch
                checked = check_batch(output, batch_id)
                if not checked["passed"]:
                    authority.halt("COMPLETED_BATCH_CHECK_FAILED")
                    raise LaunchStopped("COMPLETED_BATCH_CHECK_FAILED")
                return dict(state, reused_completed_batch=True, new_dispatches=0)
            if state["status"] == "hard_stopped":
                raise LaunchStopped("CAMPAIGN_HARD_STOPPED")
            if any(b["status"] == "reserved" for b in state["batches"]):
                raise LaunchStopped("PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
            completed = [record for record in state["batches"] if record["status"] == "completed"]
            if completed:
                # Never recreate a lost scheduler after a completed batch.
                # Admission must prove the prior global timing evidence before
                # reserving another block or reading the credential.
                if not (output / "pacing.sqlite").is_file():
                    authority.halt("PRIOR_PACING_EVIDENCE_MISSING")
                    write(output / "STATUS.json", authority.snapshot(), replace=True)
                    raise LaunchStopped("PRIOR_PACING_EVIDENCE_MISSING")
                from .checker import check_batch
                prior = check_batch(output, completed[-1]["batch_id"])
                if not prior["passed"]:
                    authority.halt("PRIOR_BATCH_OR_PACING_CHECK_FAILED")
                    write(output / "STATUS.json", authority.snapshot(), replace=True)
                    raise LaunchStopped("PRIOR_BATCH_OR_PACING_CHECK_FAILED")
            recipe_path = _recipe(output, mode, recipe, batch_id)
            batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
            reservation = authority.reserve_batch(batch)
            secret = []
            try:
                if mode == "live":
                    secret.append(read_credential(output, frozen, permission, batch_id=batch_id, environ=environ, system=system))
                command = [sys.executable, "-B", str(ROOT / "scripts/run_safety_reliability_continuation_v2.py"),
                           "_worker", "--output", str(output), "--batch", batch_id]
                if grant is not None:
                    command += ["--grant", str(grant)]
                if recipe_path is not None:
                    command += ["--recipe", str(recipe_path)]
                from safety_datahub.processes import supervise_command
                remaining = min(reservation["deadline_unix"] - time.time(),
                                reservation["deadline_monotonic"] - time.monotonic())
                if remaining <= 0:
                    raise LaunchStopped("BATCH_DEADLINE_EXPIRED")
                receipt = supervise_command(command, output / f"controller/{batch_id}", env=_child_environment(frozen),
                    key=secret[0] if secret else None, wall_seconds=remaining,
                    sample_root=output / f"controller/{batch_id}", flow_seconds=LIMITS["batch_seconds"],
                    rss_bytes=LIMITS["rss_bytes"])
            except BaseException:
                authority.halt("CREDENTIAL_OR_WORKER_LAUNCH_FAILED")
                write(output / "STATUS.json", authority.snapshot(), replace=True)
                raise
            finally:
                secret.clear()
            if receipt["exit_code"] != 0 or receipt["reason"] or not receipt["process_group_gone"]:
                # No independent proof of all dispatches: retain the entire reservation.
                authority.halt("WORKER_DEADLINE_OR_PROCESS_CLEANUP_FAILED")
            else:
                try:
                    from .checker import check_batch
                    checked = check_batch(output, batch_id)
                    write(output / f"checks/{batch_id}.json", checked)
                    if not checked["passed"]:
                        authority.halt("INDEPENDENT_CHECK_FAILED")
                    else:
                        ledger_paths = {sid: output / f"batches/{batch_id}" / sid / "ledger.sqlite"
                                        for sid in checked["slot_ids"]}
                        authority.finalize(batch, checked, ledger_paths)
                        if checked.get("expansion_stop_reason"):
                            # Keep the checked batch and checkpoint, but never
                            # turn a quality pause into permission for another batch.
                            authority.halt(checked["expansion_stop_reason"])
                except BaseException:
                    authority.halt("INDEPENDENT_CHECK_OR_FINALIZE_FAILED")
                    write(output / "STATUS.json", authority.snapshot(), replace=True)
                    raise
            state = authority.snapshot()
            write(output / "STATUS.json", state, replace=True)
            return state


def main(argv=None):
    parser = argparse.ArgumentParser(description="Independent v2 B04–B06 continuation entry; no automatic live authorization.")
    parser.add_argument("action", choices=("prepare", "run-fake", "run-live", "check", "runtime", "_worker"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--mode", choices=("fake-http", "live"), default="fake-http")
    parser.add_argument("--target", type=Path)
    parser.add_argument("--grant", type=Path)
    parser.add_argument("--recipe", type=Path)
    parser.add_argument("--batch", choices=("B04", "B05", "B06"))
    args = parser.parse_args(argv)
    try:
        if args.action == "runtime":
            result = runtime_info()
        else:
            if args.output is None:
                raise LaunchStopped("OUTPUT_REQUIRED")
            if args.action == "prepare":
                if args.grant is not None or args.recipe is not None:
                    raise LaunchStopped("PREPARE_IS_FILE_ONLY")
                frozen = prepare(args.output, args.mode, read(args.target) if args.target else None)
                result = dict(prepared=True, mode=frozen["mode"], rows=18, calls_cap=144,
                              live_authorized=False, credential_values_read=0, real_api_requests=0)
            elif args.action in {"run-fake", "run-live"}:
                result = run(args.output, mode="live" if args.action == "run-live" else "fake-http",
                             batch_id=args.batch, grant=args.grant, recipe=args.recipe)
            elif args.action == "check":
                from .checker import check_batch
                result = check_batch(args.output, args.batch)
            else:
                result = worker(args.output, batch_id=args.batch, grant_path=args.grant, recipe_path=args.recipe)
        print(json.dumps(result, sort_keys=True))
        return 2 if result.get("passed") is False or result.get("status") == "hard_stopped" else 0
    except Exception as exc:
        # Even synthetic credential-echo exceptions must not reach logs.
        code = str(exc) if type(exc) is LaunchStopped else "V2_ENTRY_REJECTED"
        print(json.dumps(dict(stopped=True, code=code, error_type=type(exc).__name__)), file=sys.stderr)
        return 2
