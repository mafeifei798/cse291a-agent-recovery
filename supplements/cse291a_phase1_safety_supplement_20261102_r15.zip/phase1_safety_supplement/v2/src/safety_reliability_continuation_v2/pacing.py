"""Durable, single-inflight pacing for the isolated continuation.

The two-second spacing is a conservative local policy, not an inferred promise
about the provider's rate-limit window. It applies after every call completes,
including repairs and batch transitions. A pending call or 429 never retries.
"""
from __future__ import annotations
from contextlib import contextmanager
import json
import math
from pathlib import Path
import sqlite3
import time as _time

from agent_recovery.contracts import ContractError
from .protocol import digest


POLICY = dict(min_interval_seconds=2.0, spacing_basis="previous_call_completion",
              automatic_retries=0, clock="wall_and_monotonic",
              pending_call_policy="hard_stop", rate_limit_policy="429_hard_stop_no_retry")


class SystemClock:
    monotonic = staticmethod(_time.monotonic)
    time = staticmethod(_time.time)
    sleep = staticmethod(_time.sleep)


class Scheduler:
    def __init__(self, path, frozen, *, clock=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if frozen.get("pacing_policy") != POLICY:
            raise ContractError("PACING_POLICY", "Pacing policy differs from frozen rules")
        if clock is not None and frozen.get("mode") != "fake-http":
            raise ContractError("PACING_LIVE_CLOCK", "Live execution requires the system clock")
        self.clock = clock or SystemClock()
        self.config = dict(policy=POLICY, frozen_digest=digest(frozen),
                           simulated=frozen.get("mode") == "fake-http",
                           clock_kind="injected_test_clock" if clock is not None else "system")
        self.con = sqlite3.connect(self.path, timeout=1, isolation_level=None)
        self.con.execute("PRAGMA synchronous=FULL")
        self.con.execute("CREATE TABLE IF NOT EXISTS config(id INTEGER PRIMARY KEY,body TEXT NOT NULL)")
        self.con.execute("CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY,body TEXT NOT NULL)")
        self.con.execute("CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY,call_id TEXT UNIQUE NOT NULL,body TEXT NOT NULL)")
        with self._tx():
            row = self.con.execute("SELECT body FROM config WHERE id=1").fetchone()
            if row is not None and json.loads(row[0]) != self.config:
                raise ContractError("PACING_CONFIG_CHANGED", "Existing scheduler binding differs")
            if row is None:
                self.con.execute("INSERT INTO config VALUES(1,?)", (json.dumps(self.config, sort_keys=True),))
                self._put_state(dict(last_observed_monotonic=None, last_observed_unix=None,
                    last_finished_monotonic=None, last_finished_unix=None,
                    pending_call_id=None, hard_stop_reason=None))

    @contextmanager
    def _tx(self):
        self.con.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.con.execute("COMMIT")
        except BaseException:
            self.con.execute("ROLLBACK")
            raise

    def _state(self):
        return json.loads(self.con.execute("SELECT body FROM state WHERE id=1").fetchone()[0])

    def _put_state(self, value):
        self.con.execute("INSERT OR REPLACE INTO state VALUES(1,?)", (json.dumps(value, sort_keys=True),))

    def _put_event(self, event):
        self.con.execute("INSERT OR REPLACE INTO events VALUES(?,?,?)",
                         (event["sequence"], event["call_id"], json.dumps(event, sort_keys=True)))

    def _observe(self, state):
        mono, wall = self.clock.monotonic(), self.clock.time()
        if not all(math.isfinite(x) for x in (mono, wall)):
            return mono, wall, "PACING_CLOCK_INVALID"
        # A reboot, backward wall-clock adjustment, or a corrupted prior clock
        # requires reconciliation; do not quietly create a fresh deadline.
        for value, key in ((mono, "last_observed_monotonic"), (wall, "last_observed_unix")):
            if state[key] is not None and value + 0.001 < state[key]:
                return mono, wall, "PACING_CLOCK_ROLLBACK"
        state.update(last_observed_monotonic=mono, last_observed_unix=wall)
        return mono, wall, None

    def before_send(self, *, call_id, batch_id, slot_id, deadline_monotonic, deadline_unix):
        error, event = None, None
        with self._tx():
            state = self._state()
            mono, wall, error = self._observe(state)
            if state["hard_stop_reason"]:
                error = "PACING_HARD_STOP"
            elif state["pending_call_id"]:
                error = "PACING_PENDING_REQUIRES_RECONCILIATION"
            elif self.con.execute("SELECT 1 FROM events WHERE call_id=?", (call_id,)).fetchone():
                error = "PACING_DUPLICATE_CALL"
            if not error and (not all(isinstance(x, (float, int)) and math.isfinite(x)
                                      for x in (deadline_monotonic, deadline_unix))):
                error = "PACING_INVALID_DEADLINE"
            if not error:
                gap = POLICY["min_interval_seconds"]
                ready_m = mono if state["last_finished_monotonic"] is None else state["last_finished_monotonic"] + gap
                ready_w = wall if state["last_finished_unix"] is None else state["last_finished_unix"] + gap
                event = dict(sequence=self.con.execute("SELECT COALESCE(MAX(seq),0)+1 FROM events").fetchone()[0],
                    call_id=call_id, batch_id=batch_id, slot_id=slot_id, status="waiting",
                    requested_monotonic=mono, requested_unix=wall,
                    deadline_monotonic=deadline_monotonic, deadline_unix=deadline_unix,
                    eligible_monotonic=ready_m, eligible_unix=ready_w, waited_seconds=0.0,
                    status_code=None, error_code=None)
                # The reservation of this admission is durable before sleeping.
                state["pending_call_id"] = call_id
                self._put_event(event)
            if error:
                state["hard_stop_reason"] = state["hard_stop_reason"] or error
            self._put_state(state)
        if error:
            raise ContractError(error, "Pacing admission refused; no HTTP dispatch")

        while True:
            with self._tx():
                state = self._state()
                mono, wall, error = self._observe(state)
                if state["hard_stop_reason"]:
                    error = "PACING_HARD_STOP"
                wait = max(0.0, event["eligible_monotonic"] - mono, event["eligible_unix"] - wall)
                left = min(deadline_monotonic - mono, deadline_unix - wall)
                if not error and (left <= 0 or wait >= left):
                    error = "PACING_FIXED_DEADLINE"
                event["waited_seconds"] = max(0.0, mono - event["requested_monotonic"])
                if error:
                    event.update(status="denied", error_code=error)
                    state.update(pending_call_id=None, hard_stop_reason=state["hard_stop_reason"] or error)
                elif wait <= 0:
                    event.update(status="admitted", admitted_monotonic=mono, admitted_unix=wall)
                self._put_event(event)
                self._put_state(state)
            if error:
                raise ContractError(error, "Pacing cannot fit within the original fixed deadline")
            if wait <= 0:
                return event
            # A fake clock can advance here for unit tests; live uses real sleep.
            self.clock.sleep(min(wait, 0.5))

    def finish(self, call_id, *, status_code=None, error_code=None):
        error = None
        with self._tx():
            state = self._state()
            row = self.con.execute("SELECT body FROM events WHERE call_id=?", (call_id,)).fetchone()
            if row is None or state["pending_call_id"] != call_id:
                raise ContractError("PACING_FINISH_IDENTITY", "No matching pending dispatch")
            event = json.loads(row[0])
            if event["status"] != "admitted":
                raise ContractError("PACING_FINISH_STATE", "Only admitted calls can finish")
            mono, wall, error = self._observe(state)
            event.update(status="finished", finished_monotonic=mono, finished_unix=wall,
                         status_code=status_code, error_code=error_code or error)
            state.update(pending_call_id=None, last_finished_monotonic=mono, last_finished_unix=wall)
            if status_code == 429 or error_code == "P3_HTTP_RATE_LIMIT":
                state["hard_stop_reason"] = "HTTP_429_NO_RETRY"
            elif error:
                state["hard_stop_reason"] = state["hard_stop_reason"] or error
            self._put_event(event)
            self._put_state(state)
        if error:
            raise ContractError(error, "Clock changed while an HTTP call was in flight")

    def halt(self, reason):
        with self._tx():
            state = self._state()
            state["hard_stop_reason"] = state["hard_stop_reason"] or reason
            self._put_state(state)

    def snapshot(self, slot_id=None):
        events = [json.loads(row[0]) for row in self.con.execute("SELECT body FROM events ORDER BY seq")]
        if slot_id is not None:
            events = [event for event in events if event["slot_id"] == slot_id]
        return dict(schema_version="continuation-pacing-v1", config=self.config, state=self._state(), events=events)

    def close(self):
        if self.con is not None:
            self.con.close()
            self.con = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
