"""Isolated continuation of the 18 never-started expansion rows.

The halted campaign is immutable evidence. Preparation checks its raw branch
artifacts and checkpoints; it neither clears the old 429 nor grants live use.
"""
from __future__ import annotations
from contextlib import closing
from copy import deepcopy
from pathlib import Path
import json
import sqlite3

from safety_reliability_expansion_v2 import protocol as parent
from safety_reliability_expansion_v2 import checker as historical_checker
from safety_reliability_live_v2.protocol import canonical, digest, sha, read, write, prompt_specs

ROOT = Path(__file__).resolve().parents[2]
STUDY = "safety-reliability-v2-continuation"
REVISION = STUDY+"-v1"
CONTINUATION_RUN_ID = REVISION
ARMS = parent.SAFETY_ARMS
SAFETY_ARMS = ARMS
SCENARIOS = parent.SCENARIOS
STEPS, TASKS, PROMPT_PATHS = parent.STEPS, parent.TASKS, parent.PROMPT_PATHS
LIMITS = dict(parent.LIMITS, rows=18, calls=144)
PACING_POLICY = dict(min_interval_seconds=2.0, spacing_basis="previous_call_completion",
    automatic_retries=0, clock="wall_and_monotonic", pending_call_policy="hard_stop",
    rate_limit_policy="429_hard_stop_no_retry")
EXPANSION_RELATIVE = "outputs/safety_reliability_expansion_v2_live_20261023/remote_evidence/outputs/safety_reliability_v2_expansion_live"
EXPECTED_HISTORY = dict(generation_calls=2401, known_nano=175247450, held_nano=3252000, total_nano=178499450)
EXPECTED_BATCH_TOTALS = {
    "B04":dict(generation_calls=22,known_nano=1261500,held_nano=984000,total_nano=2245500),
    "B05":dict(generation_calls=0,known_nano=0,held_nano=0,total_nano=0),
    "B06":dict(generation_calls=0,known_nano=0,held_nano=0,total_nano=0),
}
task, injection_spec = parent.task, parent.injection_spec


def registration():
    original = parent.registration()
    rows = []
    for old in original["rows"]:
        if old["batch_id"] in ("B05", "B06") or (old["batch_id"] == "B04" and old["scenario"] == "S07"):
            row = deepcopy(old)
            row.update(original_slot_id=old["slot_id"], original_ordinal=old["ordinal"],
                       continuation_slot_id=STUDY+":"+old["slot_id"], continuation_run_id=CONTINUATION_RUN_ID,
                       ordinal=len(rows)+1)
            rows.append(row)
    batches = []
    for bid in ("B04", "B05", "B06"):
        old = next(b for b in original["batches"] if b["batch_id"] == bid)
        selected = [r for r in rows if r["batch_id"] == bid]
        cap = sum(r["call_cap"] for r in selected)
        batch = deepcopy(old)
        batch.update(slots=[r["slot_id"] for r in selected], scenarios=list(dict.fromkeys(r["scenario"] for r in selected)),
                     call_cap=cap, worst_reservation_nano=cap*LIMITS["call_reservation_nano"],
                     original_batch_id=bid, prior_original_batch_total_nano=EXPECTED_BATCH_TOTALS[bid]["total_nano"])
        batches.append(batch)
    return dict(schema_version=REVISION+"-registration", study_id=STUDY, continuation_run_id=CONTINUATION_RUN_ID,
        original_registration_digest=digest(original), rows=rows, batches=batches, limits=deepcopy(LIMITS),
        input_allowance_is_calibrated=False, original_registry_modified=False,
        independent_fresh_runs_not_paired_freeze=True, future_batches_authorized=False,
        historical_failed_rows_preserved=True, original_generation_call_cap=296,
        original_generation_calls_already_dispatched=101, original_remaining_call_cap=195,
        task_b_selected_after_b01=True, independent_heldout_generalization_claim=False)


def _tables(path):
    with closing(sqlite3.connect(Path(path).resolve().as_uri()+"?mode=ro&immutable=1",uri=True)) as con:
        if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("HISTORY_SQLITE_INTEGRITY")
        return {t:[json.loads(v[0]) for v in con.execute("SELECT body FROM "+t+" ORDER BY rowid")]
                for t in ("config","batches","checkpoints")}, con.execute("SELECT reason FROM stop").fetchall()


def latest_history(root=None):
    root = Path(root or ROOT)
    previous = parent.latest_history(root)
    saved = root/EXPANSION_RELATIVE
    frozen_path = saved/"protocol/frozen.json"
    old_frozen = read(frozen_path)
    if (old_frozen["history"] != previous or old_frozen["registration"] != parent.registration()
            or old_frozen["mode"] != "live" or old_frozen["binding"]["simulated"]
            or old_frozen["binding"]["model"] != "api-glm-5.3-flash"):
        raise ValueError("EXPANSION_PARENT_OR_BINDING_MISMATCH")
    # Save all files used by the independent historical checker, including raw
    # HTTP exports, run state, provider receipts and fixed deadline evidence.
    files = [saved/"authority.sqlite"]
    files += [p for p in (saved/"protocol").rglob("*") if p.is_file()]
    files += [p for p in (saved/"checks").rglob("*") if p.is_file()]
    files += [p for p in (saved/"batches").rglob("*") if p.is_file() and p.name != "advance.lock"]
    files += [p for p in (saved/"controller").rglob("watchdog.json") if p.is_file()]
    pins = deepcopy(previous["source_files"])
    for path in sorted(set(files)):
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError("HISTORY_SOURCE_PATH")
        pins[str(path.relative_to(root))] = sha(path)
    tables, stops = _tables(saved/"authority.sqlite")
    records, checkpoints = tables["batches"], tables["checkpoints"]
    if (tables["config"] != [old_frozen] or [v["batch_id"] for v in records] != ["B02","B03","B04"]
            or [v["status"] for v in records] != ["completed","completed","halted"]
            or [v["batch_id"] for v in checkpoints] != ["B02","B03"]
            or stops != [("BUDGET_OR_SETTLEMENT_FENCED",)]):
        raise ValueError("EXPANSION_EXPECTED_HALTED_CHAIN")
    started, added, checks, batches = [], [], [], []
    for index, record in enumerate(records):
        bid = record["batch_id"]
        registered = old_frozen["registration"]["batches"][index]
        checked = historical_checker.check_batch(saved,bid)
        if not checked.get("passed") or checked != read(saved/"checks"/(bid+".json")):
            raise ValueError("EXPANSION_INDEPENDENT_RECHECK:"+bid)
        if digest(checked) != record["check_digest"]:
            raise ValueError("EXPANSION_CHECK_DIGEST")
        expected_pred = digest(previous if not index else checkpoints[index-1])
        if record["predecessor_digest"] != expected_pred:
            raise ValueError("EXPANSION_CHECKPOINT_PREDECESSOR")
        if index < 2:
            checkpoint = checkpoints[index]
            if (checkpoint["batch_record_digest"] != digest(record) or checkpoint["ordinal"] != index+1
                    or checkpoint["predecessor_digest"] != expected_pred
                    or checkpoint["calls"] != checked["call_ids"]
                    or checkpoint["completed_slots"] != checked["slot_ids"]):
                raise ValueError("EXPANSION_CHECKPOINT_LINK")
        expected_count = 8 if index < 2 else 6
        if (record["completed_slots"] != registered["slots"][:expected_count]
                or checked["slot_ids"] != record["completed_slots"]
                or bool(checked["hard_stop_reason"]) != (index == 2)):
            raise ValueError("EXPANSION_STARTED_SLOT_SET")
        current = []
        for sid in record["completed_slots"]:
            path = saved/"batches"/bid/sid/"ledger.sqlite"
            if record["ledger_hashes"].get(str(path.relative_to(saved))) != sha(path):
                raise ValueError("EXPANSION_LEDGER_PIN")
            with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro&immutable=1",uri=True)) as con:
                cfg = json.loads(con.execute("SELECT config FROM p3_campaign WHERE singleton=1").fetchone()[0])
                if cfg["binding"] != old_frozen["binding"]:
                    raise ValueError("EXPANSION_LEDGER_BINDING")
                for cid,body in con.execute("SELECT call_id,body FROM p3_calls ORDER BY rowid"):
                    call = json.loads(body)
                    if cid != call["call_id"] or call["simulated"] or not call["dispatched"]:
                        raise ValueError("EXPANSION_REAL_DISPATCH_PROVENANCE")
                    parent.parent._validate_call(call)
                    if call["status"] == "settled":
                        receipt = con.execute("SELECT provider_request_id,normalized_usage FROM p3_receipts WHERE call_id=?",(cid,)).fetchone()
                        if receipt is None or receipt[0]!=call["provider_request_id"] or json.loads(receipt[1])!=call["usage"]:
                            raise ValueError("EXPANSION_PROVIDER_USAGE_RECEIPT")
                    elif (bid!="B04" or sid!=record["completed_slots"][-1] or call["status"]!="uncertain"
                            or call["evidence"]["http_trace"]["status"]!=429
                            or call["held_cost_nano_usd"]!=984000 or call["known_cost_nano_usd"]!=0):
                        raise ValueError("EXPANSION_UNKNOWN_429_HOLD")
                    current.append(parent.parent._compact(call))
        ids = [c["call_id"] for c in current]
        known = sum(c["known_cost_nano_usd"] for c in current)
        held = sum(c["held_cost_nano_usd"] for c in current)
        if (ids!=record["call_ids"] or ids!=checked["call_ids"]
                or any((v["known_nano"],v["held_nano"])!=(known,held) for v in (record,checked))):
            raise ValueError("EXPANSION_RAW_SETTLEMENT_MISMATCH")
        if index<2 and (checkpoints[index]["known_nano"],checkpoints[index]["held_nano"])!=(known,held):
            raise ValueError("EXPANSION_CHECKPOINT_COST")
        started += record["completed_slots"]
        added += current
        checks.append(dict(batch_id=bid,digest=digest(checked),passed=True))
        batches.append(dict(batch_id=bid,generation_calls=len(current),known_nano=known,held_nano=held,total_nano=known+held))
    unknown = [v for v in added if v["status"] != "settled"]
    ids = [c["call_id"] for c in added]
    providers = [c["provider_request_id"] for c in added if c["provider_request_id"]]
    known,held = sum(c["known_cost_nano_usd"] for c in added),sum(c["held_cost_nano_usd"] for c in added)
    if (len(added),len(started),known,held,len(unknown)) != (101,22,5795650,984000,1):
        raise ValueError("EXPANSION_EXPECTED_TOTALS")
    exposed = previous["exposed_historical_call_ids"]+ids
    provider_ids = previous["exposed_historical_provider_ids"]+providers
    if len(set(exposed))!=len(exposed) or len(set(provider_ids))!=len(provider_ids):
        raise ValueError("EXPANSION_HISTORICAL_CALL_OVERLAP")
    unstarted = [r["slot_id"] for r in old_frozen["registration"]["rows"] if r["slot_id"] not in set(started)]
    if unstarted != [r["slot_id"] for r in registration()["rows"]]:
        raise ValueError("CONTINUATION_NOT_EXACT_UNSTARTED_ROWS")
    for relative,pin in pins.items():
        if sha(root/relative) != pin:
            raise ValueError("HISTORY_CHANGED_DURING_READ")
    total = dict(generation_calls=previous["generation_calls"]+len(added),known_nano=previous["known_nano"]+known,
                 held_nano=previous["held_nano"]+held,total_nano=previous["total_nano"]+known+held)
    if total != EXPECTED_HISTORY:
        raise ValueError("EXPANSION_NOT_LATEST_EXPECTED_TOTAL")
    batch_totals = deepcopy(EXPECTED_BATCH_TOTALS)
    if next(v for v in batches if v["batch_id"]=="B04") != dict(batch_id="B04",**batch_totals["B04"]):
        raise ValueError("ORIGINAL_BATCH_CARRY_MISMATCH")
    return dict(schema_version=REVISION+"-history",**total,parent_digest=digest(previous),
        inherited_expansion_frozen_digest=digest(old_frozen),inherited_expansion_checkpoints=checkpoints,
        inherited_expansion_batch_records=records,inherited_expansion_checks=checks,inherited_expansion_calls=added,
        inherited_expansion_batches=batches,inherited_expansion_stop_reason=stops[0][0],
        inherited_started_slot_ids=started,unstarted_slot_ids=unstarted,prior_batch_totals=batch_totals,
        historical_429_call_id=unknown[0]["call_id"],historical_429_hold_nano=984000,
        original_expansion_call_cap=296,original_expansion_dispatched_calls=101,original_expansion_remaining_call_cap=195,
        prior_v2_known_nano=previous["prior_v2_known_nano"]+known,prior_v2_held_nano=previous["prior_v2_held_nano"]+held,
        prior_v2_total_nano=previous["prior_v2_total_nano"]+known+held,
        prior_safety_known_nano=previous["prior_safety_known_nano"]+known,prior_safety_held_nano=previous["prior_safety_held_nano"]+held,
        prior_safety_total_nano=previous["prior_safety_total_nano"]+known+held,
        exposed_historical_call_ids=exposed,exposed_historical_provider_ids=provider_ids,
        explicit_id_coverage=len(exposed),opaque_aggregate_calls=previous["opaque_aggregate_calls"],source_files=pins,
        provider_account_debit_verified=False,native_historical_databases_mutated=False,
        basis="Checked raw HTTP/usage/SQLite and preserved unknown holds; not provider balance.")


def binding_dict(mode):
    binding = parent.binding_dict(mode)
    binding["binding_ref"] = STUDY+"/"+mode
    return binding


def code_hashes():
    pins=parent.code_hashes()
    paths=list((ROOT/"src/safety_reliability_continuation_v2").glob("*.py"))
    paths+=list((ROOT/"scripts").glob("*safety_reliability_continuation_v2*.py"))
    pins.update({str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)})
    return pins


def prepare(output, mode="fake-http", target=None):
    output = Path(output).resolve()
    if mode not in ("fake-http","live"):
        raise ValueError("MODE")
    frozen = dict(schema_version=REVISION,study_id=STUDY,mode=mode,registration=registration(),history=latest_history(),
        binding=binding_dict(mode),prompts={k:read(ROOT/p) for k,p in PROMPT_PATHS.items()},prompt_specs=prompt_specs(),
        target_execution=deepcopy(target),code_hashes=code_hashes(),pacing_policy=deepcopy(PACING_POLICY),live_authorized_by_preparation=False,
        target=dict(environment="DataHub CSE291A",cpus=2,memory_gib=8,gpu_count=0,endpoint="https://tritonai-api.ucsd.edu/v1"))
    path = output/"protocol/frozen.json"
    if path.exists():
        if read(path)!=frozen:
            raise ValueError("FROZEN_INPUT_CHANGED")
        return frozen
    write(path,frozen)
    write(output/"protocol/registration.json",frozen["registration"])
    write(output/"protocol/history.json",frozen["history"])
    for name,prompt in frozen["prompt_specs"].items():
        write(output/"protocol/prompts"/(name+".json"),prompt)
    write(output/"protocol/disabled-live-grant.json",dict(authorized=False,study_id=STUDY,campaign_root=str(output),
        frozen_digest=digest(frozen),binding_digest=digest(frozen["binding"]),history_digest=digest(frozen["history"]),
        limits=deepcopy(LIMITS),batch_ids=[b["batch_id"] for b in frozen["registration"]["batches"]],expires_unix=0,
        pricing_and_model_confirmed=False,quota_checked=False,credential_source="datahub_environment",credential_variable="OPENAI_API_KEY",
        authorization_reference="Future explicit live authorization required",target=frozen["target"],target_execution=frozen["target_execution"]))
    return frozen


def validate_frozen(frozen):
    if frozen.get("schema_version") != REVISION or frozen.get("registration") != registration():
        raise ValueError("FROZEN_REGISTRATION_CHANGED")
    if frozen.get("pacing_policy") != PACING_POLICY:
        raise ValueError("FROZEN_PACING_POLICY_CHANGED")
    if frozen.get("code_hashes") != code_hashes():
        raise ValueError("FROZEN_CODE_CHANGED")
    if frozen.get("history") != latest_history():
        raise ValueError("FROZEN_HISTORY_CHANGED")
    if frozen.get("prompt_specs") != prompt_specs() or frozen.get("binding") != binding_dict(frozen.get("mode")):
        raise ValueError("FROZEN_BINDING_OR_PROMPT_CHANGED")
    return True


def validate_grant(frozen, output, grant, now, batch_id=None):
    target=frozen.get("target_execution")
    target_fields={"system","hub_user","service_prefix","deployment_root","course_profile","cpus","memory_gib","gpu_count"}
    target_ok=(isinstance(target,dict) and set(target)==target_fields and target.get("system")=="Linux"
        and isinstance(target.get("hub_user"),str) and bool(target["hub_user"].strip())
        and isinstance(target.get("service_prefix"),str) and target["service_prefix"].startswith("/user/")
        and target["service_prefix"].endswith("/") and isinstance(target.get("deployment_root"),str)
        and Path(target["deployment_root"]).is_absolute() and target.get("course_profile")=="CSE291A"
        and target.get("cpus")==2 and target.get("memory_gib")==8 and target.get("gpu_count")==0)
    if frozen["mode"]!="live" or grant.get("authorized") is not True:
        raise PermissionError("V2_CONTINUATION_LIVE_DISABLED")
    if (grant.get("study_id")!=STUDY or grant.get("campaign_root")!=str(Path(output).resolve())
            or grant.get("frozen_digest")!=digest(frozen) or grant.get("binding_digest")!=digest(frozen["binding"])
            or grant.get("history_digest")!=digest(frozen["history"]) or grant.get("limits")!=LIMITS
            or grant.get("batch_ids")!=[b["batch_id"] for b in frozen["registration"]["batches"]]
            or (batch_id is not None and batch_id not in grant.get("batch_ids",[])) or not now<grant.get("expires_unix",0)
            or grant.get("pricing_and_model_confirmed") is not True or grant.get("quota_checked") is not True
            or grant.get("credential_source")!="datahub_environment" or grant.get("credential_variable")!="OPENAI_API_KEY"
            or grant.get("target")!=frozen["target"] or grant.get("target_execution")!=frozen.get("target_execution")
            or not target_ok or not grant.get("authorization_reference","").strip()):
        raise PermissionError("V2_CONTINUATION_LIVE_SCOPE_MISMATCH")
    return True
