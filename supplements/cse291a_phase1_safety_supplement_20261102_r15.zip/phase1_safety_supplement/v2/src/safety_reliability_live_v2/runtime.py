"""Bounded HTTP adapter for the unchanged five-step v2 repair mechanism.

The live path accepts only a licensed transport and an injected credential
provider. Fake recipes build new wire replies from the delivered public input;
they cannot be supplied to a live run. Historical responses are never replayed.
"""
from copy import deepcopy
import fcntl
import json
from pathlib import Path
import resource
import sqlite3
import sys
import time

from agent_recovery.contracts import ContractError, new_id, require
from agent_recovery.p3_budget import DurableP3Budget
from agent_recovery.p3_deadline import BoundedHTTPSender, WireRecipe
from agent_recovery.p3_gateway import P3ModelGateway
from agent_recovery.p3_transport import (P3Binding, P3HTTPClient, BoundTokenCounter,
    HTTPResponse, fake_http_response)
from agent_recovery.workflow import Workflow
from safety_reliability_v2.contracts import normal_payload, expected_config
from safety_reliability_v2.gateway import Gateway as OfflineGateway
from safety_reliability_v2.runtime import Session as RepairSession, Store, Hooks
from .protocol import read, write, sha, digest, canonical, LIMITS


def messages(spec, step, bundle, carriers, feedback):
    envelope = dict(step_id=step, input=bundle, public_carriers=carriers)
    if spec["prompt_kind"] == "new":
        envelope["repair_feedback"] = feedback
    return [dict(role="system", content=spec["system_prefix"]+spec["instructions"][step]),
            dict(role="user", content=canonical(envelope))]


def fake_recipe(request, occurrence, recipe):
    """Pure synthetic response construction, with no access to saved answers."""
    envelope = json.loads(request["messages"][1]["content"])
    step, bundle = envelope["step_id"], envelope["input"]
    payload = normal_payload(step, bundle)
    kind = recipe.get("kind", "clean")
    target = recipe.get("step", "read_metadata")
    hit = step == target and (occurrence == 1 or recipe.get("always", False))
    if hit and kind == "metadata_wrong":
        payload["num_examples"] -= 3
    if hit and kind == "wrong_steps":
        (payload["arguments"] if step == "execute" else payload)["steps"] -= 2
    if hit and kind == "resource_over":
        (payload["arguments"] if step == "execute" else payload)["workers"] += 10
    if hit and kind == "false_permission":
        payload["allowed"] = True
    content = canonical(payload)
    response = fake_http_response(payload, model=request["model"],
        prompt_tokens=max(1, len(canonical(request).encode())//4),
        completion_tokens=max(1, len(content.encode())//4),
        headers={"x-litellm-call-id": "fake-litellm-"+new_id()})
    raw = json.loads(response.body)
    if hit and kind == "missing_usage":
        raw.pop("usage")
    if hit and kind == "oversized_usage":
        raw["usage"].update(prompt_tokens=4001, total_tokens=4001+raw["usage"]["completion_tokens"])
    if hit and kind == "bad_json":
        raw["choices"][0]["message"]["content"] = "{broken"
    if hit and kind == "wrong_model":
        raw["model"] = "unexpected-model"
    status = int(kind[4:]) if hit and kind in ("http401", "http403", "http429", "http503") else 200
    if status != 200:
        raw = dict(error=dict(message="Synthetic transport rejection"))
    response = HTTPResponse(status, response.headers, canonical(raw).encode())
    if hit and kind in ("dns_hang", "worker_crash", "ignore_term"):
        return WireRecipe(kind=kind)
    if hit and kind in ("late_success", "slow_headers", "slow_body", "cleanup_failure"):
        return WireRecipe(kind=kind, response=response, delay_s=recipe.get("delay_s", .5))
    return WireRecipe(kind="response", response=response)


class Client(P3HTTPClient):
    def __init__(self, binding, sender, remaining, *, recipe=None, **kwargs):
        require(type(sender) is BoundedHTTPSender, "Only supervised HTTP is permitted", "V2_BOUNDED_REQUIRED")
        require(binding.simulated or recipe is None, "Live replies cannot use a fixture", "V2_LIVE_FIXTURE")
        super().__init__(binding, sender, **kwargs)
        self.remaining, self.recipe, self.occurrences = remaining, recipe, {}

    def create(self, request, *, timeout_s, before_send=None, deadline_monotonic=None):
        left = self.remaining()
        require(left > 0, "Fixed deadline expired", "V2_TOTAL_DEADLINE")
        timeout = min(timeout_s, left)
        if self.binding.simulated:
            step = json.loads(request["messages"][1]["content"])["step_id"]
            self.occurrences[step] = self.occurrences.get(step, 0)+1
            self.sender._recipes.append(fake_recipe(request, self.occurrences[step], self.recipe or {}))
        return super().create(request, timeout_s=timeout, before_send=before_send,
            deadline_monotonic=min(deadline_monotonic or time.monotonic()+timeout, time.monotonic()+timeout))


class Gateway(OfflineGateway):
    def __init__(self, client, campaign, *, store, prompt_spec, prompt_sha256, branch_id, remaining, call_cap):
        counter = BoundTokenCounter(client.binding.token_admission_evidence, lambda request: 4000)
        P3ModelGateway.__init__(self, client, campaign, trial_key=branch_id, branch_id=branch_id,
                               logical_run_key=branch_id, token_counter=counter)
        self.store, self.spec, self.spec_sha = store, prompt_spec, prompt_sha256
        self.remaining, self.call_cap = remaining, call_cap
        self.prompt_revision = prompt_spec["prompt_revision"]

    def prepare_input(self, attempt, step_id, bundle, public_carriers):
        require(len(self.campaign.calls()) < self.call_cap, "Registered branch cap", "V2_CALL_LIMIT")
        side = super().prepare_input(attempt, step_id, bundle, public_carriers)
        rendered = messages(self.spec, step_id, bundle, public_carriers, side["repair_feedback"])
        side.update(rendered_messages=rendered, rendered_messages_digest=digest(rendered))
        self._prepared[attempt["result_id"]] = side
        self._current = side
        return deepcopy(side)

    def render(self, role, bundle):
        require(self._current is not None and self._current["step_id"] == role
                and self._current["input_bundle"] == bundle, "Unprepared model input", "V2_INPUT_MISMATCH")
        return messages(self.spec, role, bundle, self._current["public_carriers"], self._current["repair_feedback"])


class Session(RepairSession):
    """Reuse the frozen repair/Store logic, with a separately bound transport."""
    def __init__(self, directory, row, frozen, *, credential_provider=None, permit=None,
                 recipe=None, flow_seconds=660):
        binding = P3Binding.from_dict(frozen["binding"])
        require(binding.simulated or recipe is None, "No scripted replies on live path", "V2_LIVE_FIXTURE")
        require(binding.simulated or (permit is not None and credential_provider is not None),
                "Licensed credentials required", "V2_LIVE_DISABLED")
        if not binding.simulated:
            permit.validate(binding)
        self.path = Path(directory).resolve()
        self.path.mkdir(parents=True, exist_ok=False)
        self.lock = (self.path/"advance.lock").open("a+b")
        fcntl.flock(self.lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.store = self.budget = None
        self.began = time.monotonic()
        try:
            self.case = dict(fixture_id=row["slot_id"], row=deepcopy(row), policy=row["policy"],
                task=deepcopy(row["task"]), original_responses={}, recipe=deepcopy(recipe or {}),
                flow_seconds=min(660, flow_seconds), limits={})
            require(self.case["flow_seconds"] > 0, "Expired batch", "V2_TOTAL_DEADLINE")
            self.spec = deepcopy(frozen["prompt_specs"][row.get("prompt_kind", row.get("prompt_version"))])
            write(self.path/"case.json", self.case)
            write(self.path/"prompt_spec.json", self.spec)
            self.store = Store(self.path/"run.sqlite")
            rid = self.store.initialize_run(self.case["task"])
            now, wall = time.monotonic(), time.time()
            state = dict(schema_version="safety-reliability-control-v2", branch_id=new_id(), run_id=rid,
                case_digest=digest(self.case), prompt_sha256=sha(self.path/"prompt_spec.json"),
                policy=row["policy"], status="running", stop_reason=None, selected={}, pending=None,
                created_monotonic=now, created_unix=wall,
                deadline_monotonic=now+self.case["flow_seconds"], deadline_unix=wall+self.case["flow_seconds"],
                initial_sources=deepcopy(self.case["task"]["initial_objects"]))
            with self.store._transaction(write=True):
                self.store.set_control(state)
            cap = row["call_cap"]
            limits = dict(call_cap=cap, slot_call_cap=5, logical_call_cap=cap,
                input_token_cap=cap*4000, output_token_cap=cap*768, max_cost_nano_usd=cap*984000)
            self.budget = DurableP3Budget(self.path/"ledger.sqlite", campaign_id=state["branch_id"],
                                         binding=binding.to_dict(), limits=limits)
            self.store.bind_p3(binding, self.budget.ref)
            self.sender = BoundedHTTPSender(recipes=[] if binding.simulated else None)
            counter = BoundTokenCounter(binding.token_admission_evidence, lambda request: 4000)
            self.client = Client(binding, self.sender, self.remaining, recipe=recipe,
                credential_provider=credential_provider, runtime_permit=permit, token_counter=counter)
            self.gateway = Gateway(self.client, self.budget, store=self.store, prompt_spec=self.spec,
                prompt_sha256=state["prompt_sha256"], branch_id=state["branch_id"],
                remaining=self.remaining, call_cap=cap)
            self.flow = Workflow(self.store, self.gateway, hooks=Hooks(self))
            self._advancing = False
        except BaseException:
            self.close()
            raise

    def _failure(self, result, verification):
        evidence = super()._failure(result, verification)
        # A verifier can catch an overclaim before the commit guard runs.
        # Apply the same non-repairable resource policy at both locations.
        if evidence["kind"] == "semantic_mismatch":
            expected = expected_config(self.case["task"]["request"], evidence["source_objects"])
            payload = result["payload"]
            step = result["step_id"]
            excessive = (step == "plan" and payload.get("workers", 0) > expected["workers"])
            if step == "read_resources":
                limit = next(s["payload"]["max_workers"] for s in evidence["source_objects"]
                             if s["object_key"] == "resource_policy:default")
                excessive |= payload.get("max_workers", 0) > limit
            if excessive:
                evidence["kind"] = "resource_violation"
        return evidence

    def _claim(self, state, evidence, ledger):
        if state["policy"] == "GUARD_STOP":
            return self._terminal(state, "safe_stopped", "GUARD_STOP")
        return super()._claim(state, evidence, ledger)

    def export(self):
        state, snapshot, ledger = self.store.control(), self.store.snapshot_run(), self.budget.snapshot()
        calls = ledger["calls"]
        fake = self.client.binding.simulated
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        report = dict(schema_version="safety-reliability-live-v2-branch", mode="fake-http" if fake else "live",
            simulated=fake, fixture_id=self.case["fixture_id"], status=state["status"],
            stop_reason=state["stop_reason"], selected=state["selected"],
            fake_http_calls=self.client.request_count if fake else 0,
            real_api_requests=self.client.real_request_count, credentials_read=0 if fake else None,
            repeated_model_calls=sum(c["attempt_no"] > 1 and c["dispatched"] for c in calls),
            repair_rounds=int(bool(self.store.repair())), usage_and_cost_are_synthetic=fake,
            known_cost_nano_usd=ledger["budget"]["known_cost_nano_usd"],
            held_cost_nano_usd=ledger["budget"]["held_cost_nano_usd"],
            training_or_prediction_calls=0, automatic_retries=0,
            provider_debit_nano_usd=0 if fake else None, provider_invoice_verified=False,
            prompt_effect_on_real_model_measured=False, fresh_real_response_observed=not fake,
            evidence_kind="synthetic-wire-response" if fake else "fresh-provider-response",
            cleanup_receipts=self.sender.cleanup_receipts, elapsed_s=time.monotonic()-self.began,
            peak_rss_bytes=int(rss if sys.platform == "darwin" else rss*1024),
            input_count_basis="fake-byte-bound" if fake else "4000-financial-allowance-not-calibrated",
            model_error_codes=[c["evidence"]["outcome"].get("error_code") for c in calls
                               if c.get("evidence") and c["evidence"].get("outcome",{}).get("error_code")])
        for name, value in (("snapshot", snapshot), ("campaign", ledger),
            ("gateway_records", [c["evidence"] for c in calls if c.get("evidence")]),
            ("accounting", self.store.model_accounting_snapshot()), ("report", report)):
            write(self.path/(name+".json"), value)
        write(self.path/"artifacts.json", {p.name:dict(sha256=sha(p), bytes=p.stat().st_size)
            for p in sorted(self.path.iterdir()) if p.is_file() and p.name != "advance.lock"})
        return report


def stop_from_branch(report, ledger, checked):
    if not checked["passed"]:
        return "INDEPENDENT_CHECK_FAILED"
    if report["status"] == "uncertain":
        return report["stop_reason"] or "UNKNOWN_OUTCOME"
    if ledger["status"] != "active" or ledger["budget"]["held_cost_nano_usd"]:
        return ledger.get("pause_reason") or "UNKNOWN_USAGE_OR_LEDGER_FENCED"
    if any(not c.get("reaped") or c.get("cleanup_failed") for c in report["cleanup_receipts"]):
        return "UNREAPED_HTTP_WORKER"
    for error in report["model_error_codes"]:
        if error not in ("MODEL_ERROR", "MODEL_SCHEMA_ERROR"):
            return error
    if report["peak_rss_bytes"] > 1024**3:
        return "RSS_LIMIT"
    if report["stop_reason"] in ("TOTAL_DEADLINE", "V2_TOTAL_DEADLINE"):
        return "FIXED_DEADLINE"
    return None


def run_batch(output, batch_id="B01", *, credential_provider=None, permit=None, fixture_recipe=None):
    from .checker import check_run
    output = Path(output).resolve()
    frozen = read(output/"protocol/frozen.json")
    require(frozen["mode"] == "fake-http" or fixture_recipe is None,
            "Live run cannot receive a fixture recipe", "V2_LIVE_FIXTURE")
    batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
    dest = output/"batches"/batch_id
    dest.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    with sqlite3.connect((output/"authority.sqlite").as_uri()+"?mode=ro&immutable=1", uri=True) as con:
        reservation = json.loads(con.execute("SELECT body FROM batches WHERE batch_id=?", (batch_id,)).fetchone()[0])
        require(reservation["status"] == "reserved" and not con.execute("SELECT 1 FROM stop").fetchone(),
                "Batch requires a live reservation", "V2_BATCH_NOT_RESERVED")
    clock = dict(created_monotonic=reservation["deadline_monotonic"]-1800,
                 created_unix=reservation["reserved_unix"],
                 deadline_monotonic=reservation["deadline_monotonic"],
                 deadline_unix=reservation["deadline_unix"])
    write(dest/"clock.json", clock)
    rows = {r["slot_id"]:r for r in frozen["registration"]["rows"]}
    checks, reports, halt = [], [], None
    for sid in batch["slots"]:
        left = min(clock["deadline_monotonic"]-time.monotonic(), clock["deadline_unix"]-time.time())
        if left <= 0:
            halt = "BATCH_DEADLINE"; break
        row = rows[sid]
        recipe = None
        if frozen["mode"] == "fake-http":
            conf = fixture_recipe or {}
            recipe = conf.get("rows", {}).get(sid, conf.get("arms", {}).get(row["arm"], conf.get("default", {})))
        with Session(dest/sid, row, frozen, credential_provider=credential_provider,
                     permit=permit, recipe=recipe, flow_seconds=min(660,left)) as branch:
            branch.run()
            report = branch.export()
            ledger = branch.budget.snapshot()
        checked = check_run(dest/sid, frozen)
        checks.append(checked); reports.append(report)
        write(dest/(sid+".check.json"), checked)
        halt = stop_from_branch(report, ledger, checked)
        if halt:
            break
    repair_reports = [r for r in reports if rows[r["fixture_id"]]["policy"] in ("GUARD_REPAIR","VERIFY_REPAIR")]
    expansion = ("NO_REPAIR_ARM_COMPLETION" if len(repair_reports) == 4
                 and all(r["status"] != "completed" for r in repair_reports) else None)
    report = dict(batch_id=batch_id, slot_ids=[r["fixture_id"] for r in reports],
        checks=checks, hard_stop_reason=halt, expansion_stop_reason=expansion,
        elapsed_s=time.monotonic()-start, simulated=frozen["mode"] == "fake-http",
        finished_unix=time.time(), finished_monotonic=time.monotonic(),
        real_api_requests=sum(r["real_api_requests"] for r in reports), automatic_retries=0)
    write(dest/"report.json", report)
    return report
