"""Durable full-batch reservation, checked settlement and unreleased uncertainty.

The authority reserves every possible B01 physical call before credentials or
workers are admitted. Reopening a pending reservation cannot re-dispatch it.
"""
from __future__ import annotations
from contextlib import closing, contextmanager
import fcntl
import json
import os
from pathlib import Path
import sqlite3
import time

from .protocol import LIMITS, canonical, digest, read, sha


@contextmanager
def campaign_lock(output):
    path=Path(output)/"campaign.lock"
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("a+") as stream:
        try:
            fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("CAMPAIGN_ALREADY_RUNNING") from None
        stream.seek(0);stream.truncate();stream.write(canonical(dict(pid=os.getpid())));stream.flush();os.fsync(stream.fileno())
        try:
            yield
        finally:
            fcntl.flock(stream,fcntl.LOCK_UN)


class Authority:
    def __init__(self,output,frozen):
        self.output,self.frozen=Path(output),frozen
        limits=frozen["registration"]["limits"]
        for key,maximum in LIMITS.items():
            if type(limits.get(key)) is not int or limits[key]<0 or limits[key]>maximum:
                raise RuntimeError("AUTHORITY_LIMIT_WIDENING:"+key)
        self.output.mkdir(parents=True,exist_ok=True)
        self.path=self.output/"authority.sqlite"
        self.con=sqlite3.connect(self.path)
        self.con.row_factory=sqlite3.Row
        self.con.execute("PRAGMA journal_mode=DELETE")
        self.con.execute("PRAGMA synchronous=FULL")
        self.con.executescript("""
            CREATE TABLE IF NOT EXISTS config(singleton INTEGER PRIMARY KEY CHECK(singleton=1),body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS batches(batch_id TEXT PRIMARY KEY,body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS checkpoints(seq INTEGER PRIMARY KEY,body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS stop(singleton INTEGER PRIMARY KEY CHECK(singleton=1),reason TEXT NOT NULL);
        """)
        old=self.con.execute("SELECT body FROM config WHERE singleton=1").fetchone()
        if old and json.loads(old[0])!=frozen:
            self.con.close()
            raise RuntimeError("AUTHORITY_CONFIG_CHANGED")
        if not old:
            self.con.execute("INSERT INTO config VALUES(1,?)",(canonical(frozen),));self.con.commit()

    def close(self):
        self.con.close()

    def __enter__(self):
        return self

    def __exit__(self,*args):
        self.close()

    def snapshot(self):
        batches=[json.loads(r[0]) for r in self.con.execute("SELECT body FROM batches ORDER BY rowid")]
        checks=[json.loads(r[0]) for r in self.con.execute("SELECT body FROM checkpoints ORDER BY seq")]
        stop=self.con.execute("SELECT reason FROM stop WHERE singleton=1").fetchone()
        known=sum(b["known_nano"] for b in batches)
        held=sum(b["held_nano"] for b in batches)
        historical=self.frozen["history"]
        state="hard_stopped" if stop else "pending" if any(b["status"]=="reserved" for b in batches) else "completed" if len(checks)==len(self.frozen["registration"]["batches"]) else "ready"
        return dict(frozen_digest=digest(self.frozen),mode=self.frozen["mode"],status=state,stop_reason=stop[0] if stop else None,
            batches=batches,checkpoints=checks,completed_batches=len(checks),study_known_nano=known,study_held_nano=held,
            study_total_nano=known+held,historical_known_nano=historical["known_nano"],historical_held_nano=historical["held_nano"],
            historical_generation_calls=historical["generation_calls"],
            combined_safety_total_nano=historical["prior_safety_total_nano"]+known+held,
            project_total_nano=historical["total_nano"]+known+held,limits=self.frozen["registration"]["limits"],
            provider_account_debit_verified=False,fake_usage_is_projected_not_real_spending=self.frozen["mode"]=="fake-http")

    def halt(self,reason):
        self.con.execute("INSERT OR IGNORE INTO stop VALUES(1,?)",(str(reason),));self.con.commit()

    def reserve_batch(self,batch):
        self.con.execute("BEGIN IMMEDIATE")
        try:
            state=self.snapshot()
            if state["status"]=="hard_stopped":
                raise RuntimeError("CAMPAIGN_HARD_STOPPED")
            if any(b["status"]!="completed" for b in state["batches"]):
                raise RuntimeError("PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
            all_batches=self.frozen["registration"]["batches"]
            if len(state["checkpoints"])>=len(all_batches) or batch!=all_batches[len(state["checkpoints"])]:
                raise RuntimeError("BATCH_ORDER_OR_DUPLICATE")
            limits=self.frozen["registration"]["limits"]
            block=batch["worst_reservation_nano"]
            if type(block) is not int or block!=batch["call_cap"]*limits["call_reservation_nano"] or batch["call_cap"]>limits["calls"]:
                raise RuntimeError("BATCH_RESERVATION_INVALID")
            for condition,reason in (
                (block<=limits["batch_nano"],"BATCH_BUDGET_CAP"),
                (state["study_total_nano"]+block<=limits["study_nano"],"STUDY_BUDGET_CAP"),
                (state["combined_safety_total_nano"]+block<=limits["combined_safety_nano"],"COMBINED_SAFETY_BUDGET_CAP"),
                (state["project_total_nano"]+block<=limits["project_nano"],"PROJECT_BUDGET_CAP")):
                if not condition:
                    raise RuntimeError(reason)
            now=time.time()
            record=dict(batch_id=batch["batch_id"],status="reserved",block_nano=block,known_nano=0,held_nano=block,
                reserved_unix=now,deadline_unix=now+limits["batch_seconds"],deadline_monotonic=time.monotonic()+limits["batch_seconds"],
                owner_pid=os.getpid(),input_project_total_nano=state["project_total_nano"],
                input_study_total_nano=state["study_total_nano"],input_combined_safety_total_nano=state["combined_safety_total_nano"],
                predecessor_digest=digest(state["checkpoints"][-1]) if state["checkpoints"] else digest(self.frozen["history"]))
            self.con.execute("INSERT INTO batches VALUES(?,?)",(batch["batch_id"],canonical(record)));self.con.commit()
            return record
        except BaseException:
            self.con.rollback();raise

    reserve=reserve_batch

    def finalize(self,batch,checked,ledger_paths):
        """Settle once from checked raw ledgers; any discrepancy retains the block."""
        if isinstance(ledger_paths,(str,Path)):
            ledger_paths={"batch":ledger_paths}
        elif not isinstance(ledger_paths,dict):
            ledger_paths={str(i):p for i,p in enumerate(ledger_paths)}
        self.con.execute("BEGIN IMMEDIATE")
        try:
            old=self.con.execute("SELECT body FROM batches WHERE batch_id=?",(batch["batch_id"],)).fetchone()
            if not old:
                raise RuntimeError("UNRESERVED_BATCH")
            record=json.loads(old[0])
            if record["status"]!="reserved":
                raise RuntimeError("FINALIZE_ALREADY_DONE")
            if checked.get("passed") is not True:
                raise RuntimeError("INDEPENDENT_CHECK_FAILED")
            if checked.get("batch_id",batch["batch_id"])!=batch["batch_id"]:
                raise RuntimeError("CHECK_BATCH_MISMATCH")
            paths={}
            calls=[]
            for key,value in ledger_paths.items():
                path=Path(value).resolve()
                if not path.is_relative_to(self.output.resolve()):
                    raise RuntimeError("LEDGER_OUTSIDE_CAMPAIGN")
                before=sha(path)
                with closing(sqlite3.connect(path.as_uri()+"?mode=ro&immutable=1",uri=True)) as con:
                    if con.execute("PRAGMA integrity_check").fetchone()[0]!="ok":
                        raise RuntimeError("FINALIZE_LEDGER_INTEGRITY")
                    calls += [json.loads(r[0]) for r in con.execute("SELECT body FROM p3_calls ORDER BY rowid")]
                if sha(path)!=before:
                    raise RuntimeError("FINALIZE_LEDGER_CHANGED")
                paths[str(path.relative_to(self.output.resolve()))]=before
            ids=[c["call_id"] for c in calls]
            historical=set(self.frozen["history"]["exposed_historical_call_ids"])
            if len(ids)!=len(set(ids)) or historical.intersection(ids):
                raise RuntimeError("PHYSICAL_CALL_REUSE")
            if len(ids)>batch["call_cap"] or checked.get("call_ids")!=ids:
                raise RuntimeError("CHECK_CALL_SET_MISMATCH")
            for call in calls:
                for field in ("known_cost_nano_usd","held_cost_nano_usd","reserved_cost_nano_usd"):
                    if type(call.get(field)) is not int or call[field]<0:
                        raise RuntimeError("FINALIZE_INVALID_MONEY")
                if call.get("status")=="settled":
                    usage=call.get("usage",{})
                    if any(type(usage.get(k)) is not int or usage[k]<0 for k in ("prompt_tokens","completion_tokens")):
                        raise RuntimeError("FINALIZE_INVALID_USAGE")
                    if call["known_cost_nano_usd"]!=usage["prompt_tokens"]*150+usage["completion_tokens"]*500 or call["held_cost_nano_usd"]:
                        raise RuntimeError("FINALIZE_USAGE_COST")
                elif call["held_cost_nano_usd"]<call["reserved_cost_nano_usd"]:
                    raise RuntimeError("FINALIZE_UNKNOWN_RELEASED")
            known=sum(c["known_cost_nano_usd"] for c in calls)
            held=sum(c["held_cost_nano_usd"] for c in calls)
            if (checked.get("known_nano"),checked.get("held_nano"))!=(known,held):
                raise RuntimeError("CHECK_MONEY_MISMATCH")
            if known+held>record["block_nano"]:
                raise RuntimeError("BLOCK_OVERRUN")
            slot_ids=checked.get("slot_ids")
            if not isinstance(slot_ids,list) or slot_ids!=batch["slots"][:len(slot_ids)] or len(set(slot_ids))!=len(slot_ids):
                raise RuntimeError("CHECK_SLOT_PREFIX")
            stop=checked.get("hard_stop_reason")
            if not stop and slot_ids!=batch["slots"]:
                raise RuntimeError("UNCHECKED_ROWS")
            if held and not stop:
                raise RuntimeError("UNKNOWN_COST_WITHOUT_STOP")
            record.update(status="halted" if stop else "completed",known_nano=known,held_nano=held,ledger_hashes=paths,
                          check_digest=digest(checked),completed_slots=slot_ids,call_ids=ids,finished_unix=time.time())
            self.con.execute("UPDATE batches SET body=? WHERE batch_id=?",(canonical(record),batch["batch_id"]))
            if stop:
                self.con.execute("INSERT OR IGNORE INTO stop VALUES(1,?)",(str(stop),))
            else:
                state=self.snapshot()
                checkpoint=dict(batch_id=batch["batch_id"],ordinal=len(state["checkpoints"])+1,
                    predecessor_digest=record["predecessor_digest"],batch_record_digest=digest(record),
                    completed_slots=slot_ids,calls=ids,known_nano=known,held_nano=held,project_total_nano=state["project_total_nano"])
                self.con.execute("INSERT INTO checkpoints VALUES(?,?)",(checkpoint["ordinal"],canonical(checkpoint)))
            self.con.commit()
            return record
        except BaseException as exc:
            self.con.rollback()
            self.halt("FINALIZE_RECONCILIATION_FAILED:"+str(exc))
            raise


def quality_stop(checks,completed_batch="B01"):
    if completed_batch!="B01":
        raise ValueError("UNREGISTERED_BATCH")
    repairs=[c for c in checks if c.get("repair_enabled") or c.get("arm") in ("new_guard_repair","new_verify_repair")]
    if len(repairs)==4 and not any(c.get("valid_completion",c.get("completed",False)) for c in repairs):
        return "ALL_FOUR_REPAIR_ARMS_FAILED"
    return None
