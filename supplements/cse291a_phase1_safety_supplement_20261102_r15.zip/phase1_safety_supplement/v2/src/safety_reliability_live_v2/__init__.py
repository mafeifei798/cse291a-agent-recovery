"""Separately registered v2 live adapter; preparation never authorizes a request."""
