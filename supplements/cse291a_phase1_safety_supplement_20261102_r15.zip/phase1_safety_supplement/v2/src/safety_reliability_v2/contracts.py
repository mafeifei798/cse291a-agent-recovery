from copy import deepcopy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "configs/safety_reliability_v2"
STEPS = ("read_metadata", "read_permission", "read_resources", "plan", "execute")
PARENTS = {"read_metadata": (), "read_permission": (), "read_resources": (),
           "plan": STEPS[:3], "execute": ("plan",)}
POLICIES = ("GUARD_REPAIR", "VERIFY_REPAIR", "VERIFY_STOP")
REVISION = "safety-reliability-v2"
MAX_REPAIRS, MAX_EXTRA, MAX_CALLS = 1, 3, 8
CALL_RESERVATION = 984000


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def sources_for(request):
    return (f"metadata:{request['dataset_id']}", f"permission:{request['dataset_id']}:{request['purpose']}",
            "resource_policy:default")


def expected_config(request, sources):
    values = {source["object_key"]: source["payload"] for source in sources}
    metadata, permission, resources = [values[key] for key in sources_for(request)]
    quotient, remainder = divmod(metadata["num_examples"], request["batch_size"])
    return dict(dataset_id=request["dataset_id"], purpose=request["purpose"], batch_size=request["batch_size"],
                epochs=request["epochs"], num_examples=metadata["num_examples"],
                steps=(quotient + bool(remainder)) * request["epochs"],
                workers=min(request["requested_workers"], resources["max_workers"]),
                permission_allowed=permission["allowed"])


def normal_payload(step, bundle):
    if step.startswith("read_"):
        return deepcopy(bundle["tool_snapshots"][0]["payload"])
    if step == "plan":
        sources = [dict(object_key=key, payload=parent["payload"])
                   for key, parent in zip(sources_for(bundle["request"]), bundle["parents"])]
        return expected_config(bundle["request"], sources)
    return dict(action="save_job", arguments=deepcopy(bundle["parents"][0]["payload"]))


def differences(actual, expected, path):
    if canonical(actual) == canonical(expected):
        return []
    if isinstance(actual, dict) and isinstance(expected, dict):
        answer = []
        for key in sorted(set(actual) | set(expected)):
            if key not in actual or key not in expected:
                answer.append(dict(location=path+"."+key, actual=actual.get(key), expected=expected.get(key)))
            else:
                answer += differences(actual[key], expected[key], path+"."+key)
        return answer
    return [dict(location=path, actual=deepcopy(actual), expected=deepcopy(expected))]


def render(spec, step, bundle, carriers, feedback):
    return [dict(role="system", content=spec["system_prefix"]+spec["instructions"][step]),
            dict(role="user", content=canonical(dict(step_id=step, input=bundle,
                 public_carriers=carriers, repair_feedback=feedback)))]


def load_fixtures():
    data = read(CONFIG/"fixtures.json")
    for case in data["cases"]:
        for relative, pin in case["source_files"].items():
            if sha(ROOT/relative) != pin:
                raise ValueError("SAVED_REPLAY_SOURCE_CHANGED:"+relative)
    return data["cases"]
