"""Persistent one-round semantic repair; legacy Workflow and guard are unchanged."""
from copy import deepcopy
from contextlib import contextmanager
import fcntl
import json
from pathlib import Path
import time

from agent_recovery.business_guard import BusinessGuardMixin
from agent_recovery.contracts import ContractError, CommitOutcomeUnknown, new_id, require
from agent_recovery.p1_delivery import check_candidate, VerificationStopped
from agent_recovery.p3_budget import DurableP3Budget
from agent_recovery.p3_gateway import P3Store
from agent_recovery.p3_transport import FakeHTTPSender
from agent_recovery.workflow import Workflow
from .contracts import (STEPS, PARENTS, POLICIES, MAX_CALLS, MAX_EXTRA, CALL_RESERVATION,
    CONFIG, canonical, digest, read, write, sha, sources_for, expected_config, differences)
from .gateway import binding, Transcript, DeadlineClient, Gateway


class Store(BusinessGuardMixin, P3Store):
    def __init__(self, path):
        super().__init__(path)
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS v2_control(singleton INTEGER PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS v2_advances(request_id TEXT PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS v2_verifications(result_id TEXT PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS v2_failures(failure_id TEXT PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS v2_repair(branch_id TEXT PRIMARY KEY, body TEXT NOT NULL);
        """)

    def control(self):
        row = self.connection.execute("SELECT body FROM v2_control").fetchone()
        return json.loads(row[0]) if row else None

    def set_control(self, state):
        self.connection.execute("INSERT INTO v2_control VALUES(1,?) ON CONFLICT(singleton) DO UPDATE SET body=excluded.body",
                                (canonical(state),))

    def repair(self):
        row = self.connection.execute("SELECT body FROM v2_repair").fetchone()
        return json.loads(row[0]) if row else None

    def _parent_chain(self, parent_ids, run_id):
        # This hook is also called inside the original atomic commit. A model
        # reply arriving in time cannot authorize a business write after cutoff.
        state = self.control()
        if self._business_guard_context is not None and state:
            require(time.monotonic() >= state["created_monotonic"]
                    and time.monotonic() < state["deadline_monotonic"]
                    and time.time() < state["deadline_unix"],
                    "Fixed deadline expired before commit", "V2_TOTAL_DEADLINE")
        return super()._parent_chain(parent_ids, run_id)

    def bind_pending_attempt(self, attempt):
        with self._transaction(write=True):
            state = self.control()
            require(state["pending"] and state["pending"]["step"] == attempt["step_id"],
                    "Attempt lacks a persisted advance", "V2_STALE_ADVANCE")
            require(state["pending"].get("attempt_id") in (None, attempt["token"]),
                    "Advance already owns a different attempt", "V2_STALE_ADVANCE")
            state["pending"].update(attempt_id=attempt["token"], result_id=attempt["result_id"])
            self.set_control(state)

    def snapshot_run(self, run_id=None):
        value = super().snapshot_run(run_id)
        value["v2_control"] = self.control()
        for name in ("advances", "verifications", "failures", "repair"):
            value["v2_"+name] = [json.loads(r[0]) for r in
                self.connection.execute("SELECT body FROM v2_"+name+" ORDER BY rowid")]
        return value


class Hooks:
    def __init__(self, session):
        self.session = session

    def after_capture(self, store, attempt, step, bundle):
        require(self.session.remaining() > 0, "Fixed deadline expired", "V2_TOTAL_DEADLINE")
        if step == "read_metadata":
            source = bundle["tool_snapshots"][0]
            carriers = [dict(carrier_kind="source_note", carrier_ref=dict(object_key=source["object_key"],
                version=source["version"]), untrusted_text="Dataset facts are in the captured snapshot.")]
        elif step == "plan":
            parent = bundle["parents"][0]
            carriers = [dict(carrier_kind="handoff_note", carrier_ref=dict(result_id=parent["result_id"],
                payload_digest=digest(parent["payload"])), untrusted_text="Use the supplied inputs without changing their facts.")]
        else:
            carriers = []
        self.session.gateway.prepare_input(attempt, step, bundle, carriers)

    def before_publish(self, store, attempt, result):
        return result, []

    def after_publish(self, store, attempt, result):
        self.session.gateway.record_publication(result)
        if (self.session.case["policy"] in ("VERIFY_REPAIR", "VERIFY_STOP")
                and result["execution_status"] == "success" and result["step_id"] != "execute"):
            sources = []
            def reader(keys):
                values = store.read_objects(keys)
                sources.extend(values)
                return values
            receipt = check_candidate(result, self.session.case["task"]["request"], reader)
            with store._transaction(write=True):
                store.connection.execute("INSERT INTO v2_verifications VALUES(?,?)",
                    (result["result_id"], canonical(dict(receipt=receipt, source_objects=sources))))
            if receipt["decision"] == "reject":
                raise VerificationStopped(receipt)


class Session:
    """One branch owns its SQLite DB, simulated ledger and exclusive CPU runner lock."""
    def __init__(self, directory, case=None):
        self.path = Path(directory).resolve()
        self.path.mkdir(parents=True, exist_ok=True)
        self.lock = (self.path/"advance.lock").open("a+b")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            self.lock.close()
            raise ContractError("V2_RUNNER_BUSY", "A branch already has a runner")
        self.store, self.budget = None, None
        try:
            if case is not None:
                case = deepcopy(case)
                case.setdefault("recipe", {})
                case.setdefault("flow_seconds", 660)
                case.setdefault("limits", {})
            if (self.path/"case.json").exists():
                persisted = read(self.path/"case.json")
                require(case is None or case == persisted, "Case changed on resume", "V2_CASE_CHANGED")
                self.case = persisted
            else:
                require(case is not None and case["policy"] in POLICIES, "Explicit fake case required", "V2_CASE_REQUIRED")
                self.case = deepcopy(case)
                require(0 < self.case["flow_seconds"] <= 660, "Invalid fixed deadline", "V2_LIMITS")
                write(self.path/"case.json", self.case)
                write(self.path/"prompt_spec.json", read(CONFIG/"prompt_spec.json"))
            self.spec = read(self.path/"prompt_spec.json")
            self.store = Store(self.path/"run.sqlite")
            state = self.store.control()
            if state is None:
                rid = self.store.initialize_run(self.case["task"])
                now, wall = time.monotonic(), time.time()
                state = dict(schema_version="safety-reliability-control-v2", branch_id=new_id(), run_id=rid,
                    case_digest=digest(self.case), prompt_sha256=sha(self.path/"prompt_spec.json"),
                    policy=self.case["policy"], status="running", stop_reason=None, selected={}, pending=None,
                    created_monotonic=now, created_unix=wall, deadline_monotonic=now+self.case["flow_seconds"],
                    deadline_unix=wall+self.case["flow_seconds"], initial_sources=deepcopy(self.case["task"]["initial_objects"]))
                with self.store._transaction(write=True):
                    self.store.set_control(state)
            require(state["case_digest"] == digest(self.case) and state["prompt_sha256"] == sha(self.path/"prompt_spec.json"),
                    "Frozen v2 configuration changed", "V2_CASE_CHANGED")
            pinned = binding()
            limits = dict(call_cap=8, slot_call_cap=5, logical_call_cap=8, input_token_cap=32000,
                          output_token_cap=6144, max_cost_nano_usd=8*CALL_RESERVATION)
            limits.update(self.case["limits"])
            require(limits["call_cap"] <= 8 and limits["logical_call_cap"] <= 8,
                    "v2 cannot exceed eight calls", "V2_LIMITS")
            self.budget = DurableP3Budget(self.path/"fake_budget.sqlite", campaign_id=state["branch_id"],
                                         binding=pinned.to_dict(), limits=limits)
            self.store.bind_p3(pinned, self.budget.ref)
            self.transcript = Transcript(self.case, self.case["recipe"])
            self.transcript.occurrence = lambda step: self.store.connection.execute(
                "SELECT MAX(attempt_no) FROM attempts WHERE step_id=?", (step,)).fetchone()[0]
            self.sender = FakeHTTPSender([self.transcript.respond]*8)
            client = DeadlineClient(pinned, self.sender, self.remaining)
            self.gateway = Gateway(client, self.budget, store=self.store, prompt_spec=self.spec,
                prompt_sha256=state["prompt_sha256"], branch_id=state["branch_id"], remaining=self.remaining)
            self.flow = Workflow(self.store, self.gateway, hooks=Hooks(self))
            self._advancing = False
        except BaseException:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        if self.budget is not None:
            self.budget.close(); self.budget = None
        if self.store is not None:
            self.store.close(); self.store = None
        if not self.lock.closed:
            fcntl.flock(self.lock, fcntl.LOCK_UN); self.lock.close()

    def remaining(self):
        state = self.store.control()
        if time.monotonic() < state["created_monotonic"]:
            return -1
        return min(state["deadline_monotonic"]-time.monotonic(), state["deadline_unix"]-time.time())

    def sources(self):
        return self.store.read_objects(list(sources_for(self.case["task"]["request"])))

    def _terminal(self, state, status, reason):
        state.update(status=status, stop_reason=reason, pending=None)
        if status == "uncertain":
            self.store.connection.execute("UPDATE attempts SET status='uncertain' WHERE status='active'")
        self.store.connection.execute("UPDATE runs SET mode=?", ("uncertain" if status == "uncertain" else "terminal",))
        self.store._event("v2", state["branch_id"], "v2_terminal", [])
        repair = self.store.repair()
        if repair:
            repair["status"] = status
            self.store.connection.execute("UPDATE v2_repair SET body=?", (canonical(repair),))
        return state

    def _failure(self, result, verification):
        snapshot = self.store.snapshot_run()
        sources, req = self.sources(), self.case["task"]["request"]
        expected = expected_config(req, sources)
        guard = next((g for g in snapshot["business_guard_checks"] if g["result_id"] == result["result_id"]), None)
        roots, diffs = [], []
        code = (result.get("error") or {}).get("code")
        origin = "INTERMEDIATE_VERIFY" if verification else "PRECOMMIT_GUARD" if guard else "EXECUTION"
        if verification:
            code = "VERIFIER_STALE_SOURCE" if any("STALE" in r for r in verification["reason_codes"]) else "VERIFIER_BUSINESS_MISMATCH"
        kind = "semantic_mismatch"
        if sources != self.store.control()["initial_sources"] or code in ("STALE_SOURCE", "VERIFIER_STALE_SOURCE"):
            kind = "source_changed"
        elif expected["permission_allowed"] is not True:
            kind = "permission_denied"
        elif guard and guard["raw_command"]["arguments"]["workers"] > expected["workers"]:
            kind = "resource_violation"
        elif code not in ("BUSINESS_VALIDATION_FAILED", "VERIFIER_BUSINESS_MISMATCH"):
            kind = "unrepairable_execution"
        else:
            by_step = {r["step_id"]: r for r in snapshot["results"]
                       if r["result_id"] in set(self.store.control()["selected"].values()) | {result["result_id"]}}
            for step, source in zip(STEPS[:3], sources):
                reader = by_step.get(step)
                if reader:
                    delta = differences(reader["payload"], source["payload"], step+".payload")
                    if delta:
                        roots.append(reader["result_id"]); diffs += delta
            if not roots and "plan" in by_step:
                delta = differences(by_step["plan"]["payload"], expected, "plan.payload")
                if delta:
                    roots.append(by_step["plan"]["result_id"]); diffs += delta
            if not roots and guard:
                delta = differences(guard["raw_command"]["arguments"], expected, "command.arguments")
                if delta:
                    roots.append(result["result_id"]); diffs += delta
            if not roots:
                kind = "unrepairable_execution"
        return dict(schema_version="v2-failure-evidence", failure_id=new_id(), origin=origin, kind=kind,
            candidate_ref=result["result_id"], candidate_digest=digest(result), step_id=result["step_id"],
            execution_status=result["execution_status"], error_code=code, root_result_ids=roots,
            differences=diffs, source_objects=sources, parent_result_ids=result["parent_result_ids"],
            verification=deepcopy(verification), guard_record_digest=digest(guard) if guard else None,
            writes_applied=len(snapshot["effects"]), result_count=len(snapshot["results"]),
            calls_before=len(self.budget.calls()), sources_digest=digest(sources))

    def _claim(self, state, evidence, ledger):
        if state["policy"] == "VERIFY_STOP":
            return self._terminal(state, "safe_stopped", "VERIFY_STOP")
        if evidence["kind"] != "semantic_mismatch" or evidence["writes_applied"]:
            return self._terminal(state, "safe_stopped", evidence["kind"].upper())
        if self.store.repair():
            return self._terminal(state, "safe_stopped", "REPAIR_LIMIT_REACHED")
        results = [json.loads(r[0]) for r in self.store.connection.execute("SELECT body FROM results ORDER BY rowid")]
        invalid = set(evidence["root_result_ids"])
        for row in results:
            if set(row["parent_result_ids"]) & invalid:
                invalid.add(row["result_id"])
        selected = {step: rid for step, rid in state["selected"].items() if rid not in invalid}
        queue = [step for step in STEPS if step not in selected]
        seen = {row["step_id"] for row in results}
        replay = [step for step in queue if step in seen]
        unstarted = [step for step in queue if step not in seen]
        if len(replay) > 3:
            return self._terminal(state, "safe_stopped", "REPAIR_EXTRA_LIMIT")
        if (len(ledger["calls"])+len(queue) > self.budget.config["limits"]["call_cap"]
                or len(ledger["calls"])+len(queue) > 8
                or ledger["budget"]["remaining_cost_nano_usd"] < len(queue)*CALL_RESERVATION):
            return self._terminal(state, "safe_stopped", "REPAIR_BUDGET_EXHAUSTED")
        if self.remaining() <= 0:
            return self._terminal(state, "safe_stopped", "TOTAL_DEADLINE")
        feedback = dict(schema_version="v2-public-repair-feedback", failure_ref=evidence["failure_id"],
            evidence_digest=digest(evidence), differences=evidence["differences"],
            instruction="Correct these differences using the supplied inputs. Do not grant permissions or change source versions.")
        record = dict(schema_version="v2-repair-admission", repair_id=new_id(), branch_id=state["branch_id"],
            round_no=1, status="active", first_failure_id=evidence["failure_id"],
            first_candidate_ref=evidence["candidate_ref"], first_failure_digest=digest(evidence),
            invalidated_result_ids=[r["result_id"] for r in results if r["result_id"] in invalid],
            replay_steps=replay, unstarted_steps=unstarted, execution_queue=queue,
            retained_result_ids=[state["selected"][s] for s in STEPS if s in selected],
            selected_before=deepcopy(state["selected"]), selected_after_claim=selected,
            source_objects=evidence["source_objects"], deadline_monotonic=state["deadline_monotonic"],
            deadline_unix=state["deadline_unix"], calls_before=len(ledger["calls"]),
            max_extra_calls=3, max_total_calls=8, feedback=feedback)
        require(not self.store.connection.execute("SELECT 1 FROM attempts WHERE status='active'").fetchone(),
                "Repair cannot follow an active attempt", "V2_UNCERTAIN_ATTEMPT")
        require(not self.store.connection.execute("SELECT 1 FROM effects WHERE state='applied'").fetchone(),
                "Repair cannot follow a write", "V2_UNCERTAIN_COMMIT")
        current = [json.loads(self.store.connection.execute("SELECT body FROM objects WHERE object_key=?", (key,)).fetchone()[0])
                   for key in sources_for(self.case["task"]["request"])]
        require(current == evidence["source_objects"], "Source changed while claiming repair", "V2_SOURCE_DRIFT")
        self.store.connection.execute("INSERT INTO v2_repair VALUES(?,?)", (state["branch_id"], canonical(record)))
        sequence = self.store._event("v2", record["repair_id"], "v2_claim_repair", record["invalidated_result_ids"])
        for row in results:
            if row["result_id"] in invalid and row["execution_status"] == "success":
                event = dict(event_seq=sequence, result_id=row["result_id"], validity="invalidated", reasons=["v2_semantic_repair"])
                self.store.connection.execute("INSERT INTO result_status_events VALUES(?,?,?)",
                    (sequence, row["result_id"], canonical(event)))
        state["selected"] = selected
        return state

    def _process(self, request_id, result=None, verification=None, terminal=None):
        ledger = self.budget.snapshot()
        evidence = self._failure(result, verification) if result is not None and (
            verification or result["execution_status"] != "success") else None
        with self.store._transaction(write=True):
            state = self.store.control()
            pending = deepcopy(state["pending"])
            if evidence:
                self.store.connection.execute("INSERT INTO v2_failures VALUES(?,?)", (evidence["failure_id"], canonical(evidence)))
            if terminal:
                state = self._terminal(state, *terminal)
            elif ledger["status"] != "active" or any(c["status"] != "settled" for c in ledger["calls"]):
                state = self._terminal(state, "uncertain" if ledger["budget"]["held_cost_nano_usd"] else "safe_stopped", "BUDGET_OR_SETTLEMENT_FENCED")
            elif result and result["step_id"] == "execute" and result["execution_status"] == "success":
                # A known atomic commit is acknowledged even if local receipt
                # bookkeeping crosses the cutoff. Never relabel that write as
                # a safe stop with no effects or dispatch it a second time.
                state["selected"]["execute"] = result["result_id"]
                state = self._terminal(state, "completed", None)
            elif self.remaining() <= 0:
                state = self._terminal(state, "safe_stopped", "TOTAL_DEADLINE")
            elif evidence:
                state = self._claim(state, evidence, ledger)
            else:
                state["selected"][result["step_id"]] = result["result_id"]
                if result["step_id"] == "execute":
                    state = self._terminal(state, "completed", None)
            state["pending"] = None
            self.store.set_control(state)
            saved_pending = (pending or {}).get("result_id")
            if saved_pending and not self.store.connection.execute("SELECT 1 FROM results WHERE result_id=?", (saved_pending,)).fetchone():
                saved_pending = None
            receipt = dict(request_id=request_id, status="done", step=pending["step"] if pending else None,
                result_id=result["result_id"] if result else saved_pending,
                verification_rejected=bool(verification), failure_ref=evidence["failure_id"] if evidence else None,
                quarantined_publication=bool(result is None and saved_pending),
                resulting_status=state["status"], stop_reason=state["stop_reason"],
                repair_claimed=bool(self.store.repair()), call_ids=[c["call_id"] for c in ledger["calls"]])
            self.store.connection.execute("UPDATE v2_advances SET body=? WHERE request_id=?", (canonical(receipt), request_id))
        return receipt

    def advance(self, request_id):
        require(isinstance(request_id, str) and 0 < len(request_id) <= 128, "Explicit advance identity required", "V2_ADVANCE_ID")
        require(not self._advancing, "One serial advance only", "V2_RUNNER_BUSY")
        self._advancing = True
        try:
            previous = self.store.connection.execute("SELECT body FROM v2_advances WHERE request_id=?", (request_id,)).fetchone()
            if previous and json.loads(previous[0])["status"] == "done":
                return json.loads(previous[0])
            state = self.store.control()
            if state["status"] != "running":
                return dict(request_id=request_id, status="no_op", resulting_status=state["status"], calls_issued=0)
            if state["pending"]:
                # A published, settled result may be reconciled without dispatch.
                pending = state["pending"]
                row = self.store.connection.execute("SELECT body FROM results WHERE result_id=?", (pending.get("result_id"),)).fetchone()
                if row and all(c["status"] == "settled" for c in self.budget.calls()):
                    result = json.loads(row[0])
                    vr = self.store.connection.execute("SELECT body FROM v2_verifications WHERE result_id=?", (result["result_id"],)).fetchone()
                    if state["policy"] in ("VERIFY_REPAIR", "VERIFY_STOP") and result["step_id"] != "execute" and not vr:
                        return self._process(pending["request_id"], terminal=("uncertain", "INTERRUPTED_VERIFICATION"))
                    verification = json.loads(vr[0])["receipt"] if vr else None
                    if verification and verification["decision"] == "accept": verification = None
                    return self._process(pending["request_id"], result, verification)
                return self._process(pending["request_id"], terminal=("uncertain", "INTERRUPTED_ADVANCE_NO_REDISPATCH"))
            step = next(s for s in STEPS if s not in state["selected"])
            with self.store._transaction(write=True):
                state["pending"] = dict(request_id=request_id, step=step)
                self.store.set_control(state)
                self.store.connection.execute("INSERT INTO v2_advances VALUES(?,?)",
                    (request_id, canonical(dict(request_id=request_id, step=step, status="started"))))
            if self.sources() != state["initial_sources"]:
                return self._process(request_id, terminal=("safe_stopped", "SOURCE_CHANGED"))
            if self.remaining() <= 0:
                return self._process(request_id, terminal=("safe_stopped", "TOTAL_DEADLINE"))
            try:
                result = self.flow.run_step(step, [state["selected"][s] for s in PARENTS[step]])
                return self._process(request_id, result)
            except VerificationStopped as stopped:
                result = self.store.get_result(stopped.receipt["candidate_ref"])
                return self._process(request_id, result, stopped.receipt)
            except CommitOutcomeUnknown:
                return self._process(request_id, terminal=("uncertain", "UNKNOWN_COMMIT_OUTCOME"))
            except ContractError as error:
                return self._process(request_id, terminal=("uncertain", error.code))
        finally:
            self._advancing = False

    def run(self):
        for _ in range(12):
            state = self.store.control()
            if state["status"] != "running":
                return state
            request_id = state["pending"]["request_id"] if state["pending"] else new_id()
            self.advance(request_id)
        raise RuntimeError("V2_SINGLE_ADVANCE_BOUND_EXCEEDED")

    def export(self):
        state = self.store.control()
        snapshot = self.store.snapshot_run()
        ledger = self.budget.snapshot()
        all_evidence = [c["evidence"] for c in ledger["calls"] if c.get("evidence")]
        report = dict(schema_version="v2-offline-report", fixture_id=self.case["fixture_id"],
            status=state["status"], stop_reason=state["stop_reason"], selected=state["selected"],
            fake_http_calls=sum(c["dispatched"] for c in ledger["calls"]),
            repeated_model_calls=sum(c["attempt_no"] > 1 and c["dispatched"] for c in ledger["calls"]),
            repair_rounds=int(bool(self.store.repair())), real_api_requests=0, credentials_read=0,
            training_or_prediction_calls=0, provider_debit_nano_usd=0,
            usage_and_cost_are_synthetic=True,
            evidence_kind="saved-v1-content-replayed-under-v2-prompts-then-scripted-correction",
            prompt_effect_on_real_model_measured=False)
        for name, value in (("snapshot", snapshot), ("campaign", ledger), ("gateway_records", all_evidence),
                            ("accounting", self.store.model_accounting_snapshot()), ("report", report)):
            write(self.path/(name+".json"), value)
        write(self.path/"artifacts.json", {p.name:dict(sha256=sha(p), bytes=p.stat().st_size)
            for p in sorted(self.path.iterdir()) if p.is_file() and p.name != "advance.lock"})
        return report
