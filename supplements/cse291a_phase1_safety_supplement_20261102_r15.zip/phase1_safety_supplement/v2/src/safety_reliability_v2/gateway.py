"""New prompt binding on the unchanged P3 accounting and fake-HTTP path."""
from copy import deepcopy
import json
from time import monotonic

from agent_recovery.contracts import new_id, require
from agent_recovery.p3_gateway import P3ModelGateway
from agent_recovery.p3_transport import (FakeHTTPSender, HTTPResponse, P3HTTPClient, P3Binding,
                                         fake_http_response)
from .contracts import canonical, digest, normal_payload, render


def binding():
    return P3Binding(binding_ref="fixture:safety-reliability-v2", model="fixture-safety-reliability-v2",
        allowed_response_models=("fixture-safety-reliability-v2",), timeout_s=120,
        input_nano_usd_per_token=150, output_nano_usd_per_token=500,
        price_evidence="fixture:synthetic-accounting-not-provider-debit", temperature=None,
        reasoning_effort="low", supported_parameters=("model", "messages", "n", "stream",
            "max_completion_tokens", "response_format", "reasoning_effort"))


class Transcript:
    """First occurrences replay saved content; later replies use public inputs only."""
    def __init__(self, fixture, recipe=None):
        self.fixture, self.recipe = fixture, recipe or {}
        self.replies = []

    def respond(self, wire):
        request = json.loads(wire.body)
        envelope = json.loads(request["messages"][1]["content"])
        step, bundle = envelope["step_id"], envelope["input"]
        # After a process reopen the persisted sidecar supplies occurrence.
        occurrence = self.occurrence(step)
        saved = self.fixture["original_responses"].get(step)
        source = saved if occurrence == 1 else None
        payload = normal_payload(step, bundle)
        content = source["content"] if source else canonical(payload)
        origin = dict(kind="saved-v1-content" if source else "scripted-from-public-input",
                      original_call_id=source["original_call_id"] if source else None)
        fault = self.recipe
        if fault.get("step", "read_metadata") == step:
            if fault.get("repeat_error") and occurrence > 1 and saved:
                content = saved["content"]; origin["kind"] = "scripted-repeat-error"
            if fault.get("payload_override") is not None and occurrence == fault.get("occurrence", 1):
                content = canonical(fault["payload_override"]); origin["kind"] = "scripted-adversarial-payload"
        prompt_tokens = max(1, (len(wire.body)+3)//4)
        completion_tokens = max(1, (len(content.encode())+3)//4)
        response = fake_http_response({}, model=request["model"], request_id="v2-fake-"+new_id(),
                                      prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)
        body = json.loads(response.body)
        body["choices"][0]["message"]["content"] = content
        body["v2_fixture_origin"] = origin
        if fault.get("kind") == "missing_usage" and fault.get("step", "read_metadata") == step:
            body.pop("usage")
        if fault.get("kind") == "delay" and fault.get("step", "read_metadata") == step:
            import time
            time.sleep(fault["seconds"])
        self.replies.append(dict(step=step, occurrence=occurrence, origin=origin))
        return HTTPResponse(response.status, response.headers, canonical(body).encode())


class DeadlineClient(P3HTTPClient):
    def __init__(self, pinned, sender, remaining):
        require(pinned.simulated and type(sender) is FakeHTTPSender, "Offline v2 is fake-only", "V2_LIVE_DISABLED")
        super().__init__(pinned, sender)
        self.remaining = remaining

    def create(self, request, *, timeout_s, before_send=None, deadline_monotonic=None):
        remaining = self.remaining()
        require(remaining > 0, "Fixed flow deadline expired", "V2_TOTAL_DEADLINE")
        timeout = min(timeout_s, remaining)
        deadline = min(deadline_monotonic or monotonic()+timeout, monotonic()+timeout)
        return super().create(request, timeout_s=timeout, deadline_monotonic=deadline, before_send=before_send)


class Gateway(P3ModelGateway):
    prompt_revision = "safety-model-v2"

    def __init__(self, client, campaign, *, store, prompt_spec, prompt_sha256, branch_id, remaining):
        require(client.binding.simulated, "Live v2 is not implemented", "V2_LIVE_DISABLED")
        super().__init__(client, campaign, trial_key=branch_id, branch_id=branch_id, logical_run_key=branch_id)
        self.store, self.spec, self.spec_sha = store, prompt_spec, prompt_sha256
        self.remaining = remaining

    def prepare_input(self, attempt, step_id, bundle, public_carriers):
        state = self.store.control()
        require(state["status"] == "running" and state["pending"]["step"] == step_id,
                "Dispatch requires its persisted single advance", "V2_STALE_ADVANCE")
        self.store.bind_pending_attempt(attempt)
        repeated = attempt["attempt_no"] > 1
        calls = self.store.model_accounting_snapshot()["calls"]
        require(len(calls) < 8 and sum(c["attempt_no"] > 1 for c in calls)+int(repeated) <= 3,
                "Eight total and three repeated calls only", "V2_CALL_LIMIT")
        repair = self.store.repair()
        feedback = repair["feedback"] if repair else None
        if repeated:
            require(repair and step_id in repair["replay_steps"], "Repetition lacks repair admission", "V2_REPAIR_NOT_ADMITTED")
        self.phase = "replay" if repair else "initial"
        self.trial_key = self.branch_id+("__repair01" if repair else "")
        messages = render(self.spec, step_id, bundle, public_carriers, feedback)
        sidecar = dict(sidecar_id=new_id(), call_id=None, attempt_id=attempt["token"],
            step_id=step_id, result_id=attempt["result_id"], run_id=attempt["run_id"],
            branch_id=self.branch_id, trial_key=self.trial_key, logical_run_key=self.logical_run_key,
            phase=self.phase, prompt_revision=self.prompt_revision, prompt_spec_digest=self.spec_sha,
            input_bundle=deepcopy(bundle), public_carriers=deepcopy(public_carriers),
            repair_feedback=deepcopy(feedback), bundle_digest=digest(bundle),
            public_carriers_digest=digest(public_carriers), rendered_messages_digest=digest(messages),
            rendered_messages=messages)
        self._prepared[attempt["result_id"]] = sidecar
        self._current = sidecar
        return deepcopy(sidecar)

    def render(self, role, input_bundle):
        current = self._current
        require(current is not None and current["step_id"] == role and current["input_bundle"] == input_bundle,
                "Unprepared v2 model input", "V2_INPUT_MISMATCH")
        return render(self.spec, role, input_bundle, current["public_carriers"], current["repair_feedback"])
