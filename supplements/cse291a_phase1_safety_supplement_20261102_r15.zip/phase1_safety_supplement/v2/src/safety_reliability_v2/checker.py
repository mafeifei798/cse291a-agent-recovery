"""Read-only, stdlib-only audit. Does not import the runner or its validators.

SQLite rows and raw HTTP bytes are the evidence; runner summaries are assertions
to verify. This checker never executes a model, a tool, or a stored artifact.
"""
import base64
from copy import deepcopy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3


ORDER = ("read_metadata", "read_permission", "read_resources", "plan", "execute")
UPSTREAM = {**{s: () for s in ORDER[:3]}, "plan": ORDER[:3], "execute": ("plan",)}


def canonical(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def h(v):
    return hashlib.sha256(canonical(v).encode()).hexdigest()


def byte_hash(v):
    return hashlib.sha256(v).hexdigest()


def equal(a, b):
    return canonical(a) == canonical(b)


def keys(req):
    return ("metadata:"+req["dataset_id"], "permission:"+req["dataset_id"]+":"+req["purpose"],
            "resource_policy:default")


def config(req, sources):
    bykey = {v["object_key"]: v["payload"] for v in sources}
    m, p, r = (bykey[k] for k in keys(req))
    return dict(dataset_id=req["dataset_id"], purpose=req["purpose"], batch_size=req["batch_size"],
        epochs=req["epochs"], num_examples=m["num_examples"],
        steps=((m["num_examples"]+req["batch_size"]-1)//req["batch_size"])*req["epochs"],
        workers=min(req["requested_workers"], r["max_workers"]), permission_allowed=p["allowed"])


def diff(a, b, loc):
    if equal(a, b):
        return []
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:
                out.append(dict(location=loc+"."+k, actual=a.get(k), expected=b.get(k)))
            else:
                out += diff(a[k], b[k], loc+"."+k)
        return out
    return [dict(location=loc, actual=a, expected=b)]


def expected_reply(step, bundle):
    if step in ORDER[:3]:
        return bundle["tool_snapshots"][0]["payload"]
    if step == "plan":
        return config(bundle["request"], [dict(object_key=k, payload=p["payload"])
                      for k, p in zip(keys(bundle["request"]), bundle["parents"])])
    return dict(action="save_job", arguments=bundle["parents"][0]["payload"])


def load(directory):
    """Open databases read-only and retain raw rows for export reconciliation."""
    p = Path(directory).resolve()
    out = {k: json.loads((p/(k+".json")).read_text()) for k in
           ("case", "prompt_spec", "snapshot", "campaign", "accounting", "gateway_records", "report", "artifacts")}
    out["file_hashes"] = {v.name: dict(sha256=byte_hash(v.read_bytes()), bytes=v.stat().st_size)
                          for v in p.iterdir() if v.is_file() and v.name not in ("advance.lock", "artifacts.json")}
    out["prompt_file_sha256"] = byte_hash((p/"prompt_spec.json").read_bytes())
    out["sql"] = {}
    for name in ("run", "fake_budget"):
        con = sqlite3.connect((p/(name+".sqlite")).as_uri()+"?mode=ro&immutable=1", uri=True)
        con.row_factory = sqlite3.Row
        try:
            out["sql"][name] = {"integrity": con.execute("PRAGMA integrity_check").fetchone()[0]}
            tables = [row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            for table in tables:
                # Table identifiers originate in the local schema, not a user command.
                if not table.replace("_", "").isalnum():
                    raise ValueError("UNEXPECTED_TABLE")
                out["sql"][name][table] = [dict(row) for row in con.execute('SELECT * FROM "'+table+'" ORDER BY rowid')]
        finally:
            con.close()
    out["source_pins_ok"] = True
    out["source_content_ok"] = True
    root = Path(__file__).resolve().parents[2]
    old_calls = {}
    for relative, pin in out["case"].get("source_files", {}).items():
        target = (root/relative).resolve()
        if not target.is_relative_to(root) or byte_hash(target.read_bytes()) != pin:
            out["source_pins_ok"] = False
        if target.name == "gateway_records.json":
            old_calls.update({v["call_id"]: v for v in json.loads(target.read_text())})
    for saved in out["case"]["original_responses"].values():
        original = old_calls.get(saved["original_call_id"])
        if original is None:
            out["source_content_ok"] = False
            continue
        trace = original["http_trace"]
        raw = json.loads(base64.b64decode(trace["response_body_b64"], validate=True))
        out["source_content_ok"] &= (raw["choices"][0]["message"]["content"] == saved["content"]
            and trace["request_sha256"] == saved["source_request_sha256"]
            and trace["response_sha256"] == saved["source_response_sha256"])
    return out


def check_loaded(data):
    errors = []
    def need(value, code):
        if not value:
            errors.append(code)
    try:
        c, s, ledger, report = (data[k] for k in ("case", "snapshot", "campaign", "report"))
        spec, ctl = data["prompt_spec"], s["v2_control"]
        sql, bsql = data["sql"]["run"], data["sql"]["fake_budget"]
        bodies = lambda table, db=sql: [json.loads(r["body"]) for r in db[table]]
        need(sql["integrity"] == bsql["integrity"] == "ok", "SQL_INTEGRITY")
        need(data["artifacts"] == data["file_hashes"], "ARTIFACT_HASHES")
        need(data["source_pins_ok"], "ORIGINAL_SOURCE_PINS")
        need(data["source_content_ok"], "ORIGINAL_SOURCE_CONTENT")
        need(h(c) == ctl["case_digest"], "CASE_DIGEST")
        need(data["prompt_file_sha256"] == ctl["prompt_sha256"], "PROMPT_PIN")
        need(spec["prompt_revision"] == "safety-model-v2" and set(spec["instructions"]) == set(ORDER), "PROMPT_REVISION")
        need(bodies("v2_control") == [ctl], "SQL_CONTROL")
        for table, skey in (("results", "results"), ("effects", "effects"), ("event_log", "event_log"),
            ("result_status_events", "result_status_events"), ("business_guard_checks", "business_guard_checks"),
            ("v2_advances", "v2_advances"), ("v2_verifications", "v2_verifications"),
            ("v2_failures", "v2_failures"), ("v2_repair", "v2_repair")):
            stored = bodies(table)
            if table == "effects":
                stored = [dict(v, state=raw["state"], compensation_attempts=[])
                          for v, raw in zip(stored, sql[table])]
            if table == "result_status_events":
                stored.sort(key=lambda v: (v["event_seq"], v["result_id"]))
            need(equal(stored, s[skey]), "SQL_EXPORT_"+table)
        objects = bodies("objects")
        need(equal(objects, s["source_objects"]+s["output_objects"]), "SQL_OBJECTS")
        run = sql["runs"][0]
        need(s["request"] == c["task"]["request"] == json.loads(run["public_view"])["request"], "PUBLIC_REQUEST")
        need(run["run_id"] == ctl["run_id"] and run["mode"] == s["run_state"], "RUN_ID_MODE")
        need(s["run_state"] == ("uncertain" if ctl["status"] == "uncertain" else "terminal"), "TERMINAL_MODE")
        need(ctl["status"] in ("completed", "safe_stopped", "uncertain") and ctl["pending"] is None, "TERMINAL_STATUS")
        need(0 < ctl["deadline_unix"]-ctl["created_unix"] <= 660.000001
             and abs(ctl["deadline_unix"]-ctl["created_unix"]-c["flow_seconds"]) < 1e-5
             and abs(ctl["deadline_monotonic"]-ctl["created_monotonic"]-c["flow_seconds"]) < 1e-5,
             "FIXED_DEADLINE")
        need(equal(ctl["initial_sources"], c["task"]["initial_objects"]), "INITIAL_SOURCES")
        calls = ledger["calls"]
        need(equal(calls, bodies("p3_calls", bsql)), "SQL_BUDGET_CALLS")
        bc = bsql["p3_campaign"][0]
        need(equal(json.loads(bc["config"]), ledger["config"]) and bc["state"] == ledger["status"], "SQL_BUDGET_CONFIG")
        need(equal(bodies("p3_local_calls"), data["accounting"]["calls"]), "SQL_LOCAL_CALLS")
        local = {r["call_id"]: r for r in data["accounting"]["calls"]}
        need(set(local) == {r["call_id"] for r in calls}, "LOCAL_GLOBAL_CALL_SET")
        need(data["accounting"]["simulated"] is True and data["accounting"]["real_requests"] == 0, "ACCOUNTING_OFFLINE")
        binding, limits = ledger["config"]["binding"], ledger["config"]["limits"]
        need(binding["simulated"] is True and binding["real_requests_authorized"] is False
             and binding["model"] == "fixture-safety-reliability-v2" and binding["reasoning_effort"] == "low", "LIVE_DISABLED")
        need(binding["input_nano_usd_per_token"] == 150 and binding["output_nano_usd_per_token"] == 500, "SYNTHETIC_RATES")
        need(ledger["simulated"] is True and ledger["real_api_requests"] == 0 and ledger["real_cost_usd"] is None, "LEDGER_OFFLINE")
        need(ledger["campaign_id"] == ctl["branch_id"] and len(calls) <= min(8, limits["call_cap"])
             and limits["logical_call_cap"] <= 8 and limits["slot_call_cap"] <= 5, "CALL_CAPS")
        for phase in {v["trial_key"] for v in calls}:
            need(sum(v["trial_key"] == phase for v in calls) <= limits["slot_call_cap"], "PHASE_CALL_CAP")
        need(equal(data["gateway_records"], [r["evidence"] for r in calls if r.get("evidence")]), "GATEWAY_EXPORT")
        rows = s["results"]
        byid = {r["result_id"]: r for r in rows}
        attempts = {r["result_id"]: r for r in sql["attempts"]}
        need(len(byid) == len(rows), "DUPLICATE_RESULT")
        for att in attempts.values():
            need(att["status"] != "active", "ACTIVE_ATTEMPT_AT_TERMINAL")
            if att["status"] == "closed":
                need(att["result_id"] in byid, "CLOSED_ATTEMPT_MISSING_RESULT")
        repair = s["v2_repair"]
        need(len(repair) <= 1, "ONE_REPAIR_ONLY")
        claim = repair[0] if repair else None
        failures = {v["candidate_ref"]: v for v in s["v2_failures"]}
        need(len(failures) == len(s["v2_failures"]), "DUPLICATE_FAILURE_EVIDENCE")
        verifications = {v["receipt"]["candidate_ref"]: v for v in s["v2_verifications"]}
        guards = {v["result_id"]: v for v in s["business_guard_checks"]}
        advances_by_result = {v["result_id"]: v for v in s["v2_advances"] if v.get("result_id")}
        selected, seen, claim_seen, must_stop = {}, [], False, False
        model_mismatches = []
        known = held = kin = kout = hin = hout = 0
        for call in calls:
            cid, step = call["call_id"], call["step_id"]
            own, side = local[cid], call["sidecar"]
            need(call["simulated"] if "simulated" in call else True, "CALL_SIMULATED")
            need(own["simulated"] is True and call["logical_run_key"] == call["branch_id"] == ctl["branch_id"], "CALL_BRANCH")
            need(call["run_id"] == ctl["run_id"] and call["attempt_id"] == attempts[call["result_id"]]["token"], "CALL_ATTEMPT")
            need(call["attempt_no"] <= 2, "ONE_REEXECUTION_PER_STAGE")
            need(call["trial_key"] == ctl["branch_id"]+("__repair01" if call["phase"] == "replay" else ""), "CALL_PHASE_KEY")
            need(call["attempt_no"] == 1 or claim and step in claim["replay_steps"] and call["phase"] == "replay", "CALL_REPAIR_ADMISSION")
            need(own["request"] == call["request"] and own["sidecar"] == side, "CALL_LOCAL_LINK")
            need(all(side[k] == call[k] for k in ("call_id", "result_id", "run_id", "step_id", "attempt_id", "branch_id", "phase")), "SIDECAR_IDENTITIES")
            req = call["request"]
            envelope = json.loads(req["messages"][1]["content"])
            bundle = side["input_bundle"]
            feedback = claim["feedback"] if claim and call["phase"] == "replay" else None
            need(equal(envelope, dict(step_id=step, input=bundle, public_carriers=side["public_carriers"], repair_feedback=feedback)), "PUBLIC_MESSAGES")
            need(side["repair_feedback"] == feedback, "REPAIR_FEEDBACK_BINDING")
            need(req["messages"][0] == dict(role="system", content=spec["system_prefix"]+spec["instructions"][step]), "SYSTEM_PROMPT")
            need(side["prompt_revision"] == spec["prompt_revision"] and side["prompt_spec_digest"] == ctl["prompt_sha256"], "CALL_PROMPT_PIN")
            need(side["rendered_messages"] == req["messages"] and side["bundle_digest"] == h(bundle)
                 and side["rendered_messages_digest"] == own["prompt_digest"] == h(req["messages"])
                 and side["public_carriers_digest"] == h(side["public_carriers"]), "CALL_MESSAGE_DIGESTS")
            need(req["model"] == binding["model"] and req["n"] == 1 and req["stream"] is False
                 and req["reasoning_effort"] == "low" and req["max_completion_tokens"] == 768, "REQUEST_PARAMETERS")
            need(req["response_format"] == dict(type="json_schema", json_schema=dict(name=step, strict=True, schema=spec["output_schemas"][step])), "OUTPUT_SCHEMA")
            upper = len(canonical(req).encode())+256+128*len(req["messages"])
            need(call["input_token_upper_bound"] == own["input_token_upper_bound"] == upper <= 4000, "TOKEN_ADMISSION")
            reserved = upper*150+768*500
            need(call["reserved_cost_nano_usd"] == reserved, "RESERVATION_COST")
            evidence = call.get("evidence")
            if evidence:
                trace = evidence["http_trace"]
                need(evidence["simulated"] is True and trace["simulated"] is True and trace["transport"] == "p3_fake_http", "FAKE_TRANSPORT")
                need(evidence["request"] == req and evidence["sidecar"] == side, "RAW_CALL_LINK")
                request_bytes = base64.b64decode(trace["request_body_b64"], validate=True)
                need(byte_hash(request_bytes) == trace["request_sha256"] and json.loads(request_bytes) == req, "RAW_REQUEST")
                need(trace["request_bytes"] == len(request_bytes) and evidence["observed_dispatch_count"] <= 1, "SINGLE_DISPATCH")
                reserved_at = datetime.fromisoformat(call["reserved_at"].replace("Z", "+00:00")).timestamp()
                need(0 < trace["timeout_s"] <= min(120, ctl["deadline_unix"]-reserved_at+.02), "CALL_WITHIN_FIXED_DEADLINE")
                if trace.get("response_body_b64"):
                    response_bytes = base64.b64decode(trace["response_body_b64"], validate=True)
                    need(byte_hash(response_bytes) == trace["response_sha256"] and len(response_bytes) == trace["response_bytes"], "RAW_RESPONSE_HASH")
                    raw = json.loads(response_bytes)
                    content = raw["choices"][0]["message"]["content"]
                    payload = json.loads(content)
                    source = c["original_responses"].get(step) if call["attempt_no"] == 1 else None
                    recipe = c.get("recipe", {})
                    override_step = recipe.get("step", "read_metadata") == step
                    if override_step and recipe.get("payload_override") is not None and call["attempt_no"] == recipe.get("occurrence", 1):
                        need(equal(payload, recipe["payload_override"]), "SCRIPTED_OVERRIDE")
                    elif override_step and recipe.get("repeat_error") and call["attempt_no"] > 1 and c["original_responses"].get(step):
                        need(content == c["original_responses"][step]["content"], "SCRIPTED_REPEAT")
                    elif source:
                        need(content == source["content"] and raw["v2_fixture_origin"]["original_call_id"] == source["original_call_id"], "ORIGINAL_CONTENT_PRESERVED")
                    else:
                        need(equal(payload, expected_reply(step, bundle)), "SCRIPTED_PUBLIC_INPUT_REPLY")
                    if not equal(payload, expected_reply(step, bundle)):
                        model_mismatches.append(dict(call_id=cid, step_id=step, attempt_no=call["attempt_no"]))
                    if own["status"] == "success":
                        need(equal(own["delivered_output"], payload) and equal(evidence["outcome"]["payload"], payload), "NO_OUTPUT_REWRITE")
                    if call["status"] == "settled":
                        usage = raw["usage"]
                        need(call["usage"]["prompt_tokens"] == usage["prompt_tokens"]
                             and call["usage"]["completion_tokens"] == usage["completion_tokens"], "RAW_USAGE")
            if call["status"] == "settled":
                usage = call["usage"]
                price = usage["prompt_tokens"]*150+usage["completion_tokens"]*500
                need(call["known_cost_nano_usd"] == price and call["held_cost_nano_usd"] == 0, "SETTLED_COST")
                known += price; kin += usage["prompt_tokens"]; kout += usage["completion_tokens"]
            else:
                need(call["known_cost_nano_usd"] == 0 and call["held_cost_nano_usd"] == reserved, "UNKNOWN_COST_HOLD")
                held += reserved; hin += upper; hout += 768
        repeated = sum(v["attempt_no"] > 1 and v["dispatched"] for v in calls)
        need(repeated <= 3, "EXTRA_CALL_CAP")
        calc_budget = dict(calls_reserved_or_spent=len(calls), calls_dispatched=sum(v["dispatched"] for v in calls),
            calls_remaining=max(0, limits["call_cap"]-len(calls)), known_input_tokens=kin, known_output_tokens=kout,
            held_input_tokens=hin, held_output_tokens=hout, known_cost_nano_usd=known, held_cost_nano_usd=held,
            remaining_cost_nano_usd=max(0, limits["max_cost_nano_usd"]-known-held))
        need(equal(calc_budget, ledger["budget"]), "BUDGET_RECONCILIATION")
        need(kin+hin <= limits["input_token_cap"] and kout+hout <= limits["output_token_cap"]
             and known+held <= limits["max_cost_nano_usd"], "RESOURCE_BUDGET_LIMITS")
        for row in rows:
            need(not must_stop, "NO_EXECUTION_AFTER_SECOND_FAILURE")
            rid, step = row["result_id"], row["step_id"]
            att = attempts[rid]
            need(all(row[k] == att[k] for k in ("run_id", "step_id", "attempt_no", "result_id")), "RESULT_ATTEMPT")
            need(row["parent_result_ids"] == [selected[p] for p in UPSTREAM[step]], "ACTUAL_SELECTED_PARENTS")
            inp = row["input_snapshot"]
            if inp:
                need(row["input_digest"] == h(inp) and inp["request"] == s["request"], "INPUT_SNAPSHOT")
                need(inp["parents"] == [dict(result_id=p, payload=byid[p]["payload"]) for p in row["parent_result_ids"]], "PARENT_PAYLOADS")
                captures = json.loads(att["read_snapshots"])
                need(equal(inp["tool_snapshots"], captures), "CAPTURED_SOURCES")
                if step in ORDER[:3]:
                    need(equal(captures, [ctl["initial_sources"][ORDER.index(step)]]), "READ_AUTHORITY_AND_VERSION")
                direct = [dict(object_key=o["object_key"], version=o["version"]) for o in captures]
                need(row["direct_reads"] == direct, "DIRECT_READS")
                allrefs = direct+[v for p in row["parent_result_ids"] for v in byid[p]["effective_read_set"]]
                refs = {v["object_key"]: v["version"] for v in allrefs}
                expected_refs = [dict(object_key=k, version=v) for k, v in sorted(refs.items())]
                need(row["effective_read_set"] == expected_refs, "TRANSITIVE_VERSIONS")
            local_calls = [v for v in local.values() if v["result_id"] == rid]
            need(equal(row["model_calls"], local_calls), "RESULT_CALLS")
            if row["execution_status"] == "success":
                need(len(local_calls) == 1 and local_calls[0]["status"] == "success", "SUCCESS_CALL_EVIDENCE")
                if step != "execute":
                    need(equal(row["payload"], local_calls[0]["delivered_output"]), "PUBLISHED_PAYLOAD")
            verify = verifications.get(rid)
            quarantined = advances_by_result.get(rid, {}).get("quarantined_publication", False)
            if quarantined:
                ar = advances_by_result[rid]
                need(ctl["status"] == ar["resulting_status"] == "uncertain"
                     and ar["stop_reason"] in ("INTERRUPTED_VERIFICATION", "UNKNOWN_COMMIT_OUTCOME"), "QUARANTINED_PUBLICATION")
            rejected = False
            if c["policy"] in ("VERIFY_REPAIR", "VERIFY_STOP") and step != "execute" and row["execution_status"] == "success":
                need(verify is not None or quarantined, "MISSING_VERIFICATION")
                if verify:
                    vr, sources = verify["receipt"], verify["source_objects"]
                    need(all(v in s["source_objects"] or v in ctl["initial_sources"] for v in sources), "VERIFIER_LEGAL_SOURCES")
                    truth = config(s["request"], sources) if step == "plan" else sources[0]["payload"]
                    reasons = []
                    if not equal(row["payload"], truth): reasons.append("VERIFIER_BUSINESS_MISMATCH")
                    refs = {v["object_key"]: v["version"] for v in row["effective_read_set"]}
                    if any(refs.get(v["object_key"]) != v["version"] for v in sources): reasons.append("VERIFIER_STALE_SOURCE")
                    need(vr["reason_codes"] == reasons and vr["candidate_unchanged_digest"] == h(row), "VERIFICATION_PREDICATE")
                    rejected = bool(reasons)
                    need(vr["decision"] == ("reject" if rejected else "accept"), "VERIFICATION_DECISION")
            elif verify:
                need(False, "UNEXPECTED_VERIFICATION")
            guard = guards.get(rid)
            if guard:
                truth, sources = config(s["request"], guard["source_objects"]), guard["source_objects"]
                need(equal(sources, s["source_objects"]), "GUARD_CURRENT_SOURCES")
                chain = []
                frontier = list(row["parent_result_ids"])
                while frontier:
                    v = byid[frontier.pop()]
                    if v["result_id"] not in {r["result_id"] for r in chain}:
                        chain.append(v); frontier += v["parent_result_ids"]
                differences = []
                for st, src in zip(ORDER[:3], sources):
                    candidates = [r for r in chain if r["step_id"] == st]
                    need(len(candidates) == 1, "GUARD_ANCESTOR_COUNT")
                    if candidates:
                        v = candidates[0]
                        differences += diff(v["payload"], src["payload"], st+".payload")
                        differences += diff(v["input_snapshot"]["tool_snapshots"], [src], st+".tool_snapshots")
                        differences += diff(v["direct_reads"], [dict(object_key=src["object_key"], version=src["version"])], st+".direct_reads")
                plan = next(v for v in chain if v["step_id"] == "plan")
                differences += diff(plan["payload"], truth, "plan.payload")
                command = guard["raw_command"]
                differences += diff(command.get("action"), "save_job", "command.action")
                differences += diff(command.get("arguments"), truth, "command.arguments")
                code = "PERMISSION_DENIED" if truth["permission_allowed"] is not True else "BUSINESS_VALIDATION_FAILED" if differences else None
                need(equal(guard["mismatches"], differences) and equal(guard["expected_config"], truth), "GUARD_PREDICATE")
                need(guard["error_code"] == code and guard["allowed_to_commit"] == (code is None), "GUARD_DECISION")
                need(equal(dict(action=command["action"], arguments=command["arguments"]), local_calls[0]["delivered_output"]), "GUARD_RAW_COMMAND")
            failed = rejected or row["execution_status"] != "success"
            seen.append(row)
            if failed:
                ev = failures.get(rid)
                need(ev is not None, "MISSING_FIRST_OR_LATER_FAILURE")
                if ev:
                    need(ev["candidate_digest"] == h(row) and ev["result_count"] == len(seen)
                         and ev["sources_digest"] == h(ev["source_objects"]), "FAILURE_EVIDENCE")
                    need(ev["guard_record_digest"] == (h(guard) if guard else None), "FAILURE_GUARD_LINK")
                    root_ids, deltas = [], []
                    active = {st: byid[r] for st, r in selected.items()}
                    active[step] = row
                    truth = config(s["request"], ev["source_objects"])
                    for st, src in zip(ORDER[:3], ev["source_objects"]):
                        if st in active:
                            delta = diff(active[st]["payload"], src["payload"], st+".payload")
                            if delta: root_ids.append(active[st]["result_id"]); deltas += delta
                    if not root_ids and "plan" in active:
                        delta = diff(active["plan"]["payload"], truth, "plan.payload")
                        if delta: root_ids.append(active["plan"]["result_id"]); deltas += delta
                    if not root_ids and guard:
                        delta = diff(guard["raw_command"]["arguments"], truth, "command.arguments")
                        if delta: root_ids.append(rid); deltas += delta
                    if ev["kind"] == "semantic_mismatch":
                        need(ev["root_result_ids"] == root_ids and equal(ev["differences"], deltas), "INDEPENDENT_ERROR_ROOTS")
                        need(truth["permission_allowed"] is True and equal(ev["source_objects"], ctl["initial_sources"]), "REPAIR_AUTHORITY")
                    if claim and claim["first_candidate_ref"] == rid:
                        claim_seen = True
                        need(ev["kind"] == "semantic_mismatch" and c["policy"] != "VERIFY_STOP", "REPAIR_ELIGIBILITY")
                        need(ev["failure_id"] == claim["first_failure_id"] and h(ev) == claim["first_failure_digest"]
                             == claim["feedback"]["evidence_digest"], "FIRST_FAILURE_RETAINED")
                        invalid = set(root_ids)
                        for v in seen:
                            if invalid.intersection(v["parent_result_ids"]): invalid.add(v["result_id"])
                        keep = {st: r for st, r in selected.items() if r not in invalid}
                        queue = [st for st in ORDER if st not in keep]
                        executed = {v["step_id"] for v in seen}
                        need(claim["selected_before"] == selected and claim["selected_after_claim"] == keep, "CLAIM_SELECTION")
                        need(claim["invalidated_result_ids"] == [v["result_id"] for v in seen if v["result_id"] in invalid], "INVALIDATION_CLOSURE")
                        need(claim["retained_result_ids"] == [keep[st] for st in ORDER if st in keep], "RETAINED_VALID_RESULTS")
                        need(claim["execution_queue"] == queue
                             and claim["replay_steps"] == [st for st in queue if st in executed]
                             and claim["unstarted_steps"] == [st for st in queue if st not in executed], "REPLAY_VS_FIRST_EXECUTION")
                        need(claim["round_no"] == 1 and claim["max_extra_calls"] == 3 and claim["max_total_calls"] == 8
                             and len(claim["replay_steps"]) <= 3, "CLAIM_LIMITS")
                        need(claim["deadline_unix"] == ctl["deadline_unix"] and claim["deadline_monotonic"] == ctl["deadline_monotonic"], "NO_DEADLINE_RESET")
                        need(claim["feedback"]["differences"] == deltas and claim["feedback"]["failure_ref"] == ev["failure_id"], "EVIDENCE_ONLY_FEEDBACK")
                        selected = keep
                    else:
                        must_stop = True
            elif not quarantined:
                selected[step] = rid
        need(selected == ctl["selected"], "FINAL_SELECTION")
        need(claim_seen == bool(claim), "CLAIM_HAS_REAL_FAILURE")
        if claim:
            need(claim["status"] == ctl["status"], "REPAIR_TERMINAL_STATUS")
            need({v["result_id"] for v in s["result_status_events"]} ==
                 {r for r in claim["invalidated_result_ids"] if byid[r]["execution_status"] == "success"}, "INVALIDATED_STATUS_LOG")
        else:
            need(repeated == 0 and not s["result_status_events"], "NO_UNADMITTED_REPLAY")
        advances = s["v2_advances"]
        need(all(v["status"] == "done" for v in advances), "UNFINISHED_ADVANCE")
        need(len({v["request_id"] for v in advances}) == len(advances), "ADVANCE_IDEMPOTENCY")
        need([v["result_id"] for v in advances if v.get("result_id")] == [v["result_id"] for v in rows], "ADVANCE_RESULT_RECEIPTS")
        failure_ids = {v["failure_id"] for v in failures.values()}
        need({v["failure_ref"] for v in advances if v.get("failure_ref")} == failure_ids, "ADVANCE_FAILURE_RECEIPTS")
        applied = [e for e in s["effects"] if e["state"] == "applied"]
        completed = ctl["status"] == "completed"
        if completed:
            need(set(selected) == set(ORDER) and len(applied) == 1 and held == 0, "COMPLETION_EVIDENCE")
            exe, truth = byid[selected["execute"]], config(s["request"], s["source_objects"])
            need(truth["permission_allowed"] is True and guards[exe["result_id"]]["allowed_to_commit"], "AUTHORIZED_COMPLETION")
            need(exe["effect_ids"] == [applied[0]["effect_id"]] and applied[0]["owner_result_id"] == exe["result_id"], "WRITE_OWNERSHIP")
            need(s["output_objects"][0]["payload"] == truth and s["output_objects"][1]["payload"]["config"] == truth, "FINAL_BUSINESS_STATE")
            need(all(v["last_writer_id"] == exe["result_id"] and v["version"] == 1 and v["exists"] is True for v in s["output_objects"]), "ATOMIC_OUTPUTS")
        elif ctl["status"] == "safe_stopped":
            need(not applied and all(not v["exists"] for v in s["output_objects"]), "SAFE_STOP_HAS_NO_WRITES")
        for key, value in dict(status=ctl["status"], stop_reason=ctl["stop_reason"], selected=selected,
            fake_http_calls=sum(v["dispatched"] for v in calls), repeated_model_calls=repeated, repair_rounds=len(repair),
            real_api_requests=0, credentials_read=0, training_or_prediction_calls=0, provider_debit_nano_usd=0,
            usage_and_cost_are_synthetic=True, prompt_effect_on_real_model_measured=False).items():
            need(equal(report[key], value), "REPORT_"+key)
        metrics = dict(status=ctl["status"], stop_reason=ctl["stop_reason"],
            fake_http_calls=sum(v["dispatched"] for v in calls), repeated_model_calls=repeated,
            retained_results=len(claim["retained_result_ids"]) if claim else 0,
            first_execution_after_repair=len(claim["unstarted_steps"]) if claim else 0,
            repair_rounds=len(repair), raw_model_mismatches=len(model_mismatches),
            synthetic_known_cost_nano_usd=known, synthetic_held_cost_nano_usd=held,
            completed=completed, real_api_requests=0, model_quality_improvement_measured=False)
    except (KeyError, IndexError, TypeError, ValueError, OverflowError, StopIteration) as exc:
        errors.append("MALFORMED_EVIDENCE:"+type(exc).__name__)
        metrics = {}
    return dict(schema_version="safety-reliability-v2-independent-check", passed=not errors,
                errors=sorted(set(errors)), metrics=metrics)


def check(directory):
    try:
        return check_loaded(load(directory))
    except (OSError, ValueError, sqlite3.DatabaseError, TypeError) as exc:
        return dict(schema_version="safety-reliability-v2-independent-check", passed=False,
                    errors=["UNREADABLE_EVIDENCE:"+type(exc).__name__], metrics={})
