"""Explicit fake-only entry point for the six saved-failure development cases."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys

from .contracts import ROOT, load_fixtures, read, write, sha
from .checker import check
from .runtime import Session


def pins():
    paths = [*ROOT.glob("src/agent_recovery/**/*.py"), *ROOT.glob("src/safety_reliability_v2/*.py"),
             *ROOT.glob("configs/safety_reliability_v2/*.json"),
             *ROOT.glob("phase1/p0/**/*"), *ROOT.glob("scripts/*safety_reliability_v2.py")]
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(set(paths)) if p.is_file() and "__pycache__" not in p.parts}


def run(output):
    path = Path(output).resolve()
    path.mkdir(parents=True, exist_ok=True)
    cases = load_fixtures()
    protocol = dict(schema_version="safety-reliability-v2-offline-protocol", fake_only=True,
        model_quality_study=False, development_cases_only=True, cases=cases, source_pins=pins(),
        max_repair_rounds=1, max_extra_model_calls=3, max_total_model_calls=8,
        expected_calls=[8, 6, 6, 6, 8, 6], expected_repeated_calls=[3, 1, 1, 1, 3, 1])
    if (path/"PROTOCOL.json").exists():
        if read(path/"PROTOCOL.json") != protocol:
            raise ValueError("FROZEN_PROTOCOL_CHANGED_USE_A_NEW_OUTPUT_DIRECTORY")
    else:
        write(path/"PROTOCOL.json", protocol)
    checks = []
    for case in cases:
        branch = path/"replays"/case["fixture_id"]
        if not (branch/"artifacts.json").exists():
            with Session(branch, case) as session:
                session.run()
                session.export()
        outcome = check(branch)
        receipt = path/"checks"/(case["fixture_id"]+".json")
        receipt.parent.mkdir(exist_ok=True)
        if not receipt.exists():
            write(receipt, outcome)
        elif read(receipt) != outcome:
            raise ValueError("SEALED_CHECK_CHANGED:"+case["fixture_id"])
        checks.append(outcome)
        if not outcome["passed"]:
            raise ValueError("INDEPENDENT_CHECK_FAILED:"+case["fixture_id"]+":"+",".join(outcome["errors"]))
    summary = dict(schema_version="safety-reliability-v2-six-replays", cases=len(checks),
        independent_checks_passed=sum(v["passed"] for v in checks),
        completed=sum(v["metrics"]["completed"] for v in checks),
        fake_http_calls=sum(v["metrics"]["fake_http_calls"] for v in checks),
        repeated_model_calls=sum(v["metrics"]["repeated_model_calls"] for v in checks),
        real_api_requests=0, provider_debit_nano_usd=0, credentials_read=0,
        prompt_improvement_measured=False, cases_are_selected_development_failures=True,
        rows=[dict(fixture_id=c["fixture_id"], original_slot_id=c["original_slot_id"], **v["metrics"])
              for c, v in zip(cases, checks)])
    if [v["metrics"]["fake_http_calls"] for v in checks] != protocol["expected_calls"]:
        raise ValueError("UNEXPECTED_FORMAL_CALL_COUNTS")
    if [v["metrics"]["repeated_model_calls"] for v in checks] != protocol["expected_repeated_calls"]:
        raise ValueError("UNEXPECTED_FORMAL_REPLAY_COUNTS")
    if (path/"SUMMARY.json").exists():
        if read(path/"SUMMARY.json") != summary:
            raise ValueError("SEALED_SUMMARY_CHANGED")
    else:
        write(path/"SUMMARY.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description="Offline CPU fake-HTTP replay only; no credential or live API path.")
    parser.add_argument("--fake-only", action="store_true", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    import json
    result = run(args.output)
    print(json.dumps({k:v for k,v in result.items() if k != "rows"}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
