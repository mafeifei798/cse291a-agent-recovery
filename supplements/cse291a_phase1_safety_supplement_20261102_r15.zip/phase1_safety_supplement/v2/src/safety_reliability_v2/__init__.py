"""Isolated CPU/fake-HTTP reliability experiment; no live entry point."""
