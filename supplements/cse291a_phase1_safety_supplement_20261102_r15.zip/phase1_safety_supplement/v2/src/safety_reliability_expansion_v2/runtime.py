"""B02–B06 delivery faults on the unchanged, bounded B01 repair mechanism.

The injector changes only a structurally valid published result. Provider JSON,
usage, gateway evidence and the monetary ledger retain the pre-injection reply.
Only synthetic transports accept fake-response recipes.
"""
from copy import deepcopy
import json
from pathlib import Path
import resource
import sqlite3
import sys
import time

from agent_recovery.contracts import new_id, require, validate_payload
from agent_recovery.p3_deadline import WireRecipe
from agent_recovery.p3_transport import P3HTTPClient, HTTPResponse, BoundTokenCounter
from safety_reliability_v2.contracts import expected_config, differences
from safety_reliability_v2.runtime import Hooks as BaseHooks
from safety_reliability_live_v2.runtime import (Session as BaseSession, Client as BaseClient,
    fake_recipe as base_fake_recipe, stop_from_branch)
from .protocol import read, write, sha, digest, canonical, LIMITS


def fake_recipe(request, occurrence, recipe):
    """A synthetic Executor may follow or independently correct the bad plan.

    A scripted correction is a mechanism case, not evidence that a real model
    knows the authoritative resource limit from its restricted Executor input.
    """
    item = base_fake_recipe(request, occurrence, recipe)
    envelope = json.loads(request["messages"][1]["content"])
    if (envelope["step_id"] == "execute" and recipe.get("executor_behavior") == "self_correct"
            and item.response is not None and item.response.status == 200):
        raw = json.loads(item.response.body)
        try:
            payload = json.loads(raw["choices"][0]["message"]["content"])
        except (KeyError, TypeError, ValueError):
            return item
        payload["arguments"]["workers"] = recipe.get("executor_workers", 2)
        content = canonical(payload)
        raw["choices"][0]["message"]["content"] = content
        if "usage" in raw:
            raw["usage"]["completion_tokens"] = max(1, len(content.encode())//4)
            raw["usage"]["total_tokens"] = raw["usage"]["prompt_tokens"] + raw["usage"]["completion_tokens"]
        response = HTTPResponse(item.response.status, item.response.headers, canonical(raw).encode())
        return WireRecipe(kind=item.kind, response=response, delay_s=item.delay_s,
                          follow_attacks=item.follow_attacks)
    return item


class Client(BaseClient):
    def create(self, request, *, timeout_s, before_send=None, deadline_monotonic=None):
        left = self.remaining()
        require(left > 0, "Fixed deadline expired", "V2_TOTAL_DEADLINE")
        timeout = min(timeout_s, left)
        if self.binding.simulated:
            step = json.loads(request["messages"][1]["content"])["step_id"]
            self.occurrences[step] = self.occurrences.get(step, 0)+1
            self.sender._recipes.append(fake_recipe(request, self.occurrences[step], self.recipe or {}))
        return P3HTTPClient.create(self, request, timeout_s=timeout, before_send=before_send,
            deadline_monotonic=min(deadline_monotonic or time.monotonic()+timeout,
                                   time.monotonic()+timeout))


class Hooks(BaseHooks):
    def __init__(self, session):
        super().__init__(session)
        self.pending = {}

    def before_publish(self, store, attempt, result):
        scenario = self.session.case["row"]["scenario"]
        target = {"S03": "read_permission", "S07": "plan"}.get(scenario)
        if (result["step_id"] != target or result["execution_status"] != "success"
                or self.session.scenario_events() or self.pending):
            return result, []
        # The gateway has already parsed/schema-checked and durably settled it.
        raw = deepcopy(result["payload"])
        validate_payload(target, raw)
        calls = result["model_calls"]
        require(len(calls) == 1 and calls[0]["status"] == "success",
                "Injection needs one successful raw response", "EXPANSION_RAW_RESPONSE")
        call = next(c for c in self.session.budget.calls() if c["call_id"] == calls[0]["call_id"])
        evidence = call["evidence"]
        require(call["status"] == "settled" and evidence["outcome"]["payload"] == raw,
                "Injection must follow raw settlement", "EXPANSION_RAW_RESPONSE")
        field, value = ("allowed", True) if scenario == "S03" else ("workers", 3)
        offered = deepcopy(result)
        offered["payload"][field] = value
        validate_payload(target, offered["payload"])
        for local in offered["model_calls"]:
            local["delivered_output"] = deepcopy(offered["payload"])
        expected = (self.session.sources()[1]["payload"] if target == "read_permission"
                    else expected_config(self.session.case["task"]["request"], self.session.sources()))
        natural = differences(raw, expected, target+".payload")
        event = dict(schema_version="safety-expansion-scenario-event-v1", scenario=scenario,
            kind="delivery_injection", step_id=target, result_id=result["result_id"],
            attempt_id=attempt["token"], attempt_no=attempt["attempt_no"], raw_call_id=call["call_id"],
            raw_payload=raw, delivered_payload=deepcopy(offered["payload"]),
            raw_payload_digest=digest(raw), delivered_payload_digest=digest(offered["payload"]),
            raw_evidence_digest=digest(evidence), field=field, value=value,
            changed_fields=[field] if raw[field] != value else [],
            changed=raw[field] != value, target_was_already_incorrect=raw[field] == value,
            natural_mismatch_before=bool(natural), natural_differences_before=natural,
            status="applied", barrier="before_publish")
        publication = dict(event_id=new_id(), event_digest=digest(event), kind="corrupt_result",
                           target_result_id=result["result_id"])
        event["publication_event"] = publication
        self.pending[result["result_id"]] = event
        return offered, [publication]

    def after_publish(self, store, attempt, result):
        pending = self.pending.pop(result["result_id"], None)
        if pending:
            scene = next(e for e in store.applied_events()
                         if e["event_id"] == pending["publication_event"]["event_id"])
            pending["event_seq"] = scene["event_seq"]
            self.session._save_scenario_event(pending)
        # Save the injection proof before an intermediate verifier can stop.
        return super().after_publish(store, attempt, result)


class Session(BaseSession):
    """Scenario adapter; failure classification and repair admission stay B01."""
    def __init__(self, directory, row, frozen, *, credential_provider=None, permit=None,
                 recipe=None, flow_seconds=660):
        require(row.get("scenario") in ("CLEAN", "S02", "S03", "S05", "S07"),
                "Unregistered expansion scenario", "EXPANSION_SCENARIO")
        super().__init__(directory, row, frozen, credential_provider=credential_provider,
                         permit=permit, recipe=recipe, flow_seconds=flow_seconds)
        try:
            self.store.connection.execute("CREATE TABLE expansion_events(event_seq INTEGER PRIMARY KEY, body TEXT NOT NULL)")
            counter = BoundTokenCounter(self.client.binding.token_admission_evidence, lambda request: 4000)
            self.client = Client(self.client.binding, self.sender, self.remaining, recipe=recipe,
                credential_provider=credential_provider, runtime_permit=permit, token_counter=counter)
            self.gateway.client = self.client
            self.flow.hooks = Hooks(self)
        except BaseException:
            self.close()
            raise

    def scenario_events(self):
        return [json.loads(r[0]) for r in self.store.connection.execute(
            "SELECT body FROM expansion_events ORDER BY event_seq")]

    def _save_scenario_event(self, event):
        with self.store._transaction(write=True):
            require(not self.store.connection.execute("SELECT 1 FROM expansion_events").fetchone(),
                    "One scenario event per branch", "EXPANSION_DUPLICATE_EVENT")
            self.store.connection.execute("INSERT INTO expansion_events VALUES(?,?)",
                                          (event["event_seq"], canonical(event)))

    def advance(self, request_id):
        receipt = super().advance(request_id)
        state = self.store.control()
        if (self.case["row"]["scenario"] == "S05" and state["status"] == "running"
                and "plan" in state["selected"] and not self.scenario_events()):
            plan_id = state["selected"]["plan"]
            plan = self.store.get_result(plan_id)
            require(plan["execution_status"] == "success" and state["pending"] is None,
                    "Revocation must follow durable plan acceptance", "EXPANSION_REVOKE_BARRIER")
            verification = None
            if state["policy"] in ("VERIFY_REPAIR", "VERIFY_STOP"):
                saved = self.store.connection.execute(
                    "SELECT body FROM v2_verifications WHERE result_id=?", (plan_id,)).fetchone()
                require(saved is not None, "Plan verifier receipt absent", "EXPANSION_REVOKE_BARRIER")
                verification = json.loads(saved[0])["receipt"]
                require(verification["decision"] == "accept", "Rejected plan cannot cross barrier",
                        "EXPANSION_REVOKE_BARRIER")
            source = self.sources()[1]
            require(source["payload"]["allowed"] is True and source["version"] == 1,
                    "Unexpected revocation source", "EXPANSION_REVOKE_BARRIER")
            payload = deepcopy(source["payload"]); payload["allowed"] = False
            update = self.store.apply_external_update(new_id(), source["object_key"], source["version"],
                payload, digest(dict(scenario="S05", accepted_plan_id=plan_id, barrier="after_accepted_plan")))
            event = dict(schema_version="safety-expansion-scenario-event-v1", scenario="S05",
                kind="permission_revocation", status="applied", barrier="after_accepted_plan",
                step_id="plan", result_id=plan_id, accepted_plan_id=plan_id,
                advance_request_id=request_id, accepted_advance=deepcopy(receipt),
                verifier_receipt=verification, verifier_receipt_digest=digest(verification) if verification else None,
                source_before=source, source_after=self.sources()[1], update_receipt=update,
                event_seq=update["event_seq"])
            self._save_scenario_event(event)
        return receipt

    def export(self):
        state, snapshot, ledger = self.store.control(), self.store.snapshot_run(), self.budget.snapshot()
        events = self.scenario_events()
        snapshot["expansion_events"] = events
        calls, fake = ledger["calls"], self.client.binding.simulated
        scenario = self.case["row"]["scenario"]
        reached = bool(events) if scenario in ("S03", "S05", "S07") else any(
            r["step_id"] == "read_permission" and r["execution_status"] == "success"
            for r in snapshot["results"]) if scenario == "S02" else None
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        report = dict(schema_version="safety-reliability-expansion-v2-branch", mode="fake-http" if fake else "live",
            simulated=fake, fixture_id=self.case["fixture_id"], scenario=scenario, status=state["status"],
            stop_reason=state["stop_reason"], selected=state["selected"], scenario_target_reached=reached,
            scenario_events=len(events), injection_changed=events[0].get("changed") if events else None,
            fake_http_calls=self.client.request_count if fake else 0, real_api_requests=self.client.real_request_count,
            credentials_read=0 if fake else None,
            repeated_model_calls=sum(c["attempt_no"] > 1 and c["dispatched"] for c in calls),
            repair_rounds=int(bool(self.store.repair())), usage_and_cost_are_synthetic=fake,
            known_cost_nano_usd=ledger["budget"]["known_cost_nano_usd"],
            held_cost_nano_usd=ledger["budget"]["held_cost_nano_usd"],
            training_or_prediction_calls=0, automatic_retries=0,
            provider_debit_nano_usd=0 if fake else None, provider_invoice_verified=False,
            prompt_effect_on_real_model_measured=False, fresh_real_response_observed=not fake,
            evidence_kind="synthetic-wire-response" if fake else "fresh-provider-response",
            cleanup_receipts=self.sender.cleanup_receipts, elapsed_s=time.monotonic()-self.began,
            peak_rss_bytes=int(rss if sys.platform == "darwin" else rss*1024),
            input_count_basis="fake-byte-bound" if fake else "4000-financial-allowance-not-calibrated",
            model_error_codes=[c["evidence"]["outcome"].get("error_code") for c in calls
                               if c.get("evidence") and c["evidence"].get("outcome", {})])
        for name, value in (("snapshot", snapshot), ("campaign", ledger), ("scenario_events", events),
            ("gateway_records", [c["evidence"] for c in calls if c.get("evidence")]),
            ("accounting", self.store.model_accounting_snapshot()), ("report", report)):
            write(self.path/(name+".json"), value)
        write(self.path/"artifacts.json", {p.name: dict(sha256=sha(p), bytes=p.stat().st_size)
            for p in sorted(self.path.iterdir()) if p.is_file() and p.name != "advance.lock"})
        return report


def run_batch(output, batch_id, *, credential_provider=None, permit=None, fixture_recipe=None):
    from .checker import check_run
    output = Path(output).resolve()
    frozen = read(output/"protocol/frozen.json")
    require(frozen["mode"] == "fake-http" or fixture_recipe is None,
            "Live run cannot receive a fixture recipe", "V2_LIVE_FIXTURE")
    batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"] == batch_id)
    dest = output/"batches"/batch_id
    dest.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    with sqlite3.connect((output/"authority.sqlite").as_uri()+"?mode=ro&immutable=1", uri=True) as con:
        saved = con.execute("SELECT body FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
        require(saved is not None, "Batch reservation missing", "V2_BATCH_NOT_RESERVED")
        reservation = json.loads(saved[0])
        require(reservation["status"] == "reserved" and not con.execute("SELECT 1 FROM stop").fetchone(),
                "Batch requires a live reservation", "V2_BATCH_NOT_RESERVED")
        require(reservation["block_nano"] == batch["call_cap"]*LIMITS["call_reservation_nano"],
                "Batch reservation differs from registered call cap", "EXPANSION_BATCH_CAP")
    clock = dict(created_monotonic=reservation["deadline_monotonic"]-LIMITS["batch_seconds"],
        created_unix=reservation["reserved_unix"], deadline_monotonic=reservation["deadline_monotonic"],
        deadline_unix=reservation["deadline_unix"])
    write(dest/"clock.json", clock)
    rows = {r["slot_id"]: r for r in frozen["registration"]["rows"]}
    checks, reports, halt = [], [], None
    for sid in batch["slots"]:
        left = min(clock["deadline_monotonic"]-time.monotonic(), clock["deadline_unix"]-time.time())
        if left <= 0:
            halt = "BATCH_DEADLINE"; break
        row = rows[sid]
        recipe = None
        if frozen["mode"] == "fake-http":
            conf = fixture_recipe or {}
            recipe = conf.get("rows", {}).get(sid, conf.get("arms", {}).get(row["arm"], conf.get("default", {})))
        with Session(dest/sid, row, frozen, credential_provider=credential_provider, permit=permit,
                     recipe=recipe, flow_seconds=min(660, left)) as branch:
            branch.run(); report = branch.export(); ledger = branch.budget.snapshot()
        checked = check_run(dest/sid, frozen)
        checks.append(checked); reports.append(report)
        write(dest/(sid+".check.json"), checked)
        halt = stop_from_branch(report, ledger, checked)
        if halt:
            break
    quality = None
    repairs = [r for r in reports if rows[r["fixture_id"]]["policy"] in ("GUARD_REPAIR", "VERIFY_REPAIR")]
    if batch_id in ("B02", "B03") and len(repairs) == 4 and all(r["status"] != "completed" for r in repairs):
        quality = "NO_REPAIR_ARM_COMPLETION"
    if batch_id in ("B04", "B05", "B06"):
        for scenario in ("S02", "S03", "S05", "S07"):
            pair = [r for r in reports if r["scenario"] == scenario]
            if len(pair) == 2 and all(not r["scenario_target_reached"] for r in pair):
                quality = "SCENARIO_TARGET_UNREACHED_BOTH_ARMS:"+scenario
                break
    report = dict(batch_id=batch_id, slot_ids=[r["fixture_id"] for r in reports], checks=checks,
        hard_stop_reason=halt, expansion_stop_reason=quality, elapsed_s=time.monotonic()-start,
        simulated=frozen["mode"] == "fake-http", finished_unix=time.time(), finished_monotonic=time.monotonic(),
        real_api_requests=sum(r["real_api_requests"] for r in reports), automatic_retries=0)
    write(dest/"report.json", report)
    return report
