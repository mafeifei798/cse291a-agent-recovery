"""Independent B02--B06 offline preparation; original B01 remains frozen."""
