# Safety supplement

Saved evidence for the permission and resource-limit study summarized in one
paragraph of the Phase 1 report (`report.pdf` in the main package). It is
separate from the 168-row configuration experiment.

## Run

Python 3.10 or newer with the standard library is enough. From this directory:

```sh
python3 -B analysis/recompute.py --output ../safety-recomputed
```

Use a new output directory each time, and do not run with `python -O`. The
script checks the SHA-256 of every file listed in `MANIFEST_SHA256.json`, then
runs the original checkers on the saved SQLite databases and raw model
responses. It makes no network calls and starts no subprocesses.

From the main package, the same check runs with:

```sh
python3 -B reproduce.py --output runs/report_with_safety \
  --safety-root supplements/phase1_safety_supplement
```

## Outputs

- `RECOMPUTATION_RECEIPT.json`: pass/fail and totals.
- `V1_SUMMARY.json`: the first study, 96 runs and 326 model calls.
- `V2_SUMMARY.json`: the follow-up study, 50 runs and 229 model calls.
- `V1_RECOMPUTED_CHECK.json`, `V2_RECOMPUTED_BATCH_CHECKS.json`,
  `PACING_RECOMPUTED_CHECK.json`: per-run checker results.

Expected results: in v1, 13 policy-violating writes in the 48 runs without a
final authorization check and none in the 48 runs with it. In v2, 21 of 24
normal runs with revised prompts completed; of 24 denial, revocation, or
resource-limit runs, 23 stopped safely and 1 hit an HTTP 429.

## Contents

- `v1/observations/`: the nine v1 batches (raw responses, SQLite state,
  journals) and the frozen registration and prompt specification in
  `protocol/`.
- `v2/outputs/`: the three v2 stages, each with its frozen protocol, old and
  revised prompts, raw responses, and databases.
- `v1/src/`, `v1/scripts/`, `v2/src/`, `v2/scripts/`: the original checker
  source, pinned by hash.
- `reference/`: the saved result tables that the recomputation must match.

A checker pass means the saved evidence is internally consistent, not that the
task succeeded: v1 includes policy-violating writes, and v2 includes safe stops
and one infrastructure failure. The two studies use separate denominators.
