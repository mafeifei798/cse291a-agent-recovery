"""Same-process monotonic timing, with nested scopes and checked closure.

No workflow decisions are made here. Runtime observers annotate selected Python
calls without replacing functions or modifying Store records. Child-process CPU
and worker clocks must stay in their own execution receipts.
"""
from collections import defaultdict
from contextlib import contextmanager
from copy import deepcopy
import os
import sys
import threading
from time import monotonic_ns, process_time_ns
from uuid import uuid4


def require(ok, code):
    if not ok:
        raise ValueError(code)


def summarize(trace):
    """Independently validate nesting and compute exclusive stage totals."""
    require(trace['schema_version'] == 'recovery-monotonic-v1', 'SCHEMA_VERSION')
    require(trace['clock_kind'] == 'same_process_monotonic_ns', 'CLOCK_KIND')
    start, end = trace['start_ns'], trace['end_ns']
    require(type(start) is int and type(end) is int and 0 <= start <= end, 'ROOT_CLOCK_RANGE')
    require(type(trace['controller_cpu_ns']) is int and trace['controller_cpu_ns'] >= 0, 'ROOT_CPU_RANGE')
    spans = {s['span_id']: s for s in trace['spans']}
    require(len(spans) == len(trace['spans']), 'DUPLICATE_SPAN')
    children = defaultdict(list)
    for s in spans.values():
        require(s['clock_domain'] == trace['clock_domain'], 'MIXED_CLOCK_DOMAINS')
        require(type(s['start_ns']) is int and type(s['end_ns']) is int and
                start <= s['start_ns'] <= s['end_ns'] <= end, 'SPAN_CLOCK_RANGE')
        require(type(s['controller_cpu_ns']) is int and s['controller_cpu_ns'] >= 0, 'CPU_CLOCK_RANGE')
        parent = s['parent_span_id']
        require(parent is None or parent in spans, 'MISSING_PARENT_SPAN')
        ancestors, current = set(), parent
        while current is not None:
            require(current not in ancestors and current != s['span_id'], 'SPAN_CYCLE')
            ancestors.add(current)
            current = spans[current]['parent_span_id']
        if parent is not None:
            require(spans[parent]['start_ns'] <= s['start_ns'] <= s['end_ns'] <= spans[parent]['end_ns'],
                    'CHILD_OUTSIDE_PARENT')
        children[parent].append(s)
    for group in children.values():
        ordered = sorted(group, key=lambda s: (s['start_ns'], s['end_ns']))
        require(all(a['end_ns'] <= b['start_ns'] for a, b in zip(ordered, ordered[1:])),
                'OVERLAPPING_SERIAL_SIBLINGS')
    exclusive = defaultdict(int)
    inclusive = defaultdict(int)
    for identity, s in spans.items():
        wall = s['end_ns'] - s['start_ns']
        own = wall - sum(c['end_ns'] - c['start_ns'] for c in children[identity])
        require(own >= 0, 'NEGATIVE_EXCLUSIVE_TIME')
        exclusive[s['stage']] += own
        inclusive[s['stage']] += wall
    attributed = sum(s['end_ns'] - s['start_ns'] for s in children[None])
    require(sum(exclusive.values()) == attributed <= end - start, 'TIME_ACCOUNTING_MISMATCH')
    closure = trace['closure']
    complete = closure.get('terminal_status') == 'completed_correct'
    if trace['closed']:
        require(closure.get('durable_terminal') is True, 'TERMINAL_NOT_DURABLE')
        require(all(type(closure.get(k)) is list for k in
                    ('active_attempt_ids', 'worker_pids', 'unsettled_call_ids')), 'CLOSURE_COUNTS_REQUIRED')
        require(type(closure.get('held_cost_nano_usd')) is int and closure['held_cost_nano_usd'] >= 0,
                'CLOSURE_RESERVATION_REQUIRED')
        require(isinstance(closure.get('terminal_status'), str) and closure['terminal_status']
                not in ('', 'unresolved', 'running'), 'KNOWN_TERMINAL_STATUS_REQUIRED')
        require(not closure.get('active_attempt_ids') and not closure.get('worker_pids'), 'WORK_NOT_REAPED')
        uncertain = closure.get('unsettled_call_ids', [])
        require(not complete or not uncertain, 'COMPLETED_WITH_UNKNOWN_CALLS')
        require(not uncertain or closure.get('held_cost_nano_usd', 0) > 0, 'UNKNOWN_USAGE_HOLD_MISSING')
    return {'completed_task': bool(trace['closed'] and complete),
            'complete_window_recorded': bool(trace['closed']),
            'recovery_wall_ns': end - start if trace['closed'] else None,
            'observed_until_abort_ns': end - start if not trace['closed'] else None,
            'controller_cpu_ns': trace['controller_cpu_ns'],
            'exclusive_stage_wall_ns': dict(exclusive),
            'inclusive_stage_wall_ns_do_not_sum': dict(inclusive),
            'unattributed_controller_wall_ns': end - start - attributed,
            'sidecar_persistence_and_independent_checker_included': False}


class RecoveryTimer:
    def __init__(self, item_id, policy, *, clock=monotonic_ns, cpu_clock=process_time_ns,
                 execution_mode='offline_fake_protocol'):
        require(policy in ('FULL', 'LAZY', 'EAGER'), 'UNKNOWN_POLICY')
        require(execution_mode in ('offline_fake_protocol', 'offline_fake_store'), 'OFFLINE_MODE_REQUIRED')
        self.clock, self.cpu_clock = clock, cpu_clock
        self.owner = (os.getpid(), threading.get_ident())
        self.domain = str(uuid4())
        self.started, self.cpu_started = clock(), cpu_clock()
        self.item_id, self.policy, self.mode = item_id, policy, execution_mode
        self.stack, self.spans = [], []
        self.input_binding = {}
        self.last = self.started
        self.finished = None

    def bind_inputs(self, *, scene_digest, dag_digest):
        require(not self.input_binding and self.finished is None, 'INPUT_BINDING_ALREADY_FIXED')
        require(all(isinstance(s, str) and len(s) == 64 and all(c in '0123456789abcdef' for c in s)
                    for s in (scene_digest, dag_digest)), 'INVALID_INPUT_DIGEST')
        self.input_binding = {'scene_digest': scene_digest, 'dag_digest': dag_digest}

    def _now(self):
        require(self.owner == (os.getpid(), threading.get_ident()), 'CROSS_PROCESS_OR_THREAD_CLOCK')
        value = self.clock()
        require(type(value) is int and value >= self.last, 'MONOTONIC_CLOCK_REGRESSED')
        self.last = value
        return value

    def begin(self, stage, subject=None):
        require(self.finished is None, 'TIMER_CLOSED')
        row = {'span_id': len(self.spans), 'parent_span_id': self.stack[-1]['span_id'] if self.stack else None,
               'stage': stage, 'subject': subject, 'clock_domain': self.domain,
               'start_ns': self._now(), 'end_ns': None, 'status': 'running',
               '_cpu_start': self.cpu_clock()}
        self.spans.append(row); self.stack.append(row)
        return row['span_id']

    def end(self, identity, status='returned'):
        require(self.finished is None and self.stack and self.stack[-1]['span_id'] == identity,
                'NON_LIFO_SPAN_CLOSE')
        row = self.stack.pop()
        row['end_ns'] = self._now()
        row['controller_cpu_ns'] = self.cpu_clock() - row.pop('_cpu_start')
        row['status'] = status

    @contextmanager
    def span(self, stage, subject=None):
        identity = self.begin(stage, subject)
        try:
            yield
        except BaseException:
            self.end(identity, 'raised')
            raise
        else:
            self.end(identity)

    @contextmanager
    def observe(self, functions):
        """Map code objects to stage strings or frame -> (stage, subject).

        Only ordinary, serial Python functions may be observed. No generators,
        async tasks, subprocess clocks, or parallel sibling accounting is used.
        """
        require(sys.getprofile() is None, 'EXISTING_PROFILER_NOT_REPLACED')
        active = {}

        def callback(frame, event, arg):
            rule = functions.get(frame.f_code)
            if rule is None:
                return
            identity = id(frame)
            if event == 'call':
                stage, subject = rule(frame) if callable(rule) else (rule, frame.f_code.co_name)
                active[identity] = self.begin(stage, subject)
            elif event == 'return' and identity in active:
                self.end(active.pop(identity), 'returned_or_unwound')
        sys.setprofile(callback)
        try:
            yield
        finally:
            sys.setprofile(None)
            require(not active, 'OBSERVED_CALL_NOT_CLOSED')

    def finish(self, closure_probe):
        require(self.finished is None and not self.stack, 'OPEN_SPANS_OR_ALREADY_CLOSED')
        with self.span('closure_probe'):
            closure = closure_probe()
        return self._freeze(True, closure)

    def incomplete(self, reason):
        require(self.finished is None and not self.stack, 'OPEN_SPANS_OR_ALREADY_CLOSED')
        return self._freeze(False, {'terminal_status': 'unresolved', 'reason': reason})

    def _freeze(self, closed, closure):
        value = {'schema_version': 'recovery-monotonic-v1', 'item_id': self.item_id,
                 'policy': self.policy, 'execution_mode': self.mode, 'clock_domain': self.domain,
                 'clock_implementation': 'stdlib_monotonic_ns' if self.clock is monotonic_ns else 'injected_test_clock',
                 'clock_kind': 'same_process_monotonic_ns', 'start_ns': self.started, 'end_ns': self._now(),
                 'input_binding': deepcopy(self.input_binding),
                 'controller_cpu_ns': self.cpu_clock() - self.cpu_started,
                 'closed': closed, 'closure': deepcopy(closure), 'spans': deepcopy(self.spans)}
        value['summary'] = summarize(value)
        self.finished = value
        return deepcopy(value)
