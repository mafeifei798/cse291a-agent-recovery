"""Separate recovery timing observations; no workflow or resource launcher."""
