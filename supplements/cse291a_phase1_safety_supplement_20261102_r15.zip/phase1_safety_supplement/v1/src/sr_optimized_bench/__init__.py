"""Isolated offline optimization experiment; original production paths remain intact."""
