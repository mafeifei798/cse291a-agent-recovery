"""Same-host, four-arm blocked comparison. No live transport or resume path."""
from copy import deepcopy
from contextlib import nullcontext
from datetime import datetime,timezone
import json
from pathlib import Path
import time,traceback
from sr_tracking_bench import runner as baseline
from sr_tracking_bench.full import run_full
from sr_tracking_bench.reference import run_reference
from sr_tracking_bench.oracle import check_run,compare_runs
from sr_tracking_bench.contracts import require,write_json,sha_file
from sr_tracking_bench.profile import SpanRecorder
from .bindings import variant_context
REPO=Path(__file__).resolve().parents[2]

def validate_plan(plan,v0):
    old=json.loads((REPO/'configs/normal_tracking_r1_plan.json').read_text())
    baseline.validate_plan(old,v0)
    require(plan['schema_version']=='normal-optimization-plan-v1','PLAN_SCHEMA')
    require(plan['tasks']==old['tasks'] and plan['resources']==old['resources'],'UNCHANGED_TASKS_RESOURCES')
    require(all(plan[k] is False for k in ('real_API_requests_authorized','key_access_authorized','cloud_start_authorized')),'OFFLINE_ONLY')
    ts=plan['trials'];require(len(ts)==104 and [t['ordinal'] for t in ts]==list(range(1,105)),'FIXED104')
    require(len({t['trial_id'] for t in ts})==104,'UNIQUE_TRIALS')
    bykey={t['task_key']:t for t in plan['tasks']};blocks={}
    for i,t in enumerate(ts):
        require(t['task_key'] in bykey and t['variant'] in ('legacy','optimized') and t['arm'] in ('full','reference'),'TRIAL_IDENTITY')
        require(t['phase']==('warmup' if i<16 else 'measured' if i<96 else 'profile'),'FIXED_PHASE_ORDER')
        require(t['profiled']==(i>=96),'PRIMARY_UNPROFILED')
        if t['profiled']:require(t['arm']=='full' and t['pair_id'] is None,'PROFILE_FULL_ONLY')
        else:blocks.setdefault(t['block_id'],[]).append(t)
    require(len(blocks)==24,'24_BLOCKS')
    for block,rows in blocks.items():
        require(len(rows)==4 and {(t['variant'],t['arm']) for t in rows}=={(v,a) for v in ('legacy','optimized') for a in ('full','reference')},'FOUR_ARM_BLOCK')
        require(len({(t['task_key'],t['phase'],t['repeat']) for t in rows})==1,'SAME_BLOCK_WORKLOAD')
    for key in bykey:
        rows=[t for t in ts if t['task_key']==key]
        require(len(rows)==26 and sum(t['profiled'] for t in rows)==2,'26_PER_TASK')
        for variant in ('legacy','optimized'):
            require(sorted(t['repeat'] for t in rows if t['phase']=='measured' and t['variant']==variant and t['arm']=='full')==[1,2,3,4,5],'FIVE_PAIRS_EACH_VERSION')
    return deepcopy(plan)

def block_values(records):
    records={(r['variant'],r['arm']):r for r in records}
    lf,lr,of,oref=[records[k]['primary_wall_ns'] for k in [('legacy','full'),('legacy','reference'),('optimized','full'),('optimized','reference')]]
    dl,do=lf-lr,of-oref
    return dict(legacy_full_ns=lf,legacy_reference_ns=lr,optimized_full_ns=of,optimized_reference_ns=oref,
        legacy_tracking_delta_ns=dl,optimized_tracking_delta_ns=do,
        tracking_delta_change_ns=do-dl,tracking_delta_reduction_ns=dl-do,
        tracking_delta_reduction_percent=None if dl<=0 else 100*(dl-do)/dl,
        full_total_reduction_ns=lf-of,full_total_reduction_percent=100*(lf-of)/lf,
        legacy_overhead_percent=100*dl/lr,optimized_overhead_percent=100*do/oref,
        overhead_percentage_point_change=100*do/oref-100*dl/lr)

def run_batch(plan_path,v0_root,output,*,startup=None):
    began=time.perf_counter_ns();plan_path=Path(plan_path).resolve();v0=Path(v0_root).resolve();output=Path(output).resolve()
    require(not output.exists(),'NEW_OUTPUT_NO_RESUME')
    plan=validate_plan(json.loads(plan_path.read_text()),v0)
    environment=baseline.configure_environment(plan['resources']);sources=baseline.source_pins();inputs=baseline.input_pins(v0)
    # source_pins from the preserved runner covers every src/*.py, plus its old
    # entrypoint; explicitly add this experiment's new entrypoint.
    sources['scripts/run_sr_optimization.py']=sha_file(REPO/'scripts/run_sr_optimization.py')
    protocol=REPO/'outputs/sr_optimization_20261021/PROTOCOL.md'
    plan_hash,protocol_hash=sha_file(plan_path),sha_file(protocol)
    output.mkdir(parents=True,exist_ok=False);(output/'arms').mkdir()
    write_json(output/'plan_snapshot.json',plan);(output/'protocol_snapshot.md').write_bytes(protocol.read_bytes())
    manifest=dict(schema_version='normal-optimization-manifest-v1',created_at_utc=datetime.now(timezone.utc).isoformat(),plan_path=str(plan_path),plan_sha256=plan_hash,protocol_sha256=protocol_hash,v0_root=str(v0),environment=environment,startup=startup,source_before=sources,inputs_before=inputs,live_transport_available=False,old_formal_registration_changed=False,estimands=plan['estimands'],timer_scope='same complete offline normal timer as r1; common oracle separate')
    write_json(output/'manifest.json',manifest)
    resources=baseline.Resources(output,plan['resources'],began+1_800_000_000_000)
    tasks={t['task_key']:t for t in plan['tasks']};records=[];pairs=[];blocks=[];pending_pairs={};pending_blocks={};warmups={};failure=None;fence=baseline.NetworkFence()
    try:
        with fence:
            for trial in plan['trials']:
                task=tasks[trial['task_key']];arm_root=output/'arms'/trial['trial_id'];resources.begin_arm(arm_root)
                spec=dict(item=deepcopy(task['registry_item']),item_id=task['registry_item']['item_id'],task_id=task['task_id'],domain=task['domain'],v0_root=str(v0),run_root=str(arm_root),run_id=trial['block_id'],arm=trial['arm'],phase=trial['phase'],repeat_index=trial['repeat'],pair_id=trial['pair_id'],trial_id=trial['trial_id'],global_deadline_ns=min(resources.global_deadline_ns,resources.arm_deadline_ns))
                profiler=SpanRecorder() if trial['profiled'] else None
                with variant_context(trial['variant'],profile=profiler) as job_function:
                    resources.function=job_function
                    if trial['variant']=='optimized' and trial['profiled']:
                        from sr_optimized_v1.validation import validation_diagnostics
                        diagnostic_context=validation_diagnostics()
                    else:diagnostic_context=nullcontext({})
                    with diagnostic_context as counters:
                        if trial['arm']=='full':record=run_full(spec,profile=profiler,job_runner=resources.job)
                        else:record=run_reference(spec,job_runner=resources.job)
                    if counters:record['optimization_diagnostics']=deepcopy(counters)
                    record.update(task_key=trial['task_key'],trial_id=trial['trial_id'],ordinal=trial['ordinal'],variant=trial['variant'],block_id=trial['block_id'])
                    records.append(record);write_json(arm_root/'run_record.json',record)
                    baseline.validate_record(record,task,trial)
                oracle=check_run(record,v0,job_runner=resources.job,global_deadline_ns=min(resources.global_deadline_ns,resources.arm_deadline_ns))
                record['common_oracle']=oracle;write_json(arm_root/'common_oracle.json',oracle)
                require(oracle['passed'] and oracle['model_fits']==0,'COMMON_ORACLE_FAILED')
                if trial['profiled']:
                    comparison=compare_runs(warmups[(trial['task_key'],trial['variant'])],oracle)
                    require(comparison['passed'],'PROFILE_BUSINESS_CHANGED');record['instrumentation_semantic_comparison']=comparison
                else:
                    group=pending_pairs.setdefault(trial['pair_id'],{});group[trial['arm']]=record
                    if len(group)==2:
                        c=compare_runs(group['full']['common_oracle'],group['reference']['common_oracle']);require(c['passed'],'VARIANT_PAIR_BUSINESS_MISMATCH')
                        f,r=group['full']['primary_wall_ns'],group['reference']['primary_wall_ns']
                        row=dict(pair_id=trial['pair_id'],block_id=trial['block_id'],task_key=trial['task_key'],variant=trial['variant'],phase=trial['phase'],passed=True,comparison=c,full_wall_ns=f,reference_wall_ns=r,full_minus_reference_wall_ns=f-r,ratio=f/r)
                        pairs.append(row);write_json(output/'pairs'/(trial['pair_id']+'.json'),row)
                        if trial['phase']=='warmup':warmups[(trial['task_key'],trial['variant'])]=oracle
                    block=pending_blocks.setdefault(trial['block_id'],[]);block.append(record)
                    if len(block)==4:
                        comparisons=[compare_runs(block[0]['common_oracle'],r['common_oracle']) for r in block[1:]]
                        require(all(c['passed'] for c in comparisons),'FOUR_ARM_BUSINESS_MISMATCH')
                        row=dict(block_id=trial['block_id'],task_key=trial['task_key'],phase=trial['phase'],repeat=trial['repeat'],passed=True,trial_ids=[r['trial_id'] for r in block],comparisons=comparisons,**block_values(block))
                        blocks.append(row);write_json(output/'blocks'/(trial['block_id']+'.json'),row)
                require(not fence.attempts,'NETWORK_FORBIDDEN')
                now_sources=baseline.source_pins();now_sources['scripts/run_sr_optimization.py']=sha_file(REPO/'scripts/run_sr_optimization.py')
                require(now_sources==sources and baseline.input_pins(v0)==inputs and sha_file(plan_path)==plan_hash and sha_file(protocol)==protocol_hash,'SOURCE_INPUT_PROTOCOL_CHANGED')
                write_json(arm_root/'run_record.json',record);resources.end_arm()
                progress=dict(status='running',completed=len(records),planned=104,successful_pairs=len(pairs),successful_blocks=len(blocks),last_trial=trial['trial_id'])
                write_json(output/'progress.json',progress);print(json.dumps({**progress,'wall_seconds':record['primary_wall_ns']/1e9}),flush=True)
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),completed_records=len(records));write_json(output/'FAILURE.json',failure)
    workflow=[j for j in resources.jobs if j['role']=='workflow'];oracle_jobs=[j for j in resources.jobs if j['role']=='common_oracle']
    counts=dict(normal_runs=len(records),fake_http_calls=sum(len(r.get('fake_calls',[])) for r in records),workflow_cpu_jobs=len(workflow),common_oracle_cpu_jobs=len(oracle_jobs),total_supervised_cpu_jobs=len(resources.jobs),fits=sum(j['tool'].startswith('fit_') for j in workflow),predicts=sum(j['tool'].startswith('predict_') for j in workflow),actual_api_requests=0)
    after=baseline.source_pins();after['scripts/run_sr_optimization.py']=sha_file(REPO/'scripts/run_sr_optimization.py');after_inputs=baseline.input_pins(v0)
    complete=failure is None and len(records)==104 and len(pairs)==48 and len(blocks)==24 and sources==after and inputs==after_inputs
    expected={k:v for k,v in plan['expected'].items() if k in counts}
    if complete and counts!=expected:failure=dict(type='COUNT_MISMATCH',counts=counts,expected=expected);complete=False;write_json(output/'FAILURE.json',failure)
    result=dict(schema_version='normal-optimization-result-v1',status='completed' if complete else 'hard_stopped',counts=counts,expected_counts=expected,trials_planned=104,successful_pairs=len(pairs),successful_blocks=len(blocks),failure=failure,elapsed_wall_ns=time.perf_counter_ns()-began,network_attempts=fence.attempts,sources_unchanged=sources==after,inputs_unchanged=inputs==after_inputs,estimands=plan['estimands'])
    write_json(output/'resource_observations.json',resources.observations);write_json(output/'supervised_jobs.json',resources.jobs)
    write_json(output/'integrity.json',dict(source_before=sources,source_after=after,inputs_before=inputs,inputs_after=after_inputs,pin_error=None))
    write_json(output/'summary.json',result);write_json(output/'progress.json',dict(status=result['status'],completed=len(records),planned=104,successful_pairs=len(pairs),successful_blocks=len(blocks)))
    return result
