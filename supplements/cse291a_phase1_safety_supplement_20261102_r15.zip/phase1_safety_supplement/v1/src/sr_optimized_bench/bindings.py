"""Explicit serial experiment bindings, restored on both success and failure."""
from contextlib import contextmanager
import importlib
from sr_tracking_bench.profile import ScopedBindings

def implementation():
    return importlib.import_module('sr_optimized_v1.executor'), importlib.import_module('sr_optimized_v1.validation')

@contextmanager
def variant_context(variant, *, profile=None, campaign=False):
    if variant not in ('legacy','optimized'):raise ValueError('KNOWN_VARIANT_REQUIRED')
    from sr_campaign_v3 import runtime, base_store, store
    from sr_tracking_bench import full
    from sr_campaign_v3.executor import run_job
    if variant=='legacy':
        yield run_job
        return
    executor,validation=implementation()
    from sr_optimized_v1.store import OptimizedV3Store
    with ScopedBindings() as scope:
        scope.set(runtime,'diagnose',validation.optimized_diagnose)
        scope.set(base_store,'diagnose',validation.optimized_diagnose)
        scope.set(runtime,'V3Store',OptimizedV3Store)
        scope.set(full,'V3Store',OptimizedV3Store)
        scope.set(runtime,'run_job',executor.run_job)
        if campaign:
            module=importlib.import_module('sr_campaign_v3.campaign')
            scope.set(module,'V3Store',OptimizedV3Store)
            # numerical_check uses the V2 adapter executor alias; only replace
            # that exact job function, with the same allowlisted tools and limits.
            from sr_cpu_v2 import adapter
            scope.set(adapter,'run_job',executor.run_job)
        if profile is not None:
            store_module=importlib.import_module('sr_optimized_v1.store')
            clone_base=store_module._ValidationBaseStore
            wrapped_guard=profile.wrapper(validation.optimized_diagnose,'guard','OptimizedStore.diagnose')
            for name in ('_check_guard','admit_decision','start_node','finish_node'):
                scope.set(clone_base,name,validation._bound(getattr(clone_base,name),{'diagnose':wrapped_guard}))
            for name in ('_members','disk_usage'):
                if hasattr(executor,name):scope.wrap(executor,name,profile,'optimized_monitor')
            if hasattr(executor,'ProcessTreeScanner'):
                cls=executor.ProcessTreeScanner
                for name in ('members','full_members'):
                    if hasattr(cls,name):scope.wrap(cls,name,profile,'optimized_monitor')
        yield executor.run_job
