"""Recompute saved micro/macro outcomes and work from original records.

Only the standard library is used. This module never imports an agent runner,
model client, sklearn, pickle, or joblib. Original macro numerical acceptance
receipts are checked and linked, not re-executed or portrayed as fresh tests.
"""
from __future__ import annotations

import base64
from collections import Counter, defaultdict
from contextlib import closing
import csv
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import sys
from urllib.parse import quote

POLICIES = ('FULL', 'LAZY', 'EAGER')
FIELDS = ('physical_dispatches', 'known_cost_nano_usd', 'held_cost_nano_usd',
          'node_attempts', 'cpu_jobs', 'fit_jobs', 'predict_jobs',
          'semantic_corrections', 'stale_corrections', 'actual_final_ancestry_reused_results')


class EvidenceError(ValueError):
    pass


def require(value, reason):
    if not value:
        raise EvidenceError(reason)


def strict_json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'DUPLICATE_JSON_KEY:' + key)
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=unique, parse_constant=lambda value:
        (_ for _ in ()).throw(EvidenceError('NONFINITE_JSON:' + value)))


def read(path):
    return strict_json(Path(path).read_text(encoding='utf-8'))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def pin(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return {'sha256': h.hexdigest(), 'size_bytes': Path(path).stat().st_size}


def index(values, key):
    result = {r[key]: r for r in values}
    require(len(result) == len(values), 'DUPLICATE_' + key.upper())
    return result


def within(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    require(path.is_relative_to(root), 'INPUT_PATH_ESCAPE:' + str(relative))
    return path


def offline_only(event, args):
    if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system', 'os.posix_spawn',
            'os.fork', 'os.forkpty', 'pickle.find_class'):
        raise RuntimeError('SAVED_AUDIT_FORBIDS:' + event)
    if event == 'sqlite3.connect':
        value = str(args[0])
        require(value.startswith('file:') and 'mode=ro&immutable=1' in value, 'SQL_MUST_BE_IMMUTABLE_READ_ONLY')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        name = Path(str(args[0])).name.lower()
        require(name not in ('.env', 'credentials', 'id_rsa', 'id_ed25519') and
            not name.endswith(('.joblib', '.pickle', '.pkl', '.npy', '.npz', '.pt', '.pth')),
            'MODEL_ARRAY_OR_CREDENTIAL_FILE_READ_FORBIDDEN')


class Audit:
    def __init__(self):
        self.checks = []

    def check(self, ok, code, ref=None, detail=None):
        self.checks.append({'passed': bool(ok), 'code': code, 'ref': ref, 'detail': detail})
        return bool(ok)

    @property
    def issues(self):
        return [r for r in self.checks if not r['passed']]


class Artifacts:
    def __init__(self, root, entries):
        self.root = Path(root).resolve()
        self.entries = entries
        self.cache = {}

    def get(self, binding, *, json_required=False):
        aid = binding['artifact_id']
        entry = self.entries.get(aid)
        require(entry is not None and entry['binding'] == binding, 'ARTIFACT_BINDING_CHANGED:' + aid)
        if entry['bytes_in_package']:
            path = within(self.root, entry['blob'])
            require(pin(path) == {'sha256': binding['sha256'], 'size_bytes': binding['size_bytes']},
                    'ARTIFACT_BYTES_CHANGED:' + aid)
            if binding['sha256'] not in self.cache:
                self.cache[binding['sha256']] = read(path)
            return self.cache[binding['sha256']]
        require(not json_required, 'EXACT_JSON_ARTIFACT_REQUIRED:' + aid)
        retained = entry.get('retained_remote_record', {})
        require(retained.get('sha256') == binding['sha256'] and retained.get('size_bytes') == binding['size_bytes'],
                'REMOTE_ARTIFACT_INVENTORY_MISMATCH:' + aid)
        return None


def open_readonly(path):
    return sqlite3.connect('file:' + quote(str(Path(path).resolve())) + '?mode=ro&immutable=1', uri=True)


def read_micro_ledger(path):
    with closing(open_readonly(path)) as db:
        db.row_factory = sqlite3.Row
        require(db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'CENTRAL_SQLITE_INTEGRITY')
        return {name: [dict(r) for r in db.execute('SELECT * FROM ' + name + ' ORDER BY rowid')]
                for name in ('campaign', 'calls', 'receipts', 'items', 'events')}


def micro_durable(path, view):
    with closing(open_readonly(path)) as db:
        require(db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'BRANCH_SQLITE_INTEGRITY')
        document = strict_json(db.execute('SELECT payload FROM document WHERE id=1').fetchone()[0])
        events = [strict_json(r[0]) for r in db.execute('SELECT event FROM commands ORDER BY seq')]
    require(document == {k: v for k, v in view.items() if k != 'events'} and events == view['events'],
            'MICRO_SQLITE_EXPORT_MISMATCH')
    return len(events)


def check_call(call, receipt=None):
    """Use raw usage once; completion_tokens already includes reasoning tokens."""
    require(call.get('dispatched') is True, 'CURRENT_CALL_NOT_DISPATCHED')
    evidence = call.get('evidence') or {}
    require(evidence.get('simulated') is False and
            evidence.get('http_evidence', {}).get('real_request_sent') is True, 'REAL_HTTP_EVIDENCE_REQUIRED')
    require(call.get('request') == evidence.get('request') and digest(call['request']) == evidence.get('request_digest'),
            'REQUEST_EVIDENCE_DIGEST')
    http = evidence['http_evidence']
    wire_request = base64.b64decode(http['request_body_b64'], validate=True)
    require(strict_json(wire_request.decode('utf-8')) == call['request'] and http['method'] == 'POST' and
            http['url'] == 'https://tritonai-api.ucsd.edu/v1/chat/completions', 'RAW_HTTP_REQUEST_BYTES_OR_ENDPOINT')
    if call['status'] == 'settled':
        response = evidence.get('raw_response') or {}
        wire_response = base64.b64decode(http['response_body_b64'], validate=True)
        require(hashlib.sha256(wire_response).hexdigest() == http['response_sha256'] and
                strict_json(wire_response.decode('utf-8')) == response, 'RAW_HTTP_RESPONSE_BYTES_MISMATCH')
        usage = call.get('raw_usage')
        require(isinstance(usage, dict) and response.get('usage') == usage, 'RAW_RESPONSE_USAGE_MISMATCH')
        p, c = usage.get('prompt_tokens'), usage.get('completion_tokens')
        require(type(p) is int and type(c) is int and p >= 0 and c >= 0 and usage.get('total_tokens') == p + c,
                'INVALID_RAW_TOKEN_USAGE')
        require(call['known_cost_nano_usd'] == 150 * p + 500 * c and call['held_cost_nano_usd'] == 0,
                'PINNED_PRICE_OR_REASONING_DOUBLE_COUNT')
        normalized = call.get('usage') or {}
        require(normalized.get('prompt_tokens') == p and normalized.get('completion_tokens') == c,
                'NORMALIZED_USAGE_MISMATCH')
        if receipt is not None:
            body = strict_json(receipt['body'])
            require(body.get('raw_usage') == usage and receipt['provider_request_id'] == call['provider_request_id'],
                    'CENTRAL_RECEIPT_USAGE_OR_ID_MISMATCH')
    else:
        require(call['known_cost_nano_usd'] == 0 and call['held_cost_nano_usd'] == call['reserved_cost_nano_usd'] > 0,
                'UNKNOWN_USAGE_HOLD_RELEASED')
    return call['known_cost_nano_usd'], call['held_cost_nano_usd']


def trace_ancestry(view, frozen_dag):
    """Follow actual parents from the committed final result, not selections alone."""
    results = index(view['results'], 'result_id')
    nodes = index(frozen_dag['nodes'], 'node_id')
    sources = index(view['sources'], 'object_key')
    selected = view['state']['selected_by_node']
    final = selected.get('execute' if view['domain'] == 'micro' else 'publish')
    require(final in results, 'NO_FINAL_RESULT')
    invalid = set(view['state']['invalidated_result_ids'])
    seen, visiting = set(), set()

    def visit(rid):
        require(rid not in visiting, 'ANCESTRY_CYCLE')
        if rid in seen:
            return
        require(rid in results, 'MISSING_ACTUAL_PARENT:' + str(rid))
        r = results[rid]
        require(r['node_id'] in nodes and selected.get(r['node_id']) == rid, 'FINAL_CHAIN_SELECTION_MISMATCH')
        require(rid not in invalid and r['execution_status'] == 'success', 'INVALID_OR_UNSUCCESSFUL_FINAL_ANCESTOR')
        node = nodes[r['node_id']]
        parents = r['parent_result_ids']
        require(len(parents) == len(set(parents)), 'DUPLICATE_ACTUAL_PARENT')
        require(all(p in results for p in parents) and
                sorted(results[p]['node_id'] for p in parents) == sorted(node['parents']), 'DAG_PARENT_MISMATCH')
        visiting.add(rid)
        for parent in parents:
            visit(parent)
        snapshot = r['input_snapshot']
        captured = index(snapshot.get('parent_inputs', []), 'result_id')
        require(set(captured) == set(parents), 'CAPTURED_PARENT_IDS_MISMATCH')
        require(all(captured[p]['node_id'] == results[p]['node_id'] and
                    captured[p]['payload'] == results[p]['payload'] for p in parents), 'CAPTURED_PARENT_PAYLOAD_MISMATCH')
        aliases = view.get('source_aliases', {})
        direct_keys = {aliases.get(k, k) for k in node.get('direct_source_keys', [])}
        direct = {x['object_key']: x['version'] for x in r['direct_reads']}
        require(set(direct) == direct_keys and len(direct) == len(r['direct_reads']), 'DIRECT_READ_SET_MISMATCH')
        captured_sources = index(snapshot.get('direct_source_inputs', []), 'object_key')
        require(set(captured_sources) == direct_keys, 'CAPTURED_SOURCE_KEYS_MISMATCH')
        for key, version in direct.items():
            require(key in sources and type(version) is int and version == sources[key]['version'] and
                    captured_sources[key]['version'] == version and
                    captured_sources[key]['payload'] == sources[key]['payload'], 'FINAL_SOURCE_BINDING_STALE:' + key)
        effective = dict(direct)
        for parent in parents:
            for ref in results[parent]['effective_reads']:
                require(ref['object_key'] not in effective or effective[ref['object_key']] == ref['version'],
                        'MIXED_SOURCE_VERSIONS')
                effective[ref['object_key']] = ref['version']
        observed = {x['object_key']: x['version'] for x in r['effective_reads']}
        require(observed == effective and len(observed) == len(r['effective_reads']), 'EFFECTIVE_READ_CLOSURE_MISMATCH')
        require(all(k in sources and type(v) is int and sources[k]['version'] == v for k, v in effective.items()),
                'FINAL_EFFECTIVE_SOURCE_STALE')
        visiting.remove(rid); seen.add(rid)
    visit(final)
    require({results[r]['node_id'] for r in seen} == set(nodes), 'FINAL_CHAIN_MISSING_DAG_STAGE')
    return seen


def reuse_from_ancestry(view, scene, ancestry):
    initial = index(scene['scene_export']['results'], 'result_id')
    require(set(view['metadata']['initial_result_ids']) == set(initial), 'INITIAL_RESULT_IDS_DIFFER')
    results = index(view['results'], 'result_id')
    new_attempts = index(view['attempts'], 'attempt_id')
    attempted_nodes = {a['node_id'] for a in new_attempts.values()}
    reused = sorted(ancestry & set(initial))
    for rid in reused:
        r = results[rid]
        require(r == initial[rid], 'REUSED_RESULT_REWRITTEN:' + rid)
        require(r['attempt_id'] not in new_attempts and r['node_id'] not in attempted_nodes,
                'REUSED_NODE_REEXECUTED:' + rid)
    return reused


def check_micro(view, results, get_artifact):
    selected = view['state']['selected_by_node']
    request = view['task']['request']
    sources = index(view['sources'], 'object_key')
    def source(prefix):
        found = [r['payload'] for k, r in sources.items() if k.startswith(prefix)]
        require(len(found) == 1, 'UNIQUE_MICRO_AUTHORITY:' + prefix)
        return found[0]
    metadata, permission, resources = source('metadata:'), source('permission:'), source('resource')
    n, batch, epochs = metadata['num_examples'], request['batch_size'], request['epochs']
    require(type(n) is int and n >= 0 and type(batch) is int and batch > 0 and type(epochs) is int,
            'INVALID_MICRO_BUSINESS_INPUT')
    require(permission['allowed'] is True and permission['dataset_id'] == request['dataset_id'] and
            permission['purpose'] == request['purpose'], 'CURRENT_PERMISSION_DENIED')
    expected = {**request, 'num_examples': n, 'steps': ((n + batch - 1) // batch) * epochs,
                'workers': min(request['requested_workers'], resources['max_workers']),
                'policy_revision': permission['policy_revision'], 'allowed': True}
    rows = {node: results[rid]['payload'] for node, rid in selected.items()}
    require(rows['read_metadata'] == metadata and rows['read_permission'] == permission and
            rows['read_resources'] == resources, 'MICRO_ANALYST_NOT_CURRENT_AUTHORITY')
    require(rows['plan'] == expected and rows['execute'].get('config') == expected and
            rows['execute'].get('command') == expected and
            rows['execute'].get('action') == 'commit_config_and_draft', 'MICRO_WRONG_PLAN_OR_COMMAND')
    final = results[selected['execute']]
    for key in ('config', 'draft'):
        obj = view['objects'][key]
        require(obj['payload'] == expected and obj['owner_result_id'] == final['result_id'], 'MICRO_WRONG_FINAL_OBJECT')
    for aid in final['artifact_refs']:
        document = get_artifact(aid, True)
        require(document.get('command', document) == expected, 'MICRO_COMMITTED_ARTIFACT_MISMATCH')


def check_macro(view, results, get_artifact, numerical):
    selected = view['state']['selected_by_node']
    rows = {node: results[rid] for node, rid in selected.items()}
    sources = index(view['sources'], 'object_key')
    receipts = index(view['tool_receipts'], 'receipt_id')
    prepare = rows['prepare']['payload']
    train = sources['data:train']['payload']['row_ids_digest']
    validation = sources['split:main']['payload']['validation_row_ids_digest']
    require(prepare['training_row_ids_digest'] == train and prepare['validation_row_ids_digest'] == validation,
            'PREPARE_SOURCE_ROWS_MISMATCH')
    metrics = {}
    for family in ('lr', 'rf'):
        recipe = sources['recipe:' + family]['payload']['parameters']
        planned = rows['plan_' + family]['payload']
        fit, prediction, summary = [rows[n + '_' + family]['payload'] for n in ('fit', 'predict', 'summary')]
        prepared = prepare['families'][family]
        require(planned['parameters'] == recipe and planned['matrix_artifact_id'] == prepared['matrix_artifact_id'],
                'PLANNER_RECIPE_OR_MATRIX_MISMATCH')
        require(fit['parameters'] == recipe and fit['matrix_artifact_id'] == prepared['matrix_artifact_id'] and
                fit['preprocessor_artifact_id'] == prepared['preprocessor_artifact_id'] and
                fit['training_row_ids_digest'] == train, 'MODEL_CURRENT_RECIPE_OR_TRAIN_BINDING')
        require(prediction['model_artifact_id'] == fit['model_artifact_id'] and
                prediction['preprocessor_artifact_id'] == fit['preprocessor_artifact_id'] and
                prediction['training_row_ids_digest'] == train and prediction['validation_row_ids_digest'] == validation,
                'PREDICTION_MODEL_OR_ROWS_BINDING')
        require(summary['model_artifact_id'] == fit['model_artifact_id'] and
                summary['prediction_artifact_id'] == prediction['prediction_artifact_id'] and
                summary['validation_row_ids_digest'] == validation, 'SUMMARY_MODEL_OR_ROWS_BINDING')
        own = [receipts[r] for r in rows['summary_' + family]['tool_receipt_ids']]
        raw = [r['parameters']['unmodified_metrics'] for r in own if 'unmodified_metrics' in r.get('parameters', {})]
        require(len(raw) == 1 and raw[0] == summary['metrics'], 'SUMMARY_NOT_RAW_CPU_METRICS')
        require(all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in raw[0].values()),
                'NONFINITE_OR_INVALID_CPU_METRIC')
        require(get_artifact(summary['metrics_artifact_id'], True)['metrics'] == raw[0], 'METRIC_ARTIFACT_NOT_RAW_CPU_METRICS')
        for node, key in (('fit_' + family, 'model_artifact_id'), ('predict_' + family, 'prediction_artifact_id')):
            require(rows[node]['payload'][key] in rows[node]['artifact_refs'], 'MODEL_OR_PREDICTION_NOT_OWN_ARTIFACT')
            get_artifact(rows[node]['payload'][key])  # Metadata-only for retained binary artifacts.
        row_doc = get_artifact(prepared['rows_artifact_id'], True)
        require(digest(row_doc['train_row_ids']) == train and digest(row_doc['validation_row_ids']) == validation and
                row_doc['training_row_ids_digest'] == train and row_doc['validation_row_ids_digest'] == validation,
                'ACTUAL_PREPARE_ROW_DOCUMENT_MISMATCH')
        metrics[family.upper()] = raw[0]
    ap = {family: value['average_precision'] for family, value in metrics.items()}
    epsilon = view['task']['request'].get('tie_break', {}).get('epsilon', 1e-6)
    winner = 'LR' if ap['LR'] + epsilon >= ap['RF'] else 'RF'
    report = rows['report']['payload']
    require(report['chosen_family'] == report['selected_family'] == winner and
            report['validation_average_precision'] == ap and report['metrics'] == metrics[winner] and
            report['validation_row_ids_digest'] == validation, 'REPORT_CHOICE_OR_EXACT_METRICS_MISMATCH')
    require(report['model_artifact_id'] == rows['fit_' + winner.lower()]['payload']['model_artifact_id'] and
            report['prediction_artifact_id'] == rows['predict_' + winner.lower()]['payload']['prediction_artifact_id'],
            'REPORT_CHOSEN_ARTIFACT_MISMATCH')
    report_doc = get_artifact(report['report_artifact_id'], True)
    require(report_doc == {k: v for k, v in report.items() if k != 'report_artifact_id'}, 'ORIGINAL_REPORT_BYTES_NOT_RESULT')
    publish = rows['publish']['payload']
    expected_manifest = {'action': 'publish_manifest', 'fixture_only': False,
        'selected_family': winner, 'metrics': metrics[winner], 'validation_row_ids_digest': validation,
        **{k: report[k] for k in ('model_artifact_id', 'prediction_artifact_id', 'report_artifact_id')}}
    require(publish['action'] == 'publish_manifest' and publish['publish_manifest'] == expected_manifest and
            get_artifact(publish['candidate_artifact_id'], True) == expected_manifest, 'PUBLISH_CONSUMED_MANIFEST_MISMATCH')
    require(view['objects']['manifest']['payload'] == publish and
            view['objects']['report_index']['payload'] == {'candidate_artifact_id': publish['candidate_artifact_id'],
                'report_result_id': rows['report']['result_id']}, 'COMMITTED_MANIFEST_OR_INDEX_MISMATCH')
    require(numerical is not None, 'RECORDED_NUMERICAL_ACCEPTANCE_MISSING')
    response, spec, execution = numerical['response'], numerical['spec'], numerical['execution']
    payload = response['payload']
    require(response['status'] == 'success' and payload['passed'] is True and not payload['issues'] and
            execution['status'] == 'success' and execution['worker_reaped'] is True and
            execution['returncode'] == 0, 'RECORDED_NUMERICAL_ACCEPTANCE_NOT_PASSED')
    require(spec['inputs']['selected_result_ids'] == selected, 'NUMERICAL_RECEIPT_SELECTED_ID_MISMATCH')
    require(all(spec['inputs']['selected_payloads'][node] == result['payload'] for node, result in rows.items()),
            'NUMERICAL_RECEIPT_PAYLOAD_MISMATCH')
    require(payload['statistics']['expected_selected_family'] == winner and
            payload['statistics']['validation_metrics'] == metrics and payload['statistics']['model_fits'] == 0,
            'NUMERICAL_RECEIPT_METRICS_OR_SCOPE_MISMATCH')


def business_outcome(view, frozen_dag, artifacts, numerical=None):
    """Success is derived from content/receipts; reported status is compared later."""
    try:
        ancestry = trace_ancestry(view, frozen_dag)
        results = index(view['results'], 'result_id')
        bindings = index(view['artifacts'], 'artifact_id')
        def get_artifact(aid, json_required=False):
            require(aid in bindings, 'UNKNOWN_ARTIFACT_ID:' + str(aid))
            return artifacts.get(bindings[aid], json_required=json_required)
        for source in view['sources']:
            require(digest(source['payload']) == source['payload_digest'], 'SOURCE_PAYLOAD_DIGEST_MISMATCH')
            require(not source['object_key'].startswith('permission') or source['payload'].get('allowed') is True,
                    'CURRENT_PERMISSION_DENIED')
        require(view['task']['request'].get('publish_allowed') is not False, 'PUBLISH_NOT_ALLOWED')
        for rid in ancestry:
            r = results[rid]
            for aid in r['artifact_refs']:
                require(aid in bindings and bindings[aid]['producer_result_id'] == rid, 'ARTIFACT_PRODUCER_ID_MISMATCH')
                get_artifact(aid)
            receipts = index(view['tool_receipts'], 'receipt_id')
            for receipt_id in r['tool_receipt_ids']:
                require(receipt_id in receipts and receipts[receipt_id]['producer_result_id'] == rid,
                        'TOOL_RECEIPT_PRODUCER_MISMATCH')
                t = receipts[receipt_id]
                require(t['exit_code'] == 0 and t['fixture_only'] is False, 'TOOL_RECEIPT_NOT_REAL_SUCCESS')
                execution = t.get('parameters', {}).get('execution')
                if view['domain'] == 'macro':
                    require(execution and execution['status'] == 'success' and execution['returncode'] == 0 and
                            execution['worker_reaped'] is True and not execution['timed_out'], 'CPU_JOB_OR_REAP_NOT_SUCCESS')
        state = view['state']
        require(state['status'] == 'terminal' and not state['active_attempt_ids'] and not state['unsettled_call_ids'] and
                not state['pending_node_ids'], 'FINAL_STATE_NOT_QUIESCENT')
        final_node = 'execute' if view['domain'] == 'micro' else 'publish'
        final_id = state['selected_by_node'][final_node]
        effects = [e for e in view['effects'] if e['producer_result_id'] == final_id and e['status'] == 'committed']
        require(len(effects) == 1 and effects[0]['after'] == view['objects'] and
                set(effects[0]['atomic_group']) == set(view['objects']), 'ATOMIC_COMMITTED_EFFECT_MISSING')
        require(all(obj['owner_result_id'] == final_id and obj['version'] > 0 and obj['payload'] is not None
                    for obj in view['objects'].values()), 'FINAL_OBJECT_OWNERSHIP')
        if view['domain'] == 'micro':
            check_micro(view, results, get_artifact)
        else:
            check_macro(view, results, get_artifact, numerical)
        return {'correct': True, 'issues': [], 'final_ancestry_result_ids': sorted(ancestry),
            'numerical_check_scope': 'Retained independent re-prediction receipt, not rerun locally.' if view['domain'] == 'macro' else None}
    except (EvidenceError, KeyError, TypeError, IndexError) as exc:
        return {'correct': False, 'issues': [str(exc)], 'final_ancestry_result_ids': [],
                'numerical_check_scope': 'No local fitting, prediction, or binary loading.'}


def physical_work(view, calls):
    attempts = index(view['attempts'], 'attempt_id')
    own = [t for t in view['tool_receipts'] if t['attempt_id'] in attempts]
    require(len({t['receipt_id'] for t in own}) == len(own), 'DUPLICATE_OWN_CPU_RECEIPT')
    require(all(c['attempt_id'] in attempts for c in calls), 'CURRENT_CALL_OUTSIDE_BRANCH_ATTEMPTS')
    return {'physical_dispatches': sum(c['dispatched'] for c in calls),
        'known_cost_nano_usd': sum(c['known_cost_nano_usd'] for c in calls),
        'held_cost_nano_usd': sum(c['held_cost_nano_usd'] for c in calls),
        'node_attempts': len(attempts), 'cpu_jobs': len(own),
        'fit_jobs': sum(t['node_id'].startswith('fit_') for t in own),
        'predict_jobs': sum(t['node_id'].startswith('predict_') for t in own),
        'semantic_corrections': view['state']['counters']['semantic_used'],
        'stale_corrections': view['state']['counters']['stale_used'],
        'new_call_ids': [c['call_id'] for c in calls], 'new_attempt_ids': sorted(attempts),
        'new_cpu_receipt_ids': sorted(t['receipt_id'] for t in own)}


def link_model_result(view, call, scene=None):
    attempts = index(view['attempts'], 'attempt_id')
    results = index(view['results'], 'result_id')
    attempt = attempts[call['attempt_id']]
    result = results[attempt['result_id']]
    evidence = call['evidence']
    require(evidence['node_id'] == result['node_id'] == attempt['node_id'] and
            evidence['input_digest'] == result['input_digest'] == attempt['input_digest'] and
            evidence['input_snapshot'] == result['input_snapshot'], 'MODEL_RESULT_CAPTURE_MISMATCH')
    require(call['call_id'] in result['call_ids'], 'RESULT_MISSING_ACTUAL_CALL_ID')
    raw = strict_json(evidence['raw_response']['choices'][0]['message']['content'])
    if raw == result['payload']:
        return 'exact_model_payload'
    fault = (scene or {}).get('fault_evidence') or {}
    if fault.get('target_result_id') == result['result_id']:
        require(fault.get('raw_payload') == raw and fault.get('delivered_payload') == result['payload'],
                'INJECTED_OUTPUT_NOT_REGISTERED_TRANSFORM')
        return 'registered_delivered_fault'
    if view['domain'] == 'macro' and result['node_id'] == 'report':
        require(raw == {k: v for k, v in result['payload'].items() if k != 'report_artifact_id'},
                'REPORT_RESULT_DIFFERS_FROM_MODEL_OUTPUT')
        return 'controller_added_report_artifact_id'
    if view['domain'] == 'macro' and result['node_id'] == 'publish':
        payload = result['payload']
        candidate = payload['publish_manifest']
        visible = raw['report']
        require(raw['action'] == payload['action'] == candidate['action'] == 'publish_manifest' and
            all(candidate[k] == visible[k] for k in ('selected_family', 'metrics', 'model_artifact_id',
                'prediction_artifact_id', 'report_artifact_id', 'validation_row_ids_digest')),
                'PUBLISH_CANDIDATE_DIFFERS_FROM_CONSUMED_MODEL_FIELDS')
        return 'controller_materialized_consumed_publish_fields'
    raise EvidenceError('RESULT_DIFFERS_FROM_MODEL_OUTPUT_WITHOUT_REGISTERED_TRANSFORM')


def publish_copy_diagnostic(view, calls):
    if view['domain'] != 'macro' or not view['state']['selected_by_node'].get('publish'):
        return None
    results = index(view['results'], 'result_id')
    final = results[view['state']['selected_by_node']['publish']]
    own = [c for c in calls if c['attempt_id'] == final['attempt_id']]
    require(len(own) == 1, 'FINAL_PUBLISH_PHYSICAL_CALL_MISSING')
    evidence = own[0]['evidence']
    parents = evidence['input_snapshot']['parent_inputs']
    require(len(parents) == 1 and parents[0]['result_id'] == view['state']['selected_by_node']['report'],
            'PUBLISH_VISIBLE_REPORT_ID_MISMATCH')
    visible = parents[0]['payload']
    response = strict_json(evidence['raw_response']['choices'][0]['message']['content'])
    report = response.get('report', {})
    consumed = ('selected_family', 'metrics', 'model_artifact_id', 'prediction_artifact_id',
                'report_artifact_id', 'validation_row_ids_digest')
    return {'call_id': own[0]['call_id'], 'full_raw_publish_object_copy_exact': report == visible,
        'report_text_exact': report.get('report_text') == visible.get('report_text'),
        'consumed_fields_exact': all(report.get(k) == visible.get(k) for k in consumed),
        'mismatched_fields': sorted(k for k in set(report) | set(visible) if report.get(k) != visible.get(k)),
        'scope': 'Instruction compliance diagnostic. Original report artifact remains checked separately and exactly.'}


def reconcile_saved_calls(saved, durable):
    old, current = index(saved, 'call_id'), index(durable, 'call_id')
    require(all(current.get(cid) == call for cid, call in old.items()), 'SAVED_CALL_REWRITTEN_OR_MISSING_FROM_DURABLE')
    return [call for cid, call in current.items() if cid not in old]


def aggregate(records):
    return {'registered': len(records), 'completed_correct': sum(r['business_completed_correct'] for r in records),
        **{field: sum(r[field] or 0 for r in records) for field in FIELDS}}


def chronological_budget(ledgers, latest):
    baseline = ledgers[0]['baseline']
    require(all(l['baseline'] == baseline for l in ledgers), 'INHERITED_BASELINE_CHANGED')
    calls = [c for ledger in ledgers for c in ledger['calls']]
    index(calls, 'call_id')
    for c in calls:
        check_call(c)
    known = baseline['known_cost_nano_usd'] + sum(c['known_cost_nano_usd'] for c in calls)
    held = baseline['held_cost_nano_usd'] + sum(c['held_cost_nano_usd'] for c in calls)
    extra = sum(max(0, c.get('late_known_exposure_nano_usd', 0) - c['known_cost_nano_usd'] - c['held_cost_nano_usd']) for c in calls)
    observed = {'generation_calls': baseline['physical_calls'] + sum(c['dispatched'] for c in calls),
        'known_cost_nano_usd': known, 'held_cost_nano_usd': held,
        'known_plus_held_nano_usd': known + held, 'unsettled_exposure_adjustment_nano_usd': extra,
        'risk_adjusted_known_plus_held_nano_usd': known + held + extra,
        'max_cost_nano_usd': baseline['max_cumulative_cost_nano_usd'],
        'remaining_after_risk_nano_usd': baseline['max_cumulative_cost_nano_usd'] - known - held - extra}
    require(observed == latest['cumulative'], 'FINAL_BUDGET_DIFFERS_FROM_ALL_PHYSICAL_CALLS')
    require(observed['remaining_after_risk_nano_usd'] >= 0, 'CUMULATIVE_BUDGET_CAP_EXCEEDED')
    return {**observed, 'provider_account_debit_verified': False,
        'historical_baseline_scope': 'Earlier 1605 calls are an inherited pinned high-water mark, not re-audited here.',
        'included_post_baseline_call_ids': sorted(c['call_id'] for c in calls),
        'epochs': [{'schema_version': l['schema_version'], 'physical_calls': len(l['calls']),
            'known_cost_nano_usd': sum(c['known_cost_nano_usd'] for c in l['calls']),
            'held_cost_nano_usd': sum(c['held_cost_nano_usd'] for c in l['calls'])} for l in ledgers]}


def verify_inputs(root):
    pins = read(root / 'INPUT_MANIFEST.json')['files']
    for relative, expected in pins.items():
        require(pin(within(root, relative)) == expected, 'PINNED_INPUT_CHANGED:' + relative)
    if (root / 'MANIFEST.json').is_file():
        for relative, expected in read(root / 'MANIFEST.json')['files'].items():
            require(pin(within(root, relative)) == expected, 'SEALED_PACKAGE_CHANGED:' + relative)
    return len(pins)


def recompute(root):
    root = Path(root).resolve()
    pinned_files = verify_inputs(root)
    audit = Audit()
    s4, s6 = [read(root / f'raw/{d}/campaign_state.json') for d in ('micro', 'macro')]
    previous = read(root / 'history/v5_campaign_state.json')
    artifact_index = read(root / 'ARTIFACT_INDEX.json')
    latest_budget = read(root / 'raw/FINAL_BUDGET.json')
    reference = read(root / 'reference/COMBINED_EVIDENCE_AUDIT.json')
    micro_sql = read_micro_ledger(root / 'raw/micro/central.sqlite')
    semantic = read(root / 'raw/macro/central_sql_export.json')
    macro_sql = semantic['macro_epoch3/budget/central.sqlite']['tables']
    states = {'micro': s4, 'macro': s6}
    sqls = {'micro': micro_sql, 'macro': macro_sql}
    registry_bytes = (root / 'contracts/formal_items.jsonl').read_bytes()
    registry = [strict_json(line) for line in registry_bytes.decode().splitlines() if line]
    registry_sha = hashlib.sha256(registry_bytes).hexdigest()
    audit.check(len(registry) == 52 and s4['registry_sha256'] == s6['registry_sha256'] == registry_sha,
                'ORIGINAL_52_REGISTRATION_UNCHANGED')
    micro_items = [i for i in s4['items'] if i['domain'] == 'micro']
    audit.check(micro_items == [i for i in s6['items'] if i['domain'] == 'micro'], 'MICRO_CARRIED_UNCHANGED_NOT_RERUN')
    # The V5 runner JSON predates its last five durable calls. Use the V6 SQL
    # initialize event's inherited high-water mark, without rewriting that JSON.
    initialize = next(strict_json(e['body']) for e in macro_sql['events'] if e['kind'] == 'initialize')
    durable_previous = initialize['predecessor']['snapshot']
    audit.check(durable_previous == s6['ledger']['predecessor']['snapshot'] and
        durable_previous['predecessor']['snapshot'] == s4['ledger'], 'EXACT_DURABLE_PRIOR_FAILURE_LEDGER_CHAIN')
    old_saved = index(previous['ledger']['calls'], 'call_id')
    old_durable = index(durable_previous['calls'], 'call_id')
    missing_previous = reconcile_saved_calls(previous['ledger']['calls'], durable_previous['calls'])
    audit.check(True, 'V5_RUNNER_SNAPSHOT_IS_UNCHANGED_DURABLE_PREFIX')
    snapshot_reconciliation = {'V5_saved_call_count': len(old_saved), 'V5_inherited_durable_call_count': len(old_durable),
        'additional_durable_calls': [{'call_id': c['call_id'], 'item_id': c['item_id'],
            'known_cost_nano_usd': c['known_cost_nano_usd'], 'held_cost_nano_usd': c['held_cost_nano_usd']}
            for c in missing_previous], 'additional_durable_known_cost_nano_usd': sum(c['known_cost_nano_usd'] for c in missing_previous),
        'old_saved_JSON_modified': False, 'authority': 'Original V6 central SQL initialize event predecessor snapshot.'}
    cohorts, discrepancies, all_current_call_ids = {}, [], []
    for domain, state in states.items():
        tables = sqls[domain]
        durable_calls = [strict_json(r['body']) for r in tables['calls']]
        audit.check(index(durable_calls, 'call_id') == index(state['ledger']['calls'], 'call_id'),
                    'DURABLE_CALLS_MATCH_STATE', domain)
        config = strict_json(tables['campaign'][0]['config'])
        audit.check(config == state['ledger']['config'], 'DURABLE_CONFIG_MATCH_STATE', domain)
        receipts = index(tables['receipts'], 'call_id')
        for call in durable_calls:
            try:
                require(call['status'] != 'settled' or call['call_id'] in receipts, 'SETTLED_CENTRAL_RECEIPT_MISSING')
                check_call(call, receipts.get(call['call_id']))
                sqlrow = next(r for r in tables['calls'] if r['call_id'] == call['call_id'])
                if call['status'] == 'settled':
                    require(sqlrow['settlement_digest'] == digest(strict_json(receipts[call['call_id']]['body'])),
                            'SETTLEMENT_RECEIPT_DIGEST')
                audit.check(True, 'RAW_HTTP_USAGE_AND_PRICE', call['call_id'])
            except (EvidenceError, KeyError, TypeError) as exc:
                audit.check(False, 'RAW_HTTP_USAGE_AND_PRICE', call['call_id'], str(exc))
        items = [i for i in state['items'] if i['domain'] == domain]
        scenes = index([s for s in state['scenes'] if s['domain'] == domain], 'scene_id')
        calls = [c for c in durable_calls if c['domain'] == domain]
        all_current_call_ids.extend(c['call_id'] for c in calls)
        owned = defaultdict(list)
        for c in calls:
            owned[c['item_id']].append(c)
        require(not set(owned) - {i['item_id'] for i in items}, 'UNREGISTERED_CALL_OWNER')
        dag = read(root / f'contracts/{domain}_dag.json')
        artifacts = Artifacts(root, artifact_index[domain])
        rows = []
        for item in items:
            iid, view = item['item_id'], item['raw_export']
            raw_path = root / f'raw/{domain}/exports/{iid}.json'
            audit.check(pin(raw_path)['sha256'] == item['export_sha256'] and read(raw_path) == view and
                        digest(view) == item['raw_export_digest'], 'ORIGINAL_BRANCH_EXPORT', iid)
            if domain == 'micro':
                try:
                    events = micro_durable(root / f'raw/micro/databases/{iid}.sqlite', view)
                    audit.check(True, 'MICRO_DURABLE_BRANCH_AND_EVENTS', iid, events)
                except EvidenceError as exc:
                    audit.check(False, 'MICRO_DURABLE_BRANCH_AND_EVENTS', iid, str(exc))
            scene = scenes.get(item.get('scene_id'))
            if item['kind'] == 'branch':
                audit.check(bool(scene) and scene['qualified'] and scene['eligibility_receipt']['passed'] and
                    digest(scene['scene_export']) == item['freeze_digest'] == scene['freeze_digest'] == view['prefix_digest'] and
                    view['initial_snapshot'] == scene['scene_export'], 'SAME_QUALIFIED_FROZEN_SCENE', iid)
            model_links = []
            for call in owned[iid]:
                try:
                    explanation = link_model_result(view, call, scene)
                    model_links.append({'call_id': call['call_id'], 'result_link': explanation})
                    audit.check(True, 'RAW_MODEL_OUTPUT_TO_RESULT_LINK', call['call_id'], explanation)
                except (EvidenceError, KeyError, TypeError, ValueError) as exc:
                    audit.check(False, 'RAW_MODEL_OUTPUT_TO_RESULT_LINK', call['call_id'], str(exc))
            numerical_path = root / f'raw/macro/numerical/{iid}.json'
            numerical = read(numerical_path) if domain == 'macro' and numerical_path.is_file() else None
            business = business_outcome(view, dag, artifacts, numerical)
            expected_label = item['status'] == 'completed_correct'
            audit.check(business['correct'] == expected_label, 'RECOMPUTED_BUSINESS_MATCHES_REPORTED_STATUS', iid,
                None if business['correct'] == expected_label else business['issues'])
            reused = [] if item['kind'] != 'branch' else None
            if business['correct']:
                try:
                    reused = reuse_from_ancestry(view, scene, set(business['final_ancestry_result_ids'])) if scene and item['kind'] == 'branch' else []
                    audit.check(item['policy'] != 'FULL' or not reused, 'FULL_HAS_NO_PREFIX_REUSE', iid)
                except EvidenceError as exc:
                    audit.check(False, 'REUSE_VALIDITY', iid, str(exc))
            work = physical_work(view, owned[iid])
            copy_diagnostic = publish_copy_diagnostic(view, owned[iid]) if business['correct'] else None
            if copy_diagnostic is not None:
                audit.check(copy_diagnostic['consumed_fields_exact'], 'PUBLISH_BUSINESS_CRITICAL_RAW_COPY_EXACT', iid)
            audit.check(set(work['new_call_ids']) == set(item['physical_dispatch_ids']), 'CENTRAL_CALL_PARTITION', iid)
            audit.check(work['physical_dispatches'] == view['state']['counters']['physical_calls'] and
                        work['cpu_jobs'] == view['state']['counters']['cpu_jobs'], 'RAW_WORK_MATCHES_COUNTERS', iid)
            results = index(view['results'], 'result_id')
            row = {'domain': domain, 'cohort': 'V4-original-real-micro' if domain == 'micro' else 'V6-macro-precision-report-r3-real',
                'item_id': iid, 'kind': item['kind'], 'policy': item['policy'], 'scene_id': item.get('scene_id'),
                'condition': scene['condition'] if scene else None, 'status': item['status'],
                'business_completed_correct': business['correct'], 'business_check': business,
                'raw_model_result_links': model_links,
                'full_raw_publish_object_copy_exact': copy_diagnostic['full_raw_publish_object_copy_exact'] if copy_diagnostic else None,
                'publish_copy_diagnostic': copy_diagnostic,
                **work, 'actual_final_ancestry_reused_results': len(reused) if reused is not None else None,
                'actual_final_ancestry_reused_result_ids': reused,
                'actual_reused_node_ids': sorted(results[r]['node_id'] for r in reused) if reused is not None else None,
                'actual_reused_fit_results': sum(results[r]['node_id'].startswith('fit_') for r in reused) if reused is not None else None,
                'same_freeze': item['kind'] == 'branch' and bool(scene) and item['freeze_digest'] == scene['freeze_digest'],
                'reported_error': item.get('error')}
            old = next(r for r in reference['cohorts'][domain]['items'] if r['item_id'] == iid)
            for field in (*FIELDS, 'business_completed_correct', 'actual_final_ancestry_reused_result_ids',
                          'full_raw_publish_object_copy_exact', 'status'):
                if row[field] != old[field]:
                    discrepancies.append({'domain': domain, 'item_id': iid, 'field': field, 'recomputed': row[field], 'previous': old[field]})
            rows.append(row)
        branches = [r for r in rows if r['kind'] == 'branch']
        policy = {p: aggregate([r for r in branches if r['policy'] == p]) for p in POLICIES}
        condition = {n: {p: aggregate([r for r in branches if r['policy'] == p and r['condition'] == n])
            for p in POLICIES} for n in ('N1', 'N2', 'N3')}
        scene_comparisons = []
        for sid, scene in scenes.items():
            triplet = {r['policy']: r for r in branches if r['scene_id'] == sid}
            audit.check(set(triplet) == set(POLICIES), 'COMPLETE_SCENE_POLICY_TRIPLET', sid)
            same = all(r['same_freeze'] for r in triplet.values())
            for p in ('LAZY', 'EAGER'):
                full, selective = triplet['FULL'], triplet[p]
                both_correct = full['business_completed_correct'] and selective['business_completed_correct']
                scene_comparisons.append({'scene_id': sid, 'condition': scene['condition'], 'policy': p,
                    'same_freeze': same, 'both_correct': both_correct,
                    **{f'difference_{key}': full[key] - selective[key] if same and both_correct else None
                        for key in ('physical_dispatches', 'known_cost_nano_usd', 'node_attempts', 'cpu_jobs', 'fit_jobs')}})
        cohorts[domain] = {'cohort': rows[0]['cohort'], 'items': rows, 'policy_branch_aggregates': policy,
            'condition_policy_branch_aggregates': condition, 'scene_comparisons': scene_comparisons,
            'all_cohort_rows': aggregate(rows), 'native_sqlite_branches_checked': domain == 'micro',
            'numerical_scope': 'Saved independent numerical acceptance receipts linked and checked; no fresh predictions.' if domain == 'macro' else 'Deterministic rules recomputed from current authority.'}
        if domain == 'macro':
            completed = [r for r in rows if r['business_completed_correct']]
            cohorts[domain]['publish_copy_summary'] = {'completed_items': len(completed),
                'full_raw_copy_exact': sum(r['full_raw_publish_object_copy_exact'] is True for r in completed),
                'full_raw_copy_noncompliant': sum(r['full_raw_publish_object_copy_exact'] is False for r in completed),
                'all_consumed_fields_exact': all(r['publish_copy_diagnostic']['consumed_fields_exact'] for r in completed)}
    require(len(set(all_current_call_ids)) == len(all_current_call_ids), 'CURRENT_COHORT_CALLS_OVERLAP')
    budget = chronological_budget([s4['ledger'], durable_previous, s6['ledger']], latest_budget)
    history = []
    for name, state in (('V4', s4), ('V5', previous)):
        rows = [i for i in state['items'] if i['domain'] == 'macro']
        history_ledger = durable_previous if name == 'V5' else state['ledger']
        history.append({'epoch': name, 'scope': 'Historical version; excluded from corrected V6 completion denominator.',
            'status_counts': dict(Counter(i['status'] for i in rows)),
            'items': [{'item_id': i['item_id'], 'kind': i['kind'], 'status': i['status'], 'error': i.get('error')}
                for i in rows], 'macro_calls': [{k: c.get(k) for k in ('call_id', 'item_id', 'status', 'failure_reason',
                    'known_cost_nano_usd', 'held_cost_nano_usd')} for c in history_ledger['calls'] if c['domain'] == 'macro']})
    audit.check(not discrepancies, 'ZERO_DIFFERENCES_FROM_PREVIOUS_TABLES', detail=len(discrepancies))
    return {'schema_version': 'real-cohort-offline-recomputation-v1', 'passed': not audit.issues,
        'input_files_verified': pinned_files, 'checks': audit.checks, 'issues': audit.issues,
        'cohorts': cohorts, 'differences': discrepancies, 'budget': budget, 'historical_failures': history,
        'runner_snapshot_reconciliation': snapshot_reconciliation,
        'new_real_api_requests': 0, 'new_training': 0, 'new_prediction': 0,
        'scope_limits': ['Micro and macro are different frozen versions and are not pooled as one experiment.',
            'Raw original records are input; previous summary tables are used only for the final difference report.',
            'Macro correctness is recomputed for exact business fields, current provenance and original JSON artifact bytes.',
            'Macro model/array/native DB binary bytes remain remote; numerical correctness also relies on linked saved independent re-prediction receipts.',
            'No local numerical metric calculation from prediction arrays, model deserialization, inference, fitting, or new prediction occurs.',
            'All post-baseline epoch costs and unknown holds are retained. Earlier baseline 1605 calls are a pinned high-water mark.',
            'One run per task/scenario/policy; not a repeated-trial reliability estimate or evidence of general EAGER superiority.',
            'Raw publish-copy compliance is independently recomputed and separated from consumed-field correctness.']}


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def write_outputs(result, output):
    output = Path(output).resolve()
    require(not output.exists(), 'FRESH_OUTPUT_REQUIRED')
    output.mkdir(parents=True)
    save(output / 'recomputed.json', result)
    save(output / 'differences.json', {'passed': not result['differences'], 'differences': result['differences']})
    save(output / 'historical_failures.json', result['historical_failures'])
    save(output / 'budget_recomputed.json', result['budget'])
    save(output / 'runner_snapshot_reconciliation.json', result['runner_snapshot_reconciliation'])
    save(output / 'publish_copy_compliance.json', result['cohorts']['macro']['publish_copy_summary'])
    rows = [r for c in result['cohorts'].values() for r in c['items']]
    columns = ('domain', 'cohort', 'item_id', 'kind', 'policy', 'scene_id', 'condition', 'status',
               'business_completed_correct', *FIELDS, 'actual_final_ancestry_reused_result_ids', 'new_call_ids')
    with (output / 'items.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows({k: canonical(v) if isinstance(v, (list, dict)) else v for k, v in r.items()} for r in rows)
    summary = {'passed': result['passed'], 'checks_count': len(result['checks']), 'issue_count': len(result['issues']),
        'difference_count': len(result['differences']), 'input_files_verified': result['input_files_verified'],
        'cohorts': {d: c['policy_branch_aggregates'] for d, c in result['cohorts'].items()},
        'cumulative_known_plus_held_nano_usd': result['budget']['known_plus_held_nano_usd'],
        'new_real_api_requests': 0, 'new_training': 0, 'new_prediction': 0,
        'scope_limits': result['scope_limits'],
        'outputs': {p.name: pin(p) for p in sorted(output.iterdir())}}
    save(output / 'EVALUATION_RECEIPT.json', summary)
    return summary
