"""Read-only evaluation of saved real API cohorts; no execution dependencies."""
