"""Explicit synthetic contracts for maintenance validation; not formal V0 data."""
import json
from pathlib import Path


def prepare_offline_contract(source_v0, destination):
    source, destination = Path(source_v0), Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    for relative in ("budget/historical_baseline.json", "budget/budget_contract.json",
                     "registry/formal_items.jsonl", "registry/registry_contract.json"):
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((source / relative).read_bytes())
    path = destination / "budget/budget_contract.json"
    contract = json.loads(path.read_text())
    contract.update(financial_reservation_nano_usd_per_new_dispatch=1_924_000,
                    maintenance_fixture_only=True,
                    note="Synthetic engine validation; not the formal frozen V0 contract.")
    path.write_text(json.dumps(contract, sort_keys=True) + "\n")
    return destination


def offline_binding():
    return dict(model="api-glm-5.3-flash", allowed_response_models=["api-glm-5.3-flash"],
                base_url="https://tritonai-api.ucsd.edu/v1", input_nano_usd_per_token=150,
                output_nano_usd_per_token=500, max_input_tokens=4000, max_output_tokens=2048,
                financial_input_allowance=6000,
                financial_reservation_nano_usd_per_dispatch=1_924_000,
                reasoning_effort="low", total_request_deadline_seconds=120,
                simulated=True, real_requests_authorized=False, automatic_http_retries=0,
                execution_mode="offline_fake_http", cached_input_nano_usd_per_token=None)
