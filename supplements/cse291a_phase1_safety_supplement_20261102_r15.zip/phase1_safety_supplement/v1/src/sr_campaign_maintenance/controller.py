"""Durable, offline-only pre-admission stop seam.

A durable intent is written BEFORE changing the ledger, so a controller killed
between quarantine/finalization/state flush can complete the SAME stop. Loading
a stopped controller never clears its stop, creates a new call, or invokes its
injected client. Financially unknown calls stay unknown; they prevent a
quiescent-checkpoint claim. This module has no credentials or transport.
"""
from copy import deepcopy
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import tempfile

from sr_campaign_v6.engine import V3BudgetError, RESERVATION, _digest, _now, _require
from .budget import OfflineMaintenanceBudget, STOPPED_BEFORE_ADMISSION


def atomic_json(path, value):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix=".maintenance-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as out:
            json.dump(value, out, sort_keys=True, ensure_ascii=False, allow_nan=False)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
        dfd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class AdmissionController:
    """One offline admission action, explicitly separate from V6 campaign()."""

    def __init__(self, root, budget, *, initial_state=None):
        _require(type(budget) is OfflineMaintenanceBudget, "MAINTENANCE_OFFLINE_ONLY")
        self.root, self.budget = Path(root).resolve(), budget
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "campaign_state.json"
        self.intent_path = self.root / "admission_stop.intent.json"
        self.lock_path = self.root / ".admission-controller.lock"
        with self._exclusive():
            if self.path.exists():
                _require(initial_state is None, "MAINTENANCE_STATE_ALREADY_CREATED")
            else:
                _require(isinstance(initial_state, dict), "MAINTENANCE_INITIAL_STATE_REQUIRED")
                state = deepcopy(initial_state)
                state.update(mode="offline_fake_http", maintenance_candidate=True,
                             stop_reason=None, authority_binding=self._identity())
                atomic_json(self.path, state)
            self._load_state()
            if self.intent_path.exists():
                self._finish_stop(json.loads(self.intent_path.read_text()))

    @contextmanager
    def _exclusive(self):
        fd = os.open(self.lock_path, os.O_CREAT | os.O_RDWR | os.O_CLOEXEC, 0o600)
        try:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise V3BudgetError("MAINTENANCE_CONTROLLER_LOCK_HELD") from None
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def _identity(self):
        # Compare the durable config too: an in-memory budget.config mutation
        # must not silently rebind an existing controller or stop intent.
        config = json.loads(self.budget.connection.execute("SELECT config FROM campaign").fetchone()[0])
        _require(config == self.budget.config, "MAINTENANCE_LEDGER_CONFIG_MISMATCH")
        ledger_path = str(self.budget.path.resolve())
        _require(config["authority"]["ledger_path"] == ledger_path
                 and self.budget.ref == ledger_path, "MAINTENANCE_LEDGER_CONFIG_MISMATCH")
        return dict(campaign_id=config["campaign_id"], ledger_path=ledger_path,
                    config_digest=_digest(config))

    def _load_state(self):
        self.state = json.loads(self.path.read_text())
        _require(self.state.get("mode") == "offline_fake_http"
                 and self.state.get("maintenance_candidate") is True,
                 "MAINTENANCE_OFFLINE_ONLY")
        _require(self.state.get("authority_binding") == self._identity(),
                 "MAINTENANCE_CONTROLLER_BINDING_MISMATCH")

    @staticmethod
    def _fenced_calls_digest(calls, reason):
        calls = deepcopy(calls)
        for call in calls:
            if call["status"] in ("reserved", "dispatched"):
                call.update(status="uncertain", held_cost_nano_usd=RESERVATION,
                            uncertainty_reason=reason)
        return _digest(calls)

    @staticmethod
    def _exposure(snapshot):
        return {key: snapshot["cumulative_budget"][key] for key in
                ("known_cost_nano_usd", "held_cost_nano_usd", "known_plus_held_nano_usd",
                 "unsettled_exposure_adjustment_nano_usd",
                 "risk_adjusted_known_plus_held_nano_usd")}

    def _finish_stop(self, intent):
        _require(set(intent) == {"item_id", "row", "row_digest", "reason", "reason_code",
                                 "calls_digest", "fenced_calls_digest", "reopened_fenced_calls_digest",
                                 "exposure", "deadline_at",
                                 "authority_binding"},
                 "MAINTENANCE_STOP_INTENT_INVALID")
        _require(intent["authority_binding"] == self._identity()
                 == self.state["authority_binding"],
                 "MAINTENANCE_STOP_BINDING_MISMATCH")
        _require(_digest(intent["row"]) == intent["row_digest"],
                 "MAINTENANCE_STOP_INTENT_INVALID")
        stopped = intent["row"]
        _require(stopped["item_id"] == intent["item_id"]
                 and stopped["status"] == STOPPED_BEFORE_ADMISSION
                 and stopped["run_count"] == 0 and stopped["started_at"] is None
                 and not stopped["physical_dispatch_ids"],
                 "MAINTENANCE_STOP_INTENT_INVALID")
        row = next(i for i in self.state["items"] if i["item_id"] == intent["item_id"])
        _require(row["deadline_at"] == intent["deadline_at"], "FIXED_DEADLINE_CHANGED")
        _require(row["status"] in ("not_started", STOPPED_BEFORE_ADMISSION)
                 and row["run_count"] == 0 and row["started_at"] is None
                 and not row["physical_dispatch_ids"],
                 "ADMISSION_STOP_STATE_CONFLICT")
        current = self.budget.snapshot()
        # Quarantine may mark already reserved/dispatched calls uncertain. It
        # never changes their amounts, IDs or provider usage. Admission cannot
        # proceed while any such call exists, and the resulting hold survives.
        if current["status"] == "active":
            _require(_digest(current["calls"]) == intent["calls_digest"],
                     "ADMISSION_STOP_CALL_HISTORY_CHANGED")
            self.budget.quarantine(None, intent["reason"])
        else:
            _require(current["status"] == "quarantined"
                     and current["pause_reason"] in
                     (intent["reason"], "REOPEN_WITH_UNFINISHED_PROGRESS"),
                     "ADMISSION_STOP_LEDGER_REASON_CONFLICT")
        current = self.budget.snapshot()
        # A process reopening the frozen engine may fence dispatched calls
        # BEFORE this controller loads its intent. Both exact expected bodies
        # are pinned in the intent; arbitrary same-cost history is not allowed.
        allowed = {intent["fenced_calls_digest"]}
        if current["pause_reason"] == "REOPEN_WITH_UNFINISHED_PROGRESS":
            allowed.add(intent["reopened_fenced_calls_digest"])
        _require(_digest(current["calls"]) in allowed,
                 "ADMISSION_STOP_CALL_HISTORY_CHANGED")
        _require(self._exposure(current) == intent["exposure"],
                 "ADMISSION_STOP_CHANGED_EXPOSURE")
        self.budget.finalize_item(intent["item_id"], STOPPED_BEFORE_ADMISSION,
                                  intent["row_digest"])
        snapshot = self.budget.snapshot()
        _require(self._exposure(snapshot) == intent["exposure"],
                 "ADMISSION_STOP_CHANGED_EXPOSURE")
        row.clear()
        row.update(deepcopy(intent["row"]))
        self.state["stop_reason"] = dict(code=intent["reason_code"], message=intent["reason"])
        self.state["ledger"] = snapshot
        unsettled = [c["call_id"] for c in snapshot["calls"] if c["status"] != "settled"]
        self.state["stop_receipt"] = dict(
            item_id=intent["item_id"], terminal_status=STOPPED_BEFORE_ADMISSION,
            no_item_dispatch=True, resume_authorized=False,
            all_current_calls_settled=not unsettled, unsettled_call_ids=unsettled,
            historical_unknown_holds_preserved=True, exposure_unchanged=True,
            fixed_deadline_at=intent["deadline_at"],
            authority_binding=deepcopy(intent["authority_binding"]),
            scope="ledger and persisted state only; no worker-reap assertion")
        atomic_json(self.path, self.state)
        return deepcopy(self.state["stop_receipt"])

    def advance(self, item_id, after_admission, *, scope="item"):
        """Never calls after_admission after a stop, including process reopen."""
        with self._exclusive():
            self._load_state()
            return self._advance_locked(item_id, after_admission, scope=scope)

    def _advance_locked(self, item_id, after_admission, *, scope):
        if self.intent_path.exists():
            return self._finish_stop(json.loads(self.intent_path.read_text()))
        if self.state["stop_reason"] is not None:
            raise V3BudgetError("STOPPED_STATE_REQUIRES_DURABLE_INTENT")
        row = next(i for i in self.state["items"] if i["item_id"] == item_id)
        _require(row["status"] == "not_started" and row["run_count"] == 0
                 and row["started_at"] is None and not row["physical_dispatch_ids"],
                 "MAINTENANCE_UNSTARTED_SLOT_REQUIRED")
        _require(not any(c["item_id"] == item_id for c in self.budget.calls()),
                 "NOT_RUN_ITEM_HAS_CALL_HISTORY")
        try:
            admission = self.budget.check_admission(item_id, scope)
        except V3BudgetError as exc:
            _require(self.budget.snapshot()["status"] == "active",
                     "PREEXISTING_LEDGER_STOP_REQUIRES_RECONCILIATION")
            stopped_row = deepcopy(row)
            stopped_row.update(status=STOPPED_BEFORE_ADMISSION, finished_at=_now(),
                               error={"code": exc.code, "message": str(exc)})
            snapshot = self.budget.snapshot()
            reason = "MAINTENANCE_ADMISSION_STOP:" + exc.code
            intent = dict(item_id=item_id, row=stopped_row, row_digest=_digest(stopped_row),
                          reason=reason, authority_binding=self._identity(),
                          reason_code=exc.code, calls_digest=_digest(snapshot["calls"]),
                          fenced_calls_digest=self._fenced_calls_digest(snapshot["calls"], reason),
                          reopened_fenced_calls_digest=self._fenced_calls_digest(
                              snapshot["calls"], "REOPEN_WITH_UNFINISHED_PROGRESS"),
                          exposure=self._exposure(snapshot), deadline_at=row["deadline_at"])
            atomic_json(self.intent_path, intent)
            return self._finish_stop(intent)
        # This seam owns a single handoff. Persist it before invoking even a
        # fake client so a crash/reopen cannot hand the same slot off again.
        row.update(status="running", run_count=1, started_at=_now())
        atomic_json(self.path, self.state)
        return after_admission(deepcopy(admission))
