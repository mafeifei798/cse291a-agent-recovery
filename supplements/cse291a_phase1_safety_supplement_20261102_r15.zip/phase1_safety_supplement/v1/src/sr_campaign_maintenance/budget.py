"""Narrow pre-admission terminal fix around the pinned V6 transaction engine.

This does not change the frozen engine's TERMINAL global or its source pin.
AdmissionStopMixin is a future controller seam, not a patch to the live V6
campaign (whose controller and Store hard-code their own budget class).
"""
from copy import deepcopy

from sr_campaign_v6.engine import DurableV3Budget, _json, _now, _require


STOPPED_BEFORE_ADMISSION = "not_run_stopped"


class AdmissionStopMixin:
    """Accept a stopped slot only if it has never reserved a physical call.

Normal finalization delegates verbatim. A stopped slot is never turned into a
resumable checkpoint: reconciliation/new authorization must remain explicit.
No settlement, release, reservation, source pin or money limit is overridden.
"""

    def finalize_item(self, item_id, status, evidence_digest):
        if status != STOPPED_BEFORE_ADMISSION:
            return super().finalize_item(item_id, status, evidence_digest)
        _require(item_id in self.registry, "ITEM_FINALIZATION_INVALID")
        if hasattr(self, "_macro"):
            self._macro(item_id)
        _require(isinstance(evidence_digest, str) and len(evidence_digest) == 64
                 and all(c in "0123456789abcdef" for c in evidence_digest),
                 "ITEM_FINALIZATION_INVALID")
        _require(not any(c["item_id"] == item_id for c in self.calls()),
                 "NOT_RUN_ITEM_HAS_CALL_HISTORY")
        old = next((i for i in self.items() if i["item_id"] == item_id), None)
        if old:
            _require(old["status"] == status and old["evidence_digest"] == evidence_digest
                     and old["started_at"] is None, "ITEM_FINALIZATION_CONFLICT")
            return deepcopy(old)
        _require(self.snapshot()["status"] == "quarantined",
                 "ADMISSION_STOP_REQUIRES_QUARANTINE")
        body = dict(item_id=item_id, status=status, evidence_digest=evidence_digest,
                    started_at=None, finalized_at=_now())
        with self._transaction():
            self.connection.execute("INSERT INTO items VALUES(?,?)", (item_id, _json(body)))
            self._event("finalize_item", item_id=item_id, body=body)
        return deepcopy(body)

    def _checkpoint_body(self):
        _require(not any(i["status"] == STOPPED_BEFORE_ADMISSION for i in self.items()),
                 "STOPPED_ADMISSION_REQUIRES_MANUAL_RECONCILIATION")
        return super()._checkpoint_body()


class OfflineMaintenanceBudget(AdmissionStopMixin, DurableV3Budget):
    """Only the engine's fake accounting mode is available through this entry."""

    def __init__(self, *args, binding, **kwargs):
        _require(binding.get("simulated") is True
                 and binding.get("real_requests_authorized") is False
                 and binding.get("execution_mode") == "offline_fake_http",
                 "MAINTENANCE_OFFLINE_ONLY")
        super().__init__(*args, binding=binding, **kwargs)
