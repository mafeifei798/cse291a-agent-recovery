"""One frozen wire compatibility profile, without weakening local validation.

The V3 validation schemas and rendering instructions remain unchanged. TritonAI
rejected the report-text regex keyword in V4. Only that keyword at the two known
macro paths is omitted from the wire; returned candidates still validate against
the full V3 schema before any result can enter the Store.
"""
from copy import deepcopy
import json
from pathlib import Path

from sr_campaign_v3.contracts import model_schema
from sr_recovery_v2.common import ProtocolError, digest


WIRE_SCHEMA_PROFILE = "macro-report-no-pattern-v1"
MICRO_NODES = frozenset(("read_metadata", "read_permission", "read_resources", "plan", "execute"))
MACRO_NODES = frozenset(("inspect", "plan_lr", "plan_rf", "report", "publish"))
REPORT_PATTERN = r"^\S+(?:\s+\S+){0,119}\s*$"


def _require(value, code):
    if not value:
        raise ProtocolError(code)


def domain_for_node(node_id):
    if node_id in MICRO_NODES:
        return "micro"
    if node_id in MACRO_NODES:
        return "macro"
    raise ProtocolError("V5_UNKNOWN_MODEL_NODE")


def wire_schema(node_id, domain, validation_schema=None):
    """Return the sole permitted projection of the original validation schema."""
    _require(domain in ("micro", "macro") and domain_for_node(node_id) == domain,
             "V5_SCHEMA_DOMAIN_MISMATCH")
    full = model_schema(node_id, domain)
    if validation_schema is not None:
        _require(validation_schema == full and digest(validation_schema) == digest(full),
                 "V5_FULL_VALIDATION_SCHEMA_CHANGED")
    projected = deepcopy(full)
    if domain == "macro" and node_id in ("report", "publish"):
        report = projected if node_id == "report" else projected["properties"]["report"]
        text = report["properties"]["report_text"]
        _require(text.get("pattern") == REPORT_PATTERN, "V5_FROZEN_REPORT_PATTERN_CHANGED")
        del text["pattern"]
    return projected


def validation_schemas(v0_root):
    """Read the original model-node catalogue; no fixture schema is substituted."""
    v0 = Path(v0_root)
    return {domain: {
        node["node_id"]: model_schema(node["node_id"], domain)
        for node in json.loads((v0 / "dags" / (domain + ".json")).read_text())["nodes"]
        if node["llm_calls_per_execution"]}
        for domain in ("micro", "macro")}


def wire_schemas(full_schemas):
    _require(isinstance(full_schemas, dict) and set(full_schemas) == {"micro", "macro"},
             "V5_FULL_SCHEMA_CATALOGUE_CHANGED")
    _require(set(full_schemas["micro"]) == MICRO_NODES
             and set(full_schemas["macro"]) == MACRO_NODES,
             "V5_FULL_SCHEMA_CATALOGUE_CHANGED")
    return {domain: {node: wire_schema(node, domain, full)
                     for node, full in catalogue.items()}
            for domain, catalogue in full_schemas.items()}


def schema_profile(full_schemas):
    return {"wire_schema_profile": WIRE_SCHEMA_PROFILE,
            "wire_schema_digest": digest(wire_schemas(full_schemas)),
            "validation_schema_digest": digest(full_schemas)}
