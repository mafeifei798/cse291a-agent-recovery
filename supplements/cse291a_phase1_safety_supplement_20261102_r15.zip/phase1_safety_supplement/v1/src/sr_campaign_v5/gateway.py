"""Explicit V5 live boundary with one pinned schema compatibility projection.

V3's immutable message builder, full validation schemas and local tokenizer are reused.
Only the two known report-text patterns are omitted from the outgoing schema.
V4's full-schema response parser remains the local admission boundary. Only a
matching durable V5 grant, central reservation and an explicitly supplied live
process supervisor can reach an explicitly injected credential provider. There
is no fake-to-live fallback, environment key lookup, redirect or retry here.
"""
from __future__ import annotations

import base64
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
from time import monotonic

from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from agent_recovery.p3_deadline import BoundedHTTPSender
from agent_recovery.p3_transport import HTTPRequest, LiveRuntimePermit, P3Binding, P3HTTPError
from sr_campaign_v3.gateway import BASE_URL, MODEL, build_request, offline_binding
from sr_recovery_v2.common import REV, ProtocolError, canonical, digest

from .budget import validate_v5_grant
from sr_campaign_v4.gateway import parse_response
from .schemas import (domain_for_node, schema_profile, validation_schemas, wire_schema)

def require(condition, code):
    if not condition:
        raise ProtocolError(code)


def live_binding(v0_root, *, price_evidence, capability_evidence):
    """Build a dormant live specification; a separate grant is still required.

    Evidence references are supplied by the caller after verification. This
    helper does not fetch prices, assert provider debit or authorize execution.
    """
    for reference in (price_evidence, capability_evidence):
        require(isinstance(reference, str) and reference.strip()
                and not reference.startswith("fixture:"), "V5_LIVE_EVIDENCE_REQUIRED")
    value = offline_binding(v0_root)
    value.update(simulated=False, real_requests_authorized=True, execution_mode="real_api",
                 price_evidence=price_evidence, capability_evidence=capability_evidence,
                 input_count_calibrated=False, runtime_input_is_a_verified_provider_bound=False,
                 provider_account_debit_verified=False, provider_bill_guarantee=False)
    return value


def transport_binding(binding):
    """P3 wire supervisor identity, separate from V5's complete campaign binding."""
    return P3Binding(binding_ref="sr-v5:explicit-live-process-transport",
        model=MODEL, allowed_response_models=tuple(binding["allowed_response_models"]),
        simulated=False, real_requests_authorized=True, max_input_tokens=4000,
        max_output_tokens=768, timeout_s=120, input_nano_usd_per_token=150,
        output_nano_usd_per_token=500, temperature=None, reasoning_effort="low",
        price_evidence=binding["price_evidence"], capability_evidence=binding["capability_evidence"],
        token_admission_evidence="sr-v5:local-upstream-estimate-plus-financial-allowance-not-calibrated",
        supported_parameters=("model", "messages", "n", "stream", "max_completion_tokens",
                              "response_format", "reasoning_effort"))


class LiveV5Gateway:
    def __init__(self, v0_root, *, binding, grant, budget, transport,
                 credential_provider, token_counter=None, evidence_sink=None):
        self.binding, self.grant, self.budget = deepcopy(binding), deepcopy(grant), budget
        self.binding_digest = digest(self.binding)
        self.transport = transport
        self.credential_provider = credential_provider
        self.evidence_sink = evidence_sink
        self.validation_schemas = validation_schemas(v0_root)
        self._configuration()
        self.token_counter = token_counter or GLM53LocalTokenCounter.from_directory(
            Path(v0_root) / "environment/tokenizer_files")
        require(isinstance(self.token_counter, GLM53LocalTokenCounter), "V5_LOCKED_LOCAL_COUNTER_REQUIRED")
        self.tokenizer_lock = json.loads((Path(v0_root) / "environment/tokenizer_asset_lock.json").read_text())
        require(self.token_counter._assets_verified is True
                and self.token_counter._tokenizer_sha256 == self.tokenizer_lock["files"]["tokenizer.json"]["sha256"]
                and self.token_counter._tokenizer_config_sha256 == self.tokenizer_lock["files"]["tokenizer_config.json"]["sha256"]
                and self.token_counter._template_sha256 == self.tokenizer_lock["files"]["chat_template.jinja"]["sha256"],
                "V5_UNVERIFIED_LOCAL_TOKENIZER")
        self.wire_binding = transport_binding(self.binding)
        self.records, self._fingerprints = {}, {}

    def _configuration(self):
        expected = schema_profile(self.validation_schemas)
        require(all(self.binding.get(key) == value for key, value in expected.items())
                and self.binding.get("schema_digest") == expected["validation_schema_digest"],
                "V5_FROZEN_SCHEMA_PROFILE_MISMATCH")
        validate_v5_grant(self.grant, binding=self.binding, budget=self.budget)
        require(type(self.transport) is BoundedHTTPSender and self.transport.simulated is False
                and self.transport._recipes is None, "V5_EXPLICIT_LIVE_TRANSPORT_REQUIRED")
        require(callable(self.credential_provider), "V5_EXPLICIT_CREDENTIAL_PROVIDER_REQUIRED")
        require(self.evidence_sink is None or callable(self.evidence_sink), "V5_EVIDENCE_SINK_INVALID")
        exact = {"model": MODEL, "base_url": BASE_URL, "max_input_tokens": 4000,
                 "max_output_tokens": 768, "financial_input_allowance": 6000,
                 "financial_reservation_nano_usd_per_dispatch": 1284000,
                 "input_nano_usd_per_token": 150, "output_nano_usd_per_token": 500,
                 "reasoning_effort": "low", "total_request_deadline_seconds": 120,
                 "automatic_http_retries": 0, "simulated": False,
                 "real_requests_authorized": True, "execution_mode": "real_api"}
        require(all(type(self.binding.get(k)) is type(v) and self.binding.get(k) == v for k, v in exact.items()),
                "V5_BINDING_MISMATCH")
        require(set(self.binding.get("allowed_response_models", [])) <= {MODEL, "glm-5.3-flash"}
                and bool(self.binding.get("allowed_response_models")), "V5_RESPONSE_MODEL_BINDING_MISMATCH")

    def _persist(self, stage, value):
        if self.evidence_sink:
            self.evidence_sink(stage, deepcopy(value))

    def invoke(self, *, call_id, item_id, branch_id, attempt_id, node_id,
               input_snapshot, output_schema, remaining_seconds=120, before_dispatch=None):
        started = monotonic()
        self._configuration()
        require(type(remaining_seconds) in (int, float) and math.isfinite(remaining_seconds)
                and 0 < remaining_seconds <= 120, "V5_TOTAL_DEADLINE_INVALID")
        deadline = started + remaining_seconds
        require(all(isinstance(x, str) and x for x in (call_id, item_id, branch_id, attempt_id, node_id))
                and isinstance(input_snapshot, dict) and isinstance(input_snapshot.get("run_id"), str)
                and input_snapshot["run_id"] and (before_dispatch is None or callable(before_dispatch)),
                "V5_CALL_IDENTITY_INVALID")
        input_snapshot = deepcopy(input_snapshot)
        fingerprint = digest({"call_id": call_id, "item_id": item_id, "branch_id": branch_id,
            "attempt_id": attempt_id, "node_id": node_id, "input_snapshot": input_snapshot,
            "output_schema": output_schema})
        if call_id in self.records:
            require(fingerprint == self._fingerprints[call_id], "V5_CALL_ID_REUSE_MISMATCH")
            return deepcopy(self.records[call_id])
        domain = domain_for_node(node_id)
        projected_schema = wire_schema(node_id, domain, output_schema)
        request = build_request(node_id, input_snapshot.get("rendered_messages"), projected_schema, self.binding)
        estimate = self.token_counter.estimate_request(request).to_dict()
        require(estimate["revision"] == self.tokenizer_lock["commit"]
                and estimate["tokenizer_sha256"] == self.tokenizer_lock["files"]["tokenizer.json"]["sha256"]
                and estimate["tokenizer_config_sha256"] == self.tokenizer_lock["files"]["tokenizer_config.json"]["sha256"]
                and estimate["template_sha256"] == self.tokenizer_lock["files"]["chat_template.jinja"]["sha256"],
                "V5_TOKENIZER_IDENTITY_DRIFT")
        require(estimate["prompt_tokens"] <= 4000, "V5_LOCAL_CONTEXT_CAP")
        require(monotonic() < deadline, "V5_PRE_RESERVATION_DEADLINE")
        sidecar = {"call_id": call_id, "item_id": item_id, "branch_id": branch_id,
            "attempt_id": attempt_id, "node_id": node_id, "input_digest": digest(input_snapshot),
            "request_digest": digest(request), "schema_digest": digest(output_schema),
            "wire_schema_digest": digest(projected_schema),
            "wire_schema_profile": self.binding["wire_schema_profile"],
            "binding_digest": self.binding_digest, "token_estimate": estimate,
            "total_deadline_seconds": remaining_seconds, "simulated": False,
            "grant_id": self.grant["grant_id"]}
        reservation = self.budget.reserve({"call_id": call_id, "attempt_id": attempt_id, "item_id": item_id,
            "input_tokens_estimate": estimate["prompt_tokens"], "request": deepcopy(request), "sidecar": sidecar})
        require(not reservation.get("reservation_replayed"), "V5_EXISTING_CALL_REQUIRES_RECONCILIATION")
        self._fingerprints[call_id] = fingerprint
        raw, usage, payload, code, response, authorization = None, None, None, None, None, None
        dispatched, cleanup = False, None
        trace = {"status": None, "headers": {}, "gateway_call_id": None,
                 "provider_request_id": None, "request_id": None, "body_response_id": None,
                 "response_sha256": None, "response_body_b64": None}
        before_receipts = len(self.transport.cleanup_receipts)
        try:
            self._persist("reserved", {**sidecar, "request": request, "input_snapshot": input_snapshot})
            # The launcher may prompt before invoke; this provider must return
            # its explicitly supplied process-local secret, never log it.
            try:
                authorization = self.credential_provider()
                require(isinstance(authorization, str) and authorization
                        and "\r" not in authorization and "\n" not in authorization,
                        "V5_CREDENTIAL_VALUE_INVALID")
            except Exception:
                raise ProtocolError("V5_CREDENTIAL_PROVIDER_ERROR") from None
            require(monotonic() < deadline, "V5_PRE_DISPATCH_DEADLINE")
            if before_dispatch:
                before_dispatch()
            require(monotonic() < deadline, "V5_PRE_DISPATCH_DEADLINE")
            self.budget.mark_dispatched(call_id)
            dispatched = True
            self._persist("dispatched", sidecar)
            permit = LiveRuntimePermit(True, self.wire_binding.binding_digest,
                                       self.grant["authorization_reference"])
            remaining = max(.000001, min(120., deadline - monotonic()))
            wire = HTTPRequest("POST", BASE_URL + "/chat/completions", canonical(request).encode(), remaining)
            try:
                response = self.transport.send(wire, authorization=authorization, runtime_permit=permit,
                    binding=self.wire_binding, deadline_monotonic=deadline, intent_committed=True)
            except Exception as exc:
                code = exc.code if isinstance(exc, (ProtocolError, P3HTTPError)) else "V5_TRANSPORT_ERROR"
            finally:
                authorization = None
            if len(self.transport.cleanup_receipts) > before_receipts:
                cleanup = deepcopy(self.transport.cleanup_receipts[-1])
            if response is not None:
                raw, usage, payload, code, trace = parse_response(response, output_schema, self.binding)
                if (not cleanup or cleanup.get("reaped") is not True or cleanup.get("cleanup_failed")
                        or cleanup.get("simulated") is not False
                        or cleanup.get("request_digest") != hashlib.sha256(wire.body).hexdigest()):
                    payload, code = None, code or "V5_WORKER_CLEANUP_UNVERIFIED"
            if monotonic() >= deadline:
                payload, code = None, "V5_TOTAL_DEADLINE_EXPIRED"
            request_id = trace.get("request_id")
            http = {"call_id": call_id, "simulated": False, "transport_intent_committed": dispatched,
                "real_request_sent": dispatched,
                "method": wire.method, "url": wire.url, "request_digest": digest(request),
                "request_body_b64": base64.b64encode(wire.body).decode(),
                "cleanup_receipt": cleanup, "provider_cancellation_confirmed": False,
                "transport_worker_started": bool(cleanup and cleanup.get("worker_started")), **trace}
            evidence = {**sidecar, "request": request, "http_evidence": http, "raw_response": raw,
                "input_snapshot": input_snapshot,
                "raw_usage": deepcopy(usage["raw"]) if usage else None,
                "response_model": raw.get("model") if isinstance(raw, dict) else None,
                "status": "completed" if code is None else "failed", "error_code": code}
            self._persist("response", evidence)
            known_cost = 0
            if usage is not None and request_id is not None:
                settled = self.budget.settle(call_id, provider_request_id=request_id,
                    raw_usage=usage["raw"], evidence=evidence,
                    failure_reason=code if code not in (None, "V4_MODEL_SCHEMA_ERROR") else None)
                known_cost = usage["prompt_tokens"] * 150 + usage["completion_tokens"] * 500
                if settled.get("status") != "settled":
                    known_cost, payload, code = 0, None, "V5_SETTLEMENT_NOT_ACCEPTED"
            else:
                self.budget.record_unknown_receipt(call_id,
                    raw_usage=deepcopy(raw.get("usage")) if isinstance(raw, dict) else None,
                    provider_request_id=request_id,
                    evidence=evidence, reason=code or "V5_USAGE_OR_ID_UNKNOWN")
            if self.budget.snapshot().get("status") != "active":
                payload, code = None, code or "V5_CAMPAIGN_QUARANTINED"
            call = {"record_type": "CallEvidence", "revision": REV, "fixture_only": False,
                "call_id": call_id, "run_id": input_snapshot["run_id"], "node_id": node_id,
                "attempt_id": attempt_id, "mode": "real", "status": "completed" if code is None else "failed",
                "provider_request_id": request_id, "usage": deepcopy(usage), "cost_nano_usd": known_cost,
                "input_digest": digest(input_snapshot), "request_sent": dispatched,
                "http_status": trace.get("status"), "endpoint": BASE_URL, "model": MODEL,
                "worker_started": bool(cleanup and cleanup.get("worker_started")),
                "evidence_kind": "authorized_live_process_transport",
                "raw_response_payload": deepcopy(payload) if isinstance(payload, dict) else {},
                "note": "Live transport intent; provider receipt confirms known usage where present. Catalog cost is not independently verified account debit."}
            result = {"call_id": call_id, "status": "completed" if code is None else "failed", "error_code": code,
                "payload": deepcopy(payload) if code is None else None, "call_evidence": call,
                "http_evidence": http, "request": request, "token_estimate": estimate, "sidecar": sidecar,
                "duration_seconds": monotonic() - started}
            self.records[call_id] = deepcopy(result)
            self._persist("settled", result)
            return result
        except Exception:
            self.budget.quarantine(call_id, "V5_GATEWAY_DURABILITY_OR_SETTLEMENT_ERROR" if dispatched else "V5_GATEWAY_PRE_DISPATCH_ABORT")
            raise
        finally:
            authorization = None
