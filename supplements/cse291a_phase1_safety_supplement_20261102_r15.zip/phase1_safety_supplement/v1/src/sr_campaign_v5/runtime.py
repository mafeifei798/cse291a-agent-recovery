"""Same frozen DAGs and recovery rules with explicit real-call admission."""
import copy
from datetime import timedelta
import json
from pathlib import Path

from sr_cpu_v2.adapter import _initial_bindings, _json_artifact, numerical_check
from sr_campaign_v3.guard import diagnose
from sr_recovery_v2.common import REV, ProtocolError, canonical, digest, merge_reads, node_map, utc_parse
from sr_recovery_v2.policy import advance
from sr_recovery_v2.runner import advance_input
from sr_campaign_v3.contracts import model_schema, render
from sr_campaign_v3.executor import now, run_job
from sr_campaign_v3.gateway import schema_for_node
from .store import V5Store


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')


def projection(view, node_id):
    node = node_map(view['dag'])[node_id]
    results = {r['result_id']: r for r in view['results']}
    sources = {s['object_key']: s for s in view['sources']}
    parents = [results[view['state']['selected_by_node'][p]] for p in node['parents']]
    aliases = view.get('source_aliases', {})
    direct = [copy.deepcopy(sources[aliases.get(k, k)]) for k in node['direct_source_keys']]
    visible = {aid for p in parents for aid in p['artifact_refs']}
    visible.update(aid for s in direct for aid in s['artifact_refs'])
    registry = {a['artifact_id']: a for a in view['artifacts']}
    snapshot = {'run_id': view['state']['run_id'], 'node_id': node_id,
        'request': copy.deepcopy(view['task']['request']),
        'parent_inputs': [{'result_id': p['result_id'], 'node_id': p['node_id'],
            'payload': copy.deepcopy(p['payload']), 'payload_digest': digest(p['payload']),
            'artifact_refs': p['artifact_refs'][:], 'effective_reads': p['effective_reads'][:]} for p in parents],
        'direct_source_inputs': direct,
        'artifact_bindings': [copy.deepcopy(registry[a]) for a in sorted(visible)]}
    if view['metadata'].get('repair_feedback'):
        snapshot['repair_feedback'] = copy.deepcopy(view['metadata']['repair_feedback'])
    snapshot['rendered_messages'] = render(snapshot) if node['llm_calls_per_execution'] else []
    allowed, visited = set(visible), set()
    def walk(result):
        if result['result_id'] in visited:
            return
        visited.add(result['result_id'])
        allowed.update(result['artifact_refs'])
        for s in result.get('input_snapshot', {}).get('direct_source_inputs', []):
            allowed.update(s['artifact_refs'])
        for parent in result['parent_result_ids']:
            walk(results[parent])
    for parent in parents:
        walk(parent)
    return snapshot, parents, [copy.deepcopy(registry[a]) for a in sorted(allowed)]


def execute_node(store, decision, v0, campaign, item, gateway, inject=False):
    view = store.snapshot()
    node_id = decision['node_id']
    node = node_map(view['dag'])[node_id]
    snapshot, parents, allowed = projection(view, node_id)
    aid = 'v2.attempt.' + digest({'branch_id': view['state']['branch_id'], 'decision': decision['decision_id']})[:32]
    rid = aid + '.result'
    accepted = []
    def start():
        attempt = store.start_node(decision, 'v3.start.' + decision['decision_id'], now())
        if attempt['attempt_id'] != aid:
            raise ProtocolError('DETERMINISTIC_ATTEMPT_MISMATCH')
        accepted.append(attempt)
    payload, made, calls, receipts, execution = None, [], [], [], None
    if node['llm_calls_per_execution']:
        schema = model_schema(node_id, item['domain'])
        remaining = min(120., (utc_parse(view['state']['deadline_utc']) - utc_parse(now())).total_seconds())
        try:
            response = gateway.invoke(call_id=aid + '.call', item_id=item['item_id'],
                branch_id=view['state']['branch_id'], attempt_id=aid, node_id=node_id,
                input_snapshot=snapshot, output_schema=schema, remaining_seconds=remaining, before_dispatch=start)
        except Exception as exc:
            reason = getattr(exc, 'code', type(exc).__name__)
            if accepted:
                central = next(c for c in gateway.budget.calls() if c['call_id'] == aid + '.call')
                call = {'record_type': 'CallEvidence', 'revision': REV, 'fixture_only': False,
                    'call_id': aid + '.call', 'run_id': view['state']['run_id'], 'node_id': node_id,
                    'attempt_id': aid, 'mode': 'real', 'status': 'uncertain',
                    'provider_request_id': central.get('provider_request_id'), 'usage': None,
                    'cost_nano_usd': central['known_cost_nano_usd'],
                    'input_digest': digest(snapshot), 'request_sent': bool(central['dispatched']),
                    'http_status': None, 'endpoint': gateway.binding['base_url'],
                    'model': gateway.binding['model'], 'worker_started': False,
                    'evidence_kind': 'real_dispatch_uncertain_no_replay', 'raw_response_payload': {},
                    'note': 'Retained real dispatch uncertainty; no replacement request is permitted.'}
                store.abort_http_attempt(aid, call, 'MISSING_PROVIDER_USAGE', now())
            else:
                store.stop_without_dispatch('budget_or_time_stopped', reason, now())
            raise
        calls.append(response['call_evidence'])
        if response['status'] != 'completed':
            store.abort_http_attempt(aid, calls[0], response['error_code'], now())
            return {'http_failed': True, 'reason': response['error_code']}
        payload = copy.deepcopy(response['payload'])
        if node_id == 'report':
            artifact = _json_artifact(store.artifact_root, rid, 'report', payload)
            made.append(artifact)
            payload['report_artifact_id'] = artifact['artifact_id']
    else:
        start()
    attempt = accepted[0]
    raw_delivered = copy.deepcopy(payload)
    failed = False
    if node['cpu_jobs_per_execution']:
        bodies = {p['node_id']: p['payload'] for p in parents}
        if item['domain'] == 'micro':
            inputs = {'candidate': payload}
        else:
            source = next(s for s in view['sources'] if s['object_key'] == 'data:train')
            inputs = {'dataset_id': view['task']['request']['dataset_id'], 'train_version': source['version']}
            if node_id.startswith(('fit_', 'predict_', 'summary_')):
                family = node_id[-2:]
                inputs.update(family=family, prepare=bodies['prepare'])
                if node_id.startswith('fit_'):
                    inputs['parameters'] = bodies['plan_' + family]['parameters']
                elif node_id.startswith('predict_'):
                    inputs['fit'] = bodies['fit_' + family]
                else:
                    inputs['predict'] = bodies['predict_' + family]
            elif node_id == 'publish':
                inputs.update(report=payload['report'], action=payload['action'])
        stage = store.artifact_root / 'jobs' / aid
        spec = {'tool': node_id, 'job_id': aid, 'result_id': rid, 'output_dir': str(stage),
            'v0_root': str(v0), 'artifact_root': str(store.artifact_root), 'inputs': inputs,
            'artifacts': allowed, 'deadline_utc': attempt['deadline_utc'],
            'output_reservation_bytes': 128*1024**2 if node_id in ('prepare', 'fit_rf') else 64*1024**2}
        run = run_job(spec, campaign, on_started=lambda identity: store.record_worker_started(
            aid, identity, 'v3.worker.started.' + aid, now()))
        execution, response = run['execution'], run['response'] or {}
        failed = execution['status'] != 'success'
        payload = copy.deepcopy(response.get('payload')) if not failed else None
        raw_delivered = copy.deepcopy(payload)
        if not failed:
            made.extend(response.get('artifacts', []))
            if node_id == 'publish':
                manifest = next(a for a in made if a['artifact_id'] == payload['candidate_artifact_id'])
                payload['publish_manifest'] = json.loads((store.artifact_root / manifest['uri']).read_text())
        receipts.append({'record_type': 'ToolReceipt', 'revision': REV, 'fixture_only': False,
            'receipt_id': aid + '.receipt', 'run_id': view['state']['run_id'], 'node_id': node_id,
            'attempt_id': aid, 'producer_result_id': rid, 'tool': 'v3.cpu.' + node_id,
            'input_digest': digest(snapshot), 'parameters': {**response.get('parameters', {}), 'execution': execution},
            'artifact_refs': [a['artifact_id'] for a in made], 'cpu_seconds': execution['cpu_seconds'],
            'wall_seconds': execution['wall_seconds'],
            'exit_code': execution['returncode'] if execution['returncode'] is not None else 255,
            'warnings': response.get('warnings', [])})
    target = 'read_metadata' if item['domain'] == 'micro' else 'summary_lr'
    if inject and node_id == target and not failed:
        raw_delivered = copy.deepcopy(payload)
        if item['domain'] == 'micro':
            source = next(s for s in snapshot['direct_source_inputs'] if s['object_key'].startswith('metadata:'))
            payload['num_examples'] = source['payload']['num_examples'] + snapshot['request']['batch_size']
        else:
            ap = payload['metrics']['average_precision']
            payload['metrics']['average_precision'] = 0.0 if ap >= .5 else 1.0
        write(campaign / 'injections' / (item['item_id'] + '.json'),
              {'injection_count': 1, 'target_result_id': rid, 'raw_payload': raw_delivered,
               'delivered_payload': copy.deepcopy(payload), 'node_id': node_id, 'item_id': item['item_id']})
    direct = sorted([{'object_key': s['object_key'], 'version': s['version']}
                     for s in snapshot['direct_source_inputs']], key=lambda r: r['object_key'])
    result = {'record_type': 'NodeResult', 'revision': REV, 'fixture_only': False,
        'run_id': view['state']['run_id'], 'node_id': node_id, 'attempt_id': aid,
        'result_id': rid, 'producer': node['role'], 'execution_status': 'tool_failed' if failed else 'success',
        'parent_result_ids': [p['result_id'] for p in parents], 'direct_reads': direct,
        'effective_reads': merge_reads([direct] + [p['effective_reads'] for p in parents]),
        'input_digest': digest(snapshot), 'input_snapshot': snapshot, 'payload': payload,
        'artifact_refs': [a['artifact_id'] for a in made], 'call_ids': [c['call_id'] for c in calls],
        'tool_receipt_ids': [r['receipt_id'] for r in receipts]}
    return store.finish_node(aid, {'result': result, 'artifacts': made, 'calls': calls,
        'tool_receipts': receipts, 'job_execution': execution}, now())


def initial_store(item, run_id, v0, campaign, files, *, budget):
    if item['domain'] == 'macro':
        dataset = 'adult' if 'adult' in item['task_id'] else 'bank'
        task, sources, artifacts, producers = _initial_bindings(v0, files, dataset)
    else:
        task = next(t for t in json.loads((v0 / 'tasks/micro_tasks.json').read_text())['tasks']
                    if t['task_id'] == item['task_id'])
        task = copy.deepcopy(task)
        task['request'] = copy.deepcopy(task['public_request'])
        sources = [s for s in json.loads((v0 / ('tasks/authority/' + item['task_id'] + '.sources.json')).read_text())['sources'] if s['version'] == 1]
        artifacts, producers = [], []
    dag = json.loads((v0 / ('dags/' + item['domain'] + '.json')).read_text())
    task['nodes'] = copy.deepcopy(dag['nodes'])
    task['limits'] = copy.deepcopy(dag['branch_caps'])
    store = V5Store(campaign / 'db' / (item['item_id'] + '.sqlite'), files, budget=budget)
    store.create_initial(task, dag, sources, artifacts, producers, run_id, source_history=sources)
    return store


def run_item(store, item, v0, campaign, gateway):
    store.bind_item(item, gateway.budget.ref, now())
    store.begin_branch('v3.begin.' + item['item_id'], now())
    for _ in range(180):
        view = store.snapshot()
        if view['state']['status'] == 'terminal':
            return store.export()
        if view['state']['active_attempt_ids'] or view['state']['unsettled_call_ids']:
            raise ProtocolError('ACTIVE_OR_UNSETTLED_WORK')
        initial = view['metadata'].get('initial_mode')
        refusal = view.get('last_guard')
        if initial and refusal and refusal['classification'] != 'passed':
            if item['kind'] == 'control' and refusal['classification'] == 'semantic':
                store.enable_control_repair(now())
                continue
            if refusal['classification'] in ('integrity_error', 'uncertain', 'source_drift'):
                raise ProtocolError('ENGINEERING_GUARD_REFUSAL', refusal['classification'])
            if refusal['classification'] in ('permission_denied', 'conflict'):
                status = 'permission_denied_safe' if refusal['classification'] == 'permission_denied' else 'conflict_safe'
                store.stop_without_dispatch(status, refusal['classification'], now())
            return store.export()
        guard = None if not refusal or refusal['classification'] == 'passed' else refusal
        if initial:
            decision = store.initial_decision('v3.initial.' + str(view['state']['state_version']), now())
        else:
            decision = advance(advance_input(view, now(), guard), view['dag'])
        if decision['kind'] == 'need_version_scan':
            guard = diagnose(view, view['dag']['topological_order'][-1], full=True, artifact_root=store.artifact_root)
            store.record_scan(decision, guard, 'v3.scan.' + guard['guard_id'], now())
            view = store.snapshot()
            decision = advance(advance_input(view, now(), guard), view['dag'])
        elif decision['kind'] == 'execute_node':
            guard = diagnose(view, decision['node_id'], artifact_root=store.artifact_root)
            store.record_guard(guard, 'v3.guard.' + guard['guard_id'], now())
            view = store.snapshot()
            if initial:
                if guard['classification'] != 'passed':
                    if guard['classification'] in ('integrity_error', 'uncertain', 'source_drift'):
                        raise ProtocolError('ENGINEERING_GUARD_REFUSAL', guard['classification'])
                    status = 'permission_denied_safe' if guard['classification'] == 'permission_denied' else 'conflict_safe' if guard['classification'] == 'conflict' else 'validation_rejected'
                    store.stop_without_dispatch(status, guard['classification'], now())
                    return store.export()
                decision = store.initial_decision('v3.initial.' + str(view['state']['state_version']), now())
            else:
                decision = advance(advance_input(view, now(), guard), view['dag'])
                if decision['kind'] == 'need_version_scan':
                    guard = diagnose(view, view['dag']['topological_order'][-1], full=True, artifact_root=store.artifact_root)
                    store.record_scan(decision, guard, 'v3.scan.' + guard['guard_id'], now())
                    view = store.snapshot()
                    decision = advance(advance_input(view, now(), guard), view['dag'])
        store.admit_decision(decision, now(), guard_evidence=guard)
        if decision['kind'] == 'execute_node':
            execute_node(store, decision, v0, campaign, item, gateway, inject=item['kind'] == 'prefix')
        if gateway.budget.snapshot()['status'] != 'active':
            return store.export()
    raise ProtocolError('V3_DRIVER_STEP_CAP')


def freeze(store, item, v0, scene_id):
    view = store.export()
    target = 'read_metadata' if item['domain'] == 'micro' else 'summary_lr'
    bad = next(r for r in view['results'] if r['node_id'] == target)
    notice = {'record_type': 'Notice', 'revision': REV, 'fixture_only': False,
        'notice_id': 'notice.' + view['state']['run_id'], 'run_id': view['state']['run_id'],
        'faulty_result_id': bad['result_id']}
    history = json.loads((v0 / ('tasks/authority/' + item['task_id'] + '.sources.json')).read_text())['sources']
    condition = item['scene_id'].rsplit('.', 1)[-1]
    if item['domain'] == 'macro':
        keys = {'recipe:rf'} if condition == 'N2' else {'data:train'} if condition == 'N3' else set()
    else:
        keys = {k for k in (s['object_key'] for s in history) if k.startswith('resource')} if condition == 'N2' else {s['object_key'] for s in history} if condition == 'N3' else set()
    updated = [s for s in history if s['version'] == 2 and s['object_key'] in keys]
    return store.freeze_prefix(notice, updated, 'v3.freeze.' + scene_id, now())
