"""Explicit macro-only continuation epoch; predecessor V4 evidence is immutable."""
