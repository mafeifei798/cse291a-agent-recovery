"""An explicit new macro epoch under the existing cumulative budget authority.

V4 files are immutable evidence. Its unknown receipt stays unknown and its hold
stays carried. Only the authority pin is atomically handed over; no old ledger
row, item, receipt or event is changed or presented as settled.
"""
from copy import deepcopy
import fcntl
import json
import os
from pathlib import Path
import sqlite3
import tempfile

from sr_campaign_v3 import budget as _engine
from sr_campaign_v3.budget import (DurableV3Budget, V3BudgetError, RESERVATION,
                                  MAX_COST, MAX_CALLS, _digest, _json, _sha, _require)
from sr_campaign_v4.budget import (DurableV4Budget, _real_binding, ENGINE_SHA256,
                                  GRANT_FIELDS as V4_GRANT_FIELDS)

V5BudgetError = V3BudgetError
GRANT_FIELDS = V4_GRANT_FIELDS | {"predecessor_digest", "max_epoch_physical_calls"}


def read_predecessor(root):
    """Read and cross-check a closed V4 export without opening it writable."""
    root = Path(root).resolve()
    db = root / "budget/central.sqlite"
    sp = root / "campaign_state.json"
    _require(db.is_file() and sp.is_file(), "V5_PREDECESSOR_MISSING")
    _require(not Path(str(db)+"-wal").exists() and not Path(str(db)+"-journal").exists(),
             "V5_PREDECESSOR_NOT_CLOSED")
    dbsha, statesha = _sha(db), _sha(sp)
    state = json.loads(sp.read_text())
    expected = state.get("ledger")
    _require(isinstance(expected, dict), "V5_PREDECESSOR_STATE_INVALID")
    connection = sqlite3.connect(db.as_uri()+"?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        row = connection.execute("SELECT * FROM campaign").fetchone()
        config = json.loads(row["config"])
        _require(config.get("schema_version") == "sr-v4-budget-config-v1"
                 and config.get("execution_mode") == "real_api", "V5_PREDECESSOR_NOT_V4")
        init = connection.execute("SELECT body FROM events WHERE kind='initialize' ORDER BY seq LIMIT 1").fetchone()
        initialized = json.loads(init[0])
        _require(initialized["config"] == config, "V5_PREDECESSOR_INITIALIZE_MISMATCH")
        probe = object.__new__(DurableV4Budget)
        probe.connection, probe.config = connection, config
        probe.ref = config["authority"]["ledger_path"]
        probe.baseline = initialized["baseline"]
        probe.registry = {r["item_id"]: r for r in expected["registry"]}
        observed = DurableV4Budget.snapshot(probe)
        _require(observed == expected, "V5_PREDECESSOR_SNAPSHOT_MISMATCH")
    finally:
        connection.close()
    _require(_sha(db) == dbsha and _sha(sp) == statesha, "V5_PREDECESSOR_CHANGED")
    pin = {**config["authority"], "campaign_id":config["campaign_id"], "config_digest":_digest(config)}
    _require(config["binding_digest"] == _digest(config["binding"])
             and config["grant_digest"] == _digest(config["grant"]), "V5_PREDECESSOR_BINDING_MISMATCH")
    _real_binding(config["binding"])
    # This continuation is tied to the completed micro run and one failed Adult
    # control, rather than a generic facility to restart arbitrary campaigns.
    calls = observed["calls"]
    micro_ids = [r["item_id"] for r in observed["registry"] if r["domain"] == "micro"]
    completed = {r["item_id"] for r in observed["items"] if r["status"] != "in_progress"}
    _require(len(calls) == 125 and sum(c["dispatched"] for c in calls) == 125
             and observed["budget"]["known_cost_nano_usd"] == 7_818_100
             and observed["budget"]["held_cost_nano_usd"] == RESERVATION
             and observed["budget"]["domain_counts"] == {"micro":121,"macro":4}
             and observed["budget"]["item_counts"].get("sr-v2.macro.adult.control") == 4
             and set(micro_ids) <= completed
             and all(c["status"] == "settled" or
                     (c["status"] == "uncertain" and c["item_id"] == "sr-v2.macro.adult.control")
                     for c in calls), "V5_PREDECESSOR_SCOPE_MISMATCH")
    value = dict(schema_version="sr-v5-predecessor-v1", root=str(root), ledger_sha256=dbsha,
                 campaign_state_sha256=statesha, snapshot=observed,
                 snapshot_digest=_digest(observed), authority_pin=pin)
    value["descriptor_digest"] = _digest(value)
    return value


def grant_template(*, campaign_id, binding, ledger_path, lock_root, v0_root, grant_id,
                   predecessor_root, authorization_reference="Awaiting explicit macro continuation authorization"):
    _real_binding(binding)
    p = read_predecessor(predecessor_root)
    root = Path(v0_root).resolve()
    return dict(schema_version="sr-v5-runtime-grant-v1", record_type="V5RuntimeGrant",
        grant_id=grant_id, campaign_id=campaign_id, authorized=False, execution_mode="real_api",
        binding_digest=_digest(binding), registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()), lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640, max_epoch_physical_calls=515,
        max_cumulative_cost_nano_usd=MAX_COST, predecessor_digest=p["descriptor_digest"],
        authorization_reference=authorization_reference)


def validate_v5_grant(grant, *, binding, budget=None, campaign_id=None, ledger_path=None,
                      lock_root=None, v0_root=None, predecessor_root=None, predecessor=None):
    _real_binding(binding)
    if budget is not None:
        _require(budget.config.get("execution_mode") == "real_api", "V5_REAL_BUDGET_REQUIRED")
        campaign_id, ledger_path = budget.config["campaign_id"], budget.path
        lock_root, v0_root = budget.lock_root, budget.v0_root
        predecessor = budget.predecessor
        _require(budget.config["binding_digest"] == _digest(binding), "V5_GRANT_BINDING_MISMATCH")
    p = predecessor if predecessor is not None else read_predecessor(predecessor_root)
    _require(isinstance(grant, dict) and set(grant) == GRANT_FIELDS, "V5_GRANT_INVALID")
    _require(grant["schema_version"] == "sr-v5-runtime-grant-v1" and grant["record_type"] == "V5RuntimeGrant"
             and grant["execution_mode"] == "real_api", "V5_NEW_RUNTIME_GRANT_REQUIRED")
    _require(grant["authorized"] is True, "V5_REAL_REQUESTS_NOT_AUTHORIZED")
    _require(isinstance(grant["grant_id"], str) and grant["grant_id"]
             and isinstance(grant["authorization_reference"], str) and grant["authorization_reference"].strip(),
             "V5_GRANT_AUTHORIZATION_REFERENCE_REQUIRED")
    _require(all(x is not None for x in (campaign_id,ledger_path,lock_root,v0_root)), "V5_GRANT_IDENTITY_REQUIRED")
    root = Path(v0_root).resolve()
    expected = dict(campaign_id=campaign_id, binding_digest=_digest(binding),
        registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()), lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640, max_epoch_physical_calls=515,
        max_cumulative_cost_nano_usd=MAX_COST, predecessor_digest=p["descriptor_digest"])
    _require(all(grant.get(k)==v and type(grant.get(k)) is type(v) for k,v in expected.items()),
             "V5_GRANT_BINDING_MISMATCH")
    if budget is not None:
        _require(_digest(grant) == budget.config["grant_digest"], "V5_GRANT_CHANGED")
    return deepcopy(grant)


def _atomic_json(path, value):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=".v5-", dir=path.parent)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,"w") as out:
            out.write(_json(value)+"\n"); out.flush(); os.fsync(out.fileno())
        os.replace(name,path)
        dfd = os.open(path.parent,os.O_RDONLY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        if os.path.exists(name): os.unlink(name)


class DurableV5Budget(DurableV4Budget):
    """A macro-only ledger carrying all predecessor exposure and all call caps."""
    def __init__(self,path,*,campaign_id,binding,v0_root,lock_root,grant,predecessor_root,resume_checkpoint=None):
        self.path, self.lock_root = Path(path).resolve(), Path(lock_root).resolve()
        self.ref, self.v0_root = str(self.path), Path(v0_root).resolve()
        self.connection, self._lock_fd, self._failed = None, None, False
        self.binding = _real_binding(binding)
        self.predecessor = read_predecessor(predecessor_root)
        self.grant = validate_v5_grant(grant,binding=self.binding,campaign_id=campaign_id,
            ledger_path=self.path,lock_root=self.lock_root,v0_root=self.v0_root,predecessor=self.predecessor)
        old = self.predecessor["snapshot"]
        self.baseline = deepcopy(old["baseline"])
        self.registry = {r["item_id"]:deepcopy(r) for r in old["registry"]}
        bpath, rpath = self.v0_root/"budget/historical_baseline.json", self.v0_root/"registry/formal_items.jsonl"
        _require(_sha(Path(_engine.__file__)) == ENGINE_SHA256, "V5_TRANSACTION_ENGINE_CHANGED")
        _require(json.loads(bpath.read_text()) == self.baseline
                 and _sha(bpath) == old["authority"]["baseline_sha256"]
                 and _sha(rpath) == old["config"]["registry_sha256"], "V5_FROZEN_INPUT_CHANGED")
        _require(str(self.lock_root) == old["authority"]["lock_root"]
                 and self.ref != old["campaign_budget_ref"], "V5_HISTORICAL_AUTHORITY_REQUIRED")
        self.config = {**deepcopy(old["config"]), "schema_version":"sr-v5-budget-config-v1",
            "campaign_id":campaign_id,"binding":deepcopy(self.binding),"binding_digest":_digest(self.binding),
            "grant":deepcopy(self.grant),"grant_digest":_digest(self.grant),
            "authority":{**old["authority"],"ledger_path":self.ref},
            "predecessor_digest":self.predecessor["descriptor_digest"],
            "predecessor_ledger_sha256":self.predecessor["ledger_sha256"],
            "epoch_physical_call_cap":515,"continuation_scope":"uncompleted macro slots only"}
        oldpin = self.predecessor["authority_pin"]
        newpin = {**self.config["authority"],"campaign_id":campaign_id,"config_digest":_digest(self.config)}
        self.lock_root.mkdir(parents=True,exist_ok=True)
        self._lock_fd = os.open(self.lock_root/("sr-v3-"+oldpin["baseline_sha256"]+".lock"),
                                os.O_CREAT|os.O_RDWR|os.O_CLOEXEC,0o600)
        try:
            try: fcntl.flock(self._lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: raise V5BudgetError("CAMPAIGN_LOCK_HELD")
            pinpath = self.lock_root/"authority.json"
            _require(pinpath.is_file(), "V5_OLD_AUTHORITY_PIN_MISSING")
            pin = json.loads(pinpath.read_text())
            _require(pin in (oldpin,newpin), "BUDGET_AUTHORITY_MISMATCH")
            self._verify_predecessor_files()
            intent = dict(schema_version="sr-v5-authority-handover-v1", previous_authority=oldpin,
                new_authority=newpin, predecessor_digest=self.predecessor["descriptor_digest"],
                predecessor_ledger_sha256=self.predecessor["ledger_sha256"],
                grant_digest=_digest(self.grant), unknown_reservation_released=False)
            intentpath, commitpath = self.lock_root/"v5_handover.intent.json", self.lock_root/"v5_handover.commit.json"
            if intentpath.exists():
                _require(json.loads(intentpath.read_text()) == intent, "V5_HANDOVER_INTENT_CONFLICT")
            else:
                _require(pin == oldpin and not self.path.exists(), "V5_HANDOVER_STATE_INVALID")
                _atomic_json(intentpath,intent)
            if commitpath.exists():
                _require(json.loads(commitpath.read_text()) == {**intent,"committed":True}, "V5_HANDOVER_COMMIT_CONFLICT")
                _require(pin == newpin, "V5_HANDOVER_STATE_INVALID")
            self.path.parent.mkdir(parents=True,exist_ok=True)
            self.connection = sqlite3.connect(self.path,isolation_level=None,timeout=5)
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("PRAGMA journal_mode=DELETE")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS campaign(singleton INTEGER PRIMARY KEY CHECK(singleton=1),config TEXT NOT NULL,status TEXT NOT NULL,reason TEXT);
                CREATE TABLE IF NOT EXISTS calls(call_id TEXT PRIMARY KEY,attempt_id TEXT UNIQUE NOT NULL,item_id TEXT NOT NULL,body TEXT NOT NULL,request_digest TEXT NOT NULL,settlement_digest TEXT);
                CREATE TABLE IF NOT EXISTS items(item_id TEXT PRIMARY KEY,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,call_id TEXT,item_id TEXT,at TEXT NOT NULL,body TEXT NOT NULL,event_digest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS receipts(provider_request_id TEXT PRIMARY KEY,call_id TEXT UNIQUE NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS late_receipts(id INTEGER PRIMARY KEY,call_id TEXT NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS checkpoints(id INTEGER PRIMARY KEY,body TEXT NOT NULL);
            """)
            current = self.connection.execute("SELECT * FROM campaign").fetchone()
            if current:
                _require(current["config"] == _json(self.config), "BUDGET_AUTHORITY_MISMATCH")
                _require(pin == newpin or (not self.calls() and not self.items()), "V5_HANDOVER_STATE_INVALID")
            else:
                _require(pin == oldpin, "V5_HANDOVER_LEDGER_MISSING")
                with self._transaction():
                    self.connection.execute("INSERT INTO campaign VALUES(1,?,'active',NULL)",(_json(self.config),))
                    self._event("initialize",body={"config":self.config,"baseline":self.baseline,
                        "predecessor_digest":self.predecessor["descriptor_digest"],"predecessor":self.predecessor})
            if pin == oldpin: _atomic_json(pinpath,newpin)
            if not commitpath.exists(): _atomic_json(commitpath,{**intent,"committed":True})
            # An interrupted new epoch is never made active by the handover.
            if current:
                if any(c["status"] != "settled" for c in self.calls()) or any(i["status"] == "in_progress" for i in self.items()):
                    self.quarantine(None,"REOPEN_WITH_UNFINISHED_PROGRESS")
                elif current["status"] == "active" and (self.calls() or self.items()):
                    latest = self.connection.execute("SELECT body FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
                    _require(isinstance(resume_checkpoint,dict),"CHECKPOINT_REQUIRED")
                    _require(latest is not None and json.loads(latest[0]) == resume_checkpoint
                             and self._checkpoint_body() == resume_checkpoint,"CHECKPOINT_MISMATCH")
                    with self._transaction(): self._event("reopen",body={"checkpoint_digest":resume_checkpoint["checkpoint_digest"]})
        except BaseException:
            self.close(); raise

    def _verify_predecessor_files(self):
        root = Path(self.predecessor["root"])
        _require(_sha(root/"budget/central.sqlite") == self.predecessor["ledger_sha256"]
                 and _sha(root/"campaign_state.json") == self.predecessor["campaign_state_sha256"],
                 "V5_PREDECESSOR_CHANGED")

    def _active(self):
        try:
            validate_v5_grant(self.grant,binding=self.binding,budget=self)
            self._verify_predecessor_files()
            expected = {**self.config["authority"],"campaign_id":self.config["campaign_id"],"config_digest":_digest(self.config)}
            _require(json.loads((self.lock_root/"authority.json").read_text()) == expected,"BUDGET_AUTHORITY_MISMATCH")
        except V3BudgetError as exc:
            if self.connection is not None and not self.connection.in_transaction:
                self._reject(exc.code,evidence={"kind":"v5_authority_validation_failed"})
            raise
        return DurableV3Budget._active(self)

    def _macro(self,item_id):
        _require(item_id in self.registry,"REGISTRY_IDENTITY_MISMATCH")
        _require(self.registry[item_id]["domain"] == "macro","V5_COMPLETED_MICRO_IMMUTABLE")

    def check_admission(self,item_id,scope="item"):
        self._active(); self._macro(item_id)
        row = self.registry[item_id]
        _require(not any(c["status"] != "settled" for c in self.calls()),"UNKNOWN_SETTLEMENT")
        if scope == "item": ids = [item_id]
        elif scope in ("scene","pre_prefix"):
            _require(row["scene_id"] is not None,"SCENE_ADMISSION_MISMATCH")
            ids = [r["item_id"] for r in self.registry.values() if r["scene_id"] == row["scene_id"]
                   and (r["kind"] == "branch" or scope == "pre_prefix")]
        else: raise V5BudgetError("SCENE_ADMISSION_MISMATCH")
        _require(not any(i["item_id"] in ids for i in self.items()),"ITEM_ALREADY_STARTED")
        counts = self.snapshot()["budget"]["item_counts"]
        required = sum(self.registry[i]["limits"]["physical_llm_call_cap"] - counts[i] for i in ids)
        snap = self.snapshot()
        _require(snap["budget"]["calls_reserved_or_spent"] + required <= MAX_CALLS,"CALL_CAP_EXCEEDED")
        _require(snap["budget"]["domain_counts"]["macro"] + required <= 320,"DOMAIN_CALL_CAP_EXCEEDED")
        for kind,cap in self.config["domain_kind_call_caps"].items():
            needed = sum(self.registry[i]["limits"]["physical_llm_call_cap"] - counts[i]
                         for i in ids if self.registry[i]["kind"] == kind)
            _require(snap["budget"]["kind_counts"]["macro"][kind] + needed <= cap,
                     "KIND_CALL_CAP_EXCEEDED")
        _require(snap["cumulative_budget"]["risk_adjusted_known_plus_held_nano_usd"] + required*RESERVATION <= MAX_COST,
                 "MONEY_CAP_EXCEEDED")
        return dict(item_id=item_id,scope=scope,checked_item_ids=ids,required_call_capacity=required,
                    checked_cost_nano_usd=required*RESERVATION,additional_hold_created=False,passed=True)

    def reserve(self,record):
        _require(isinstance(record,dict),"CALL_RECORD_INVALID")
        self._macro(record.get("item_id"))
        if not self.connection.execute("SELECT 1 FROM calls WHERE call_id=?",(record.get("call_id"),)).fetchone():
            self._active()
            calls = self.predecessor["snapshot"]["calls"] + self.calls()
            row = self.registry[record["item_id"]]
            for ok,code in ((len(calls)<640,"CALL_CAP_EXCEEDED"),
                (sum(c["domain"]==row["domain"] for c in calls)<320,"DOMAIN_CALL_CAP_EXCEEDED"),
                (sum(c["domain"]==row["domain"] and c["kind"]==row["kind"] for c in calls)<self.config["domain_kind_call_caps"][row["kind"]],"KIND_CALL_CAP_EXCEEDED"),
                (sum(c["item_id"]==row["item_id"] for c in calls)<row["limits"]["physical_llm_call_cap"],"ITEM_CALL_CAP_EXCEEDED"),
                (self.snapshot()["cumulative_budget"]["risk_adjusted_known_plus_held_nano_usd"]+RESERVATION<=MAX_COST,"MONEY_CAP_EXCEEDED"),
                (not any(c["call_id"]==record.get("call_id") or c["attempt_id"]==record.get("attempt_id") for c in self.predecessor["snapshot"]["calls"]),"V5_PREDECESSOR_CALL_REENTRY")):
                if not ok: self._reject(code)
        return DurableV3Budget.reserve(self,record)

    def settle(self,call_id,*,provider_request_id,raw_usage,evidence=None,failure_reason=None):
        if provider_request_id is not None and any(c["provider_request_id"] == provider_request_id
                                                   for c in self.predecessor["snapshot"]["calls"]):
            self._reject("CONFLICTING_PROVIDER_RECEIPT",call_id=call_id)
        return DurableV3Budget.settle(self,call_id,provider_request_id=provider_request_id,
            raw_usage=raw_usage,evidence=evidence,failure_reason=failure_reason)

    def record_unknown_receipt(self,call_id,*,raw_usage,provider_request_id=None,evidence=None,
                               reason="UNKNOWN_PROVIDER_RECEIPT"):
        proof = {**deepcopy(evidence or {}),"unknown_receipt_reason":reason,
                 "receipt_identity_unverified":provider_request_id is None}
        result = self.settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                             evidence=proof,failure_reason=reason)
        try: _engine._parse_usage(raw_usage)
        except V3BudgetError: return result
        if result["status"] == "uncertain":
            result = self.settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                                 evidence=proof,failure_reason=reason)
        return result

    def finalize_item(self,item_id,status,evidence_digest):
        self._macro(item_id)
        return DurableV3Budget.finalize_item(self,item_id,status,evidence_digest)

    def _checkpoint_body(self):
        self._active()
        calls,items = self.calls(),self.items()
        _require(all(c["status"] == "settled" for c in calls)
                 and all(i["status"] in _engine.TERMINAL for i in items),"CHECKPOINT_UNFINISHED_PROGRESS")
        ids = [r["item_id"] for r in self.registry.values() if r["domain"] == "macro"]
        _require({i["item_id"] for i in items} == set(ids[:len(items)]),"CHECKPOINT_NOT_REGISTRY_PREFIX")
        body = dict(schema_version="sr-v5-budget-checkpoint-v1",campaign_id=self.config["campaign_id"],
            authority=deepcopy(self.config["authority"]),config_digest=_digest(self.config),
            calls_digest=_digest(calls),items_digest=_digest(items),completed_item_ids=ids[:len(items)],
            carried_completed_micro_item_ids=[r["item_id"] for r in self.registry.values() if r["domain"] == "micro"],
            predecessor_digest=self.predecessor["descriptor_digest"],all_calls_settled=True,no_active_items=True)
        body["checkpoint_digest"] = _digest(body)
        return body

    def snapshot(self):
        value = DurableV4Budget.snapshot(self)
        active = deepcopy(value["budget"])
        old = self.predecessor["snapshot"]
        calls = old["calls"] + value["calls"]
        known = sum(c["known_cost_nano_usd"] for c in calls)
        held = sum(c["held_cost_nano_usd"] for c in calls)
        dispatched = sum(c["dispatched"] for c in calls)
        adjustment = sum(max(0,c.get("late_known_exposure_nano_usd",0)-c["known_cost_nano_usd"]-c["held_cost_nano_usd"]) for c in calls)
        cumulative_known = self.baseline["known_cost_nano_usd"]+known
        cumulative_held = self.baseline["held_cost_nano_usd"]+held
        value.update(schema_version="sr-v5-budget-snapshot-v1",predecessor=deepcopy(self.predecessor),
            epoch_budget=active,epoch_real_api_requests=active["calls_dispatched"],
            real_api_requests=dispatched,real_incremental_cost_nano_usd=known,
            epoch_real_incremental_cost_nano_usd=active["known_cost_nano_usd"])
        value["budget"] = dict(calls_reserved_or_spent=len(calls),calls_dispatched=dispatched,
            calls_remaining=max(0,640-len(calls)),known_cost_nano_usd=known,held_cost_nano_usd=held,
            domain_counts={d:sum(c["domain"]==d for c in calls) for d in ("micro","macro")},
            kind_counts={d:{k:sum(c["domain"]==d and c["kind"]==k for c in calls) for k in ("control","prefix","branch")} for d in ("micro","macro")},
            item_counts={i:sum(c["item_id"]==i for c in calls) for i in self.registry})
        value["cumulative_budget"].update(cumulative_calls=1605+dispatched,known_cost_nano_usd=cumulative_known,
            held_cost_nano_usd=cumulative_held,known_plus_held_nano_usd=cumulative_known+cumulative_held,
            unsettled_exposure_adjustment_nano_usd=adjustment,
            risk_adjusted_known_plus_held_nano_usd=cumulative_known+cumulative_held+adjustment,
            risk_adjusted_overrun=cumulative_known+cumulative_held+adjustment>MAX_COST,
            remaining_after_known_and_held_nano_usd=max(0,MAX_COST-cumulative_known-cumulative_held))
        return value
