"""V4 real-call admission around the preserved transactional CPU Store.

finish_node retains V3's transaction, guard and resource checks verbatim except
its fake-only call gate, replaced by exact durable real-ledger admission.
"""
import copy
import math
from sr_campaign_v3.store import V3Store
from sr_campaign_v3.guard import diagnose
from sr_recovery_v2.common import ProtocolError, digest, node_map, utc_parse
from agent_recovery.p3_transport import parse_p3_usage
from sr_campaign_v3.gateway import _strict_json
from .budget import DurableV5Budget


class V5Store(V3Store):
    def __init__(self, path, artifact_root, *, budget):
        if type(budget) is not DurableV5Budget:
            raise ProtocolError('V4_CENTRAL_REAL_LEDGER_REQUIRED')
        self.budget = budget
        super().__init__(path, artifact_root)

    def bind_item(self, item, ledger_ref, now):
        if ledger_ref != self.budget.ref or self.budget.binding.get('simulated') is not False:
            raise ProtocolError('V4_REAL_LEDGER_BINDING_REQUIRED')
        def mutate(doc):
            domain = 'micro' if 'read_metadata' in doc['dag']['topological_order'] else 'macro'
            if (item['task_id'] != doc['task']['task_id'] or item['domain'] != domain
                    or item['workflow_id'] != doc['dag']['workflow_id']):
                raise ProtocolError('REGISTERED_WORKFLOW_IDENTITY_MISMATCH')
            doc['domain'] = item['domain']
            # Keep policy-neutral V3 metadata keys for inherited correction rules.
            doc['metadata'].update(v3_item_id=item['item_id'], v3_item_kind=item['kind'],
                v3_budget_ref=ledger_ref, v4_item_id=item['item_id'],
                v4_budget_ref=ledger_ref, implementation='V4-real-HTTP-r1')
            return {'item_id': item['item_id'], 'balance_cloned': False, 'real_ledger': True}, None
        return self._apply('v4.bind.' + item['item_id'], 'v4_bind_item',
            {'item': item, 'ledger_ref': ledger_ref}, now, mutate)

    def _validate_live_calls(self, package, doc, attempt_id, *, successful):
        records = {c['call_id']: c for c in self.budget.calls()}
        result = package.get('result')
        for call in package.get('calls', []):
            row = records.get(call.get('call_id'))
            if not row or (call.get('fixture_only') is not False or call.get('mode') != 'real'
                    or call.get('attempt_id') != attempt_id
                    or call.get('run_id') != doc['state']['run_id']
                    or row['item_id'] != doc['metadata']['v4_item_id']
                    or row['attempt_id'] != attempt_id
                    or call.get('provider_request_id') != row.get('provider_request_id')
                    or call.get('cost_nano_usd') != row['known_cost_nano_usd']
                    or call.get('request_sent') is not bool(row['dispatched'])
                    or call.get('input_digest') != row['sidecar']['input_digest']
                    or row['sidecar']['binding_digest'] != self.budget.config['binding_digest']):
                raise ProtocolError('V4_REAL_CALL_LEDGER_BINDING_MISMATCH')
            if result and (call.get('input_digest') != result['input_digest']
                           or call.get('node_id') != result['node_id']):
                raise ProtocolError('V4_REAL_CALL_RESULT_BINDING_MISMATCH')
            if (call.get('model') != self.budget.binding['model']
                    or call.get('endpoint') != self.budget.binding['base_url']):
                raise ProtocolError('V4_REAL_CALL_ENDPOINT_MISMATCH')
            usage = call.get('usage')
            if usage is not None:
                if (usage.get('raw') != row.get('raw_usage') or
                        parse_p3_usage({'usage': row['raw_usage']}) != usage):
                    raise ProtocolError('V4_REAL_CALL_USAGE_MISMATCH')
            if successful:
                evidence = row.get('evidence') or {}
                http = evidence.get('http_evidence') or {}
                cleanup = http.get('cleanup_receipt') or {}
                if (row['status'] != 'settled' or row['dispatched'] is not True
                        or call.get('status') != 'completed' or call.get('worker_started') is not True
                        or call.get('http_status') != 200 or usage is None
                        or http.get('simulated') is not False or http.get('real_request_sent') is not True
                        or cleanup.get('reaped') is not True or cleanup.get('cleanup_failed') is not False):
                    raise ProtocolError('V4_SETTLED_REAPED_REAL_CALL_REQUIRED')
                try:
                    raw_payload = _strict_json(evidence['raw_response']['choices'][0]['message']['content'])
                except (KeyError, IndexError, TypeError, ValueError):
                    raise ProtocolError('V4_ORIGINAL_MODEL_PAYLOAD_REQUIRED') from None
                if call.get('raw_response_payload') != raw_payload:
                    raise ProtocolError('V4_ORIGINAL_MODEL_PAYLOAD_MISMATCH')

    def abort_http_attempt(self, attempt_id, call, reason, now):
        self._validate_live_calls({'calls': [call]}, self.snapshot(), attempt_id, successful=False)
        return super().abort_http_attempt(attempt_id, call, reason, now)

    def finish_node(self, attempt_id, package, now_utc):
        # Byte staging cannot mutate any business object. Refused candidates and
        # their artifacts remain available for failure analysis.
        self._stage_artifacts(package)
        persisted_package = {k: v for k, v in package.items() if k != 'artifact_contents'}
        def mutate(doc):
            state = doc['state']
            attempt = next((a for a in doc['attempts'] if a['attempt_id'] == attempt_id), None)
            if not attempt:
                raise ProtocolError('UNKNOWN_ATTEMPT')
            if attempt['status'] != 'running':
                raise ProtocolError('ATTEMPT_ALREADY_SETTLED')
            result = copy.deepcopy(package['result'])
            self._validate(result)
            if result['attempt_id'] != attempt_id or result['node_id'] != attempt['node_id'] or result['run_id'] != state['run_id']:
                raise ProtocolError('RESULT_IDENTITY_MISMATCH')
            expected_parents = [state['selected_by_node'][p] for p in node_map(doc['dag'])[result['node_id']]['parents']]
            if result['parent_result_ids'] != expected_parents:
                raise ProtocolError('RESULT_PARENT_BINDING_MISMATCH')
            if any(r['result_id'] == result['result_id'] for r in doc['results']):
                raise ProtocolError('DUPLICATE_RESULT_ID')
            self._validate_live_calls(package, doc, attempt_id, successful=True)
            execution = package.get('job_execution')
            if attempt['counter_cpu']:
                if result.get('fixture_only') is not False:
                    raise ProtocolError('REAL_CPU_RESULT_REQUIRED')
                required = {'job_id', 'tool', 'pid', 'pgid', 'started_at_utc', 'finished_at_utc',
                    'deadline_utc', 'effective_timeout_seconds', 'status', 'returncode',
                    'worker_reaped', 'timed_out', 'peak_rss_bytes', 'cpu_seconds', 'wall_seconds',
                    'output_bytes', 'signal', 'termination', 'limits', 'source_sha256'}
                if not isinstance(execution, dict) or not required <= execution.keys():
                    raise ProtocolError('RESOURCE_EXECUTION_RECEIPT_REQUIRED')
                if execution['deadline_utc'] != attempt['deadline_utc']:
                    raise ProtocolError('EXECUTION_DEADLINE_BINDING_MISMATCH')
                if (utc_parse(execution['started_at_utc']) < utc_parse(attempt['started_at_utc']) or
                        utc_parse(execution['finished_at_utc']) < utc_parse(execution['started_at_utc']) or
                        utc_parse(execution['finished_at_utc']) > utc_parse(now_utc)):
                    raise ProtocolError('EXECUTION_CLOCK_BINDING_MISMATCH')
                if execution['effective_timeout_seconds'] > 120 or execution['effective_timeout_seconds'] < 0:
                    raise ProtocolError('EXECUTION_TIMEOUT_LIMIT_INVALID')
                limits = execution['limits']
                expected_limits = {'address_space_bytes': 8589934592,
                    'rss_monitor_bytes': 8589934592, 'max_artifact_bytes': 134217728,
                    'total_disk_bytes': 4294967296}
                if limits != expected_limits:
                    raise ProtocolError('EXECUTION_LIMITS_MISMATCH')
                worker_identity = attempt.get('worker_identity')
                if worker_identity is None and execution['status'] == 'success':
                    raise ProtocolError('EXECUTION_WORKER_BINDING_REQUIRED')
                if worker_identity is not None and any(execution.get(k) != worker_identity[k]
                        for k in ('job_id', 'pid', 'pgid', 'started_at_utc')):
                    raise ProtocolError('EXECUTION_WORKER_BINDING_MISMATCH')
                measurements = ('effective_timeout_seconds', 'peak_rss_bytes', 'cpu_seconds',
                                'wall_seconds', 'output_bytes')
                if any(isinstance(execution[k], bool) or not isinstance(execution[k], (int, float)) or
                       not math.isfinite(execution[k]) or execution[k] < 0 for k in measurements):
                    raise ProtocolError('EXECUTION_MEASUREMENTS_INVALID')
                if (execution['status'] not in ('success', 'failed', 'timeout', 'memory_exceeded', 'disk_exceeded', 'uncertain') or
                        not isinstance(execution['worker_reaped'], bool) or not isinstance(execution['timed_out'], bool) or
                        any(isinstance(execution[k], bool) or not isinstance(execution[k], int) or execution[k] <= 0 for k in ('pid', 'pgid')) or
                        not isinstance(execution['source_sha256'], str) or len(execution['source_sha256']) != 64 or
                        any(c not in '0123456789abcdef' for c in execution['source_sha256'])):
                    raise ProtocolError('EXECUTION_IDENTITY_INVALID')
                if any(r.get('fixture_only') is not False or r.get('parameters', {}).get('execution') != execution
                       for r in package.get('tool_receipts', [])):
                    raise ProtocolError('REAL_TOOL_EXECUTION_BINDING_REQUIRED')
                attempt['worker_reaped'] = bool(execution['worker_reaped'])
                attempt['job_execution'] = copy.deepcopy(execution)
                resource_failed = (execution['status'] != 'success' or execution['returncode'] != 0 or
                    not execution['worker_reaped'] or execution['timed_out'] or
                    execution['peak_rss_bytes'] > 8589934592 or
                    execution['output_bytes'] > 4294967296 or
                    execution['wall_seconds'] > execution['effective_timeout_seconds'])
                if resource_failed:
                    result['execution_status'] = 'uncertain'
            else:
                if execution is not None:
                    raise ProtocolError('UNEXPECTED_CPU_EXECUTION')
                resource_failed = False
            for name, identity in [('calls', 'call_id'), ('tool_receipts', 'receipt_id'), ('artifacts', 'artifact_id')]:
                values = package.get(name, [])
                old_ids = {v[identity] for v in doc[name]}
                if len({v[identity] for v in values}) != len(values) or any(v[identity] in old_ids for v in values):
                    raise ProtocolError('EVIDENCE_ID_REBOUND')
                for value in values:
                    self._validate(value)
                doc[name].extend(copy.deepcopy(values))
            if len(package.get('calls', [])) != attempt['counter_llm'] or len(package.get('tool_receipts', [])) != attempt['counter_cpu']:
                raise ProtocolError('DISPATCH_EVIDENCE_COUNT_MISMATCH')
            if any(c['status'] != 'completed' for c in package.get('calls', [])) or any(
                    r['exit_code'] != 0 for r in package.get('tool_receipts', [])):
                result['execution_status'] = 'uncertain'
            late = utc_parse(now_utc) >= utc_parse(attempt['deadline_utc']) or state['status'] == 'terminal'
            attempt.update(status='late_ignored' if late else 'completed', finished_at_utc=now_utc,
                           result_id=result['result_id'], input_digest=result['input_digest'], late=late)
            state['active_attempt_ids'].remove(attempt_id)
            if attempt['counter_llm']:
                state['unsettled_call_ids'].remove(attempt_id + '.call')
            if late:
                doc['late_outputs'].append({'attempt_id': attempt_id, 'raw_result': result, 'observed_at_utc': now_utc})
                result['execution_status'] = 'cancelled'
                doc['results'].append(result)
                state.update(status='terminal', terminal_status='budget_or_time_stopped')
                return {'late_ignored': True, 'raw_candidate': package['result']}, {'result': result, 'guard': None, 'state': state, 'late': True}
            final = result['node_id'] == doc['dag']['topological_order'][-1]
            guard = diagnose(doc, result['node_id'], 'precommit' if final else 'post_tool',
                             candidate=result, full=False, artifact_root=self.artifact_root)
            doc['results'].append(result)
            # Guard digest refers to exactly the persisted candidate-inclusive
            # result list. Store accepts refusal status as a separate disposition.
            if guard['classification'] != 'passed':
                if result['execution_status'] == 'success':
                    result['execution_status'] = 'validation_rejected'
                guard = diagnose(doc, result['node_id'], 'precommit' if final else 'post_tool',
                                 candidate=result, full=False, artifact_root=self.artifact_root)
                self._append_guard(doc, guard)
                if resource_failed:
                    state.update(status='terminal', terminal_status='uncertain')
            else:
                state['selected_by_node'][result['node_id']] = result['result_id']
                state['pending_node_ids'] = [n for n in state['pending_node_ids'] if n != result['node_id']]
                state['stage_completed_node_ids'].append(result['node_id'])
                doc['last_guard'] = None
                if final:
                    self._publish(doc, result)
                    state.update(status='terminal', terminal_status='completed_correct')
                doc['guards'].append(guard)
                if result['node_id'] in ('fit_lr', 'fit_rf'):
                    doc['metadata']['actual_training'] += 1
            return ({'attempt_id': attempt_id, 'raw_candidate': package['result'],
                    'guard_id': guard['guard_id'], 'classification': guard['classification']},
                    {'result': result, 'guard': guard, 'state': state, 'late': False})
        return self._apply('v2.finish.' + attempt_id, 'settle', {'attempt_id': attempt_id, 'package': persisted_package},
                           now_utc, mutate, allow_expired=True)

