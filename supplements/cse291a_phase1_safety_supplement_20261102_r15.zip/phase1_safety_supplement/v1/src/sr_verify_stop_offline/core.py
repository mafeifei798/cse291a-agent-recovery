"""Replay public evidence through the existing macro business predicates.

This is a preventive control starting at the workflow entrance, not a fourth
recovery policy. The only adapter implemented here returns saved records.
Binary evidence is checked against retained inventories, never deserialized.
"""
from collections import Counter
from copy import deepcopy
from statistics import median
from time import perf_counter_ns, process_time_ns

from sr_saved_audit.core import Artifacts, EvidenceError, digest, index, read, require
from sr_campaign_v3.guard import _macro_business, _cpu_metadata_business
from sr_recovery_v2.common import source_fingerprint

ORDER = ('profile', 'inspect', 'prepare', 'plan_lr', 'fit_lr', 'predict_lr',
         'summary_lr', 'plan_rf', 'fit_rf', 'predict_rf', 'summary_rf', 'report', 'publish')
RESULT_FIELDS = ('result_id', 'run_id', 'node_id', 'attempt_id', 'input_digest',
                 'input_snapshot', 'parent_result_ids', 'direct_reads', 'effective_reads',
                 'execution_status', 'payload', 'artifact_refs', 'call_ids', 'tool_receipt_ids')
SOURCE_FIELDS = ('object_key', 'version', 'payload', 'payload_digest', 'artifact_refs')
# V6 macro epoch3 uses the 2,048-token cap, not the earlier V3 cap.
RESERVE = 1924000


class ReadCount(dict):
    """Logical public-record accesses, not filesystem or remote SQL reads."""
    def __init__(self, values):
        super().__init__(values)
        self.reads = 0

    def get(self, key, default=None):
        self.reads += 1
        return super().get(key, default)

    def __getitem__(self, key):
        self.reads += 1
        return super().__getitem__(key)


def public_frame(view, candidate, dag):
    """Project one actual candidate; never project the fault label or verdict.

    The matching historical checkpoint supplies only its authority references.
    Using final view.sources would leak N2/N3 updates that happened after freeze.
    """
    guards = [g for g in view['guards'] if g.get('candidate_result_id') == candidate['result_id']
              and g['checkpoint'] in ('post_tool', 'precommit')]
    require(len(guards) == 1, 'UNIQUE_HISTORICAL_CHECKPOINT_REQUIRED')
    checkpoint = guards[0]
    versions = {}
    for s in view.get('source_history', []) + view['sources']:
        key = (s['object_key'], s['version'])
        if key in versions:
            require(versions[key] == s, 'AMBIGUOUS_SOURCE_HISTORY')
        versions[key] = s
    sources = [versions[(r['object_key'], r['version'])] for r in checkpoint['current_sources']]
    require(source_fingerprint(sources) == checkpoint['source_fingerprint'], 'HISTORICAL_SOURCE_FINGERPRINT')
    # Deliberately no view.state, selected_by_node, notice, guard issues,
    # independent checker output, private scene specification, or future result.
    return {'candidate': {k: deepcopy(candidate[k]) for k in RESULT_FIELDS},
            'sources': [{k: deepcopy(s[k]) for k in SOURCE_FIELDS} for s in sources],
            'request': deepcopy(view['task']['request']),
            'node': deepcopy(next(n for n in dag['nodes'] if n['node_id'] == candidate['node_id'])),
            'calls': [deepcopy(c) for c in view['calls'] if c['call_id'] in candidate['call_ids']],
            'tool_receipts': [deepcopy(r) for r in view['tool_receipts']
                              if r['receipt_id'] in candidate['tool_receipt_ids']],
            'artifact_bindings': [deepcopy(a) for a in view['artifacts']
                                  if a['artifact_id'] in candidate['artifact_refs']]}


class PublicArtifacts:
    """Only evidence explicitly bound to already dispatched frames is visible."""
    def __init__(self, root, entries):
        self.provider = Artifacts(root, entries)
        self.bindings = {}
        self.logical_reads = self.json_bytes = self.binary_inventory_reads = 0
        self.unique_json = set()
        self.unique_json_bytes = 0

    def bind(self, bindings):
        for b in bindings:
            old = self.bindings.get(b['artifact_id'])
            require(old is None or old == b, 'ARTIFACT_REBOUND')
            self.bindings[b['artifact_id']] = b

    def get(self, aid, result_id=None):
        require(aid in self.bindings, 'UNBOUND_OR_FUTURE_ARTIFACT:' + str(aid))
        binding = self.bindings[aid]
        self.logical_reads += 1
        value = self.provider.get(binding)
        if value is None:
            self.binary_inventory_reads += 1
        else:
            self.json_bytes += binding['size_bytes']
            if binding['sha256'] not in self.unique_json:
                self.unique_json.add(binding['sha256'])
                self.unique_json_bytes += binding['size_bytes']
        return value

    def counters(self):
        return {'logical_artifact_reads': self.logical_reads, 'json_bytes_hashed': self.json_bytes,
                'unique_json_bytes': self.unique_json_bytes,
                'binary_inventory_reads': self.binary_inventory_reads}


class Verifier:
    """Same frozen business predicates, evaluated on the available prefix only."""
    def __init__(self, artifacts):
        self.artifacts = artifacts
        self.accepted = {}
        self.receipts = {}
        self._verified_digest = None

    def pre_dispatch(self, frame):
        """The shared consumed-parent freshness/permission check stays earlier."""
        current = index(frame['sources'], 'object_key')
        if frame['request'].get('publish_allowed') is False:
            return 'PUBLISH_PERMISSION_DENIED'
        for node in frame['node']['parents']:
            parent = self.accepted.get(node)
            if parent is None:
                return 'PARENT_NOT_ACCEPTED'
            for ref in parent['effective_reads']:
                if current.get(ref['object_key'], {}).get('version') != ref['version']:
                    return 'CONSUMED_SOURCE_VERSION_CHANGED'
        return None

    def check(self, frame):
        wall, cpu = perf_counter_ns(), process_time_ns()
        before = self.artifacts.counters()
        issues = []
        business_wall = business_cpu = None
        business_before = None
        business_sources = business_receipts = 0
        current = receipts = None
        self._verified_digest = None

        def issue(cls, code, field, related=(), refs=(), **extra):
            record = {'classification': cls, 'code': code, 'field': field}
            if record not in issues:
                issues.append(record)

        try:
            r, node, sources = frame['candidate'], frame['node'], frame['sources']
            current = ReadCount(index(sources, 'object_key'))
            require(r['node_id'] == node['node_id'], 'NODE_IDENTITY_MISMATCH')
            require(r['execution_status'] in ('success', 'validation_rejected'), 'CANDIDATE_NOT_SETTLED')
            require(r['input_digest'] == digest(r['input_snapshot']), 'INPUT_DIGEST_MISMATCH')
            snapshot = r['input_snapshot']
            require(snapshot['node_id'] == r['node_id'] and snapshot['run_id'] == r['run_id']
                    and snapshot['request'] == frame['request'], 'INPUT_IDENTITY_MISMATCH')
            parents = [self.accepted.get(p) for p in node['parents']]
            require(all(parents), 'PARENT_NOT_ACCEPTED')
            require(set(r['parent_result_ids']) == {p['result_id'] for p in parents}
                    and len(r['parent_result_ids']) == len(parents), 'ACTUAL_PARENT_IDS_MISMATCH')
            captured = index(snapshot['parent_inputs'], 'result_id')
            require(set(captured) == set(r['parent_result_ids']), 'CAPTURED_PARENT_IDS_MISMATCH')
            for p in parents:
                saved = captured[p['result_id']]
                require(saved['payload'] == p['payload'] and saved['payload_digest'] == digest(p['payload'])
                        and saved['effective_reads'] == p['effective_reads'], 'CAPTURED_PARENT_PAYLOAD_MISMATCH')
            for s in sources:
                require(digest(s['payload']) == s['payload_digest'], 'SOURCE_DIGEST_MISMATCH')
                if s['object_key'].startswith('permission') and s['payload'].get('allowed') is not True:
                    issue('permission_denied', 'PERMISSION_DENIED', s['object_key'])
            if frame['request'].get('publish_allowed') is False:
                issue('permission_denied', 'PUBLISH_PERMISSION_DENIED', 'request')
            direct = index(r['direct_reads'], 'object_key')
            require(set(direct) == set(node['direct_source_keys']), 'DIRECT_READ_KEYS_MISMATCH')
            captured_sources = index(snapshot['direct_source_inputs'], 'object_key')
            require(set(captured_sources) == set(direct), 'CAPTURED_SOURCE_KEYS_MISMATCH')
            effective = {}
            for p in parents:
                for ref in p['effective_reads']:
                    require(ref['object_key'] not in effective or effective[ref['object_key']] == ref['version'],
                            'MIXED_SOURCE_VERSIONS')
                    effective[ref['object_key']] = ref['version']
            for key, ref in direct.items():
                source = current[key]
                require(ref['version'] == source['version'] and
                        all(captured_sources[key][k] == source[k] for k in SOURCE_FIELDS), 'DIRECT_SOURCE_NOT_CURRENT')
                require(key not in effective or effective[key] == ref['version'], 'MIXED_SOURCE_VERSIONS')
                effective[key] = ref['version']
            observed = index(r['effective_reads'], 'object_key')
            require({k: v['version'] for k, v in observed.items()} == effective, 'EFFECTIVE_READ_CLOSURE_MISMATCH')
            for key, version in effective.items():
                if current[key]['version'] != version:
                    issue('stale', 'CONSUMED_SOURCE_VERSION_CHANGED', key)
            bindings = frame['artifact_bindings']
            require({b['artifact_id'] for b in bindings} == set(r['artifact_refs']), 'OUTPUT_BINDING_MISSING')
            require(all(b['producer_result_id'] == r['result_id'] for b in bindings), 'ARTIFACT_PRODUCER_MISMATCH')
            allowed_inputs = set(self.artifacts.bindings) | {
                aid for source in sources for aid in source['artifact_refs']}
            require(all(b['artifact_id'] in allowed_inputs for b in snapshot['artifact_bindings']),
                    'INPUT_ARTIFACT_OUTSIDE_ACCEPTED_PREFIX')
            self.artifacts.bind(snapshot['artifact_bindings'] + bindings)
            for b in snapshot['artifact_bindings']:
                self.artifacts.get(b['artifact_id'])
            for aid in r['artifact_refs']:
                self.artifacts.get(aid)
            for key, idkey, records in [('call_ids', 'call_id', frame['calls']),
                                         ('tool_receipt_ids', 'receipt_id', frame['tool_receipts'])]:
                evidence = index(records, idkey)
                require(set(evidence) == set(r[key]), 'CANDIDATE_RECEIPT_MISSING')
                require(len(evidence) == node['llm_calls_per_execution' if key == 'call_ids' else 'cpu_jobs_per_execution'],
                        'EVIDENCE_COUNT_MISMATCH')
                for rec in records:
                    require(all(rec[k] == r[k] for k in ('run_id', 'node_id', 'attempt_id', 'input_digest')),
                            'RECEIPT_IDENTITY_MISMATCH')
                    if key == 'tool_receipt_ids':
                        require(rec['producer_result_id'] == r['result_id'], 'TOOL_PRODUCER_MISMATCH')
                        execution = rec.get('parameters', {}).get('execution', {})
                        require(execution.get('status') == 'success' and execution.get('worker_reaped') is True
                                and execution.get('returncode') == 0 and not execution.get('timed_out'),
                                'CPU_COMPLETION_UNCERTAIN')
                    else:
                        require(rec['status'] == 'completed', 'MODEL_COMPLETION_UNCERTAIN')
            # Do not inspect future rows, saved diagnoses, injected-fault IDs,
            # numerical checker receipts or private test labels.
            rows = {**self.accepted, r['node_id']: r}
            by_id = {p['result_id']: p for p in rows.values()}
            selected = {n: p['result_id'] for n, p in rows.items()}
            receipts = ReadCount({**self.receipts, **index(frame['tool_receipts'], 'receipt_id')})
            business_before = self.artifacts.counters()
            business_sources, business_receipts = current.reads, receipts.reads
            business_wall, business_cpu = perf_counter_ns(), process_time_ns()
            _macro_business(current, selected, by_id, receipts, self.artifacts.get,
                            frame['request'], r, issue)
            if 'prepare' in rows:
                _cpu_metadata_business(current, selected, by_id, receipts,
                                       self.artifacts.bindings, self.artifacts.get, r, issue)
            # Preserve the common business profile: unused raw publish prose
            # is not turned into a new rejection criterion for VERIFY_STOP.
        except (EvidenceError, KeyError, TypeError, ValueError, OSError) as exc:
            unavailable = ('CANDIDATE_NOT_SETTLED', 'CANDIDATE_RECEIPT_MISSING', 'OUTPUT_BINDING_MISSING',
                           'CPU_COMPLETION_UNCERTAIN', 'MODEL_COMPLETION_UNCERTAIN',
                           'ARTIFACT_BINDING_CHANGED', 'UNBOUND_OR_FUTURE_ARTIFACT')
            classification = ('uncertain' if not isinstance(exc, EvidenceError) or
                              str(exc).startswith(unavailable) else 'integrity_error')
            issue(classification, str(exc), 'public_evidence')
        after = self.artifacts.counters()
        business_stats = {'business_wall_ns': perf_counter_ns() - business_wall if business_wall else 0,
                          'business_cpu_ns': process_time_ns() - business_cpu if business_cpu else 0,
                          'business_source_object_reads': current.reads - business_sources if business_before else 0,
                          'business_tool_receipt_reads': receipts.reads - business_receipts if business_before else 0}
        business_stats.update({'business_' + k: after[k] - business_before[k] if business_before else 0
                               for k in after})
        if not issues:
            self._verified_digest = digest(frame)
        return {'node_id': frame['candidate']['node_id'], 'result_id': frame['candidate']['result_id'],
                'passed': not issues, 'issues': issues,
                'checkpoint': 'precommit' if frame['candidate']['node_id'] == 'publish' else 'post_delivery_before_bind',
                'incremental_semantic_gate': frame['candidate']['node_id'] != 'publish',
                'wall_ns': perf_counter_ns() - wall, 'cpu_ns': process_time_ns() - cpu,
                **business_stats,
                **{k: after[k] - before[k] for k in after}}

    def accept(self, frame):
        require(self._verified_digest is not None and self._verified_digest == digest(frame),
                'PASSED_UNMODIFIED_CANDIDATE_REQUIRED')
        self.accepted[frame['candidate']['node_id']] = deepcopy(frame['candidate'])
        self.receipts.update(index(deepcopy(frame['tool_receipts']), 'receipt_id'))
        self._verified_digest = None


class SavedClient:
    """Finite fake adapter; dispatch returns saved outputs, never runs tools."""
    def __init__(self, frames, timeouts=(), durations=None):
        self.frames = frames
        self.timeouts = set(timeouts)
        self.durations = durations or {}
        self.dispatched = []

    def dispatch(self, position, timeout_seconds=120):
        frame = deepcopy(self.frames[position])
        node = frame['candidate']['node_id']
        self.dispatched.append(node)
        duration = self.durations.get(node, 0)
        if node in self.timeouts or duration > timeout_seconds:
            return None, min(duration or timeout_seconds, timeout_seconds)
        return frame, duration


class StopController:
    def __init__(self, verifier, *, available_nano=847834550, deadline=1800,
                 max_calls=15, max_cpu=30):
        self.verifier = verifier
        self.available = available_nano
        self.deadline = deadline
        self.max_calls, self.max_cpu = max_calls, max_cpu
        self.elapsed = self.calls = self.cpu_jobs = self.held = self.known = 0
        self.status = 'running'
        self.gates = []
        self.accepted_nodes = []
        self.published = False
        self.pre_dispatch_refusal = None

    def run(self, client):
        for position, spec in enumerate(client.frames):
            if self.status != 'running':
                break
            node = spec['node']
            refusal = self.verifier.pre_dispatch(spec)
            if refusal:
                self.status = 'pre_dispatch_stop'
                self.pre_dispatch_refusal = {'node_id': node['node_id'], 'code': refusal}
                break
            calls, cpu = node['llm_calls_per_execution'], node['cpu_jobs_per_execution']
            if self.elapsed >= self.deadline:
                self.status = 'deadline_stop'; break
            if self.calls + calls > self.max_calls or self.cpu_jobs + cpu > self.max_cpu:
                self.status = 'resource_cap_stop'; break
            reserve = calls * RESERVE
            if self.available < reserve:
                self.status = 'budget_stop'; break
            self.available -= reserve
            self.held += reserve
            self.calls += calls
            self.cpu_jobs += cpu
            frame, duration = client.dispatch(position, min(120, self.deadline - self.elapsed))
            self.elapsed += duration
            if frame is None or self.elapsed > self.deadline:
                # Unknown usage keeps the full reservation; no retry or late bind.
                self.status = 'uncertain_stop'; break
            # This is a separate simulated ledger, not the project's real ledger.
            settled = sum(c.get('cost_nano_usd', 0) for c in frame['calls'])
            require(type(settled) is int and 0 <= settled <= reserve, 'INVALID_SIMULATED_SETTLEMENT')
            self.available += reserve - settled
            self.known += settled
            self.held -= reserve
            gate = self.verifier.check(frame)
            self.gates.append(gate)
            if not gate['passed']:
                uncertain = any(i['classification'] == 'uncertain' for i in gate['issues'])
                self.status = 'uncertain_stop' if uncertain else 'verification_stop'
                break
            self.verifier.accept(frame)
            self.accepted_nodes.append(node['node_id'])
            if node['node_id'] == 'publish':
                self.published = True
                self.status = 'completed'
                break
        if self.status == 'running':
            self.status = 'completed' if self.published else 'incomplete'
        return self.snapshot()

    def snapshot(self):
        return {'status': self.status, 'completed': self.status == 'completed',
                'published_in_fake_store': self.published, 'accepted_nodes': list(self.accepted_nodes),
                'simulated_llm_dispatches': self.calls, 'simulated_cpu_jobs': self.cpu_jobs,
                'simulated_known_cost_nano_usd': self.known,
                'unsettled_simulated_reservation_nano_usd': self.held,
                'pre_dispatch_refusal': deepcopy(self.pre_dispatch_refusal),
                'stop_node': self.gates[-1]['node_id'] if self.gates and not self.gates[-1]['passed'] else None,
                'gates': deepcopy(self.gates), 'new_real_api_calls': 0, 'new_training_jobs': 0}

    def deliver_late(self, frame):
        require(self.status != 'running', 'NOT_TERMINAL')
        return {'accepted': False, 'reason': 'terminal_controller'}


def load_tapes(root, *, valid_controls=False):
    dag = read(root / 'contracts/macro_dag.json')
    tapes = {}
    for dataset in ('adult', 'bank'):
        for suffix in ('control', 'N1.prefix', 'N2.prefix', 'N3.prefix'):
            name = 'sr-v2.macro.' + dataset + '.' + suffix
            view = read(root / 'raw/macro/exports' / (name + '.json'))
            results = index(view['results'], 'result_id')
            if valid_controls and suffix == 'control':
                candidates = [results[view['state']['selected_by_node'][n]] for n in ORDER]
            else:
                candidates = [results[a['result_id']] for a in view['attempts']]
            frames = [public_frame(view, r, dag) for r in candidates]
            tapes[name] = {'frames': frames,
                           'final_source_versions': {s['object_key']: s['version'] for s in view['sources']},
                           'recorded_calls': len(view['calls']), 'recorded_attempts': len(view['attempts']),
                           'recorded_cpu_jobs': sum(a['counter_cpu'] for a in view['attempts']),
                           'recorded_cost_nano_usd': sum(c.get('cost_nano_usd', 0) for c in view['calls']),
                           'recorded_guard_checkpoints': dict(Counter(g['checkpoint'] for g in view['guards']))}
    return tapes


def run_tape(root, entries, frames, **kwargs):
    verifier = Verifier(PublicArtifacts(root, entries))
    client = SavedClient(frames)
    result = StopController(verifier, **kwargs).run(client)
    result['dispatched_nodes'] = client.dispatched
    return result


def replay(root, entries, tapes):
    result = []
    for name, tape in tapes.items():
        runs = [run_tape(root, entries, tape['frames']) for _ in range(3)]
        out = runs[0]
        out['item_id'] = name
        out['evidence_mode'] = 'recorded_trace_counterfactual_not_new_execution'
        reached = tape['frames'][:len(out['dispatched_nodes'])]
        out['recorded_work_through_stop'] = {
            'node_attempts': len(reached), 'llm_calls': sum(len(f['calls']) for f in reached),
            'cpu_jobs': sum(len(f['tool_receipts']) for f in reached),
            'known_cost_nano_usd': sum(c.get('cost_nano_usd', 0) for f in reached for c in f['calls'])}
        out['original_recorded_work'] = {k: v for k, v in tape.items() if k != 'frames'}
        out['not_reached_nodes'] = [n for n in ORDER if n not in out['dispatched_nodes']]
        out['checks_wall_ms_three_replays'] = [sum(g['wall_ns'] for g in r['gates']) / 1e6 for r in runs]
        out['checks_cpu_ms_three_replays'] = [sum(g['cpu_ns'] for g in r['gates']) / 1e6 for r in runs]
        out['incremental_check_wall_ms_median'] = median(
            sum(g['business_wall_ns'] for g in r['gates'] if g['incremental_semantic_gate']) / 1e6 for r in runs)
        out['incremental_check_cpu_ms_median'] = median(
            sum(g['business_cpu_ns'] for g in r['gates'] if g['incremental_semantic_gate']) / 1e6 for r in runs)
        out['real_verify_stop_trial'] = False
        result.append(out)
    return result
