"""Offline VERIFY_STOP evidence replay; no model or CPU-workflow launcher."""
