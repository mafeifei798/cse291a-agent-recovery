"""Bounded protocol scenarios. Every model/CPU dispatch is a saved-data fake."""
from copy import deepcopy
from sr_saved_audit.core import digest, read, require
from .core import (ORDER, RESERVE, PublicArtifacts, SavedClient, StopController,
                   Verifier, load_tapes)


def fake_suite(root, entries):
    controls = load_tapes(root, valid_controls=True)
    adult = controls['sr-v2.macro.adult.control']['frames']
    bank = controls['sr-v2.macro.bank.control']['frames']
    cases = []

    def run(name, *, frames=None, mutate=None, expected='verification_stop', stop=None,
            timeout=(), durations=None, controller_options=None, artifact_mutate=None,
            expected_pre_dispatch=None, expected_dispatches=None, late=False):
        frames = deepcopy(adult if frames is None else frames)
        if mutate:
            mutate(frames)
        local_entries = deepcopy(entries)
        if artifact_mutate:
            artifact_mutate(local_entries, frames)
        client = SavedClient(frames, timeout, durations)
        controller = StopController(Verifier(PublicArtifacts(root, local_entries)),
                                    **(controller_options or {}))
        outcome = controller.run(client)
        checks = {'status': outcome['status'] == expected,
                  'stop_node': outcome['stop_node'] == stop,
                  'no_real_work': outcome['new_real_api_calls'] == outcome['new_training_jobs'] == 0,
                  'no_publish_after_stop': outcome['completed'] or not outcome['published_in_fake_store']}
        if expected_pre_dispatch:
            checks['pre_dispatch'] = (outcome['pre_dispatch_refusal'] or {}).get('node_id') == expected_pre_dispatch
        if expected_dispatches is not None:
            checks['no_downstream_dispatch'] = len(client.dispatched) == expected_dispatches
        if late:
            frozen = digest(controller.snapshot())
            late_receipt = controller.deliver_late(frames[-1])
            checks['late_ignored_and_state_unchanged'] = not late_receipt['accepted'] and digest(controller.snapshot()) == frozen
        # A duplicate run call cannot reopen a terminal branch or spend again.
        before, dispatches = digest(controller.snapshot()), len(client.dispatched)
        controller.run(client)
        checks['terminal_idempotence'] = before == digest(controller.snapshot()) and len(client.dispatched) == dispatches
        record = {'case_id': name, 'passed': all(checks.values()), 'assertions': checks,
                  'mode': 'fake_clients_with_saved_public_evidence', 'outcome': outcome,
                  'dispatched_nodes': client.dispatched}
        cases.append(record)

    run('clean_adult', expected='completed', expected_dispatches=13)
    # Uses the final valid saved Bank report. This is explicitly scripted,
    # not a replacement for the Bank first-attempt failure in recorded replay.
    run('clean_bank_scripted_valid_report', frames=bank, expected='completed', expected_dispatches=13)
    def metric(frames, family):
        frame = frames[ORDER.index('summary_' + family)]
        frame['candidate']['payload']['metrics']['average_precision'] = 0.0
    run('wrong_lr_summary', mutate=lambda f: metric(f, 'lr'), stop='summary_lr', expected_dispatches=7)
    run('wrong_rf_summary', mutate=lambda f: metric(f, 'rf'), stop='summary_rf', expected_dispatches=11)
    run('wrong_rf_recipe', mutate=lambda f: f[7]['candidate']['payload']['parameters'].update(n_estimators=999),
        stop='plan_rf', expected_dispatches=8)
    run('wrong_report_selection', mutate=lambda f: f[11]['candidate']['payload'].update(chosen_family='LR'),
        stop='report', expected_dispatches=12)
    run('wrong_publish_model', mutate=lambda f: f[12]['candidate']['payload'].update(model_artifact_id='foreign-model'),
        stop='publish', expected_dispatches=13)
    def paraphrase(frames):
        frames[12]['calls'][0]['raw_response_payload']['report']['report_text'] = 'Equivalent unused publish copy.'
    run('unused_publish_copy_prose', mutate=paraphrase, expected='completed', expected_dispatches=13)
    run('missing_profile_receipt', mutate=lambda f: f[0].update(tool_receipts=[]),
        expected='uncertain_stop', stop='profile', expected_dispatches=1)
    def unfinished(frames):
        frames[4]['tool_receipts'][0]['parameters']['execution']['worker_reaped'] = False
    run('unreaped_cpu_receipt', mutate=unfinished, expected='uncertain_stop', stop='fit_lr', expected_dispatches=5)
    def changed_source(frames):
        source = next(s for s in frames[3]['sources'] if s['object_key'] == 'data:train')
        source['version'] += 1
    run('source_updated_before_plan', mutate=changed_source, expected='pre_dispatch_stop',
        expected_pre_dispatch='plan_lr', expected_dispatches=3)
    def lost_json(entries, frames):
        aid = frames[2]['candidate']['payload']['families']['lr']['rows_artifact_id']
        entries.pop(aid)
    run('missing_prepare_row_evidence', artifact_mutate=lost_json,
        expected='uncertain_stop', stop='prepare', expected_dispatches=3)
    run('zero_output_timeout_and_late_response', timeout=('inspect',), expected='uncertain_stop',
        expected_dispatches=2, late=True)
    run('budget_before_first_llm', controller_options={'available_nano': RESERVE - 1},
        expected='budget_stop', expected_dispatches=1)
    run('fixed_deadline_no_next_dispatch', durations={'profile': 100}, controller_options={'deadline': 100},
        expected='deadline_stop', expected_dispatches=1)
    run('remaining_deadline_bounds_call', durations={'profile': 60, 'inspect': 50},
        controller_options={'deadline': 100}, expected='uncertain_stop', expected_dispatches=2)
    run('cpu_resource_cap', controller_options={'max_cpu': 1}, expected='resource_cap_stop', expected_dispatches=2)
    run('llm_resource_cap', controller_options={'max_calls': 0}, expected='resource_cap_stop', expected_dispatches=1)
    timeout_case = next(c for c in cases if c['case_id'] == 'zero_output_timeout_and_late_response')
    timeout_case['assertions']['unknown_usage_hold_retained'] = (
        timeout_case['outcome']['unsettled_simulated_reservation_nano_usd'] == RESERVE)
    timeout_case['passed'] = all(timeout_case['assertions'].values())
    return {'passed': all(c['passed'] for c in cases), 'count': len(cases), 'cases': cases,
            'new_real_api_calls': 0, 'new_training_jobs': 0}
