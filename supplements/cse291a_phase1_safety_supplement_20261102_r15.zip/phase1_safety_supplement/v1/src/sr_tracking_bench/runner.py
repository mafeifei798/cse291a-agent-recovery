"""Serial, plan-pinned normal runs. There is no live transport or resume mode."""
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import sqlite3
import statistics
import sys
import time
import traceback

from sr_campaign_v3.executor import run_job, disk_usage
from .contracts import TASK_ITEM_IDS, normal_items, require, sha_file, write_json
from .full import run_full
from .reference import run_reference
from .oracle import check_run, compare_runs

REPO = Path(__file__).resolve().parents[2]
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")


def validate_plan(plan, v0_root):
    require(plan["schema_version"] == "normal-tracking-plan-v1", "PLAN_SCHEMA")
    require(plan["real_API_requests_authorized"] is False
            and plan["key_access_authorized"] is False
            and plan["cloud_start_authorized"] is False, "OFFLINE_PLAN_ONLY")
    tasks, trials = plan["tasks"], plan["trials"]
    require(len(tasks) == 4 and len(trials) == 52, "FIXED_52_PLAN_REQUIRED")
    frozen = {r["item_id"]: r for r in normal_items(v0_root)}
    require({t["registry_item"]["item_id"] for t in tasks} == set(TASK_ITEM_IDS), "PLAN_FOUR_CONTROLS")
    for task in tasks:
        item = task["registry_item"]
        require(item == frozen[item["item_id"]], "ORIGINAL_REGISTERED_ITEM_CHANGED")
        require(task["task_id"] == item["task_id"] and task["domain"] == item["domain"], "PLAN_TASK_IDENTITY")
        expected_counts = (5, 9, 2, 2) if item["domain"] == "macro" else (5, 1, 0, 0)
        require((task["expected_fake_http_calls"], task["expected_cpu_jobs"], task["expected_fits"],
                 task["expected_predicts"]) == expected_counts, "PLAN_EXPECTED_COUNTS")
    require([t["ordinal"] for t in trials] == list(range(1, 53)), "PLAN_ORDINALS")
    require(len({t["trial_id"] for t in trials}) == 52, "PLAN_UNIQUE_TRIALS")
    keys = {t["task_key"] for t in tasks}
    pairs = {}
    for index, trial in enumerate(trials):
        require(trial["task_key"] in keys and trial["arm"] in ("full", "reference"), "PLAN_TRIAL_TASK_ARM")
        require(trial["phase"] == ("warmup" if index < 8 else "measured" if index < 48 else "profile"),
                "PLAN_FIXED_PHASE_ORDER")
        require(trial["profiled"] == (index >= 48), "PLAN_PRIMARY_UNPROFILED")
        if index >= 48:
            require(trial["pair_id"] is None and trial["arm"] == "full", "PLAN_DIAGNOSTIC_FULL_ONLY")
        else:
            require(isinstance(trial["pair_id"], str), "PLAN_PAIR_REQUIRED")
            pairs.setdefault(trial["pair_id"], []).append(trial)
    require(len(pairs) == 24, "PLAN_24_PAIRS")
    require(all(len(p) == 2 and {x["arm"] for x in p} == {"full", "reference"}
                and p[0]["task_key"] == p[1]["task_key"] and p[0]["repeat"] == p[1]["repeat"]
                and p[0]["phase"] == p[1]["phase"] for p in pairs.values()), "PLAN_PAIRED_CONTRACT")
    for key in keys:
        tt = [t for t in trials if t["task_key"] == key]
        require(len(tt) == 13 and sum(t["phase"] == "profile" for t in tt) == 1,
                "PLAN_PER_TASK_13_RUNS")
        require(sorted(t["repeat"] for t in tt if t["phase"] == "measured" and t["arm"] == "full") == [1,2,3,4,5],
                "PLAN_FIVE_MEASURED_PAIRS")
    r = plan["resources"]
    require(r == dict(cpu_affinity=[12,77], nice=19, threads=1, gpu=False,
                     global_wall_seconds_max=1800, per_arm_wall_seconds_max=240,
                     worker_seconds_max=120, working_disk_bytes_max=4*1024**3,
                     minimum_free_disk_bytes=10*1024**3), "PLAN_FIXED_RESOURCES")
    return deepcopy(plan)


def source_pins():
    paths = sorted((REPO / "src").rglob("*.py")) + [REPO / "scripts/run_sr_normal_tracking.py"]
    return {str(p.relative_to(REPO)): sha_file(p) for p in paths}


def input_pins(v0_root):
    v0 = Path(v0_root).resolve()
    freeze = json.loads((v0 / "FREEZE.json").read_text())
    pins = {"FREEZE.json": sha_file(v0 / "FREEZE.json")}
    for row in freeze["files"]:
        if not row["path"].startswith("sr_v2/v0/"):
            continue
        relative = row["path"][len("sr_v2/v0/"):]
        actual = sha_file(v0 / relative)
        require(actual == row["sha256"], "FROZEN_V0_INPUT_HASH_MISMATCH:" + relative)
        pins[relative] = actual
    require(len(pins) > 20, "FROZEN_V0_INPUT_SET_REQUIRED")
    return pins


def configure_environment(resources):
    require(sys.platform == "linux" and Path("/proc/self/stat").is_file(), "LINUX_PROC_WORKER_REQUIRED")
    wanted = set(resources["cpu_affinity"])
    require(wanted <= set(os.sched_getaffinity(0)), "PLAN_CPU_AFFINITY_UNAVAILABLE")
    os.sched_setaffinity(0, wanted)
    current = os.getpriority(os.PRIO_PROCESS, 0)
    require(current <= resources["nice"], "UNEXPECTED_EXISTING_NICE")
    if current < resources["nice"]:
        os.nice(resources["nice"] - current)
    for name in THREAD_VARIABLES:
        os.environ[name] = "1"
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    # Intentionally no environment enumeration or credential lookup.
    return dict(platform=platform.platform(), machine=platform.machine(), python=sys.version,
                executable=sys.executable, sqlite=sqlite3.sqlite_version,
                affinity=sorted(os.sched_getaffinity(0)), nice=os.getpriority(os.PRIO_PROCESS, 0),
                thread_environment={k: os.environ[k] for k in THREAD_VARIABLES}, gpu=False,
                service_model="already imported interpreter; CLI import/startup timing is separate")


class NetworkFence:
    """Process audit hook: only Internet sockets are forbidden; local pipes remain usable."""
    def __init__(self):
        self.active, self.attempts = False, []
    def hook(self, event, args):
        if not self.active:
            return
        internet = event == "socket.__new__" and len(args) > 1 and args[1] in (socket.AF_INET, socket.AF_INET6)
        internet |= event == "socket.connect" and args and getattr(args[0], "family", None) in (socket.AF_INET, socket.AF_INET6)
        if internet or event in ("socket.getaddrinfo", "socket.gethostbyname", "socket.gethostbyaddr"):
            self.attempts.append(dict(event=event, at_perf_ns=time.perf_counter_ns()))
            raise RuntimeError("TRACKING_UNEXPECTED_NETWORK")
    def __enter__(self):
        sys.addaudithook(self.hook)
        self.active = True
        return self
    def __exit__(self, *args):
        self.active = False


class Resources:
    def __init__(self, root, config, global_deadline_ns, *, function=run_job):
        self.root, self.config = Path(root), config
        self.global_deadline_ns, self.function = global_deadline_ns, function
        self.completed_bytes, self.current_root = 0, None
        self.arm_deadline_ns = global_deadline_ns
        self.jobs, self.observations = [], []

    def begin_arm(self, arm_root):
        self.current_root = Path(arm_root)
        self.arm_deadline_ns = min(self.global_deadline_ns,
            time.perf_counter_ns() + int(self.config["per_arm_wall_seconds_max"]*1e9))
        self.check()

    def check(self):
        require(time.perf_counter_ns() < min(self.global_deadline_ns, self.arm_deadline_ns), "TRACKING_RESOURCE_DEADLINE")
        live = disk_usage(self.current_root)["physical_bytes"] if self.current_root and self.current_root.exists() else 0
        total = self.completed_bytes + live
        free = shutil.disk_usage(self.root).free
        self.observations.append(dict(at_perf_ns=time.perf_counter_ns(),
            conservative_output_physical_bytes=total, filesystem_free_bytes=free))
        require(total <= self.config["working_disk_bytes_max"], "TRACKING_CUMULATIVE_DISK_STOP")
        require(free >= self.config["minimum_free_disk_bytes"], "TRACKING_FILESYSTEM_FREE_STOP")

    def job(self, spec, campaign_root, **kwargs):
        self.check()
        require(Path(campaign_root).resolve() == self.current_root.resolve(), "TRACKING_WORKER_OWN_ARM_ROOT")
        remaining = (min(self.global_deadline_ns, self.arm_deadline_ns)-time.perf_counter_ns()) / 1e9
        kwargs["timeout_seconds"] = min(float(kwargs.get("timeout_seconds", 120)),
                                          self.config["worker_seconds_max"], remaining)
        require(kwargs["timeout_seconds"] > 0, "TRACKING_WORKER_DEADLINE")
        result = self.function(spec, campaign_root, **kwargs)
        execution = deepcopy(result["execution"])
        self.jobs.append(dict(tool=spec["tool"], run_root=str(self.current_root), execution=execution,
                              role="common_oracle" if spec["tool"] == "independent_check" else "workflow"))
        require(execution["status"] == "success" and execution["worker_reaped"] is True
                and execution["returncode"] == 0 and not execution.get("remaining_processes")
                and execution.get("timed_out") is False, "TRACKING_WORKER_NOT_CLEAN_SUCCESS")
        self.check()
        return result

    def end_arm(self):
        self.check()
        self.completed_bytes += disk_usage(self.current_root)["physical_bytes"]
        self.current_root = None


def validate_record(record, task, trial):
    require(record["status"] == "completed_correct", "NORMAL_TRIAL_FAILED")
    require(record["actual_api_requests"] == 0 and record["actual_api_cost_nano_usd"] == 0, "NO_REAL_API_REQUIRED")
    stamps = record["monotonic_ns"]
    require(all(type(stamps.get(k)) is int for k in ("start", "ready", "post_commit", "end"))
            and stamps["start"] <= stamps["ready"] <= stamps["post_commit"] <= stamps["end"], "REAL_MONOTONIC_STAGE_MARKERS")
    require(record["primary_wall_ns"] == stamps["end"]-stamps["start"]
            and 0 < record["primary_wall_ns"] <= 240_000_000_000, "PRIMARY_TIMER_CONTRACT")
    require(len(record["fake_calls"]) == task["expected_fake_http_calls"], "FIVE_FAKE_HTTP_REQUIRED")
    require(all(c["request_sent"] is False and c["simulated"] is True
                and c["cleanup_receipt"]["reaped"] is True
                and c["cleanup_receipt"].get("cleanup_failed") is False for c in record["fake_calls"]), "FAKE_HTTP_CLEANUP_REQUIRED")
    executions = record["executions"]
    require(len(executions) == task["expected_cpu_jobs"], "WORKFLOW_CPU_COUNT")
    require(sum(e["tool"].startswith("fit_") for e in executions) == task["expected_fits"]
            and sum(e["tool"].startswith("predict_") for e in executions) == task["expected_predicts"], "FITS_PREDICTS_COUNT")
    if trial["arm"] == "full":
        require(record["record_audit"]["passed"] and record["record_audit"]["business_correct"], "FULL_NATIVE_RECORD_AUDIT")
        require(bool(record.get("profile")) == trial["profiled"], "PRIMARY_NO_PROFILER")


def summarize(records, pairs):
    result = {}
    for key in sorted({r["task_key"] for r in records}):
        measured = [p for p in pairs if p["task_key"] == key and p["phase"] == "measured"]
        def stats(values):
            return dict(median=statistics.median(values), min=min(values), max=max(values)) if values else None
        result[key] = dict(measured_pairs=len(measured),
            full_pipeline_wall_ns=stats([p["full_wall_ns"] for p in measured]),
            reference_pipeline_wall_ns=stats([p["reference_wall_ns"] for p in measured]),
            paired_full_minus_reference_wall_ns=stats([p["full_minus_reference_wall_ns"] for p in measured]),
            paired_ratio=stats([p["ratio"] for p in measured]),
            all_pairs_match=all(p["passed"] for p in measured))
    return result


def run_batch(plan_path, v0_root, output, *, startup=None):
    began = time.perf_counter_ns()
    plan_path, v0, output = Path(plan_path).resolve(), Path(v0_root).resolve(), Path(output).resolve()
    require(not output.exists(), "NEW_BATCH_ROOT_REQUIRED_NO_RESUME")
    plan = validate_plan(json.loads(plan_path.read_text()), v0)
    environment = configure_environment(plan["resources"])
    source_before, inputs_before = source_pins(), input_pins(v0)
    protocol = REPO / "outputs/sr_normal_tracking_20261021/PROTOCOL.md"
    plan_hash, protocol_hash = sha_file(plan_path), sha_file(protocol)
    output.mkdir(parents=True, exist_ok=False)
    (output / "arms").mkdir()
    write_json(output / "plan_snapshot.json", plan)
    (output / "protocol_snapshot.md").write_bytes(protocol.read_bytes())
    manifest = dict(schema_version="normal-tracking-manifest-v1", created_at_utc=datetime.now(timezone.utc).isoformat(),
        plan_path=str(plan_path), plan_sha256=plan_hash, protocol_sha256=protocol_hash, v0_root=str(v0),
        environment=environment, startup=startup, source_before=source_before, inputs_before=inputs_before,
        timer_scope="loaded service; per-arm validation/staging, native audit, logs and close included; common oracle separate",
        benchmark_projection_scope="benchmark-only extraction/receipt serialization after end; five fake trace harvests inside each arm",
        estimand=plan["estimand"], old_formal_registration_changed=False, live_transport_available=False)
    write_json(output / "manifest.json", manifest)
    resource = Resources(output, plan["resources"], began + 1_800_000_000_000)
    tasks = {t["task_key"]: t for t in plan["tasks"]}
    records, paired, pending, baselines = [], [], {}, {}
    failure = None
    fence = NetworkFence()
    try:
        with fence:
            for trial in plan["trials"]:
                task = tasks[trial["task_key"]]
                arm_root = output / "arms" / trial["trial_id"]
                resource.begin_arm(arm_root)
                spec = dict(item=deepcopy(task["registry_item"]), item_id=task["registry_item"]["item_id"],
                    task_id=task["task_id"], domain=task["domain"], v0_root=str(v0), run_root=str(arm_root),
                    run_id=trial["pair_id"] or trial["trial_id"], arm=trial["arm"], phase=trial["phase"],
                    repeat_index=trial["repeat"], pair_id=trial["pair_id"], trial_id=trial["trial_id"],
                    global_deadline_ns=min(resource.global_deadline_ns, resource.arm_deadline_ns))
                function = run_full if trial["arm"] == "full" else run_reference
                kwargs = dict(job_runner=resource.job)
                if trial["arm"] == "full":
                    kwargs["profile"] = trial["profiled"]
                record = function(spec, **kwargs)
                record.update(task_key=trial["task_key"], trial_id=trial["trial_id"], ordinal=trial["ordinal"])
                records.append(record)
                write_json(arm_root / "run_record.json", record)
                validate_record(record, task, trial)
                oracle = check_run(record, v0, job_runner=resource.job,
                    global_deadline_ns=min(resource.global_deadline_ns, resource.arm_deadline_ns))
                record["common_oracle"] = oracle
                write_json(arm_root / "common_oracle.json", oracle)
                require(oracle["passed"] and oracle["model_fits"] == 0, "COMMON_INDEPENDENT_ORACLE_FAILED")
                if trial["phase"] == "profile":
                    comparison = compare_runs(baselines[trial["task_key"]], oracle)
                    require(comparison["passed"], "PROFILE_INSTRUMENTATION_SEMANTIC_MISMATCH")
                    record["instrumentation_semantic_comparison"] = comparison
                else:
                    group = pending.setdefault(trial["pair_id"], {})
                    group[trial["arm"]] = record
                    if len(group) == 2:
                        comparison = compare_runs(group["full"]["common_oracle"], group["reference"]["common_oracle"])
                        full_ns, ref_ns = group["full"]["primary_wall_ns"], group["reference"]["primary_wall_ns"]
                        row = dict(pair_id=trial["pair_id"], task_key=trial["task_key"], phase=trial["phase"],
                            passed=comparison["passed"], comparison=comparison, full_wall_ns=full_ns,
                            reference_wall_ns=ref_ns, full_minus_reference_wall_ns=full_ns-ref_ns, ratio=full_ns/ref_ns)
                        paired.append(row)
                        write_json(output / "pairs" / (trial["pair_id"] + ".json"), row)
                        require(comparison["passed"], "PAIRED_BUSINESS_OR_MODEL_MISMATCH")
                        if trial["phase"] == "warmup":
                            baselines[trial["task_key"]] = oracle
                require(not fence.attempts, "UNEXPECTED_NETWORK_ATTEMPT")
                require(source_pins() == source_before and input_pins(v0) == inputs_before
                        and sha_file(plan_path) == plan_hash and sha_file(protocol) == protocol_hash,
                        "SOURCE_INPUT_OR_PROTOCOL_PIN_CHANGED")
                write_json(arm_root / "run_record.json", record)
                resource.end_arm()
                write_json(output / "progress.json", dict(completed=len(records), planned=52,
                    successful_pairs=len(paired), last_trial=trial["trial_id"], status="running"))
                print(json.dumps(dict(trial=trial["trial_id"], status="passed", completed=len(records),
                                      primary_wall_seconds=record["primary_wall_ns"]/1e9)), flush=True)
    except BaseException as exc:
        failure = dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc(),
                       at_perf_ns=time.perf_counter_ns(), completed_records=len(records))
        write_json(output / "FAILURE.json", failure)
    workflow = [j for j in resource.jobs if j["role"] == "workflow"]
    oracle_jobs = [j for j in resource.jobs if j["role"] == "common_oracle"]
    counts = dict(normal_runs=len(records), fake_http_calls=sum(len(r["fake_calls"]) for r in records),
        workflow_cpu_jobs=len(workflow), common_oracle_cpu_jobs=len(oracle_jobs),
        total_supervised_cpu_jobs=len(resource.jobs), fits=sum(j["tool"].startswith("fit_") for j in workflow),
        predicts=sum(j["tool"].startswith("predict_") for j in workflow), actual_api_requests=0)
    source_after, inputs_after, pin_error = {}, {}, None
    try:
        source_after, inputs_after = source_pins(), input_pins(v0)
        require(source_before == source_after and inputs_before == inputs_after,
                "FINAL_SOURCE_OR_INPUT_PIN_CHANGED")
    except BaseException as exc:
        pin_error = dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc())
        if failure is None:
            failure = pin_error
            write_json(output / "FAILURE.json", failure)
    complete = failure is None and len(records) == 52 and len(paired) == 24
    expected = dict(normal_runs=52, fake_http_calls=260, workflow_cpu_jobs=260,
        common_oracle_cpu_jobs=26, total_supervised_cpu_jobs=286, fits=52, predicts=52, actual_api_requests=0)
    if complete and counts != expected:
        failure = dict(type="CountMismatch", counts=counts, expected=expected)
        write_json(output / "FAILURE.json", failure)
        complete = False
    result = dict(schema_version="normal-tracking-result-v1", status="completed" if complete else "hard_stopped",
        counts=counts, expected_counts=expected, trials_planned=52, successful_pairs=len(paired),
        failure=failure, elapsed_wall_ns=time.perf_counter_ns()-began,
        estimates=summarize(records, paired), network_attempts=fence.attempts,
        sources_unchanged=source_before == source_after, inputs_unchanged=inputs_before == inputs_after,
        estimand=plan["estimand"], caveats=["Five measured pairs per task; descriptive median/min/max only.",
          "Primary runs exclude interpreter/import startup and the common independent oracle.",
          "Reference is trusted normal-only and does not provide equivalent safety or recovery.",
          "Profiled diagnostics are separate and include instrumentation overhead.",
          "Per-run native audits are included; whole-campaign 52-slot audit is outside this normal-only scope."])
    write_json(output / "resource_observations.json", resource.observations)
    write_json(output / "supervised_jobs.json", resource.jobs)
    write_json(output / "integrity.json", dict(source_before=source_before, source_after=source_after,
        inputs_before=inputs_before, inputs_after=inputs_after, pin_error=pin_error))
    write_json(output / "summary.json", result)
    write_json(output / "progress.json", dict(status=result["status"], completed=len(records), planned=52,
        successful_pairs=len(paired)))
    return result
