"""Common normal-business oracle for both tracing benchmark arms.

The oracle runs after the primary timer. It does not call a production Store,
guard, recovery policy or fitter. Numerical checking uses the existing independent
CPU checker on this run's newly produced, hash-verified trusted artifacts.
"""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from sr_campaign_v3.executor import run_job

V0_FREEZE_SHA256 = '643acd951eb135d484e4b32ff63de4e670d66a7f50a7da5f304505a6f471f6b2'


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def normalize_record(record):
    """Adapt a full export and the normal-only reference to one oracle interface."""
    value = dict(record)
    view = value.get('view') or value.get('raw_export')
    if view:
        results = {x['result_id']: x for x in view['results']}
        selected = view['state']['selected_by_node']
        if not value.get('selected_result_ids'): value['selected_result_ids'] = dict(selected)
        if not value.get('selected_payloads'):
            value['selected_payloads'] = {node: copy.deepcopy(results[rid]['payload']) for node, rid in selected.items() if rid}
        if not value.get('artifacts'): value['artifacts'] = view['artifacts']
        if not value.get('sources'): value['sources'] = view['sources']
        if not value.get('request'): value['request'] = view['task']['request']
        if not value.get('task_id'): value['task_id'] = view['task']['task_id']
        if not value.get('domain'): value['domain'] = view.get('domain', 'micro' if 'execute' in selected else 'macro')
        if not value.get('executions'): value['executions'] = [x['job_execution'] for x in view['attempts'] if x.get('job_execution')]
    if not value.get('business_db_path'): value['business_db_path'] = value.get('db_path')
    if not value.get('artifact_root'): value['artifact_root'] = value.get('files_root')
    return value


def _locked_document(v0, relative):
    raw = (v0/'FREEZE.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != V0_FREEZE_SHA256:
        raise ValueError('ORACLE_V0_FREEZE_PIN')
    frozen = {x['path']: x for x in json.loads(raw)['files']}
    raw = (v0/relative).read_bytes()
    if hashlib.sha256(raw).hexdigest() != frozen['sr_v2/v0/'+relative]['sha256']:
        raise ValueError('ORACLE_FROZEN_INPUT_PIN:'+relative)
    return json.loads(raw)


def _read_business_database(path):
    """Read actual committed objects, not an arm's self-reported success flag."""
    uri = Path(path).resolve().as_uri() + '?mode=ro'
    db = sqlite3.connect(uri, uri=True)
    try:
        tables = {x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'document' in tables:
            doc = json.loads(db.execute('SELECT payload FROM document WHERE id=1').fetchone()[0])
            return doc['objects'], doc.get('effects', []), doc
        if not {'business_objects', 'business_commits'} <= tables:
            raise ValueError('ORACLE_BUSINESS_TABLES_MISSING')
        objects = {key: {'payload': json.loads(payload), 'version': version,
                         'owner_result_id': owner}
                   for key, payload, version, owner in db.execute(
                       'SELECT object_key,payload,version,owner_result_id FROM business_objects')}
        commits = [{'operation_id': op, 'atomic_group': json.loads(keys), 'status': 'committed',
                    'producer_result_id': owner}
                   for op, keys, owner in db.execute('SELECT operation_id,atomic_keys,owner_result_id FROM business_commits')]
        return objects, commits, None
    finally:
        db.close()


def _artifact_normalizer(record):
    result_roles = {rid: '@result:'+node for node, rid in record['selected_result_ids'].items()}
    artifact_roles = {}
    for a in record['artifacts']:
        producer = a['producer_result_id']
        if producer in result_roles:
            suffix = a['artifact_id'][len(producer):] if a['artifact_id'].startswith(producer) else a['artifact_id'].rsplit('.', 1)[-1]
            artifact_roles[a['artifact_id']] = '@artifact:'+result_roles[producer][8:]+':'+suffix.lstrip('.')
    def norm(value):
        if isinstance(value, dict):
            return {key: norm(item) for key, item in sorted(value.items())}
        if isinstance(value, list):
            return [norm(item) for item in value]
        if isinstance(value, str):
            return artifact_roles.get(value, result_roles.get(value, value))
        return value
    return norm


def check_run(record, v0_root, *, job_runner=None, global_deadline_ns=None):
    """Check either arm identically; return canonical business data for pairing."""
    started, cpu_started = time.perf_counter_ns(), time.process_time_ns()
    issues, checks, numerical = [], [], None
    oracle_execution = None
    normalized = None
    def require(ok, code, ref=None):
        checks.append(code)
        if not ok:
            issues.append({'code': code, 'ref': ref})
            raise ValueError(code)
    try:
        record = normalize_record(record)
        v0 = Path(v0_root).resolve(); root = Path(record['artifact_root']).resolve()
        run_root = Path(record['run_root']).resolve()
        require(root.is_relative_to(run_root), 'OWN_RUN_ARTIFACT_ROOT')
        business_db = Path(record['business_db_path']).resolve()
        require(business_db.is_relative_to(run_root) and business_db != run_root,
                'OWN_RUN_BUSINESS_DATABASE')
        require(record.get('status') == 'completed_correct', 'ARM_REPORTED_COMPLETED')
        payloads, ids = record['selected_payloads'], record['selected_result_ids']
        require(all(isinstance(x, str) and x for x in ids.values()) and len(set(ids.values())) == len(ids),
                'CURRENT_SELECTED_IDENTITIES_UNIQUE')
        objects, effects, document = _read_business_database(business_db)
        commits = [e for e in effects if e.get('status') == 'committed']
        require(len(commits) == 1, 'EXACTLY_ONE_ATOMIC_BUSINESS_COMMIT')
        registry = {a['artifact_id']: a for a in record['artifacts']}
        require(len(registry) == len(record['artifacts']), 'UNIQUE_ARTIFACTS')
        def load_artifact(aid):
            require(aid in registry, 'ARTIFACT_REGISTERED', aid)
            art = registry[aid]; path = (root/art['uri']).resolve()
            require(not Path(art['uri']).is_absolute() and path.is_relative_to(root) and path != root,
                    'ARTIFACT_OWN_ROOT', aid)
            raw = path.read_bytes()
            require(len(raw) == art['size_bytes'] and hashlib.sha256(raw).hexdigest() == art['sha256'],
                    'ARTIFACT_BYTES', aid)
            require(not (path.stat().st_mode & 0o222), 'ARTIFACT_IMMUTABLE', aid)
            require(art['producer_result_id'] in ids.values() or aid.startswith('input.'),
                    'ARTIFACT_CURRENT_RUN_OR_PUBLIC_INPUT', aid)
            return raw
        # Reject corrupt/outside files before any pickle/array is loaded.
        for aid in registry:
            load_artifact(aid)
        domain = record['domain']
        dag = _locked_document(v0, 'dags/'+domain+'.json')
        require(set(ids) == set(payloads) == {n['node_id'] for n in dag['nodes']}, 'EXACT_FIXED_NORMAL_NODE_SET')
        expected_jobs = [node for node in dag['topological_order']
                         if next(n for n in dag['nodes'] if n['node_id'] == node)['cpu_jobs_per_execution']]
        require([job['tool'] for job in record['executions']] == expected_jobs,
                'EXACT_NORMAL_SUPERVISED_WORKFLOW_JOBS')
        require(all(job.get('status') == 'success' and job.get('worker_reaped') and
                    job.get('returncode') == 0 and not job.get('remaining_processes') and
                    not job.get('timed_out') for job in record['executions']),
                'ALL_WORKFLOW_JOBS_SUCCESSFULLY_REAPED')
        calls = record.get('fake_calls', [])
        require(len(calls) == dag['complete_traversal']['llm_calls'] == 5,
                'EXACTLY_FIVE_FAKE_HTTP_CALLS')
        require(all(call.get('request_sent') is False and call.get('simulated') is True and
                    (call.get('cleanup_receipt') or {}).get('reaped') is True and
                    not (call.get('cleanup_receipt') or {}).get('cleanup_failed') for call in calls),
                'ALL_HTTP_CALLS_SIMULATED_AND_REAPED')
        final = 'execute' if domain == 'micro' else 'publish'
        require(commits[0].get('producer_result_id') == ids[final],
                'ATOMIC_COMMIT_CURRENT_FINAL_OWNER')
        if document:
            require(document['state']['terminal_status'] == 'completed_correct', 'FULL_ACTUAL_DB_COMPLETED')
            require(document['state']['selected_by_node'] == ids, 'FULL_ACTUAL_DB_SELECTED_BINDING')
        if domain == 'micro':
            tasks = _locked_document(v0, 'tasks/micro_tasks.json')['tasks']
            task = next(t for t in tasks if t['task_id'] == record['task_id'])
            expected_request = task['public_request']
            source_doc = _locked_document(v0, 'tasks/authority/'+record['task_id']+'.sources.json')
            authority = {s['object_key']: s for s in source_doc['sources'] if s['version'] == 1}
            aliases = task['resolved_source_aliases']
            meta, permission, resource = [authority[aliases[k]]['payload'] for k in ('metadata','permission','resources')]
            require(record['request'] == expected_request, 'MICRO_PUBLIC_REQUEST')
            require(payloads['read_metadata'] == meta and payloads['read_permission'] == permission and
                    payloads['read_resources'] == resource, 'MICRO_READERS_MATCH_AUTHORITY')
            n, batch, epochs = meta['num_examples'], expected_request['batch_size'], expected_request['epochs']
            expected = {**expected_request, 'num_examples': n, 'steps': ((n+batch-1)//batch)*epochs,
                        'workers': min(expected_request['requested_workers'], resource['max_workers']),
                        'allowed': permission['allowed'], 'policy_revision': permission['policy_revision']}
            require(permission['allowed'] is True, 'MICRO_PERMISSION_ALLOWED')
            require(payloads['plan'] == expected, 'MICRO_COMPLETE_PLAN_ARITHMETIC')
            require(payloads['execute'] == {'action':'commit_config_and_draft','config':expected,'command':expected},
                    'MICRO_EXECUTOR_IDENTICAL_COMMAND')
            require(set(objects) == {'config','draft'} and commits[0]['atomic_group'] == ['config','draft'],
                    'MICRO_EXACT_ATOMIC_OBJECT_GROUP')
            for key in ('config','draft'):
                require(objects[key]['payload'] == expected and objects[key]['version'] == 1 and
                        objects[key]['owner_result_id'] == ids['execute'], 'MICRO_ACTUAL_OBJECT', key)
                aid = ids['execute']+'.'+key
                require(json.loads(load_artifact(aid)) == {'command':expected}, 'MICRO_STAGED_OBJECT_BYTES', key)
            normalized = {'domain':'micro', 'task_id':record['task_id'], 'request':expected_request,
                          'command':expected,'business_objects':{'config':expected,'draft':expected}}
        elif domain == 'macro':
            require(set(objects) == {'manifest','report_index'} and
                    commits[0]['atomic_group'] == ['manifest','report_index'], 'MACRO_EXACT_ATOMIC_OBJECT_GROUP')
            task=next(t for t in _locked_document(v0,'tasks/macro_tasks.json')['tasks'] if t['task_id']==record['task_id'])
            require(record['request']=={**task['public_request'],'tie_break':{'epsilon':1e-6,'winner':'LR'}}, 'MACRO_PUBLIC_REQUEST')
            source_doc = _locked_document(v0, 'tasks/authority/'+record['task_id']+'.sources.json')
            sources = {s['object_key']:s for s in source_doc['sources'] if s['version']==1}
            require({s['object_key']:s for s in record['sources']} == sources, 'MACRO_FROZEN_NORMAL_SOURCES')
            expected_parameters={f:sources['recipe:'+f]['payload']['parameters'] for f in ['lr','rf']}
            fit_jobs=[j for j in record['executions'] if j['tool'].startswith('fit_')]
            require(len(fit_jobs)==2 and {j['tool'] for j in fit_jobs}=={'fit_lr','fit_rf'},'MACRO_TWO_FRESH_FITS')
            predict_jobs=[j for j in record['executions'] if j['tool'].startswith('predict_')]
            require(len(predict_jobs)==2 and {j['tool'] for j in predict_jobs}=={'predict_lr','predict_rf'},
                    'MACRO_TWO_FRESH_PREDICTIONS')
            for node in ['prepare','fit_lr','fit_rf','predict_lr','predict_rf']:
                require(all(a['producer_result_id'] == ids[node] for a in record['artifacts']
                            if a['artifact_id'].startswith(ids[node]+'.')), 'OWN_CURRENT_MODEL_PRODUCER', node)
            for family in ['lr','rf']:
                require(payloads['plan_'+family]['parameters'] == expected_parameters[family] and
                        payloads['fit_'+family]['parameters'] == expected_parameters[family],
                        'MACRO_EXACT_CURRENT_RECIPE_PARAMETERS', family)
            remaining=min(120., ((global_deadline_ns-time.perf_counter_ns())/1e9) if global_deadline_ns is not None else 120.)
            require(remaining > 0, 'ORACLE_GLOBAL_DEADLINE')
            job_id='oracle.'+digest({'root':str(run_root),'run_id':record.get('run_id')})[:32]
            spec={'tool':'independent_check','job_id':job_id,'result_id':job_id,
                  'output_dir':str(root/'oracle_jobs'/job_id),'deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=remaining)).isoformat().replace('+00:00','Z'),
                  'output_reservation_bytes':4*1024**2,
                  'v0_root':str(v0),'artifact_root':str(root),'artifacts':record['artifacts'],
                  'inputs':{'dataset_id':record['request']['dataset_id'],'train_version':1,
                            'selected_payloads':payloads,'selected_result_ids':ids,
                            'expected_parameters':expected_parameters,'evaluate_test':False,
                            'allow_delivered_summary_fault':False}}
            checked=(job_runner or run_job)(spec,run_root)
            oracle_execution=checked['execution']
            require(oracle_execution['status']=='success' and oracle_execution['worker_reaped'] and
                    not oracle_execution.get('remaining_processes') and oracle_execution.get('returncode')==0,
                    'ORACLE_SUPERVISED_CHECK_SUCCESSFULLY_REAPED')
            numerical=(checked.get('response') or {}).get('payload',{})
            require(numerical.get('passed') and numerical['statistics']['model_fits']==0 and
                    numerical['statistics']['models_loaded']==2,
                    'MACRO_INDEPENDENT_RAW_ROWS_MODEL_PREDICT_METRICS', numerical.get('issues'))
            report,publish=payloads['report'],payloads['publish']
            chosen=report['selected_family']
            require(report['chosen_family']==chosen and report['metrics']==payloads['summary_'+chosen.lower()]['metrics'],
                    'MACRO_REPORT_EXACT_CHOSEN_SUMMARY')
            require(report['validation_average_precision']=={f:payloads['summary_'+f.lower()]['metrics']['average_precision'] for f in ['LR','RF']},
                    'MACRO_REPORT_EXACT_BOTH_AP_VALUES')
            original_report=json.loads(load_artifact(report['report_artifact_id']))
            require(original_report=={k:v for k,v in report.items() if k!='report_artifact_id'},
                    'MACRO_WHOLE_ORIGINAL_REPORT_MATCH')
            require(len(report['report_text'].split())<=120 and len(report['report_text'])<=1024,
                    'MACRO_REPORT_BOUNDS')
            manifest=json.loads(load_artifact(publish['candidate_artifact_id']))
            require(objects['manifest']['payload']==publish and publish['publish_manifest']==manifest,
                    'MACRO_ACTUAL_MANIFEST_OBJECT')
            require(objects['report_index']['payload']=={'report_result_id':ids['report'],
                    'candidate_artifact_id':publish['candidate_artifact_id']}, 'MACRO_ACTUAL_REPORT_INDEX')
            for key in objects:
                require(objects[key]['version']==1 and objects[key]['owner_result_id']==ids['publish'],
                        'MACRO_COMMITTED_VERSION_OWNER', key)
            norm=_artifact_normalizer(record)
            normalized={'domain':'macro','task_id':record['task_id'],'request':record['request'],
                        'training_version':1,'parameters':expected_parameters,
                        'row_counts':payloads['prepare']['row_counts'],
                        'training_row_ids_digest':payloads['prepare']['training_row_ids_digest'],
                        'validation_row_ids_digest':payloads['prepare']['validation_row_ids_digest'],
                        'both_validation_metrics':numerical['statistics']['validation_metrics'],
                        'report':norm(report), 'publish':norm(publish),
                        'business_objects':{key:norm(objects[key]['payload']) for key in sorted(objects)}}
        else:
            require(False,'UNKNOWN_DOMAIN')
    except Exception as exc:
        if not issues:
            issues.append({'code':'ORACLE_EXCEPTION','ref':f'{type(exc).__name__}: {exc}'})
    return {'passed':not issues,'issues':issues,'checks':len(checks),
            'canonical_business':normalized,'canonical_digest':digest(normalized) if normalized is not None else None,
            'numerical_check':numerical,'oracle_execution':oracle_execution,'model_fits':0,'real_API_requests':0,
            'oracle_wall_ns':time.perf_counter_ns()-started,'oracle_process_cpu_ns':time.process_time_ns()-cpu_started}


def compare_runs(first, second):
    """Compare only two independently passing common-oracle records."""
    return {'passed':bool(first.get('passed') and second.get('passed') and
                          first.get('canonical_business') == second.get('canonical_business')),
            'first_digest':first.get('canonical_digest'),'second_digest':second.get('canonical_digest'),
            'comparison_scope':'Full normal business content/parameters/rows/report/publication after generated-ID normalization; not equal recovery or safety features.'}
