"""Unchanged V3 normal path with new arm roots and optional diagnostic wrappers."""
from contextlib import nullcontext
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
import time
import traceback

from sr_campaign_v3 import runtime
from sr_campaign_v3 import base_store, guard, gateway as gateway_module
from sr_campaign_v3 import executor, checker as campaign_checker
from sr_campaign_v3.budget import DurableV3Budget
from sr_campaign_v3.gateway import OfflineV3Gateway, offline_binding
from sr_campaign_v3.store import V3Store
from sr_cpu_v2.checker import audit_export
from sr_recovery_v2 import common, policy
from sr_recovery_v2.common import digest
from .contracts import (validate_spec, record_base, make_fake_client, fake_calls_from,
                        selected_from_view, write_json, require)
from .profile import SpanRecorder, ScopedBindings, ConnectionProxy


def _profile_globals(scope, recorder):
    connect = sqlite3.connect
    def profiled_connect(*args, **kwargs):
        with recorder.span("sql", "sqlite3.connect"):
            return ConnectionProxy(connect(*args, **kwargs), recorder)
    scope.set(sqlite3, "connect", profiled_connect)
    for owner in (runtime, base_store):
        scope.wrap(owner, "diagnose", recorder, "guard")
    for owner, names in ((common, ("canonical", "digest", "source_fingerprint", "closure_ids", "merge_reads")),
                         (runtime, ("projection", "merge_reads", "digest")),
                         (base_store, ("canonical", "digest", "source_fingerprint", "selected_graph_digest", "closure_ids")),
                         (guard, ("digest", "source_fingerprint", "selected_graph_digest")),
                         (policy, ("digest", "closure_ids", "selected_graph_digest"))):
        for name in names:
            scope.wrap(owner, name, recorder, "metadata_hash")
    import jsonschema
    scope.wrap(jsonschema.Draft202012Validator, "validate", recorder, "schema")
    for name in ("disk_usage", "_members"):
        scope.wrap(executor, name, recorder, "cpu_monitor_disk")
    # This is the same process-global time module. ScopedBindings restores it;
    # it is enabled only in the four serial diagnostic runs, never primary.
    scope.wrap(executor.time, "sleep", recorder, "parent_sleep")
    for name in ("_initial_bindings", "_json_artifact", "write"):
        scope.wrap(runtime, name, recorder, "artifact_io")


def audit_normal_records(view, item, artifact_root, v0_root):
    if item["domain"] == "macro":
        return audit_export(view, artifact_root, v0_root)
    # The CPU audit hard-codes macro publish ancestry. The original V3 micro
    # auditor checks raw records, compact inputs, ancestry, actual CPU receipts,
    # sources and both final business objects; _raw_result calls _micro_business.
    audit = campaign_checker._Audit()
    dag = json.loads((Path(v0_root) / "dags/micro.json").read_text())
    campaign_checker._raw_result(view, item, "completed_correct", audit, expected_dag=dag)
    return dict(passed=not audit.issues, business_correct=not audit.issues,
                checks=audit.checks, issues=audit.issues,
                scope="V3 single-run micro raw-record/business audit; not whole-campaign audit")


def run_full(task_spec, *, profile=None, job_runner=None, fake_client_factory=None):
    start, cpu_start = time.perf_counter_ns(), time.process_time_ns()
    spec = validate_spec(task_spec)
    require(spec["arm"] in ("full", "full_profiled"), "FULL_ARM_REQUIRED")
    require(not profile or spec["phase"] in ("profile", "diagnostic"), "DIAGNOSTIC_PROFILER_ONLY")
    record = record_base(spec)
    record["monotonic_ns"]["start"] = start
    root, v0 = Path(spec["run_root"]).resolve(), Path(spec["v0_root"]).resolve()
    budget, store, client, view = None, None, None, None
    original_job = runtime.run_job
    recorder = SpanRecorder() if profile is True else profile
    marker = {"candidate_terminal": False, "post_commit": None}
    deadline_ns = min(spec["global_deadline_ns"], start + 240_000_000_000)
    def remaining():
        seconds = (deadline_ns - time.perf_counter_ns()) / 1e9
        require(seconds > 0, "TRACKING_ARM_DEADLINE")
        return min(120., seconds)
    try:
        root.mkdir(parents=True, exist_ok=False)
        for folder in ("db", "files", "http", "audits"):
            (root / folder).mkdir()
        record["artifact_root"] = str(root / "files")
        with ScopedBindings() as scope:
            if recorder:
                _profile_globals(scope, recorder)
            original_store = V3Store
            def constructor(*args, **kwargs):
                nonlocal store
                store = original_store(*args, **kwargs)
                save, apply = store._save, store._apply
                def mark_save(doc):
                    result = save(doc)
                    if doc["state"].get("terminal_status") == "completed_correct":
                        marker["candidate_terminal"] = True
                    return result
                def mark_apply(*values, **options):
                    result = apply(*values, **options)
                    if marker["candidate_terminal"] and marker["post_commit"] is None:
                        marker["post_commit"] = time.perf_counter_ns()
                    return result
                scope.set(store, "_save", mark_save)
                scope.set(store, "_apply", mark_apply)
                if recorder:
                    for name in ("_load", "_save", "_apply"):
                        scope.wrap(store, name, recorder, "orchestration")
                    scope.wrap(store, "_stage_artifacts", recorder, "artifact_io")
                return store
            scope.set(runtime, "V3Store", constructor)
            def jobs(*args, **kwargs):
                function = job_runner or original_job
                kwargs["timeout_seconds"] = min(float(kwargs.get("timeout_seconds", 120)), remaining())
                with recorder.span("cpu_wait_monitor", "run_job") if recorder else nullcontext():
                    result = function(*args, **kwargs)
                record["executions"].append(deepcopy(result["execution"]))
                return result
            scope.set(runtime, "run_job", jobs)
            binding = offline_binding(v0)
            budget = DurableV3Budget(root / "budget/central.sqlite", campaign_id="tracking." + spec["run_id"],
                                     binding=binding, v0_root=v0, lock_root=root / "budget_authority")
            if recorder:
                for name in ("check_admission", "reserve", "mark_dispatched", "settle", "snapshot", "finalize_item", "close"):
                    scope.wrap(budget, name, recorder, "ledger")
            factory = fake_client_factory or make_fake_client
            client = factory(v0, spec["run_id"])
            if recorder:
                scope.wrap(client, "exchange", recorder, "http_fake")
            def sink(stage, entry):
                call_id = entry.get("call_id") or entry.get("sidecar", {}).get("call_id")
                require(isinstance(call_id, str) and "/" not in call_id, "FAKE_HTTP_EVIDENCE_ID")
                write_json(root / "http" / call_id / (stage + ".json"), entry)
            gateway = OfflineV3Gateway(v0, client=client, budget=budget,
                                      token_counter=client.bench_counter, binding=binding, evidence_sink=sink)
            invoke = gateway.invoke
            def bounded_invoke(**kwargs):
                kwargs["remaining_seconds"] = min(float(kwargs.get("remaining_seconds", 120)), remaining())
                return invoke(**kwargs)
            scope.set(gateway, "invoke", bounded_invoke)
            if recorder:
                scope.wrap(gateway, "invoke", recorder, "orchestration")
            budget.check_admission(spec["item_id"])
            store = runtime.initial_store(spec["item"], spec["run_id"], v0, root, root / "files")
            record["monotonic_ns"]["ready"] = time.perf_counter_ns()
            view = runtime.run_item(store, spec["item"], v0, root, gateway)
            record["monotonic_ns"]["post_commit"] = marker["post_commit"]
            require(view["state"]["terminal_status"] == "completed_correct", "FULL_NORMAL_NOT_CORRECT")
            require(view["state"]["counters"]["stale_used"] == 0
                    and view["state"]["counters"]["semantic_used"] == 0, "FULL_NORMAL_UNEXPECTED_CORRECTION")
            with recorder.span("record_audit", "audit_export_and_write") if recorder else nullcontext():
                audit = audit_normal_records(view, spec["item"], root / "files", v0)
                write_json(root / "audits/records.json", audit)
            record["record_audit"] = audit
            require(audit["passed"] and audit["business_correct"], "FULL_RECORD_AUDIT_FAILED")
            budget.finalize_item(spec["item_id"], "completed_correct", digest(view))
            write_json(root / "full_export.json", view)
            write_json(root / "ledger_snapshot.json", budget.snapshot())
            record.update(status="completed_correct", view=view,
                business_db_path=str(store.db_path))
            store.close()
            store = None
            budget.close()
            budget = None
            remaining()
    except BaseException as exc:
        record["status"] = "failed"
        record["error"] = dict(type=type(exc).__name__, code=getattr(exc, "code", None),
                               message=str(exc), traceback=traceback.format_exc())
    finally:
        if store is not None:
            store.close()
        if budget is not None:
            budget.close()
        if client is not None:
            record["fake_calls"] = fake_calls_from(client)
        end, cpu_end = time.perf_counter_ns(), time.process_time_ns()
        record["monotonic_ns"]["end"] = end
        record["monotonic_ns"]["post_commit"] = marker["post_commit"]
        record["pipeline_wall_ns"] = end - start
        record["parent_cpu_ns"] = cpu_end - cpu_start
        record["primary_wall_ns"] = end - start
        record["primary_process_cpu_ns"] = cpu_end - cpu_start
        record["arm_deadline_ns"] = deadline_ns
        if recorder:
            record["profile"] = recorder.report(start, end, cpu_end - cpu_start)
        # The following is benchmark-only projection, not a production stage.
        # Production export, record audit, files and finalization were timed.
        if view is not None:
            record.update(selected_payloads=selected_from_view(view),
                selected_result_ids=deepcopy(view["state"]["selected_by_node"]),
                artifacts=deepcopy(view["artifacts"]), sources=deepcopy(view["sources"]),
                request=deepcopy(view["task"]["request"]), objects=deepcopy(view["objects"]),
                effects=deepcopy(view["effects"]))
        if root.is_dir():
            write_json(root / "run_record.json", record)
    return record
