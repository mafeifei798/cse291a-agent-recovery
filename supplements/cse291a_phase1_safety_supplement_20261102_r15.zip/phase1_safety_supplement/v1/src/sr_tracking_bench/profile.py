"""Diagnostic-only scoped spans; no files or production source are modified."""
from collections import defaultdict
from contextlib import contextmanager
from functools import wraps
import time


class SpanRecorder:
    def __init__(self, wall_clock=time.perf_counter_ns, cpu_clock=time.process_time_ns):
        self.wall_clock, self.cpu_clock = wall_clock, cpu_clock
        self.stack, self.spans = [], []
        self.serial = 0

    @contextmanager
    def span(self, category, label):
        self.serial += 1
        entry = dict(span_id=self.serial, parent_id=self.stack[-1]["span_id"] if self.stack else None,
                     category=category, label=label, start_ns=self.wall_clock(), cpu_start_ns=self.cpu_clock(),
                     child_wall_ns=0, child_cpu_ns=0, error=None)
        self.stack.append(entry)
        try:
            yield
        except BaseException as exc:
            entry["error"] = type(exc).__name__
            raise
        finally:
            cpu_end, end = self.cpu_clock(), self.wall_clock()
            self.stack.pop()
            entry.update(end_ns=end, inclusive_wall_ns=end - entry["start_ns"],
                         inclusive_cpu_ns=cpu_end - entry["cpu_start_ns"])
            entry["exclusive_wall_ns"] = entry["inclusive_wall_ns"] - entry["child_wall_ns"]
            entry["exclusive_cpu_ns"] = entry["inclusive_cpu_ns"] - entry["child_cpu_ns"]
            if self.stack:
                self.stack[-1]["child_wall_ns"] += entry["inclusive_wall_ns"]
                self.stack[-1]["child_cpu_ns"] += entry["inclusive_cpu_ns"]
            self.spans.append(entry)

    def wrapper(self, function, category, label):
        @wraps(function)
        def wrapped(*args, **kwargs):
            with self.span(category, label):
                return function(*args, **kwargs)
        return wrapped

    def report(self, start_ns, end_ns, parent_cpu_ns=None):
        if self.stack:
            raise ValueError("PROFILE_UNCLOSED_SPANS")
        by_category = defaultdict(lambda: dict(exclusive_wall_ns=0, exclusive_cpu_ns=0, calls=0))
        for span in self.spans:
            if span["exclusive_wall_ns"] < 0 or span["exclusive_cpu_ns"] < 0:
                raise ValueError("PROFILE_NEGATIVE_EXCLUSIVE_SPAN")
            row = by_category[span["category"]]
            row["exclusive_wall_ns"] += span["exclusive_wall_ns"]
            row["exclusive_cpu_ns"] += span["exclusive_cpu_ns"]
            row["calls"] += 1
        total = end_ns - start_ns
        classified = sum(r["exclusive_wall_ns"] for r in by_category.values())
        if classified > total:
            raise ValueError("PROFILE_CLASSIFICATION_EXCEEDS_WINDOW")
        by_category["unclassified"]["exclusive_wall_ns"] = total - classified
        if parent_cpu_ns is not None:
            by_category["unclassified"]["exclusive_cpu_ns"] = max(
                0, parent_cpu_ns - sum(r["exclusive_cpu_ns"] for r in by_category.values()))
        return dict(schema_version="sr-normal-exclusive-profile-v1", total_wall_ns=total,
                    categories=dict(by_category), spans=self.spans,
                    diagnostic_only=True, primary_estimate=False,
                    cpu_scope="parent process only; worker CPU is in execution receipts",
                    inclusive_spans_must_not_be_added=True,
                    instrument_overhead_can_redistribute_exclusive_categories=True)


class ScopedBindings:
    def __init__(self):
        self.saved = []

    def set(self, owner, name, value):
        owned = name in getattr(owner, "__dict__", {})
        self.saved.append((owner, name, owned, getattr(owner, name)))
        setattr(owner, name, value)

    def wrap(self, owner, name, recorder, category):
        self.set(owner, name, recorder.wrapper(getattr(owner, name), category,
                 getattr(owner, "__name__", type(owner).__name__) + "." + name))

    def __enter__(self):
        return self

    def __exit__(self, *args):
        for owner, name, owned, original in reversed(self.saved):
            if owned:
                setattr(owner, name, original)
            else:
                delattr(owner, name)


class CursorProxy:
    def __init__(self, cursor, recorder):
        self.cursor, self.recorder = cursor, recorder

    def __getattr__(self, key):
        return getattr(self.cursor, key)

    def fetchone(self):
        with self.recorder.span("sql", "cursor.fetchone"):
            return self.cursor.fetchone()

    def fetchall(self):
        with self.recorder.span("sql", "cursor.fetchall"):
            return self.cursor.fetchall()

    def __iter__(self):
        while True:
            row = self.fetchone()
            if row is None:
                return
            yield row


class ConnectionProxy:
    def __init__(self, connection, recorder):
        object.__setattr__(self, "connection", connection)
        object.__setattr__(self, "recorder", recorder)

    def __getattr__(self, key):
        return getattr(self.connection, key)

    def __setattr__(self, key, value):
        setattr(self.connection, key, value)

    def execute(self, *args, **kwargs):
        with self.recorder.span("sql", "connection.execute"):
            return CursorProxy(self.connection.execute(*args, **kwargs), self.recorder)

    def executescript(self, *args, **kwargs):
        with self.recorder.span("sql", "connection.executescript"):
            return CursorProxy(self.connection.executescript(*args, **kwargs), self.recorder)

    def commit(self):
        with self.recorder.span("sql", "connection.commit"):
            return self.connection.commit()

    def rollback(self):
        with self.recorder.span("sql", "connection.rollback"):
            return self.connection.rollback()

    def close(self):
        with self.recorder.span("sql", "connection.close"):
            return self.connection.close()
