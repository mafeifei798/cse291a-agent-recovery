"""Trusted normal-only comparison arm; no durable recovery/trace state.

It deliberately does not offer Full's recovery, provenance or concurrency safety.
It uses the same socket-free HTTP worker and Linux CPU resource supervisor, and
commits the two final business objects atomically. The shared oracle checks both
arms after their primary timers. Injection hooks exist for pure local unit tests.
"""
from __future__ import annotations
import copy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
import time

from sr_campaign_v3.contracts import model_schema, render
from sr_campaign_v3.gateway import build_request, offline_binding, _strict_json
from sr_campaign_v3.executor import run_job
from sr_cpu_v2.adapter import _initial_bindings, _json_artifact
from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from agent_recovery.p3_transport import parse_p3_usage
from .oracle import canonical, digest
from .contracts import validate_spec, record_base, make_fake_client, fake_calls_from


def _utc_after(seconds):
    return (datetime.now(timezone.utc)+timedelta(seconds=seconds)).isoformat().replace('+00:00','Z')


def commit_objects(db, objects, owner_result_id, operation_id):
    """One transaction writes the complete pair plus its single receipt."""
    if set(objects) not in ({'config','draft'}, {'manifest','report_index'}):
        raise ValueError('REFERENCE_EXACT_TWO_BUSINESS_OBJECTS')
    db.execute('BEGIN IMMEDIATE')
    try:
        if db.execute('SELECT COUNT(*) FROM business_objects').fetchone()[0]:
            raise ValueError('REFERENCE_NEW_OUTPUTS_ONLY')
        for key, value in sorted(objects.items()):
            db.execute('INSERT INTO business_objects VALUES(?,?,?,?)',
                       (key,canonical(value),1,owner_result_id))
        db.execute('INSERT INTO business_commits VALUES(?,?,?)',
                   (operation_id,canonical(sorted(objects)),owner_result_id))
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK')
        raise


def run_reference(spec, *, job_runner=None, fake_client_factory=None):
    started = time.perf_counter_ns()
    cpu_started = time.process_time_ns()
    root=Path(spec['run_root']).resolve();v0=Path(spec['v0_root']).resolve()
    item=copy.deepcopy(spec['item']);domain=item['domain'];run_id=spec['run_id']
    result={'schema_version':'sr-normal-tracking-run-v1','arm':spec['arm'],'domain':domain,
            'task_id':item['task_id'],'item_id':item['item_id'],'run_id':run_id,
            'run_root':str(root),'artifact_root':str(root/'files'),
            'business_db_path':str(root/'business.sqlite'),'status':'failed','error':None,
            'selected_payloads':{},'selected_result_ids':{},'artifacts':[], 'sources':[],
            'request':None,'executions':[],'fake_calls':[],
            'monotonic_ns':{'start':started,'ready':None,'post_commit':None,'end':None},
            'comparison_boundary':'normal-only minimal reference; lacks durable recovery history/source ancestry/concurrency guard/central ledger guarantees'}
    result.update({k: v for k, v in record_base(spec).items() if k in ('phase','trial_id','repeat_index','pair_id','actual_api_requests','actual_api_cost_nano_usd','simulated_financial_ledger_only')})
    db=None; client=None
    try:
        validate_spec(spec)
        if item['kind']!='control' or any(spec[k]!=item[k] for k in ('task_id','item_id','domain')):
            raise ValueError('REFERENCE_NORMAL_REGISTERED_TASK_ONLY')
        if spec['arm']!='reference':
            raise ValueError('REFERENCE_ARM_ID')
        root.mkdir(parents=True,exist_ok=False);files=root/'files';files.mkdir()
        db=sqlite3.connect(str(root/'business.sqlite'),timeout=10,isolation_level=None)
        db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=FULL')
        db.executescript('''CREATE TABLE business_objects(object_key TEXT PRIMARY KEY,payload TEXT NOT NULL,
            version INTEGER NOT NULL,owner_result_id TEXT NOT NULL);
            CREATE TABLE business_commits(operation_id TEXT PRIMARY KEY,atomic_keys TEXT NOT NULL,
            owner_result_id TEXT NOT NULL);''')
        if domain=='macro':
            dataset='adult' if 'adult' in item['task_id'] else 'bank'
            task,sources,artifacts,_=_initial_bindings(v0,files,dataset)
            request=task['request'];aliases={}
        else:
            task=next(t for t in json.loads((v0/'tasks/micro_tasks.json').read_text())['tasks']
                      if t['task_id']==item['task_id'])
            request=copy.deepcopy(task['public_request']);aliases=task['resolved_source_aliases']
            sources=[s for s in json.loads((v0/('tasks/authority/'+item['task_id']+'.sources.json')).read_text())['sources'] if s['version']==1]
            artifacts=[]
        result.update(request=request,sources=sources,artifacts=artifacts)
        dag=json.loads((v0/('dags/'+domain+'.json')).read_text())
        nodes={n['node_id']:n for n in dag['nodes']};current={s['object_key']:s for s in sources}
        counter=GLM53LocalTokenCounter.from_directory(v0/'environment/tokenizer_files')
        binding=offline_binding(v0)
        factory=fake_client_factory or make_fake_client
        client=factory(v0,run_id,counter=counter)
        runner=job_runner or run_job
        deadline=min(int(spec['global_deadline_ns']),started+240_000_000_000)
        payloads=result['selected_payloads'];ids=result['selected_result_ids']
        result['monotonic_ns']['ready']=time.perf_counter_ns()
        for node_id in dag['topological_order']:
            remaining=min(120.,(deadline-time.perf_counter_ns())/1e9)
            if remaining<=0:raise TimeoutError('REFERENCE_FIXED_DEADLINE')
            node=nodes[node_id]
            aid='reference.attempt.'+digest({'root':str(root),'run_id':run_id,'node':node_id})[:32]
            rid=aid+'.result';ids[node_id]=rid
            direct=[current[aliases.get(key,key)] for key in node['direct_source_keys']]
            snapshot={'run_id':run_id,'node_id':node_id,'request':request,
                      'parent_inputs':[{'node_id':parent,'payload':payloads[parent]} for parent in node['parents']],
                      'direct_source_inputs':direct}
            payload=None
            if node['llm_calls_per_execution']:
                messages=render(snapshot);schema=model_schema(node_id,domain)
                req=build_request(node_id,messages,schema,binding)
                estimate=counter.estimate_request(req).to_dict()
                if estimate['prompt_tokens']>4000:raise ValueError('REFERENCE_INPUT_CAP')
                response=client.exchange(req,deadline_monotonic=time.monotonic()+remaining)
                raw=_strict_json(response.body.decode());usage=parse_p3_usage(raw)
                if response.status!=200 or raw.get('model') not in binding['allowed_response_models'] or 'error' in raw:
                    raise ValueError('REFERENCE_FAKE_HTTP_ENVELOPE')
                choice=raw['choices'][0]
                if len(raw['choices'])!=1 or choice['finish_reason']!='stop':raise ValueError('REFERENCE_ONE_COMPLETE_CHOICE')
                payload=_strict_json(choice['message']['content'])
                import jsonschema
                jsonschema.Draft202012Validator(schema).validate(payload)
                if usage['prompt_tokens']>4000 or usage['completion_tokens']>768:raise ValueError('REFERENCE_USAGE_CAP')
                receipt=client.receipts[-1]
                if not receipt.get('reaped') or receipt.get('cleanup_failed') or client.fenced:
                    raise ValueError('REFERENCE_HTTP_WORKER_NOT_REAPED')
                result['fake_calls'].append({'node_id':node_id,'call_id':aid+'.call','request_digest':digest(req),
                                             'usage':usage,'status':'completed','worker_reaped':True,
                                             'cleanup_receipt':copy.deepcopy(receipt),'real_request_sent':False})
                if node_id=='report':
                    artifact=_json_artifact(files,rid,'report',payload);artifacts.append(artifact)
                    payload['report_artifact_id']=artifact['artifact_id']
                # The common FakeHTTPClient stores its own input list; the
                # reference keeps no additional durable request/history ledger.
            if node['cpu_jobs_per_execution']:
                if domain=='micro':inputs={'candidate':payload}
                else:
                    inputs={'dataset_id':request['dataset_id'],'train_version':1}
                    if node_id in ('prepare','profile'):
                        pass
                    elif node_id.startswith(('fit_','predict_','summary_')):
                        family=node_id[-2:];inputs.update(family=family,prepare=payloads['prepare'])
                        if node_id.startswith('fit_'):inputs['parameters']=payloads['plan_'+family]['parameters']
                        elif node_id.startswith('predict_'):inputs['fit']=payloads['fit_'+family]
                        else:inputs['predict']=payloads['predict_'+family]
                    elif node_id=='publish':inputs.update(report=payload['report'],action=payload['action'])
                remaining=min(120.,(deadline-time.perf_counter_ns())/1e9)
                if remaining<=0:raise TimeoutError('REFERENCE_FIXED_DEADLINE_BEFORE_CPU')
                stage=files/'jobs'/aid
                jobspec={'tool':node_id,'job_id':aid,'result_id':rid,'output_dir':str(stage),
                         'v0_root':str(v0),'artifact_root':str(files),'inputs':inputs,
                         'artifacts':artifacts[:],'deadline_utc':_utc_after(remaining),
                         'output_reservation_bytes':128*1024**2 if node_id in ('prepare','fit_rf') else 64*1024**2}
                execution=runner(jobspec,root)
                result['executions'].append(execution['execution'])
                journal=execution['execution'];body=execution.get('response') or {}
                if journal['status']!='success' or not journal['worker_reaped'] or journal.get('remaining_processes') or journal.get('timed_out'):
                    raise RuntimeError('REFERENCE_CPU_JOB_NOT_SUCCESSFULLY_REAPED')
                if journal.get('returncode')!=0:raise RuntimeError('REFERENCE_CPU_EXIT')
                payload=copy.deepcopy(body['payload']);artifacts.extend(body.get('artifacts',[]))
                if node_id=='publish':
                    candidate=next(a for a in artifacts if a['artifact_id']==payload['candidate_artifact_id'])
                    payload['publish_manifest']=json.loads((files/candidate['uri']).read_text())
            payloads[node_id]=payload
        if len(result['fake_calls'])!=5 or len(result['executions'])!=(9 if domain=='macro' else 1):
            raise ValueError('REFERENCE_FIXED_CALL_JOB_COUNTS')
        final='publish' if domain=='macro' else 'execute';publish=payloads[final]
        if domain=='micro':objects={'config':publish['config'],'draft':publish['command']}
        else:objects={'manifest':publish,'report_index':{'report_result_id':ids['report'],
                                                       'candidate_artifact_id':publish['candidate_artifact_id']}}
        if time.perf_counter_ns()>=deadline:raise TimeoutError('REFERENCE_FIXED_DEADLINE_BEFORE_COMMIT')
        commit_objects(db,objects,ids[final],'reference.operation.'+ids[final])
        result['monotonic_ns']['post_commit']=time.perf_counter_ns()
        result['status']='completed_correct'
    except Exception as exc:
        result['error']={'type':type(exc).__name__,'message':str(exc)}
    finally:
        if client is not None and hasattr(client,'bench_trace'):
            result['fake_calls']=fake_calls_from(client)
        if db is not None:db.close()
        result['monotonic_ns']['end']=time.perf_counter_ns()
        result['primary_wall_ns']=result['monotonic_ns']['end']-started
        result['primary_process_cpu_ns']=time.process_time_ns()-cpu_started
        # Shared runner names; the primary names remain explicit aliases.
        result['pipeline_wall_ns']=result['primary_wall_ns']
        result['parent_cpu_ns']=result['primary_process_cpu_ns']
    return result
