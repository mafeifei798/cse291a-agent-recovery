"""New offline normal-workflow benchmark; frozen experiment sources are reused."""
