"""Shared dict contracts and socket-free deterministic fixture transport."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import time

from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from sr_recovery_v2.common import canonical, digest
from sr_campaign_v3.contracts import scripted_payload
from sr_campaign_v3.gateway import FakeHTTPClient, fake_response, offline_binding

SCHEMA_VERSION = "sr-normal-tracking-run-v1"
ARMS = {"full", "reference", "full_profiled"}
TASK_ITEM_IDS = ("sr-v2.micro.eval02.control", "sr-v2.micro.eval03.control",
                 "sr-v2.macro.adult.control", "sr-v2.macro.bank.control")


def require(ok, code):
    if not ok:
        raise ValueError(code)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_spec(spec):
    fields = {"item", "task_id", "item_id", "domain", "v0_root", "run_root", "run_id",
              "arm", "phase", "repeat_index", "pair_id", "global_deadline_ns"}
    require(isinstance(spec, dict) and fields <= set(spec), "TRACKING_RUN_SPEC_FIELDS")
    require(spec["arm"] in ARMS and spec["phase"] in ("warmup", "measured", "diagnostic", "profile"),
            "TRACKING_RUN_SPEC_MODE")
    item = spec["item"]
    require(item["item_id"] in TASK_ITEM_IDS and item["kind"] == "control"
            and all(spec[k] == item[k] for k in ("item_id", "task_id", "domain")),
            "TRACKING_NORMAL_TASK_ONLY")
    require(isinstance(spec["global_deadline_ns"], int)
            and time.perf_counter_ns() < spec["global_deadline_ns"], "TRACKING_GLOBAL_DEADLINE")
    require(not Path(spec["run_root"]).exists(), "TRACKING_NEW_ARM_ROOT_REQUIRED")
    return deepcopy(spec)


def record_base(spec):
    return dict(schema_version=SCHEMA_VERSION, arm=spec["arm"], phase=spec["phase"],
        trial_id=spec.get("trial_id"),
        repeat_index=spec["repeat_index"], pair_id=spec["pair_id"], task_id=spec["task_id"],
        item_id=spec["item_id"], domain=spec["domain"], run_id=spec["run_id"],
        run_root=str(Path(spec["run_root"]).resolve()), status="not_started", error=None,
        artifact_root=None, business_db_path=None, selected_payloads={}, selected_result_ids={},
        artifacts=[], sources=[], request={}, executions=[], fake_calls=[],
        monotonic_ns={"start": None, "post_commit": None, "end": None},
        actual_api_requests=0, actual_api_cost_nano_usd=0, simulated_financial_ledger_only=True)


def selected_from_view(view):
    results = {r["result_id"]: r for r in view["results"]}
    selected = view["state"]["selected_by_node"]
    return {node: deepcopy(results[rid]["payload"]) for node, rid in selected.items() if rid in results}


def make_fake_client(v0_root, run_id, *, counter=None):
    """Exact production FakeHTTPClient; no live-client/key/environment path.

    Both arms use the same public-message response rule, local token counter,
    response envelope and reasoning-token fixture. Artifact identities remain
    bound to each arm's own current inputs, never copied from another arm.
    """
    counter = counter or GLM53LocalTokenCounter.from_directory(Path(v0_root) / "environment/tokenizer_files")
    trace = []
    def builder(request):
        payload = scripted_payload({"rendered_messages": request["messages"]})
        prompt = counter.estimate_request(request).to_dict()["prompt_tokens"]
        visible = len(counter._encoder(canonical(payload)))
        response = fake_response(payload, request_id="fixture.normal." + run_id + "." + str(len(trace) + 1),
                                 prompt_tokens=prompt, completion_tokens=visible + 16, reasoning_tokens=16)
        trace.append(dict(request=deepcopy(request), payload=deepcopy(payload),
                          raw_response=json.loads(response.body.decode()),
                          request_digest=digest(request), response_sha256=hashlib.sha256(response.body).hexdigest(),
                          request_sent=False, simulated=True))
        return response
    client = FakeHTTPClient(response_builder=builder)
    client.bench_counter = counter
    client.bench_trace = trace
    return client


def fake_calls_from(client):
    return [{**deepcopy(row), "cleanup_receipt": deepcopy(client.receipts[i])
             if i < len(client.receipts) else None} for i, row in enumerate(client.bench_trace)]


def normal_items(v0_root):
    rows = [json.loads(line) for line in
            (Path(v0_root) / "registry/formal_items.jsonl").read_text().splitlines() if line.strip()]
    picked = {row["item_id"]: row for row in rows if row["item_id"] in TASK_ITEM_IDS}
    require(set(picked) == set(TASK_ITEM_IDS), "TRACKING_FOUR_NORMAL_ITEMS_REQUIRED")
    return [deepcopy(picked[iid]) for iid in TASK_ITEM_IDS]
