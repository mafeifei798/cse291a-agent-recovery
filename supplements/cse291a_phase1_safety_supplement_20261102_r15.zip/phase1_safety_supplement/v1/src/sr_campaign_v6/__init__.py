"""Separate macro precision/report repair round; immutable predecessor evidence."""
