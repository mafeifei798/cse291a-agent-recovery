"""Read-only V6 epoch and inherited-history auditor; real records never masquerade as fixtures.

Business and scene reconstruction reuse pinned, mode-neutral V3 audit helpers.
Real authorization, wire evidence, usage and money are checked here without
importing a gateway, Store, ledger implementation, policy or runtime guard.
An auditable safe failure is separate from a successfully completed workload.
"""
from __future__ import annotations

import base64
from copy import deepcopy
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3

from sr_campaign_v3.checker import (
    _Audit, _digest, _rows, _utc, _load_item_export, _raw_result, _scenes,
    _checkpoints, _runner_events, _ledger_events, _input_projection, qualify_prefix,
)


CAMPAIGN = "sr-v2-formal-live-r1"
RESERVATION, BASE_KNOWN, BASE_HELD = 1_924_000, 90_998_300, 984_000
MAX_COST, BASE_CALLS = 1_000_000_000, 1605
TERMINAL = {"completed_correct", "validation_rejected", "permission_denied_safe", "conflict_safe",
            "tool_failed", "budget_or_time_stopped", "uncertain", "not_run_blocked_prefix", "not_run_stopped"}
UNSTARTED = {"not_started", "not_run_blocked_prefix", "not_run_stopped"}
V4_GRANT_FIELDS = {"schema_version", "record_type", "grant_id", "campaign_id", "authorized",
    "execution_mode", "binding_digest", "registry_sha256", "baseline_sha256", "ledger_path",
    "lock_root", "max_new_physical_calls", "max_cumulative_cost_nano_usd", "authorization_reference"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _strict_json(data):
    def pairs(values):
        out = {}
        for key, value in values:
            if key in out:
                raise ValueError("duplicate JSON member")
            out[key] = value
        return out
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite JSON")))


def _within(root, relative):
    path = Path(relative)
    path = (root / path).resolve() if not path.is_absolute() else path.resolve()
    if path == root or root not in path.parents:
        raise ValueError("evidence path escapes campaign root")
    return path


def _usage(raw):
    if not isinstance(raw, dict):
        return None
    p, c, t = (raw.get(k) for k in ("prompt_tokens", "completion_tokens", "total_tokens"))
    pd, cd = raw.get("prompt_tokens_details") or {}, raw.get("completion_tokens_details") or {}
    if not isinstance(pd, dict) or not isinstance(cd, dict):
        return None
    cached, reasoning = pd.get("cached_tokens", 0), cd.get("reasoning_tokens", 0)
    if not all(type(v) is int and v >= 0 for v in (p, c, t, cached, reasoning)) or \
            t != p + c or cached > p or reasoning > c:
        return None
    return dict(prompt_tokens=p, completion_tokens=c, total_tokens=t,
                cached_input_tokens=cached, reasoning_tokens=reasoning)


def _schema_ok(schema, value):
    """Small independent validator for the frozen object/primitive contracts."""
    allowed = {"type", "properties", "required", "additionalProperties", "items", "minItems", "maxItems",
               "const", "enum", "minimum", "maximum", "minLength", "maxLength", "pattern", "title", "description"}
    if not isinstance(schema, dict) or not set(schema) <= allowed:
        return False
    kind = schema.get("type")
    valid_type = {"object": type(value) is dict, "array": type(value) is list,
        "string": type(value) is str, "integer": type(value) is int,
        "number": type(value) in (int, float) and math.isfinite(value),
        "boolean": type(value) is bool, "null": value is None}
    if kind is not None and not valid_type.get(kind, False):
        return False
    if "const" in schema and (value != schema["const"] or type(value) is not type(schema["const"])):
        return False
    if "enum" in schema and not any(value == x and type(value) is type(x) for x in schema["enum"]):
        return False
    if type(value) is dict:
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is not False or set(schema.get("required", [])) != set(props):
            return False
        if not set(schema.get("required", [])) <= set(value):
            return False
        if schema.get("additionalProperties") is False and not set(value) <= set(props):
            return False
        return all(_schema_ok(props[k], v) for k, v in value.items() if k in props)
    if type(value) is list:
        return len(value) >= schema.get("minItems", 0) and len(value) <= schema.get("maxItems", math.inf) and \
               all(_schema_ok(schema.get("items", {}), x) for x in value)
    if type(value) is str:
        return schema.get("minLength", 0) <= len(value) <= schema.get("maxLength", math.inf) and \
               ("pattern" not in schema or re.search(schema["pattern"], value) is not None)
    if type(value) in (int, float):
        return schema.get("minimum", -math.inf) <= value <= schema.get("maximum", math.inf)
    return True




def _http_calls(calls, raw_calls, ledger, root, a, schemas=None, input_by_call=None):
    binding = ledger["config"]["binding"]; confirmed = 0
    seen_ids = {c.get("provider_request_id") for c in _flatten_calls(ledger.get("predecessor", {}).get("snapshot", {}))
                if c.get("provider_request_id")}
    for call in calls:
        if not call.get("dispatched"):
            continue
        cid, request = call["call_id"], call["request"]
        evidence = call.get("evidence")
        stages = {}
        if root is not None:
            for stage in ("reserved", "dispatched", "response", "settled"):
                path = _within(root, Path("http") / cid / (stage + ".json"))
                if path.is_file(): stages[stage] = _strict_json(path.read_text())
            a.expect(set(stages) == {"reserved", "dispatched", "response", "settled"}, "V6_ALL_FOUR_HTTP_STAGES_RETAINED", cid)
            if "response" in stages:
                if evidence is not None:
                    unverified = {k: v for k, v in evidence.items() if k not in {"unknown_receipt_reason", "receipt_identity_unverified"}}
                    unknown_reason = evidence.get("unknown_receipt_reason")
                    unknown_metadata = call.get("status") == "uncertain" and isinstance(unknown_reason, str) and \
                        bool(unknown_reason.strip()) and evidence.get("receipt_identity_unverified") is \
                        (call.get("provider_request_id") is None)
                    a.expect(stages["response"] == evidence or (unknown_metadata and unverified == stages["response"]),
                        "V6_CENTRAL_RESPONSE_EQUALS_RAW_FILE", cid)
                evidence = stages["response"]
            for stage, record in stages.items():
                a.expect(record.get("call_id", record.get("sidecar", {}).get("call_id")) == cid, "V6_STAGE_CALL_IDENTITY", cid + ":" + stage)
        if not a.expect(isinstance(evidence, dict), "V6_RAW_HTTP_EVIDENCE_REQUIRED", cid): continue
        sidecar = call.get("sidecar", {})
        a.expect(evidence.get("request") == request and all(evidence.get(k) == v for k, v in sidecar.items()),
                 "V6_CENTRAL_SIDECAR_MATCHES_RESPONSE", cid)
        if {"reserved", "dispatched"} <= set(stages):
            a.expect(stages["dispatched"] == sidecar and stages["reserved"] ==
                     {**sidecar, "request": request, "input_snapshot": evidence.get("input_snapshot")},
                     "V6_PRE_DISPATCH_STAGES_EXACTLY_BOUND", cid)
        total_deadline = evidence.get("total_deadline_seconds")
        a.expect(type(total_deadline) in (int, float) and math.isfinite(total_deadline) and
                 0 < total_deadline <= 120, "V6_TOTAL_HTTP_DEADLINE_BOUND", cid)
        http = evidence.get("http_evidence", {})
        a.expect(http.get("simulated") is False and http.get("transport_intent_committed") is True and
                 http.get("method") == "POST" and http.get("url") == binding["base_url"] + "/chat/completions",
                 "V6_LIVE_HTTP_INTENT_FIXED_ENDPOINT", cid)
        body = base64.b64decode(http.get("request_body_b64", ""), validate=True)
        wire_request = _strict_json(body)
        a.expect(wire_request == request and hashlib.sha256(body).hexdigest() == http.get("request_digest") ==
                 evidence.get("request_digest") == _digest(request), "V6_REQUEST_WIRE_BYTES_BOUND", cid)
        fmt = request.get("response_format", {}); contract = fmt.get("json_schema", {})
        _strict_json(request["messages"][1]["content"])
        a.expect(request.get("model") == binding["model"] and request.get("n") == 1 and request.get("stream") is False and
                 request.get("reasoning_effort") == "low" and request.get("max_completion_tokens") == 2048 and
                 fmt.get("type") == "json_schema" and contract.get("strict") is True and
                 _digest(contract.get("schema")) == evidence.get("wire_schema_digest"), "V6_REAL_MODEL_REQUEST_CONTRACT", cid)
        if schemas is not None:
            a.expect(contract.get("schema") == _wire_schemas(schemas).get(call["domain"], {}).get(evidence.get("node_id")) and
                     evidence.get("schema_digest") == _digest(schemas.get(call["domain"], {}).get(evidence.get("node_id"))) and
                     evidence.get("wire_schema_profile") == "macro-unbounded-wire-number-compact-v2",
                     "V6_REQUEST_USES_FROZEN_NODE_SCHEMA", cid)
        snapshot = evidence.get("input_snapshot")
        if a.expect(isinstance(snapshot, dict), "V6_PRE_DISPATCH_FULL_SNAPSHOT_RETAINED", cid):
            if (input_by_call or {}).get(cid) is not None:
                a.expect(snapshot == input_by_call[cid], "V6_WIRE_SNAPSHOT_EQUALS_NODE_RESULT", cid)
            # Only model nodes reach the HTTP gateway; compact projection is
            # checked independently even if no NodeResult could be appended.
            _input_projection({"result_id": cid, "input_snapshot": snapshot,
                               "input_digest": evidence.get("input_digest")},
                              {"node_id": evidence.get("node_id"), "llm_calls_per_execution": 1}, a)
            a.expect(_project_messages(snapshot.get("rendered_messages")) == request.get("messages") and
                     _digest(snapshot) == evidence.get("input_digest") == raw_calls.get(cid, {}).get("input_digest"),
                     "V6_REAL_WIRE_MATCHES_ACTUAL_NODE_INPUT", cid)
        a.expect(evidence.get("binding_digest") == ledger["config"]["binding_digest"] and evidence.get("simulated") is False and
                 evidence.get("grant_id") == ledger["config"]["grant"]["grant_id"], "V6_WIRE_GRANT_BINDING", cid)
        cleanup = http.get("cleanup_receipt")
        if a.expect(isinstance(cleanup, dict), "V6_TRANSPORT_CLEANUP_RECEIPT_REQUIRED", cid):
            a.expect(cleanup.get("unit_mocked_process") is not True, "V6_MOCK_TRANSPORT_EVIDENCE_FORBIDDEN", cid)
            a.expect(cleanup.get("simulated") is False and cleanup.get("reaped") is True and cleanup.get("cleanup_failed") is False and
                     cleanup.get("request_digest") == hashlib.sha256(body).hexdigest() and
                     0 < cleanup.get("timeout_s", 0) <= 120, "V6_LIVE_WORKER_REAPED_WITH_DEADLINE", cid)
            a.expect(cleanup.get("provider_cancelled") is False and http.get("provider_cancellation_confirmed") is False,
                     "V6_LOCAL_CANCELLATION_NOT_PROVIDER_GUARANTEE", cid)
        raw = None
        if http.get("response_body_b64") is not None:
            response = base64.b64decode(http["response_body_b64"], validate=True)
            a.expect(hashlib.sha256(response).hexdigest() == http.get("response_sha256"), "V6_ORIGINAL_RESPONSE_BYTES_SHA", cid)
            try: raw = _strict_json(response)
            except ValueError: raw = None
        a.expect(raw == evidence.get("raw_response"), "V6_PARSED_RESPONSE_MATCHES_ORIGINAL_BYTES", cid)
        headers = http.get("headers", {})
        a.expect(set(headers) <= {"x-litellm-call-id", "x-request-id", "request-id", "content-type"} and
                 all(isinstance(v, str) and len(v) <= 256 and "\r" not in v and "\n" not in v for v in headers.values()),
                 "V6_PUBLIC_HEADERS_ONLY", cid)
        def present(name):
            value = headers.get(name)
            return value if isinstance(value, str) and value.strip() else None
        provider_id = present("x-litellm-call-id") or present("x-request-id") or present("request-id")
        a.expect(http.get("request_id") == provider_id, "V6_PROVIDER_ID_PRECEDENCE", cid)
        a.expect(call.get("provider_request_id") == provider_id, "V6_CENTRAL_HEADER_ID_PRESERVED_EVEN_UNKNOWN", cid)
        parsed_usage = _usage(raw.get("usage")) if isinstance(raw, dict) else None
        if call["status"] == "settled":
            a.expect(bool(provider_id) and provider_id == call.get("provider_request_id") and provider_id not in seen_ids,
                     "V6_SETTLED_PROVIDER_RECEIPT_ID", cid); seen_ids.add(provider_id)
            a.expect(parsed_usage == call.get("usage") and parsed_usage is not None, "V6_WIRE_USAGE_MATCHES_LEDGER", cid)
            confirmed += 1
        raw_call = raw_calls.get(cid, {})
        wire_usage = raw.get("usage") if isinstance(raw, dict) else None
        expected_call_usage = {**parsed_usage, "raw": wire_usage} if parsed_usage is not None else None
        a.expect(raw_call.get("usage") == expected_call_usage and call.get("raw_usage") == wire_usage and
                 evidence.get("raw_usage") == (wire_usage if parsed_usage is not None else None),
                 "V6_ALL_ORIGINAL_USAGE_COPIES_BOUND", cid)
        a.expect(raw_call.get("cost_nano_usd") == call.get("known_cost_nano_usd") and
                 raw_call.get("provider_request_id") == provider_id, "V6_WORKFLOW_CALL_COST_AND_PROVIDER_ID", cid)
        a.expect(raw_call.get("attempt_id") == call["attempt_id"] == evidence.get("attempt_id") and
                 evidence.get("item_id") == call["item_id"] and evidence.get("call_id") == cid and
                 evidence.get("node_id") == raw_call.get("node_id") == contract.get("name"), "V6_WIRE_ATTEMPT_NODE_IDENTITY", cid)
        if evidence.get("status") == "completed":
            a.expect(isinstance(raw, dict) and raw.get("model") in binding["allowed_response_models"] and http.get("status") == 200,
                     "V6_SUCCESS_RESPONSE_MODEL_AND_STATUS", cid)
            choices = raw.get("choices", []) if isinstance(raw, dict) else []
            if a.expect(len(choices) == 1 and choices[0].get("finish_reason") == "stop" and choices[0].get("index") == 0,
                        "V6_SINGLE_COMPLETE_CHOICE", cid):
                message = choices[0].get("message", {})
                payload = _strict_json(message["content"])
                a.expect(message.get("role") == "assistant" and message.get("refusal") in (None, "") and
                         (_schema_ok(schemas.get(call["domain"], {}).get(evidence.get("node_id")), payload) if schemas is not None else _schema_ok(contract["schema"], payload)), "V6_SUCCESS_PAYLOAD_SCHEMA_INDEPENDENT", cid)
                a.expect(raw_call.get("raw_response_payload") == payload, "V6_ORIGINAL_MODEL_PAYLOAD_RETAINED", cid)
        if "settled" in stages:
            a.expect(stages["settled"].get("call_evidence") == raw_call and stages["settled"].get("request") == request and
                     stages["settled"].get("http_evidence") == http, "V6_FINAL_HTTP_STAGE_MATCHES_WORKFLOW", cid)
    return dict(physical_live_dispatches=sum(c.get("dispatched") is True for c in calls),
                confirmed_provider_receipts=confirmed, request_count_basis="durable live intent, not packet capture")


OUTPUT_INSTRUCTION = (
    "Return only one compact JSON object, with no Markdown, indentation, or "
    "unnecessary whitespace. Copy every supplied numeric value exactly, including "
    "all decimal digits; do not round or recompute supplied metrics. For report "
    "and publish, keep report_text concise (at most 30 words). Include all required "
    "fields and finish the complete JSON object within the output limit."
)


def _output_profile():
    return dict(output_profile="compact-json-exact-metrics-v1", output_instruction=OUTPUT_INSTRUCTION,
                output_instruction_digest=_digest(OUTPUT_INSTRUCTION))


def _project_messages(messages):
    if not isinstance(messages, list) or len(messages) != 2 or any(
            not isinstance(m, dict) or set(m) != {"role", "content"} or not isinstance(m["content"], str)
            for m in messages) or [m["role"] for m in messages] != ["system", "user"]:
        raise ValueError("original message contract changed")
    result = deepcopy(messages)
    result[0]["content"] += "\n\n" + OUTPUT_INSTRUCTION
    return result


def _flatten_calls(snapshot):
    previous = snapshot.get("predecessor", {}).get("snapshot")
    return (_flatten_calls(previous) if isinstance(previous, dict) else []) + _rows(snapshot.get("calls"))


def _wire_schemas(schemas):
    """Independent exact projection: 2 patterns and 24 number-bound keywords."""
    wire = deepcopy(schemas)
    for node in ("report", "publish"):
        report = wire["macro"][node]
        if node == "publish":
            report = report["properties"]["report"]
        text = report["properties"]["report_text"]
        if text.get("pattern") != r"^\S+(?:\s+\S+){0,119}\s*$":
            raise ValueError("full report pattern was altered")
        del text["pattern"]
        paths = [("validation_average_precision", "LR"), ("validation_average_precision", "RF")]
        paths += [("metrics", key) for key in ("average_precision", "roc_auc", "accuracy", "f1")]
        for owner, key in paths:
            value = report["properties"][owner]["properties"][key]
            if value != {"type": "number", "minimum": 0, "maximum": 1}:
                raise ValueError("full metric number schema was altered")
            del value["minimum"]
            del value["maximum"]
    return wire


def _source_pins(ledger, root, source, a, v0):
    from sr_campaign_v4.checker import _source_pins as original_pins
    from sr_campaign_v3.contracts import model_schema
    schemas = original_pins(ledger, root, source, a, v0)
    if root is None or not schemas:
        return schemas
    manifest = _strict_json((root / "frozen/source_manifest.json").read_text())
    packages = ("agent_recovery", "sr_recovery_v2", "sr_cpu_v2", "sr_campaign_v3", "sr_campaign_v4", "sr_campaign_v5", "sr_campaign_v6")
    inventory = {str(path.relative_to(source)) for package in packages
                 for path in (source / "src" / package).glob("*.py") if not path.name.startswith("._")}
    inventory.update(("scripts/run_sr_campaign_v4.py", "scripts/run_sr_campaign_v5.py", "scripts/run_sr_campaign_v6.py"))
    a.expect(set(manifest) == inventory, "V6_COMPLETE_PRODUCTION_SOURCE_MANIFEST")
    expected = {domain: {node["node_id"]: model_schema(node["node_id"], domain)
                for node in _strict_json((v0 / "dags" / (domain + ".json")).read_text())["nodes"]
                if node["llm_calls_per_execution"]} for domain in ("micro", "macro")}
    a.expect(schemas == expected, "V6_ORIGINAL_FULL_VALIDATION_SCHEMAS")
    wire_path, profile_path = root / "frozen/wire_schemas.json", root / "frozen/schema_profile.json"
    if not a.expect(wire_path.is_file() and profile_path.is_file(), "V6_DUAL_SCHEMA_FILES_REQUIRED"):
        return schemas
    wire, profile = _strict_json(wire_path.read_text()), _strict_json(profile_path.read_text())
    expected_profile = dict(wire_schema_profile="macro-unbounded-wire-number-compact-v2",
                            wire_schema_digest=_digest(_wire_schemas(expected)),
                            validation_schema_digest=_digest(expected), **_output_profile())
    a.expect(wire == _wire_schemas(expected) and profile == expected_profile,
             "V6_ONLY_APPROVED_WIRE_PATTERN_AND_NUMBER_KEYWORDS_REMOVED")
    binding = ledger["config"]["binding"]
    a.expect(all(binding.get(k) == v for k, v in expected_profile.items()),
             "V6_DUAL_SCHEMA_BINDING_PIN")
    return schemas


def audit_campaign_path(path, v0_root, artifact_root=None, source_root=None, predecessor_root=None):
    p = Path(path)
    try:
        value = _strict_json(p.read_text())
    except (OSError, ValueError) as exc:
        return {"passed": False, "checks": 1,
                "issues": [{"code": "V6_BUNDLE_UNREADABLE", "detail": str(exc)}]}
    return audit_campaign(value, v0_root, artifact_root or p.parent, source_root, predecessor_root)


def audit_campaign(bundle, v0_root, artifact_root=None, source_root=None, predecessor_root=None):
    a = _Audit()
    try:
        return _audit(bundle, Path(v0_root).resolve(),
                      Path(artifact_root).resolve() if artifact_root else None,
                      Path(source_root).resolve() if source_root else Path(__file__).resolve().parents[2],
                      Path(predecessor_root).resolve() if predecessor_root else None, a)
    except (KeyError, TypeError, ValueError, OSError, IndexError, AttributeError, OverflowError, sqlite3.Error) as exc:
        a.expect(False, "V6_MALFORMED_EVIDENCE", detail=f"{type(exc).__name__}: {exc}")
        return {"passed": False, "business_healthy": False, "checks": a.checks, "issues": a.issues,
                "statistics": {}, "limitations": ["An audit failure does not authorize rerunning an item."]}


def _audit_predecessor_native(desc, previous, previous_root, v0, source, a):
    """Read the original V5 SQL and HTTP files; never rewrite stale state."""
    from sr_campaign_v5.checker import (_real_ledger as audit_v5_ledger, _http_calls as audit_v5_http,
                                         _source_pins as audit_v5_pins)
    from sr_campaign_v4.checker import audit_campaign_path as audit_v4
    snapshot = desc["snapshot"]
    db = previous_root / "budget/central.sqlite"
    a.expect(not any(Path(str(db) + suffix).exists() for suffix in ("-journal", "-wal")),
             "V6_NATIVE_PREDECESSOR_CLOSED")
    con = sqlite3.connect(db.as_uri() + "?mode=ro&immutable=1", uri=True)
    con.row_factory = sqlite3.Row
    try:
        campaign = dict(con.execute("SELECT * FROM campaign").fetchone())
        a.expect(_strict_json(campaign["config"]) == snapshot["config"]
                 and campaign["status"] == snapshot["status"]
                 and campaign.get("reason") == snapshot.get("pause_reason"), "V6_PREDECESSOR_NATIVE_CAMPAIGN")
        for table in ("calls", "items"):
            physical = [_strict_json(row[0]) for row in con.execute("SELECT body FROM " + table + " ORDER BY rowid")]
            a.expect(physical == snapshot.get(table, []), "V6_PREDECESSOR_NATIVE_SQL_ROWS", table)
        events = []
        for row in con.execute("SELECT * FROM events ORDER BY seq"):
            value = dict(row); value["body"] = _strict_json(value["body"]); events.append(value)
        a.expect(events == snapshot.get("events"), "V6_PREDECESSOR_NATIVE_EVENT_ROWS")
        receipts = [dict(row) for row in con.execute("SELECT * FROM receipts ORDER BY rowid")]
        calls = {c["call_id"]: c for c in snapshot["calls"]}
        a.expect(len(receipts) == len(snapshot["calls"]), "V6_PREDECESSOR_ALL_NATIVE_RECEIPTS")
        for receipt in receipts:
            value = _strict_json(receipt["body"])
            call = calls.get(receipt["call_id"], {})
            a.expect(receipt["provider_request_id"] == call.get("provider_request_id")
                     and value.get("provider_request_id") == receipt["provider_request_id"]
                     and value.get("raw_usage") == call.get("raw_usage"), "V6_PREDECESSOR_NATIVE_RECEIPT_BINDING", receipt["call_id"])
        checkpoints = [_strict_json(row[0]) for row in con.execute("SELECT body FROM checkpoints ORDER BY id")]
        a.expect(checkpoints == [e["body"] for e in events if e["kind"] == "checkpoint"],
                 "V6_PREDECESSOR_NATIVE_CHECKPOINT_BINDING")
        late = [dict(call_id=row[0], receipt=_strict_json(row[1]))
                for row in con.execute("SELECT call_id,body FROM late_receipts ORDER BY id")]
        a.expect(late == snapshot.get("late_receipts", []), "V6_PREDECESSOR_NATIVE_LATE_ROWS")
    finally:
        con.close()
    stale = previous["ledger"]
    a.expect(desc.get("source_of_truth") == "durable_native_sql" and desc.get("state_snapshot_current") is False
             and desc.get("state_epoch_calls") == 76 and desc.get("durable_epoch_calls") == 81,
             "V6_EXPLICIT_STALE_STATE_SOURCE_OF_TRUTH")
    a.expect(len(stale["calls"]) == 76 and len(snapshot["calls"]) == 81
             and stale["calls"] == snapshot["calls"][:76]
             and stale["events"] == snapshot["events"][:len(stale["events"])]
             and stale["config"] == snapshot["config"] and stale["predecessor"] == snapshot["predecessor"],
             "V6_STALE_STATE_DURABLE_PREFIX_PRESERVED")
    a.expect(all(c["status"] == "settled" and c["dispatched"] is True for c in snapshot["calls"])
             and len(_flatten_calls(snapshot)) == 206 and snapshot["cumulative_budget"]["cumulative_calls"] == 1811
             and snapshot["cumulative_budget"]["known_cost_nano_usd"] == 122_853_950
             and snapshot["cumulative_budget"]["held_cost_nano_usd"] == 2_268_000,
             "V6_COMPLETE_81_SQL_CALLS_AND_206_INHERITANCE")
    receipt_path = Path(desc["stop_receipt_path"])
    stop = _strict_json(receipt_path.read_text())
    a.expect(_sha(receipt_path) == desc.get("stop_receipt_sha256") and stop == desc.get("stop_receipt"),
             "V6_ORIGINAL_HARD_STOP_RECEIPT_BYTES")
    a.expect(stop.get("status") == "quiescent_hard_stop" and stop.get("all_current_calls_settled") is True
             and stop.get("all_stores_no_active_attempts") is True and stop.get("active_cpu_or_http_children") == []
             and stop.get("epoch_call_count") == stop.get("epoch_dispatched") == 81
             and stop.get("epoch_known_nano_usd") == 24_037_550 and stop.get("epoch_held_nano_usd") == 0
             and stop.get("unknown_reservation_released") is False, "V6_QUIESCENT_HARD_STOP_REQUIRED")
    physical_stores = []
    for path in sorted((previous_root / "db").glob("*.sqlite")):
        a.expect(not any(Path(str(path) + suffix).exists() for suffix in ("-journal", "-wal")),
                 "V6_PREDECESSOR_STORE_CLOSED", path.name)
        con = sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True)
        try: document = _strict_json(con.execute("SELECT payload FROM document WHERE id=1").fetchone()[0])
        finally: con.close()
        a.expect(not document["state"]["active_attempt_ids"] and not document["state"]["unsettled_call_ids"],
                 "V6_PREDECESSOR_STORES_QUIESCENT", path.name)
        physical_stores.append(dict(relative_path=str(path.relative_to(previous_root)), sha256=_sha(path)))
    a.expect(bool(physical_stores) and physical_stores == desc.get("store_files"), "V6_ALL_NATIVE_STORE_PINS")
    registry = [_strict_json(line) for line in (v0 / "registry/formal_items.jsonl").read_text().splitlines() if line.strip()]
    accounting = audit_v5_ledger(snapshot, registry, v0, a)
    schemas = audit_v5_pins(snapshot, previous_root, source, a, v0)
    raw_calls = {}; input_by_call = {}
    for call in snapshot["calls"]:
        cid = call["call_id"]
        settled = _strict_json((previous_root / "http" / cid / "settled.json").read_text())
        raw_calls[cid] = settled["call_evidence"]
        input_by_call[cid] = call["evidence"]["input_snapshot"]
    http = audit_v5_http(snapshot["calls"], raw_calls, snapshot, previous_root, a, schemas, input_by_call)
    old_desc = snapshot["predecessor"]
    old_root = Path(old_desc["root"])
    old_state = old_root / "campaign_state.json"
    a.expect(_sha(old_state) == old_desc["campaign_state_sha256"]
             and _sha(old_root / "budget/central.sqlite") == old_desc["ledger_sha256"], "V6_ORIGINAL_V4_BYTES_RETAINED")
    report = audit_v4(old_state, v0, old_root, source)
    a.expect(report.get("passed") is True, "V6_ORIGINAL_V4_NATIVE_AUDIT", detail=report.get("issues", [])[:8])
    if report.get("passed"): a.checks += report.get("checks", 0)
    return dict(native_sql_verified=True, accounting=accounting, http=http, original_v4=report,
                business_success_claimed=False, stale_state_preserved=True)


def _predecessor(bundle, ledger, v0, source, supplied_root, a):
    desc = ledger["predecessor"]
    declared = bundle.get("predecessor", {})
    previous_root = supplied_root or Path(declared.get("root", desc["root"])).resolve()
    state_path, db_path = previous_root / "campaign_state.json", previous_root / "budget/central.sqlite"
    a.expect(desc.get("schema_version") == "sr-v6-predecessor-v1", "V6_PREDECESSOR_DESCRIPTOR")
    a.expect(desc.get("descriptor_digest") == _digest({k: v for k, v in desc.items() if k != "descriptor_digest"}),
             "V6_PREDECESSOR_DESCRIPTOR_DIGEST")
    a.expect(state_path.is_file() and db_path.is_file(), "V6_PREDECESSOR_ORIGINAL_FILES_REQUIRED")
    previous = _strict_json(state_path.read_text())
    a.expect(_sha(state_path) == desc.get("campaign_state_sha256") and _sha(db_path) == desc.get("ledger_sha256"),
             "V6_PREDECESSOR_STATE_AND_DB_BYTES")
    a.expect(_digest(desc.get("snapshot")) == desc.get("snapshot_digest"), "V6_PREDECESSOR_NATIVE_SNAPSHOT_DIGEST")
    if declared:
        a.expect(declared.get("campaign_state_sha256") == desc.get("campaign_state_sha256"),
                 "V6_RUNNER_PREDECESSOR_STATE_BINDING")
    report = _audit_predecessor_native(desc, previous, previous_root, v0, source, a)
    a.expect(len(previous.get("items", [])) == 52 and
             all(r.get("status") in TERMINAL for r in previous["items"][:26]), "V6_PREDECESSOR_MICRO_ALL_TERMINAL")
    a.expect(bundle.get("items", [])[:26] == previous["items"][:26], "V6_MICRO_ROWS_BYTE_EQUIVALENT")
    a.expect(_rows(bundle.get("scenes"))[:6] == _rows(previous.get("scenes"))[:6], "V6_MICRO_SCENES_UNMODIFIED")
    old_partial = [r["item_id"] for r in previous["items"][26:] if r.get("status") not in UNSTARTED]
    a.expect(bundle.get("predecessor_partial_item_ids", declared.get("predecessor_partial_item_ids")) == old_partial,
             "V6_ORIGINAL_FAILED_MACRO_ATTEMPTS_EXPLICITLY_RETAINED")
    return previous, previous_root, report


def _audit(bundle, v0, root, source, previous_root, a):
    registry_path = v0 / "registry/formal_items.jsonl"
    registry = [_strict_json(l) for l in registry_path.read_text().splitlines() if l.strip()]
    specs = {r["item_id"]: r for r in registry}
    a.expect(bundle.get("mode", bundle.get("execution_mode")) == "real_api" and bundle.get("phase") == "V6" and
             bundle.get("epoch_id") == "macro-precision-report-r3", "V6_EXPLICIT_REAL_MACRO_EPOCH")
    a.expect(bundle.get("campaign_id") == CAMPAIGN and len(registry) == len(specs) == 52 and
             bundle.get("registry_sha256") == _sha(registry_path), "V6_SAME_CAMPAIGN_ORIGINAL_52_REGISTRY")
    ledger = bundle["ledger"]
    previous, previous_root, previous_audit = _predecessor(bundle, ledger, v0, source, previous_root, a)
    accounting = _real_ledger(ledger, registry, v0, a)
    schemas = _source_pins(ledger, root, source, a, v0)
    _authority_handover(ledger, root, a)
    items = _rows(bundle["items"]); imap = {r["item_id"]: r for r in items}
    a.expect(len(items) == len(imap) == 52 and set(imap) == set(specs), "V6_ALL_52_ROWS_RETAINED")
    calls = _rows(ledger.get("calls")); dispatched = {c["call_id"]: c for c in calls if c.get("dispatched")}
    by_item = {iid: [cid for cid, c in dispatched.items() if c["item_id"] == iid] for iid in specs}
    scenes = {s["scene_id"]: s for s in _rows(bundle.get("scenes"))}
    frozen_dags = {d: _strict_json((v0 / "dags" / (d + ".json")).read_text()) for d in ("micro", "macro")}
    raw, raw_calls, inputs, cpu_audits = {}, {}, {}, {}
    for ordinal, row in enumerate(items, 1):
        iid = row["item_id"]
        if not a.expect(iid in specs, "V6_REGISTERED_ITEM", iid):
            continue
        spec = specs[iid]
        for key in ("domain", "kind", "task_id", "policy", "scene_id", "execution_ordinal"):
            if key in row:
                a.expect(row[key] == spec[key], "V6_REGISTERED_ITEM_UNMODIFIED", iid + ":" + key)
        if ordinal <= 26:
            a.expect(not by_item[iid], "V6_NO_MICRO_REDISPATCH", iid)
            old_view = _load_item_export(row, Path(ledger["predecessor"]["snapshot"]["predecessor"]["root"]), a)
            if isinstance(old_view, dict): raw[iid] = old_view
            continue
        a.expect(spec["domain"] == "macro", "V6_ACTIVE_ITEMS_MACRO_ONLY", iid)
        status = row.get("status")
        a.expect(status in TERMINAL | {"not_started", "running"}, "V6_ITEM_STATUS", iid)
        touched = status not in UNSTARTED
        a.expect(row.get("run_count") == int(touched), "V6_NO_RESAMPLE_OR_EPOCH_RERUN", iid)
        ids = row.get("physical_dispatch_ids", [])
        a.expect(len(ids) == len(set(ids)) and set(ids) == set(by_item[iid]), "V6_ITEM_CENTRAL_DISPATCH_BIJECTION", iid)
        if not touched:
            a.expect(not ids and not row.get("raw_export"), "V6_UNSTARTED_ITEM_NO_NEW_WORK", iid)
            continue
        start = row.get("started_at", row.get("started_at_utc"))
        deadline = row.get("deadline_at", row.get("deadline_utc"))
        a.expect(bool(start) and bool(deadline) and (_utc(deadline) - _utc(start)).total_seconds() == 1800,
                 "V6_FIXED_ITEM_DEADLINE", iid)
        view = _load_item_export(row, root, a)
        if not a.expect(isinstance(view, dict), "V6_STARTED_RAW_EXPORT_REQUIRED", iid):
            continue
        raw[iid] = view
        qualified = spec["kind"] == "prefix" and scenes.get(spec.get("scene_id"), {}).get("qualified") is True
        _raw_result(view, spec, status, a, frozen_dags["macro"], qualified)
        for result in _rows(view.get("results")):
            for cid in result.get("call_ids", []):
                snapshot = result.get("input_snapshot")
                a.expect(cid not in inputs or inputs[cid] == snapshot, "V6_CLONED_CALL_INPUT_IDENTICAL", cid)
                inputs[cid] = snapshot
        for call in _rows(view.get("calls")):
            cid = call["call_id"]
            a.expect(call.get("fixture_only") is False and call.get("mode") == "real" and call.get("request_sent") is True,
                     "V6_RAW_CALL_IS_REAL_INTENT", cid)
            a.expect(cid not in raw_calls or raw_calls[cid] == call, "V6_PREFIX_CALL_COPIES_IDENTICAL", cid)
            raw_calls[cid] = call
        # Every touched macro retains the same physical and causal checks. Safe
        # failure need not have completed business output to pass record audit.
        if root is not None:
            from .cpu_checker import audit_export
            report = audit_export(view, root / "files", v0, ledger=ledger, schemas=schemas)
            cpu_audits[iid] = report
            a.expect(report.get("passed") is True, "V6_REAL_CPU_PHYSICAL_AUDIT", iid,
                     report.get("issues", [])[:8])
            if report.get("passed"): a.checks += report.get("checks", 0)
    a.expect(set(raw_calls) == set(dispatched), "V6_ACTIVE_RAW_CALL_LEDGER_BIJECTION")
    http = _http_calls(calls, raw_calls, ledger, root, a, schemas, inputs)
    scene_specs = _strict_json((v0 / "registry/formal_scenes.json").read_text())["scenes"]
    matrix = _scenes(bundle, scene_specs, imap, raw, v0, a)
    checkpoints = _checkpoints(bundle, ledger, a)
    active_items = {iid: row for iid, row in imap.items() if specs[iid]["domain"] == "macro"}
    active_specs = {iid: row for iid, row in specs.items() if row["domain"] == "macro"}
    _runner_events(bundle.get("events", []), active_items, active_specs, a)
    a.expect(bundle.get("real_api_requests") == accounting["total_v4_v6_physical_dispatches"], "V6_RUNNER_TOTAL_REAL_DISPATCH_COUNT")
    if "epoch_real_api_requests" in bundle:
        a.expect(bundle["epoch_real_api_requests"] == len(dispatched), "V6_RUNNER_EPOCH_DISPATCH_COUNT")
    a.expect(bundle.get("actual_api_cost_nano_usd") == accounting["total_v4_v6_known_cost_nano_usd"], "V6_RUNNER_TOTAL_COST")
    touched = [r for r in items if r.get("status") not in UNSTARTED]
    healthy = all(r["status"] == "completed_correct" if specs[r["item_id"]]["kind"] != "prefix" else
                  scenes.get(specs[r["item_id"]]["scene_id"], {}).get("qualified") is True for r in touched)
    return {"passed": not a.issues, "business_healthy": healthy and bool(touched), "checks": a.checks,
            "issues": a.issues, "accounting": accounting, "http": http, "matrix": matrix,
            "checkpoint_audit": checkpoints, "predecessor_audit": {k: previous_audit.get(k) for k in ("passed", "checks", "statistics")},
            "cpu_audits": cpu_audits,
            "statistics": {"registered_items": 52, "inherited_micro_items": 26,
                "started_macro_items": sum(r.get("status") not in UNSTARTED for r in items[26:]),
                "terminal_status_counts": dict(Counter(r["status"] for r in items)),
                "all_items_processed": all(r.get("status") in TERMINAL for r in items),
                "epoch_physical_live_dispatches": len(dispatched),
                "physical_live_dispatches": accounting["total_v4_v6_physical_dispatches"],
                "confirmed_provider_receipts": http["confirmed_provider_receipts"]},
            "limitations": ["The old failed Adult attempt remains in the predecessor and is counted in total expenditure.",
                "Provider usage times frozen catalog prices is an estimate, not a verified account debit.",
                "Real intent is a conservative dispatch fence, not packet capture.",
                "The approved wire pattern and numeric bounds are omitted; original local validation remains mandatory."]}


def _real_ledger(ledger, registry, v0, a):
    config, binding = ledger["config"], ledger["config"]["binding"]
    previous = ledger["predecessor"]; old = previous["snapshot"]
    calls = _rows(ledger.get("calls"))
    old_calls = _flatten_calls(old)
    all_calls = old_calls + calls
    a.expect(ledger.get("schema_version") == "sr-v6-budget-snapshot-v1" and
             config.get("schema_version") == "sr-v6-budget-config-v1" and
             ledger.get("execution_mode") == config.get("execution_mode") == "real_api" and
             ledger.get("simulated") is False, "V6_NATIVE_REAL_LEDGER")
    a.expect(ledger.get("campaign_id") == config.get("campaign_id") == CAMPAIGN, "V6_LEDGER_SAME_CAMPAIGN")
    fixed = dict(model="api-glm-5.3-flash", base_url="https://tritonai-api.ucsd.edu/v1", input_nano_usd_per_token=150,
        output_nano_usd_per_token=500, max_input_tokens=4000, max_output_tokens=2048, financial_input_allowance=6000,
        financial_reservation_nano_usd_per_dispatch=RESERVATION, reasoning_effort="low", total_request_deadline_seconds=120,
        simulated=False, real_requests_authorized=True, automatic_http_retries=0, execution_mode="real_api")
    a.expect(all(binding.get(k) == v and type(binding.get(k)) is type(v) for k, v in fixed.items()), "V6_PINNED_REAL_BINDING")
    allowed = binding.get("allowed_response_models")
    a.expect(isinstance(allowed, list) and bool(allowed) and set(allowed) <= {"api-glm-5.3-flash", "glm-5.3-flash"},
             "V6_ALLOWED_RESPONSE_MODELS")
    a.expect(_digest(binding) == config.get("binding_digest"), "V6_BINDING_DIGEST")
    registry_sha, baseline_sha = _sha(v0 / "registry/formal_items.jsonl"), _sha(v0 / "budget/historical_baseline.json")
    a.expect(ledger.get("registry") == registry and config.get("registry_sha256") == registry_sha, "V6_UNMODIFIED_REGISTRY")
    a.expect(config.get("predecessor_digest") == previous.get("descriptor_digest") and
             config.get("predecessor_ledger_sha256") == previous.get("ledger_sha256") and
             config.get("epoch_physical_call_cap") == 434 and
             config.get("continuation_scope") == "explicit fresh macro repair round"
             and config.get("round_id") == "macro-precision-report-r3"
             and config.get("round_item_caps_reset") is True and config.get("round_kind_caps_reset") is True and config.get("inherited_kind_counts_retained") is True
             and config.get("per_request_reservation_nano_usd") == RESERVATION and config.get("output_token_cap") == 2048, "V6_CONFIG_PREDECESSOR_BINDING")
    authority, grant = config.get("authority", {}), config.get("grant", {})
    a.expect(authority.get("execution_mode") == "real_api" and authority.get("baseline_sha256") == baseline_sha and
             all(isinstance(authority.get(k), str) and Path(authority[k]).is_absolute() for k in ("ledger_path", "lock_root")) and
             ledger.get("campaign_budget_ref") == authority.get("ledger_path") and
             authority.get("lock_root") == old["authority"]["lock_root"] and
             authority.get("ledger_path") != old["authority"]["ledger_path"], "V6_SHARED_AUTHORITY_NEW_LEDGER")
    fields = V4_GRANT_FIELDS | {"predecessor_digest", "max_epoch_physical_calls", "round_id", "new_macro_round_slots", "round_item_caps_reset"}
    a.expect(set(grant) == fields and grant.get("schema_version") == "sr-v6-runtime-grant-v1" and
             grant.get("record_type") == "V6RuntimeGrant" and grant.get("authorized") is True and
             grant.get("execution_mode") == "real_api" and bool(grant.get("grant_id")) and
             isinstance(grant.get("authorization_reference"), str) and bool(grant["authorization_reference"].strip()),
             "V6_NEW_EXPLICIT_BOUND_GRANT")
    for k, expected in dict(campaign_id=CAMPAIGN, binding_digest=_digest(binding), registry_sha256=registry_sha,
        baseline_sha256=baseline_sha, ledger_path=authority.get("ledger_path"), lock_root=authority.get("lock_root"),
        max_new_physical_calls=640, max_epoch_physical_calls=434, max_cumulative_cost_nano_usd=MAX_COST,
        round_id="macro-precision-report-r3", new_macro_round_slots=26, round_item_caps_reset=True,
        predecessor_digest=previous.get("descriptor_digest")).items():
        a.expect(grant.get(k) == expected and type(grant.get(k)) is type(expected), "V6_GRANT_IDENTITY_BINDING", k)
    a.expect(config.get("grant_digest") == _digest(grant), "V6_GRANT_DIGEST")
    a.expect(ledger.get("baseline") == old.get("baseline") == _strict_json((v0 / "budget/historical_baseline.json").read_text()),
             "V6_ORIGINAL_BASELINE_IMPORTED_ONCE")
    init = [e for e in ledger.get("events", []) if e.get("kind") == "initialize"]
    expected_init = dict(config=config, baseline=ledger.get("baseline"), predecessor_digest=previous.get("descriptor_digest"), predecessor=previous)
    a.expect(len(init) == 1 and init[0].get("seq") == 1 and init[0].get("body") == expected_init, "V6_ORIGINAL_INITIALIZATION")
    ids = [c["call_id"] for c in all_calls]; attempts = [c["attempt_id"] for c in all_calls]
    a.expect(len(set(ids)) == len(ids) <= 640 and len(calls) <= 434, "V6_GLOBAL_640_AND_EPOCH_434_CALL_CAPS")
    a.expect(len(set(attempts)) == len(attempts), "V6_ATTEMPT_IDENTITIES_NOT_REUSED")
    a.expect(all(c.get("domain") == "macro" for c in calls), "V6_NO_MICRO_ACTIVE_CALLS")
    specs = {r["item_id"]: r for r in registry}; hard = []
    for c in calls:
        cid, iid = c["call_id"], c["item_id"]
        if not a.expect(iid in specs and specs[iid]["domain"] == "macro", "V6_REGISTERED_MACRO_CALL_OWNER", cid):
            continue
        a.expect(c.get("domain") == specs[iid]["domain"] and c.get("kind") == specs[iid]["kind"] and
                 c.get("reserved_cost_nano_usd") == RESERVATION, "V6_CALL_IDENTITY_RESERVATION", cid)
        usage = _usage(c.get("raw_usage"))
        if c.get("status") == "settled":
            if a.expect(usage is not None, "V6_SETTLED_RAW_USAGE", cid):
                cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
                a.expect(c.get("usage") == usage and c.get("known_cost_nano_usd") == cost and c.get("held_cost_nano_usd") == 0,
                         "V6_EXACT_USAGE_COST_NO_CLIPPING", cid)
                if usage["prompt_tokens"] > 4000 or usage["completion_tokens"] > 2048 or cost > RESERVATION:
                    hard.append(cid)
        else:
            a.expect(c.get("status") in {"reserved", "dispatched", "uncertain"} and c.get("known_cost_nano_usd") == 0 and
                     c.get("held_cost_nano_usd") == RESERVATION, "V6_NEW_UNKNOWN_FULL_HOLD", cid)
            if c.get("status") == "uncertain": hard.append(cid)
    def totals(rows):
        return dict(calls_reserved_or_spent=len(rows), calls_dispatched=sum(c.get("dispatched") is True for c in rows),
                    known_cost_nano_usd=sum(c.get("known_cost_nano_usd", 0) for c in rows),
                    held_cost_nano_usd=sum(c.get("held_cost_nano_usd", 0) for c in rows),
                    domain_counts={d: sum(c.get("domain") == d for c in rows) for d in ("micro", "macro")},
                    item_counts={iid: sum(c.get("item_id") == iid for c in rows) for iid in specs},
                    kind_counts={d: {k: sum(c.get("domain") == d and c.get("kind") == k for c in rows)
                        for k in ("control", "prefix", "branch")} for d in ("micro", "macro")})
    total, epoch = totals(all_calls), totals(calls)
    for scope, calculated in (("budget", total), ("epoch_budget", epoch)):
        for k, expected in calculated.items():
            a.expect(ledger.get(scope, {}).get(k) == expected, "V6_REBUILT_" + scope.upper(), k)
    a.expect(all(n <= 320 for n in total["domain_counts"].values()), "V6_SHARED_DOMAIN_320_CAP")
    for iid, n in epoch["item_counts"].items():
        a.expect(n <= specs[iid]["limits"]["physical_llm_call_cap"], "V6_SHARED_ITEM_CALL_CAP", iid)
    for d, counts in epoch["kind_counts"].items():
        for kind, n in counts.items():
            a.expect(n <= config["domain_kind_call_caps"][kind], "V6_SHARED_KIND_CALL_CAP", d + ":" + kind)
    cum = ledger["cumulative_budget"]
    a.expect(cum.get("baseline_calls") == BASE_CALLS and cum.get("baseline_known_cost_nano_usd") == BASE_KNOWN and
             cum.get("baseline_held_cost_nano_usd") == BASE_HELD and cum.get("old_unknown_reservation_released") is False,
             "V6_BASELINE_UNKNOWN_NOT_RELEASED")
    known = BASE_KNOWN + total["known_cost_nano_usd"]; held = BASE_HELD + total["held_cost_nano_usd"]
    adjustment = sum(max(0, c.get("late_known_exposure_nano_usd", 0) - c.get("known_cost_nano_usd", 0) -
                         c.get("held_cost_nano_usd", 0)) for c in all_calls)
    for k, expected in dict(cumulative_calls=BASE_CALLS + total["calls_dispatched"], known_cost_nano_usd=known,
        held_cost_nano_usd=held, known_plus_held_nano_usd=known + held, max_cost_nano_usd=MAX_COST,
        unsettled_exposure_adjustment_nano_usd=adjustment,
        risk_adjusted_known_plus_held_nano_usd=known + held + adjustment,
        risk_adjusted_overrun=known + held + adjustment > MAX_COST).items():
        a.expect(cum.get(k) == expected, "V6_CUMULATIVE_HISTORY_AND_UNKNOWN_CARRY", k)
    a.expect(ledger.get("real_api_requests") == total["calls_dispatched"] and
             ledger.get("epoch_real_api_requests") == epoch["calls_dispatched"] and
             ledger.get("real_incremental_cost_nano_usd") == total["known_cost_nano_usd"] and
             ledger.get("epoch_real_incremental_cost_nano_usd") == epoch["known_cost_nano_usd"], "V6_REAL_EPOCH_AND_CUMULATIVE_COUNTERS")
    if known + held + adjustment > MAX_COST: hard.append("cumulative_cost")
    if hard:
        a.expect(ledger.get("status") in {"quarantined", "stopped", "paused"} and bool(ledger.get("pause_reason")),
                 "V6_ACTIVE_ANOMALY_HARD_STOP", detail=hard)
    _late_epoch(ledger, {c["call_id"]: c for c in calls}, a)
    events = _ledger_events_epoch(ledger, {c["call_id"]: c for c in calls}, a)
    return dict(epoch_physical_dispatches=epoch["calls_dispatched"], epoch_known_cost_nano_usd=epoch["known_cost_nano_usd"],
        epoch_unknown_hold_nano_usd=epoch["held_cost_nano_usd"], total_v4_v6_physical_dispatches=total["calls_dispatched"],
        total_v4_v6_known_cost_nano_usd=total["known_cost_nano_usd"],
        historical_unknown_hold_nano_usd=old["cumulative_budget"]["held_cost_nano_usd"],
        cumulative_known_plus_held_nano_usd=known + held,
        risk_adjusted_known_plus_held_nano_usd=known + held + adjustment,
        events=events, provider_account_debit_verified=False)


def _late_epoch(ledger, calls, a):
    rows = _rows(ledger.get("late_receipts")); maxima = {}
    a.expect(rows == [dict(call_id=e.get("call_id"), receipt=e.get("body"))
                     for e in ledger.get("events", []) if e.get("kind") == "late_receipt"], "V6_LATE_RECEIPTS_PRESERVED")
    for row in rows:
        cid, receipt = row["call_id"], row["receipt"]
        a.expect(cid in calls and calls[cid].get("status") == "uncertain", "V6_LATE_ONLY_CURRENT_UNKNOWN", cid)
        usage = _usage(receipt.get("raw_usage"))
        if usage:
            cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
            a.expect(receipt.get("exact_cost_nano_usd") == cost and receipt.get("manual_reconciliation_required") is True,
                     "V6_LATE_COST_RETAINED_WITHOUT_RELEASE", cid)
            maxima[cid] = max(maxima.get(cid, 0), cost)
    for cid, call in calls.items():
        a.expect(call.get("late_known_exposure_nano_usd", 0) == maxima.get(cid, 0), "V6_LATE_EXPOSURE_REBUILT", cid)


def _ledger_events_epoch(ledger: dict, call_map: dict[str, dict], a: _Audit) -> dict:
    events = _rows(ledger.get("events"))
    old = ledger["predecessor"]["snapshot"]
    historical_risk = old["cumulative_budget"].get("risk_adjusted_known_plus_held_nano_usd", old["cumulative_budget"]["known_plus_held_nano_usd"])
    seqs = [e["seq"] for e in events]
    a.expect(seqs == list(range(1, len(events) + 1)), "LEDGER_EVENT_SEQUENCE")
    last: dict[str, dict] = {}
    phase: dict[str, str] = {}
    started_items: set[str] = set()
    finalized_items: dict[str, dict] = {}
    item_insert_order: list[str] = []
    checkpoint_events = []
    first_stop_seq = None
    for event in events:
        seq, kind = event["seq"], event["kind"]
        if event.get("event_digest"):
            a.expect(event["event_digest"] == _digest({k: v for k, v in event.items() if k not in {"event_digest", "seq"}}),
                     "LEDGER_EVENT_DIGEST", str(seq))
        cid, body = event.get("call_id"), event.get("body", {})
        if kind == "quarantine":
            first_stop_seq = first_stop_seq or seq
            for row in body.get("calls", []):
                qid = row["call_id"]
                a.expect(qid in call_map and phase.get(qid) in {"reserved", "dispatched"},
                         "UNKNOWN_AFTER_STARTED_CALL", qid)
                phase[qid] = "uncertain"
                last[qid] = row
        elif kind in {"reserve", "dispatch", "settle"}:
            row = body.get("call", body)
            if not a.expect(cid in call_map and isinstance(row, dict) and row.get("call_id") == cid,
                            "CALL_EVENT_RESOLVES", str(seq)):
                continue
            a.expect(event.get("item_id") == row.get("item_id"), "CALL_EVENT_IDENTITY", cid)
            if kind == "reserve":
                a.expect(cid not in phase, "RESERVE_ONCE", cid)
                a.expect(first_stop_seq is None, "NO_DISPATCH_AFTER_HARD_STOP", cid)
                a.expect(all(p == "settled" for p in phase.values()), "NO_RESERVE_WHILE_UNSETTLED", cid)
                prior_known = sum(r.get("known_cost_nano_usd", 0) for r in last.values())
                prior_held = sum(r.get("held_cost_nano_usd", 0) for r in last.values())
                a.expect(historical_risk + prior_known + prior_held + RESERVATION <= MAX_COST,
                         "RESERVATION_ADMITTED_WITHIN_ONE_DOLLAR", cid)
                phase[cid] = "reserved"
                started_items.add(row["item_id"])
                if row["item_id"] not in item_insert_order:
                    item_insert_order.append(row["item_id"])
            elif kind == "dispatch":
                a.expect(phase.get(cid) == "reserved", "DISPATCH_ONCE_AFTER_RESERVE", cid)
                a.expect(first_stop_seq is None, "NO_DISPATCH_AFTER_HARD_STOP", cid)
                phase[cid] = "dispatched"
            elif kind == "settle":
                a.expect(phase.get(cid) == "dispatched", "SETTLE_ONCE_AFTER_DISPATCH", cid)
                phase[cid] = "settled"
                usage = row.get("usage") or {}
                if usage.get("prompt_tokens", 0) > 4000 or usage.get("completion_tokens", 0) > 2048 or row.get("known_cost_nano_usd", 0) > RESERVATION:
                    first_stop_seq = first_stop_seq or seq
            last[cid] = row
        elif kind == "late_receipt":
            a.expect(phase.get(cid) == "uncertain", "LATE_AFTER_UNKNOWN_ONLY", cid or "")
        elif kind == "finalize_item":
            iid = event.get("item_id")
            a.expect(iid == body.get("item_id") and iid not in finalized_items,
                     "ITEM_FINALIZED_ONCE", iid or "")
            # finalize_item uses INSERT OR REPLACE: SQLite deletes an existing
            # row and appends the replacement at the end of rowid order.
            if iid in item_insert_order:
                item_insert_order.remove(iid)
            item_insert_order.append(iid)
            finalized_items[iid] = body
        elif kind == "checkpoint":
            d = body.get("checkpoint_digest")
            a.expect(d == _digest({k: v for k, v in body.items() if k != "checkpoint_digest"}),
                     "LEDGER_CHECKPOINT_DIGEST", str(seq))
            a.expect(all(v == "settled" for v in phase.values()) and started_items <= set(finalized_items),
                     "LEDGER_CHECKPOINT_DURABLY_QUIESCENT", str(seq))
            a.expect(body.get("calls_digest") == _digest(list(last.values())) and
                     body.get("items_digest") == _digest([finalized_items[i] for i in item_insert_order
                                                          if i in finalized_items]),
                     "LEDGER_CHECKPOINT_CONTENT_DIGEST", str(seq))
            formal_order = [r["item_id"] for r in ledger.get("registry", []) if r["domain"] == "macro"]
            completed = body.get("completed_item_ids", [])
            a.expect(completed == formal_order[:len(completed)] and set(completed) == set(finalized_items),
                     "LEDGER_CHECKPOINT_FORMAL_PREFIX", str(seq))
            a.expect(body.get("carried_completed_micro_item_ids") == [r["item_id"] for r in ledger["registry"] if r["domain"] == "micro"] and
                     body.get("predecessor_digest") == ledger["predecessor"]["descriptor_digest"],
                     "V6_CHECKPOINT_MICRO_CARRY_AND_PREDECESSOR", str(seq))
            a.expect(body.get("config_digest") == _digest(ledger.get("config", {})) and
                     body.get("authority") == ledger.get("config", {}).get("authority"),
                     "LEDGER_CHECKPOINT_AUTHORITY_BINDING", str(seq))
            checkpoint_events.append({"seq": seq, "checkpoint_digest": d,
                                      "completed_items": len(completed)})
        elif kind in {"stop", "pause"}:
            first_stop_seq = first_stop_seq or seq
    a.expect(set(last) == set(call_map), "ALL_CENTRAL_CALLS_HAVE_EVENT_HISTORY")
    for cid, call in call_map.items():
        if cid in last:
            for field in ("status", "dispatched", "known_cost_nano_usd", "held_cost_nano_usd", "item_id", "attempt_id"):
                a.expect(last[cid].get(field) == call.get(field), "EVENT_FINAL_CALL_MATCH", cid + ":" + field)
    return {"count": len(events), "first_hard_stop_seq": first_stop_seq,
            "reserved_calls_rebuilt": len(phase), "checkpoints": checkpoint_events}




def _authority_handover(ledger, root, a):
    if root is None:
        a.expect(False, "V6_HANDOVER_REQUIRES_EXPORTED_FILES")
        return
    expected_new = {**ledger["config"]["authority"], "campaign_id": CAMPAIGN,
                    "config_digest": _digest(ledger["config"])}
    expected = dict(schema_version="sr-v6-authority-handover-v1",
                    previous_authority=ledger["predecessor"]["authority_pin"],
                    new_authority=expected_new,
                    predecessor_digest=ledger["predecessor"]["descriptor_digest"],
                    predecessor_ledger_sha256=ledger["predecessor"]["ledger_sha256"],
                    grant_digest=ledger["config"]["grant_digest"],
                    unknown_reservation_released=False)
    for name, value in (("authority_handover.intent.json", expected),
                        ("authority_handover.commit.json", {**expected, "committed": True}),
                        ("authority_pin.json", expected_new)):
        path = root / "frozen" / name
        a.expect(path.is_file() and _strict_json(path.read_text()) == value,
                 "V6_ORIGINAL_SHARED_AUTHORITY_HANDOVER", name)
