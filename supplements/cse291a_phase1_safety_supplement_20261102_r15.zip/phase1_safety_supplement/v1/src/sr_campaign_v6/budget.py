"""An explicit new macro epoch under the existing cumulative budget authority.

V4 files are immutable evidence. Its unknown receipt stays unknown and its hold
stays carried. Only the authority pin is atomically handed over; no old ledger
row, item, receipt or event is changed or presented as settled.
"""
from copy import deepcopy
import fcntl
import json
import os
from pathlib import Path
import sqlite3
import tempfile

from . import engine as _engine
from .engine import (DurableV3Budget, V3BudgetError, RESERVATION,
                     MAX_COST, MAX_CALLS, _digest, _json, _sha, _require)
from sr_campaign_v5.budget import DurableV5Budget
from sr_campaign_v4.budget import GRANT_FIELDS as V4_GRANT_FIELDS

ENGINE_SHA256 = "548e90f864f3f053f47b6e105a7ad42f4c9e27885b31e93c84d2c7d681681706"
V5_LEDGER_SHA256 = "f3be3f915e6e111f3bbade694e7fc1a49e835cbbd2db0e44507021239913afb2"
V5_STATE_SHA256 = "265907365c28e05b91374b736b7084043de46eaf4dc26f8939319f760f19fe83"
V5_STOP_SHA256 = "63dd11a9908dce8c6fa2adc07181e7f1d90065767800d7acd461bffa3c508242"


def _real_binding(binding):
    _require(isinstance(binding, dict), "V6_BINDING_INVALID")
    fixed = dict(model="api-glm-5.3-flash", base_url="https://tritonai-api.ucsd.edu/v1",
        input_nano_usd_per_token=150, output_nano_usd_per_token=500,
        max_input_tokens=4000, max_output_tokens=2048, financial_input_allowance=6000,
        financial_reservation_nano_usd_per_dispatch=RESERVATION, reasoning_effort="low",
        total_request_deadline_seconds=120, simulated=False, real_requests_authorized=True,
        automatic_http_retries=0, execution_mode="real_api")
    _require(all(binding.get(k)==v and type(binding.get(k)) is type(v) for k,v in fixed.items()),
             "V6_BINDING_INVALID")
    _require(isinstance(binding.get("allowed_response_models"),list)
             and binding["allowed_response_models"] and set(binding["allowed_response_models"]) <=
             {"api-glm-5.3-flash", "glm-5.3-flash"}
             and binding.get("cached_input_nano_usd_per_token") is None,
             "V6_BINDING_INVALID")
    for key in ("template_digest","schema_digest","guard_digest","correction_digest"):
        value=binding.get(key)
        _require(isinstance(value,str) and len(value)==64 and all(c in "0123456789abcdef" for c in value),
                 "V6_NEW_RUNTIME_BINDING_REQUIRED")
    return deepcopy(binding)


def inherited_calls(snapshot):
    """Flatten disjoint epochs; historical baseline is deliberately not a call list."""
    p=snapshot.get("predecessor",{}).get("snapshot")
    return (inherited_calls(p) if p is not None else []) + deepcopy(snapshot["calls"])


V6BudgetError = V3BudgetError
GRANT_FIELDS = V4_GRANT_FIELDS | {"predecessor_digest", "max_epoch_physical_calls", "round_id", "new_macro_round_slots", "round_item_caps_reset"}


def read_predecessor(root, stop_receipt_path=None):
    """Read the native closed V5 DB, preserving its explicitly stale state file.

    Fixed physical pins deliberately prohibit rebuilding the unavailable binary
    from a semantic export. Tests patch this reader with visibly synthetic data.
    """
    root=Path(root).resolve(); db=root/"budget/central.sqlite"; sp=root/"campaign_state.json"
    receipt_path=Path(stop_receipt_path).resolve() if stop_receipt_path else root.parent/"v5_hard_stop_receipt.json"
    _require(db.is_file() and sp.is_file() and receipt_path.is_file(), "V6_PREDECESSOR_MISSING")
    for path in [db, *sorted((root/"db").glob("*.sqlite"))]:
        _require(not Path(str(path)+"-wal").exists() and not Path(str(path)+"-journal").exists(),
                 "V6_PREDECESSOR_NOT_CLOSED")
    dbsha,statesha,stopsha=_sha(db),_sha(sp),_sha(receipt_path)
    _require(dbsha==V5_LEDGER_SHA256 and statesha==V5_STATE_SHA256 and stopsha==V5_STOP_SHA256,
             "V6_NATIVE_PREDECESSOR_PIN_MISMATCH")
    state=json.loads(sp.read_text()); stale=state["ledger"]; stop=json.loads(receipt_path.read_text())
    _require(stop.get("status")=="quiescent_hard_stop" and stop.get("all_current_calls_settled") is True
             and stop.get("all_stores_no_active_attempts") is True and not stop.get("active_cpu_or_http_children")
             and stop.get("epoch_call_count")==81 and stop.get("epoch_dispatched")==81
             and stop.get("epoch_known_nano_usd")==24_037_550 and stop.get("epoch_held_nano_usd")==0
             and stop.get("unknown_reservation_released") is False, "V6_PREDECESSOR_STOP_NOT_QUIESCENT")
    connection=sqlite3.connect(db.as_uri()+"?mode=ro&immutable=1",uri=True);connection.row_factory=sqlite3.Row
    try:
        config=json.loads(connection.execute("SELECT config FROM campaign").fetchone()[0])
        init=json.loads(connection.execute("SELECT body FROM events WHERE kind='initialize' ORDER BY seq LIMIT 1").fetchone()[0])
        _require(config==init["config"]==stale["config"] and config["schema_version"]=="sr-v5-budget-config-v1",
                 "V6_PREDECESSOR_CONFIG_MISMATCH")
        probe=object.__new__(DurableV5Budget);probe.connection=connection;probe.config=config
        probe.ref=config["authority"]["ledger_path"];probe.baseline=init["baseline"]
        probe.registry={r["item_id"]:r for r in stale["registry"]};probe.predecessor=init["predecessor"]
        observed=DurableV5Budget.snapshot(probe)
    finally: connection.close()
    _require(len(stale["calls"])==76 and len(observed["calls"])==81
             and stale["calls"]==observed["calls"][:76]
             and stale["events"]==observed["events"][:len(stale["events"])]
             and stale["predecessor"]==observed["predecessor"], "V6_STALE_STATE_NOT_DURABLE_PREFIX")
    calls=inherited_calls(observed)
    _require(len(calls)==206 and all(c["dispatched"] for c in calls)
             and all(c["status"]=="settled" for c in observed["calls"])
             and observed["cumulative_budget"]["known_cost_nano_usd"]==122_853_950
             and observed["cumulative_budget"]["held_cost_nano_usd"]==2_268_000
             and observed["budget"]["domain_counts"]=={"micro":121,"macro":85},
             "V6_PREDECESSOR_SCOPE_MISMATCH")
    stores=[]
    for path in sorted((root/"db").glob("*.sqlite")):
        con=sqlite3.connect(path.as_uri()+"?mode=ro&immutable=1",uri=True)
        try: doc=json.loads(con.execute("SELECT payload FROM document WHERE id=1").fetchone()[0])
        finally: con.close()
        _require(not doc["state"]["active_attempt_ids"] and not doc["state"]["unsettled_call_ids"],
                 "V6_PREDECESSOR_ACTIVE_STORE")
        stores.append({"relative_path":str(path.relative_to(root)),"sha256":_sha(path)})
    _require(bool(stores), "V6_PREDECESSOR_STORE_EVIDENCE_REQUIRED")
    pin={**config["authority"],"campaign_id":config["campaign_id"],"config_digest":_digest(config)}
    value=dict(schema_version="sr-v6-predecessor-v1",root=str(root),ledger_sha256=dbsha,
        campaign_state_sha256=statesha,snapshot=observed,snapshot_digest=_digest(observed),authority_pin=pin,
        stop_receipt_path=str(receipt_path),stop_receipt_sha256=stopsha,stop_receipt=stop,
        store_files=stores,source_of_truth="durable_native_sql",state_snapshot_current=False,
        state_epoch_calls=76,durable_epoch_calls=81)
    value["descriptor_digest"]=_digest(value)
    _require(_sha(db)==dbsha and _sha(sp)==statesha and _sha(receipt_path)==stopsha,
             "V6_PREDECESSOR_CHANGED")
    return value


def grant_template(*, campaign_id, binding, ledger_path, lock_root, v0_root, grant_id,
                   predecessor_root, predecessor_stop_receipt=None, authorization_reference="Awaiting explicit macro continuation authorization"):
    _real_binding(binding)
    p = read_predecessor(predecessor_root, predecessor_stop_receipt)
    root = Path(v0_root).resolve()
    return dict(schema_version="sr-v6-runtime-grant-v1", record_type="V6RuntimeGrant",
        grant_id=grant_id, campaign_id=campaign_id, authorized=False, execution_mode="real_api",
        binding_digest=_digest(binding), registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()), lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640, max_epoch_physical_calls=434,
        round_id="macro-precision-report-r3",new_macro_round_slots=26,round_item_caps_reset=True,
        max_cumulative_cost_nano_usd=MAX_COST, predecessor_digest=p["descriptor_digest"],
        authorization_reference=authorization_reference)


def validate_v6_grant(grant, *, binding, budget=None, campaign_id=None, ledger_path=None,
                      lock_root=None, v0_root=None, predecessor_root=None, predecessor=None, predecessor_stop_receipt=None):
    _real_binding(binding)
    if budget is not None:
        _require(budget.config.get("execution_mode") == "real_api", "V6_REAL_BUDGET_REQUIRED")
        campaign_id, ledger_path = budget.config["campaign_id"], budget.path
        lock_root, v0_root = budget.lock_root, budget.v0_root
        predecessor = budget.predecessor
        _require(budget.config["binding_digest"] == _digest(binding), "V6_GRANT_BINDING_MISMATCH")
    p = predecessor if predecessor is not None else read_predecessor(predecessor_root, predecessor_stop_receipt)
    _require(isinstance(grant, dict) and set(grant) == GRANT_FIELDS, "V6_GRANT_INVALID")
    _require(grant["schema_version"] == "sr-v6-runtime-grant-v1" and grant["record_type"] == "V6RuntimeGrant"
             and grant["execution_mode"] == "real_api", "V6_NEW_RUNTIME_GRANT_REQUIRED")
    _require(grant["authorized"] is True, "V6_REAL_REQUESTS_NOT_AUTHORIZED")
    _require(isinstance(grant["grant_id"], str) and grant["grant_id"]
             and isinstance(grant["authorization_reference"], str) and grant["authorization_reference"].strip(),
             "V6_GRANT_AUTHORIZATION_REFERENCE_REQUIRED")
    _require(all(x is not None for x in (campaign_id,ledger_path,lock_root,v0_root)), "V6_GRANT_IDENTITY_REQUIRED")
    root = Path(v0_root).resolve()
    expected = dict(campaign_id=campaign_id, binding_digest=_digest(binding),
        registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()), lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640, max_epoch_physical_calls=434,
        round_id="macro-precision-report-r3",new_macro_round_slots=26,round_item_caps_reset=True,
        max_cumulative_cost_nano_usd=MAX_COST, predecessor_digest=p["descriptor_digest"])
    _require(all(grant.get(k)==v and type(grant.get(k)) is type(v) for k,v in expected.items()),
             "V6_GRANT_BINDING_MISMATCH")
    if budget is not None:
        _require(_digest(grant) == budget.config["grant_digest"], "V6_GRANT_CHANGED")
    return deepcopy(grant)


def _atomic_json(path, value):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=".v6-", dir=path.parent)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,"w") as out:
            out.write(_json(value)+"\n"); out.flush(); os.fsync(out.fileno())
        os.replace(name,path)
        dfd = os.open(path.parent,os.O_RDONLY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        if os.path.exists(name): os.unlink(name)


class DurableV6Budget(DurableV3Budget):
    """A macro-only ledger carrying all predecessor exposure and all call caps."""
    def __init__(self,path,*,campaign_id,binding,v0_root,lock_root,grant,predecessor_root,predecessor_stop_receipt=None,resume_checkpoint=None):
        self.path, self.lock_root = Path(path).resolve(), Path(lock_root).resolve()
        self.ref, self.v0_root = str(self.path), Path(v0_root).resolve()
        self.connection, self._lock_fd, self._failed = None, None, False
        self.binding = _real_binding(binding)
        self.predecessor = read_predecessor(predecessor_root, predecessor_stop_receipt)
        self.grant = validate_v6_grant(grant,binding=self.binding,campaign_id=campaign_id,
            ledger_path=self.path,lock_root=self.lock_root,v0_root=self.v0_root,predecessor=self.predecessor)
        old = self.predecessor["snapshot"]
        self.baseline = deepcopy(old["baseline"])
        self.registry = {r["item_id"]:deepcopy(r) for r in old["registry"]}
        bpath, rpath = self.v0_root/"budget/historical_baseline.json", self.v0_root/"registry/formal_items.jsonl"
        _require(_sha(Path(_engine.__file__)) == ENGINE_SHA256, "V6_TRANSACTION_ENGINE_CHANGED")
        _require(json.loads(bpath.read_text()) == self.baseline
                 and _sha(bpath) == old["authority"]["baseline_sha256"]
                 and _sha(rpath) == old["config"]["registry_sha256"], "V6_FROZEN_INPUT_CHANGED")
        _require(str(self.lock_root) == old["authority"]["lock_root"]
                 and self.ref != old["campaign_budget_ref"], "V6_HISTORICAL_AUTHORITY_REQUIRED")
        self.config = {**deepcopy(old["config"]), "schema_version":"sr-v6-budget-config-v1",
            "campaign_id":campaign_id,"binding":deepcopy(self.binding),"binding_digest":_digest(self.binding),
            "grant":deepcopy(self.grant),"grant_digest":_digest(self.grant),
            "authority":{**old["authority"],"ledger_path":self.ref},
            "predecessor_digest":self.predecessor["descriptor_digest"],
            "predecessor_ledger_sha256":self.predecessor["ledger_sha256"],
            "epoch_physical_call_cap":434,"continuation_scope":"explicit fresh macro repair round",
            "per_request_reservation_nano_usd":RESERVATION,"output_token_cap":2048,
            "transaction_engine_sha256":ENGINE_SHA256,
            "transaction_engine":"separate frozen V6 copy; unchanged settlement semantics with2048-token reservation",
            "round_id":"macro-precision-report-r3",
            "round_item_caps_reset":True,"round_kind_caps_reset":True,
            "inherited_kind_counts_retained":True,
            "reset_reason":"Explicit user authorized a separately recorded macro repair round"}
        oldpin = self.predecessor["authority_pin"]
        newpin = {**self.config["authority"],"campaign_id":campaign_id,"config_digest":_digest(self.config)}
        self.lock_root.mkdir(parents=True,exist_ok=True)
        self._lock_fd = os.open(self.lock_root/("sr-v3-"+oldpin["baseline_sha256"]+".lock"),
                                os.O_CREAT|os.O_RDWR|os.O_CLOEXEC,0o600)
        try:
            try: fcntl.flock(self._lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: raise V6BudgetError("CAMPAIGN_LOCK_HELD")
            pinpath = self.lock_root/"authority.json"
            _require(pinpath.is_file(), "V6_OLD_AUTHORITY_PIN_MISSING")
            pin = json.loads(pinpath.read_text())
            _require(pin in (oldpin,newpin), "BUDGET_AUTHORITY_MISMATCH")
            self._verify_predecessor_files()
            intent = dict(schema_version="sr-v6-authority-handover-v1", previous_authority=oldpin,
                new_authority=newpin, predecessor_digest=self.predecessor["descriptor_digest"],
                predecessor_ledger_sha256=self.predecessor["ledger_sha256"],
                grant_digest=_digest(self.grant), unknown_reservation_released=False)
            intentpath, commitpath = self.lock_root/"v6_handover.intent.json", self.lock_root/"v6_handover.commit.json"
            if intentpath.exists():
                _require(json.loads(intentpath.read_text()) == intent, "V6_HANDOVER_INTENT_CONFLICT")
            else:
                _require(pin == oldpin and not self.path.exists(), "V6_HANDOVER_STATE_INVALID")
                _atomic_json(intentpath,intent)
            if commitpath.exists():
                _require(json.loads(commitpath.read_text()) == {**intent,"committed":True}, "V6_HANDOVER_COMMIT_CONFLICT")
                _require(pin == newpin, "V6_HANDOVER_STATE_INVALID")
            self.path.parent.mkdir(parents=True,exist_ok=True)
            self.connection = sqlite3.connect(self.path,isolation_level=None,timeout=5)
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("PRAGMA journal_mode=DELETE")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS campaign(singleton INTEGER PRIMARY KEY CHECK(singleton=1),config TEXT NOT NULL,status TEXT NOT NULL,reason TEXT);
                CREATE TABLE IF NOT EXISTS calls(call_id TEXT PRIMARY KEY,attempt_id TEXT UNIQUE NOT NULL,item_id TEXT NOT NULL,body TEXT NOT NULL,request_digest TEXT NOT NULL,settlement_digest TEXT);
                CREATE TABLE IF NOT EXISTS items(item_id TEXT PRIMARY KEY,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,call_id TEXT,item_id TEXT,at TEXT NOT NULL,body TEXT NOT NULL,event_digest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS receipts(provider_request_id TEXT PRIMARY KEY,call_id TEXT UNIQUE NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS late_receipts(id INTEGER PRIMARY KEY,call_id TEXT NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS checkpoints(id INTEGER PRIMARY KEY,body TEXT NOT NULL);
            """)
            current = self.connection.execute("SELECT * FROM campaign").fetchone()
            if current:
                _require(current["config"] == _json(self.config), "BUDGET_AUTHORITY_MISMATCH")
                _require(pin == newpin or (not self.calls() and not self.items()), "V6_HANDOVER_STATE_INVALID")
            else:
                _require(pin == oldpin, "V6_HANDOVER_LEDGER_MISSING")
                with self._transaction():
                    self.connection.execute("INSERT INTO campaign VALUES(1,?,'active',NULL)",(_json(self.config),))
                    self._event("initialize",body={"config":self.config,"baseline":self.baseline,
                        "predecessor_digest":self.predecessor["descriptor_digest"],"predecessor":self.predecessor})
            if pin == oldpin: _atomic_json(pinpath,newpin)
            if not commitpath.exists(): _atomic_json(commitpath,{**intent,"committed":True})
            # An interrupted new epoch is never made active by the handover.
            if current:
                if any(c["status"] != "settled" for c in self.calls()) or any(i["status"] == "in_progress" for i in self.items()):
                    self.quarantine(None,"REOPEN_WITH_UNFINISHED_PROGRESS")
                elif current["status"] == "active" and (self.calls() or self.items()):
                    latest = self.connection.execute("SELECT body FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
                    _require(isinstance(resume_checkpoint,dict),"CHECKPOINT_REQUIRED")
                    _require(latest is not None and json.loads(latest[0]) == resume_checkpoint
                             and self._checkpoint_body() == resume_checkpoint,"CHECKPOINT_MISMATCH")
                    with self._transaction(): self._event("reopen",body={"checkpoint_digest":resume_checkpoint["checkpoint_digest"]})
        except BaseException:
            self.close(); raise

    def _verify_predecessor_files(self):
        root=Path(self.predecessor["root"])
        _require(_sha(root/"budget/central.sqlite")==self.predecessor["ledger_sha256"]
                 and _sha(root/"campaign_state.json")==self.predecessor["campaign_state_sha256"]
                 and _sha(self.predecessor["stop_receipt_path"])==self.predecessor["stop_receipt_sha256"]
                 and all(_sha(root/p["relative_path"])==p["sha256"] for p in self.predecessor["store_files"]),
                 "V6_PREDECESSOR_CHANGED")

    def _active(self):
        try:
            validate_v6_grant(self.grant,binding=self.binding,budget=self)
            self._verify_predecessor_files()
            expected = {**self.config["authority"],"campaign_id":self.config["campaign_id"],"config_digest":_digest(self.config)}
            _require(json.loads((self.lock_root/"authority.json").read_text()) == expected,"BUDGET_AUTHORITY_MISMATCH")
        except V3BudgetError as exc:
            if self.connection is not None and not self.connection.in_transaction:
                self._reject(exc.code,evidence={"kind":"v6_authority_validation_failed"})
            raise
        return DurableV3Budget._active(self)

    def _macro(self,item_id):
        _require(item_id in self.registry,"REGISTRY_IDENTITY_MISMATCH")
        _require(self.registry[item_id]["domain"] == "macro","V6_COMPLETED_MICRO_IMMUTABLE")

    def check_admission(self,item_id,scope="item"):
        self._active(); self._macro(item_id)
        row = self.registry[item_id]
        _require(not any(c["status"] != "settled" for c in self.calls()),"UNKNOWN_SETTLEMENT")
        if scope == "item": ids = [item_id]
        elif scope in ("scene","pre_prefix"):
            _require(row["scene_id"] is not None,"SCENE_ADMISSION_MISMATCH")
            ids = [r["item_id"] for r in self.registry.values() if r["scene_id"] == row["scene_id"]
                   and (r["kind"] == "branch" or scope == "pre_prefix")]
        else: raise V6BudgetError("SCENE_ADMISSION_MISMATCH")
        _require(not any(i["item_id"] in ids for i in self.items()),"ITEM_ALREADY_STARTED")
        counts = self.snapshot()["epoch_budget"]["item_counts"]
        required = sum(self.registry[i]["limits"]["physical_llm_call_cap"] - counts[i] for i in ids)
        snap = self.snapshot()
        _require(snap["budget"]["calls_reserved_or_spent"] + required <= MAX_CALLS,"CALL_CAP_EXCEEDED")
        _require(snap["budget"]["domain_counts"]["macro"] + required <= 320,"DOMAIN_CALL_CAP_EXCEEDED")
        for kind,cap in self.config["domain_kind_call_caps"].items():
            needed = sum(self.registry[i]["limits"]["physical_llm_call_cap"] - counts[i]
                         for i in ids if self.registry[i]["kind"] == kind)
            _require(snap["epoch_budget"]["kind_counts"]["macro"][kind] + needed <= cap,
                     "KIND_CALL_CAP_EXCEEDED")
        _require(snap["cumulative_budget"]["risk_adjusted_known_plus_held_nano_usd"] + required*RESERVATION <= MAX_COST,
                 "MONEY_CAP_EXCEEDED")
        return dict(item_id=item_id,scope=scope,checked_item_ids=ids,required_call_capacity=required,
                    checked_cost_nano_usd=required*RESERVATION,additional_hold_created=False,passed=True)

    def reserve(self,record):
        _require(isinstance(record,dict),"CALL_RECORD_INVALID")
        self._macro(record.get("item_id"))
        if not self.connection.execute("SELECT 1 FROM calls WHERE call_id=?",(record.get("call_id"),)).fetchone():
            self._active()
            calls = inherited_calls(self.predecessor["snapshot"]) + self.calls()
            row = self.registry[record["item_id"]]
            for ok,code in ((len(calls)<640,"CALL_CAP_EXCEEDED"),
                (sum(c["domain"]==row["domain"] for c in calls)<320,"DOMAIN_CALL_CAP_EXCEEDED"),
                (sum(c["domain"]==row["domain"] and c["kind"]==row["kind"] for c in self.calls())<self.config["domain_kind_call_caps"][row["kind"]],"KIND_CALL_CAP_EXCEEDED"),
                (sum(c["item_id"]==row["item_id"] for c in self.calls())<row["limits"]["physical_llm_call_cap"],"ITEM_CALL_CAP_EXCEEDED"),
                (self.snapshot()["cumulative_budget"]["risk_adjusted_known_plus_held_nano_usd"]+RESERVATION<=MAX_COST,"MONEY_CAP_EXCEEDED"),
                (not any(c["call_id"]==record.get("call_id") or c["attempt_id"]==record.get("attempt_id") for c in inherited_calls(self.predecessor["snapshot"])),"V6_PREDECESSOR_CALL_REENTRY")):
                if not ok: self._reject(code)
        return DurableV3Budget.reserve(self,record)

    def settle(self,call_id,*,provider_request_id,raw_usage,evidence=None,failure_reason=None):
        if provider_request_id is not None and any(c["provider_request_id"] == provider_request_id
                                                   for c in inherited_calls(self.predecessor["snapshot"])):
            self._reject("CONFLICTING_PROVIDER_RECEIPT",call_id=call_id)
        return DurableV3Budget.settle(self,call_id,provider_request_id=provider_request_id,
            raw_usage=raw_usage,evidence=evidence,failure_reason=failure_reason)

    def record_unknown_receipt(self,call_id,*,raw_usage,provider_request_id=None,evidence=None,
                               reason="UNKNOWN_PROVIDER_RECEIPT"):
        proof = {**deepcopy(evidence or {}),"unknown_receipt_reason":reason,
                 "receipt_identity_unverified":provider_request_id is None}
        result = self.settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                             evidence=proof,failure_reason=reason)
        try: _engine._parse_usage(raw_usage)
        except V3BudgetError: return result
        if result["status"] == "uncertain":
            result = self.settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                                 evidence=proof,failure_reason=reason)
        return result

    def finalize_item(self,item_id,status,evidence_digest):
        self._macro(item_id)
        return DurableV3Budget.finalize_item(self,item_id,status,evidence_digest)

    def _checkpoint_body(self):
        self._active()
        calls,items = self.calls(),self.items()
        _require(all(c["status"] == "settled" for c in calls)
                 and all(i["status"] in _engine.TERMINAL for i in items),"CHECKPOINT_UNFINISHED_PROGRESS")
        ids = [r["item_id"] for r in self.registry.values() if r["domain"] == "macro"]
        _require({i["item_id"] for i in items} == set(ids[:len(items)]),"CHECKPOINT_NOT_REGISTRY_PREFIX")
        body = dict(schema_version="sr-v6-budget-checkpoint-v1",campaign_id=self.config["campaign_id"],
            authority=deepcopy(self.config["authority"]),config_digest=_digest(self.config),
            calls_digest=_digest(calls),items_digest=_digest(items),completed_item_ids=ids[:len(items)],
            carried_completed_micro_item_ids=[r["item_id"] for r in self.registry.values() if r["domain"] == "micro"],
            predecessor_digest=self.predecessor["descriptor_digest"],all_calls_settled=True,no_active_items=True)
        body["checkpoint_digest"] = _digest(body)
        return body

    def snapshot(self):
        value = DurableV3Budget.snapshot(self)
        value.update(execution_mode="real_api",simulated=False,provider_account_debit_verified=False,provider_bill_guarantee=False)
        active = deepcopy(value["budget"])
        old = self.predecessor["snapshot"]
        calls = inherited_calls(old) + value["calls"]
        known = sum(c["known_cost_nano_usd"] for c in calls)
        held = sum(c["held_cost_nano_usd"] for c in calls)
        dispatched = sum(c["dispatched"] for c in calls)
        adjustment = sum(max(0,c.get("late_known_exposure_nano_usd",0)-c["known_cost_nano_usd"]-c["held_cost_nano_usd"]) for c in calls)
        cumulative_known = self.baseline["known_cost_nano_usd"]+known
        cumulative_held = self.baseline["held_cost_nano_usd"]+held
        value.update(schema_version="sr-v6-budget-snapshot-v1",predecessor=deepcopy(self.predecessor),
            epoch_budget=active,epoch_real_api_requests=active["calls_dispatched"],
            real_api_requests=dispatched,real_incremental_cost_nano_usd=known,
            epoch_real_incremental_cost_nano_usd=active["known_cost_nano_usd"],round_id="macro-precision-report-r3")
        value["budget"] = dict(calls_reserved_or_spent=len(calls),calls_dispatched=dispatched,
            calls_remaining=max(0,640-len(calls)),known_cost_nano_usd=known,held_cost_nano_usd=held,
            domain_counts={d:sum(c["domain"]==d for c in calls) for d in ("micro","macro")},
            kind_counts={d:{k:sum(c["domain"]==d and c["kind"]==k for c in calls) for k in ("control","prefix","branch")} for d in ("micro","macro")},
            item_counts={i:sum(c["item_id"]==i for c in calls) for i in self.registry})
        value["cumulative_budget"].update(cumulative_calls=1605+dispatched,known_cost_nano_usd=cumulative_known,
            held_cost_nano_usd=cumulative_held,known_plus_held_nano_usd=cumulative_known+cumulative_held,
            unsettled_exposure_adjustment_nano_usd=adjustment,
            risk_adjusted_known_plus_held_nano_usd=cumulative_known+cumulative_held+adjustment,
            risk_adjusted_overrun=cumulative_known+cumulative_held+adjustment>MAX_COST,
            basis="provider usage times pinned catalog; account debit unverified",
            remaining_after_known_and_held_nano_usd=max(0,MAX_COST-cumulative_known-cumulative_held))
        return value
