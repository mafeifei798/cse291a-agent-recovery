"""V6 wire compatibility; the complete V3 schema remains local admission.

The wire omits the known report regex and metric number bounds. XGrammar 0.2.8
uses a six-decimal grammar for bounded numbers, whereas these metrics must be
copied exactly. No local numeric bound or business equality is relaxed.
"""
from copy import deepcopy
import json
from pathlib import Path

from sr_campaign_v3.contracts import model_schema
from sr_recovery_v2.common import ProtocolError, digest


WIRE_SCHEMA_PROFILE = "macro-unbounded-wire-number-compact-v2"
OUTPUT_PROFILE = "compact-json-exact-metrics-v1"
OUTPUT_CAP = 2048
FINANCIAL_RESERVATION = 1_924_000
OUTPUT_INSTRUCTION = (
    "Return only one compact JSON object, with no Markdown, indentation, or "
    "unnecessary whitespace. Copy every supplied numeric value exactly, including "
    "all decimal digits; do not round or recompute supplied metrics. For report "
    "and publish, keep report_text concise (at most 30 words). Include all required "
    "fields and finish the complete JSON object within the output limit."
)
MICRO_NODES = frozenset(("read_metadata", "read_permission", "read_resources", "plan", "execute"))
MACRO_NODES = frozenset(("inspect", "plan_lr", "plan_rf", "report", "publish"))
REPORT_PATTERN = r"^\S+(?:\s+\S+){0,119}\s*$"
NUMBER_PATHS = (
    ("validation_average_precision", "LR"),
    ("validation_average_precision", "RF"),
    ("metrics", "average_precision"),
    ("metrics", "roc_auc"),
    ("metrics", "accuracy"),
    ("metrics", "f1"),
)


def _require(value, code):
    if not value:
        raise ProtocolError(code)


def output_profile():
    return {"output_profile": OUTPUT_PROFILE,
            "output_instruction": OUTPUT_INSTRUCTION,
            "output_instruction_digest": digest(OUTPUT_INSTRUCTION)}


def project_messages(messages):
    """The same registered suffix is used for every policy, before counting."""
    _require(isinstance(messages, list) and len(messages) == 2
             and all(isinstance(m, dict) and set(m) == {"role", "content"}
                     and isinstance(m["content"], str) for m in messages)
             and [m["role"] for m in messages] == ["system", "user"],
             "V6_MESSAGE_CONTRACT")
    projected = deepcopy(messages)
    projected[0]["content"] += "\n\n" + OUTPUT_INSTRUCTION
    return projected


def domain_for_node(node_id):
    if node_id in MICRO_NODES:
        return "micro"
    if node_id in MACRO_NODES:
        return "macro"
    raise ProtocolError("V6_UNKNOWN_MODEL_NODE")


def wire_schema(node_id, domain, validation_schema=None):
    """Return only the frozen projection, checking each removed keyword."""
    _require(domain in ("micro", "macro") and domain_for_node(node_id) == domain,
             "V6_SCHEMA_DOMAIN_MISMATCH")
    full = model_schema(node_id, domain)
    if validation_schema is not None:
        _require(validation_schema == full and digest(validation_schema) == digest(full),
                 "V6_FULL_VALIDATION_SCHEMA_CHANGED")
    projected = deepcopy(full)
    if domain == "macro" and node_id in ("report", "publish"):
        report = projected if node_id == "report" else projected["properties"]["report"]
        text = report["properties"]["report_text"]
        _require(text.get("pattern") == REPORT_PATTERN, "V6_FROZEN_REPORT_PATTERN_CHANGED")
        del text["pattern"]
        for owner, name in NUMBER_PATHS:
            number = report["properties"][owner]["properties"][name]
            _require(number == {"type": "number", "minimum": 0, "maximum": 1},
                     "V6_FROZEN_NUMBER_SCHEMA_CHANGED")
            del number["minimum"]
            del number["maximum"]
    return projected


def validation_schemas(v0_root):
    v0 = Path(v0_root)
    return {domain: {
        node["node_id"]: model_schema(node["node_id"], domain)
        for node in json.loads((v0 / "dags" / (domain + ".json")).read_text())["nodes"]
        if node["llm_calls_per_execution"]}
        for domain in ("micro", "macro")}


def wire_schemas(full_schemas):
    _require(isinstance(full_schemas, dict) and set(full_schemas) == {"micro", "macro"},
             "V6_FULL_SCHEMA_CATALOGUE_CHANGED")
    _require(set(full_schemas["micro"]) == MICRO_NODES
             and set(full_schemas["macro"]) == MACRO_NODES,
             "V6_FULL_SCHEMA_CATALOGUE_CHANGED")
    return {domain: {node: wire_schema(node, domain, full)
                     for node, full in catalogue.items()}
            for domain, catalogue in full_schemas.items()}


def schema_profile(full_schemas):
    return {"wire_schema_profile": WIRE_SCHEMA_PROFILE,
            "wire_schema_digest": digest(wire_schemas(full_schemas)),
            "validation_schema_digest": digest(full_schemas), **output_profile()}
