"""A new authority-admission command around the unchanged V3 acceptance gate.

This is a single-controller checkpoint protocol, not a watcher or a claim of
serializability with an external service. An external writer must use this
command. Unrecorded mutations still fail the original source-drift guard.
"""
from copy import deepcopy
import hashlib

from sr_campaign_v3.store import V3Store
from sr_recovery_v2.common import ProtocolError, digest, source_fingerprint


class CheckpointStore(V3Store):
    """Harness callback after a durable accepted report, outside its transaction."""

    def __init__(self, *args, on_checkpoint=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.on_checkpoint = on_checkpoint

    def finish_node(self, attempt_id, package, now_utc):
        response = super().finish_node(attempt_id, package, now_utc)
        result = response.get('result', {})
        if (self.on_checkpoint is not None and result.get('node_id') == 'report'
                and response.get('guard', {}).get('classification') == 'passed'
                and self.snapshot()['state']['selected_by_node'].get('report') == result['result_id']):
            self.on_checkpoint(self, result)
        return response


class DynamicStore(CheckpointStore):
    """Admit at most two source writes; never replenish correction allowances.

All three policies retain their existing initial invalidation behavior and
share the existing one-stale/one-semantic correction rule after an update.
FULL here means full *initial* restart plus the same bounded correction gate.
"""

    def accept_authority_update(self, source, *, event_id, expected_state_version,
                                expected_source_digest, now_utc):
        command = {'source': deepcopy(source), 'expected_state_version': expected_state_version,
                   'expected_source_digest': expected_source_digest}

        def mutate(doc):
            state = doc['state']
            if state['state_version'] != expected_state_version:
                raise ProtocolError('STALE_STATE_VERSION')
            if state['status'] != 'running' or not state['active_plan_id'] or doc['metadata'].get('initial_mode'):
                raise ProtocolError('RECOVERY_CHECKPOINT_REQUIRED')
            if state['active_attempt_ids'] or state['unsettled_call_ids'] or doc['pending_decision']:
                raise ProtocolError('QUIESCENT_CHECKPOINT_REQUIRED')
            before_fp = source_fingerprint(doc['sources'])
            if before_fp != state['source_fingerprint']:
                raise ProtocolError('UNRECORDED_AUTHORITY_DRIFT')
            updates = doc['metadata'].get('authority_updates', [])
            if len(updates) >= 2:
                raise ProtocolError('AUTHORITY_UPDATE_CAP')
            self._validate(source)
            old = next((s for s in doc['sources'] if s['object_key'] == source['object_key']), None)
            if old is None or digest(old) != expected_source_digest:
                raise ProtocolError('AUTHORITY_SOURCE_CAS_MISMATCH')
            if source['version'] != old['version'] + 1:
                raise ProtocolError('AUTHORITY_VERSION_MUST_INCREMENT_ONCE')
            if digest(source['payload']) != source['payload_digest']:
                raise ProtocolError('SOURCE_PAYLOAD_DIGEST_MISMATCH')
            registry = {a['artifact_id']: a for a in doc['artifacts']}
            for aid in source['artifact_refs']:
                art = registry.get(aid)
                if art is None:
                    raise ProtocolError('UNREGISTERED_SOURCE_ARTIFACT')
                path = (self.artifact_root / art['uri']).resolve()
                if not path.is_relative_to(self.artifact_root):
                    raise ProtocolError('ARTIFACT_PATH_ESCAPE')
                if (not path.is_file() or path.stat().st_mode & 0o222
                        or path.stat().st_size != art['size_bytes']
                        or hashlib.sha256(path.read_bytes()).hexdigest() != art['sha256']):
                    raise ProtocolError('SOURCE_ARTIFACT_BYTES_OR_MODE')
            for binding in (old, source):
                prior = [s for s in doc['source_history'] if s['object_key'] == binding['object_key']
                         and s['version'] == binding['version']]
                if any(p != binding for p in prior):
                    raise ProtocolError('AUTHORITY_HISTORY_REBOUND')
                if not prior:
                    doc['source_history'].append(deepcopy(binding))
            before = deepcopy(old)
            doc['sources'] = [deepcopy(source) if s['object_key'] == source['object_key'] else s
                              for s in doc['sources']]
            state['source_fingerprint'] = source_fingerprint(doc['sources'])
            # A saved guard is never re-used across authority epochs. Result
            # selection and pending work remain for the original shared policy
            # to diagnose, invalidate and charge; no work is silently repaired.
            doc['last_guard'] = None
            receipt = {'update_id': event_id, 'ordinal': len(updates) + 1,
                'expected_state_version': expected_state_version,
                'expected_source_digest': expected_source_digest,
                'source_before': before, 'source_after': deepcopy(source),
                'fingerprint_before': before_fp, 'fingerprint_after': state['source_fingerprint'],
                'deadline_utc': state['deadline_utc'], 'counters': deepcopy(state['counters']),
                'checkpoint_only': True, 'correction_credit_added': False}
            doc['metadata'].setdefault('authority_updates', []).append(deepcopy(receipt))
            return receipt, deepcopy(receipt)

        return self._apply(event_id, 'authority_update', command, now_utc, mutate)
