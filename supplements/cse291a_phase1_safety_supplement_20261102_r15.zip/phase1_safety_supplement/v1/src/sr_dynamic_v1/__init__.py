"""Opt-in, bounded authority updates at quiescent recovery boundaries."""
