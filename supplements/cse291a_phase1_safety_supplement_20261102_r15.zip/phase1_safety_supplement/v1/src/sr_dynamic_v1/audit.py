"""Read-only authority-epoch audit, independent of Store, policy and guards."""
from copy import deepcopy
import hashlib
import json


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _fingerprint(sources):
    return _digest(sorted([{'object_key': s['object_key'], 'version': s['version'],
        'payload_digest': s['payload_digest']} for s in sources], key=lambda s: s['object_key']))


def audit_updates(view):
    issues, checks = [], 0

    def expect(value, code, ref=''):
        nonlocal checks
        checks += 1
        if not value:
            issues.append({'code': code, 'ref': ref})

    try:
        frozen = view['initial_snapshot']
        expect(view['prefix_digest'] == _digest(frozen), 'FROZEN_PREFIX_DIGEST')
        current = {s['object_key']: deepcopy(s) for s in frozen['current_sources']}
        expected_fp = _fingerprint(list(current.values()))
        metadata = view['metadata'].get('authority_updates', [])
        updates = []
        last_state = None
        for event in view['events']:
            before, after = event['before'], event['after']
            if last_state is not None:
                expect(before == last_state, 'EVENT_STATE_CONTINUITY', event['event_id'])
            expect(after['state_version'] == before['state_version'] + 1, 'STATE_CAS', event['event_id'])
            if before.get('deadline_utc'):
                expect(before['deadline_utc'] == after['deadline_utc'] and
                       before['started_at_utc'] == after['started_at_utc'], 'DEADLINE_NOT_RESTARTED', event['event_id'])
            for key in before['counters']:
                expect(after['counters'][key] >= before['counters'][key], 'NO_COUNTER_REFUND', key)
            if event['kind'] == 'authority_update':
                d = event['details']
                key = d['source_before']['object_key']
                expect(before['source_fingerprint'] == expected_fp == d['fingerprint_before'], 'UPDATE_OLD_EPOCH')
                expect(current[key] == d['source_before'] and _digest(current[key]) == d['expected_source_digest'], 'SOURCE_CAS')
                expect(before['state_version'] == d['expected_state_version'], 'UPDATE_EXPECTED_STATE')
                expect(not before['active_attempt_ids'] and not before['unsettled_call_ids'] and
                       before['status'] == 'running' and bool(before['active_plan_id']), 'UPDATE_QUIESCENT_RUNNING')
                source = d['source_after']
                expect(source['object_key'] == key and source['version'] == current[key]['version'] + 1,
                       'MONOTONIC_SINGLE_VERSION')
                expect(_digest(source['payload']) == source['payload_digest'], 'SOURCE_CONTENT_DIGEST')
                current[key] = deepcopy(source)
                expected_fp = _fingerprint(list(current.values()))
                expect(after['source_fingerprint'] == d['fingerprint_after'] == expected_fp, 'UPDATE_NEW_EPOCH')
                expect(before['counters'] == after['counters'] == d['counters'], 'UPDATE_NO_CREDIT_RESET')
                for field in before:
                    if field not in ('state_version', 'source_fingerprint'):
                        expect(before[field] == after[field], 'UPDATE_PRESERVES_STATE', field)
                expect(d['correction_credit_added'] is False and d['checkpoint_only'] is True, 'BOUNDED_UPDATE_RULE')
                expect(d['update_id'] == event['event_id'] and d['ordinal'] == len(updates) + 1, 'UPDATE_ID_ORDINAL')
                expect(d['deadline_utc'] == before['deadline_utc'], 'UPDATE_DEADLINE_RECEIPT')
                updates.append(d)
            else:
                expect(before['source_fingerprint'] == after['source_fingerprint'] == expected_fp,
                       'NO_UNRECORDED_EPOCH_SWITCH', event['event_id'])
            last_state = after
        expect(last_state == view['state'], 'FINAL_STATE_EQUALS_JOURNAL')
        expect(updates == metadata and len(updates) <= 2, 'EXACT_BOUNDED_UPDATE_JOURNAL')
        expect(view['state']['source_fingerprint'] == _fingerprint(view['sources']) == expected_fp, 'FINAL_AUTHORITY_EPOCH')
        expect(current == {s['object_key']: s for s in view['sources']}, 'AUTHORITY_REPLAY_EQUALS_FINAL')
        history = {(s['object_key'], s['version']): s for s in view['source_history']}
        for d in updates:
            for s in (d['source_before'], d['source_after']):
                expect(history.get((s['object_key'], s['version'])) == s, 'UPDATE_HISTORY_PRESERVED')
        for kind in ('stale', 'semantic'):
            expect(view['state']['counters'][kind + '_used'] in (0, 1), 'BOUNDED_CORRECTIONS', kind)
        for call in view['calls']:
            expect(call['request_sent'] is False and call['cost_nano_usd'] == 0, 'NO_LIVE_API', call['call_id'])
        completed = view['state']['terminal_status'] == 'completed_correct'
        if not completed:
            expect(not any(e['status'] == 'committed' for e in view['effects']), 'NO_PUBLICATION_ON_SAFE_STOP')
        else:
            results = {r['result_id']: r for r in view['results']}
            todo, seen = [view['state']['selected_by_node']['publish']], set()
            while todo:
                rid = todo.pop()
                if rid in seen:
                    continue
                seen.add(rid)
                result = results[rid]
                for ref in result['effective_reads']:
                    expect(current[ref['object_key']]['version'] == ref['version'], 'NO_STALE_PUBLISHED_ANCESTOR', rid)
                todo.extend(result['parent_result_ids'])
        expect(not view['state']['active_attempt_ids'] and not view['state']['unsettled_call_ids'], 'QUIESCENT_TERMINAL')
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        expect(False, 'MALFORMED_DYNAMIC_EXPORT', str(exc))
    return {'passed': not issues, 'checks': checks, 'issues': issues,
            'scope': 'Admitted controller checkpoints only; no inference about arbitrary external concurrency.'}
