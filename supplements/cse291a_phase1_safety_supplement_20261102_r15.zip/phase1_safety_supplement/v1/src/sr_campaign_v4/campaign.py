"""Explicit V4 formal-order live campaign; no implicit credential source or retry."""
import argparse
import copy
from datetime import timedelta
import hashlib
import json
from pathlib import Path
import traceback

from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from sr_cpu_v2.adapter import numerical_check
from sr_cpu_v2.checker import audit_export
from sr_recovery_v2.common import ProtocolError, canonical, digest, utc_parse, utc_format
from .budget import DurableV4Budget, validate_v4_grant
from .checker import audit_campaign, qualify_prefix
from sr_campaign_v3.contracts import model_schema
from sr_campaign_v3.executor import now
from .gateway import LiveV4Gateway, live_binding
from agent_recovery.p3_deadline import BoundedHTTPSender
from .runtime import initial_store, run_item, freeze, write
from .store import V4Store


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def replace_json(path, value):
    path = Path(path)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')
    with tmp.open('rb') as handle:
        __import__('os').fsync(handle.fileno())
    tmp.replace(path)


def write_http_evidence(root, stage, record):
    top = record.get('call_id')
    nested = record.get('sidecar', {}).get('call_id')
    if top and nested and top != nested:
        raise ValueError('HTTP_EVIDENCE_CALL_ID_CONFLICT')
    identity = top or nested
    if not isinstance(identity, str) or not identity or '/' in identity or '\\' in identity:
        raise ValueError('HTTP_EVIDENCE_CALL_ID_MISSING_OR_INVALID')
    write(Path(root) / 'http' / identity / (stage + '.json'), record)


def input_manifest(v0_root):
    v0 = Path(v0_root).resolve()
    return {str(Path('sr_v2/v0') / p.relative_to(v0)): sha(p)
            for p in sorted(v0.rglob('*')) if p.is_file()
            and not p.name.startswith('._') and '__pycache__' not in p.parts}


def runtime_spec(v0_root):
    """Read-only reviewable specification; this does not grant execution."""
    v0 = Path(v0_root).resolve()
    source = Path(__file__).resolve().parents[2]
    schemas = {domain: {n['node_id']: model_schema(n['node_id'], domain)
                        for n in read(v0 / ('dags/' + domain + '.json'))['nodes'] if n['llm_calls_per_execution']}
               for domain in ('micro', 'macro')}
    folders = ('src/agent_recovery', 'src/sr_recovery_v2', 'src/sr_cpu_v2',
               'src/sr_campaign_v3', 'src/sr_campaign_v4')
    files = {str(p.relative_to(source)): sha(p) for folder in folders
             for p in sorted((source / folder).glob('*.py')) if not p.name.startswith('._')}
    files['scripts/run_sr_campaign_v4.py'] = sha(source / 'scripts/run_sr_campaign_v4.py')
    binding = {**live_binding(v0,
        price_evidence='sr_v2/v0/budget/model_binding_spec.json:pinned-directory-prices-not-account-debit',
        capability_evidence='outputs/p4_formal_20261020:602-completed-Flash-low-strict-schema-calls;new-macro-schema-unverified'),
        'schema_digest': digest(schemas),
        'template_digest': sha(source / 'src/sr_campaign_v3/contracts.py'),
        'guard_digest': sha(source / 'src/sr_campaign_v3/guard.py'),
        'correction_digest': sha(source / 'src/sr_recovery_v2/policy.py'),
        'source_manifest_digest': digest(files), 'identifier_conditions_blinded': True,
        'input_manifest_digest': digest(input_manifest(v0)),
        'runtime_store_digest': sha(source / 'src/sr_campaign_v4/store.py'),
        'runtime_controller_digest': sha(source / 'src/sr_campaign_v4/runtime.py')}
    return binding, schemas, files


def freeze_binding(root, v0, supplied_binding, grant):
    binding, schemas, files = runtime_spec(v0)
    if binding != supplied_binding:
        raise ValueError('V4_REVIEWED_RUNTIME_BINDING_CHANGED')
    write(root / 'frozen/binding.json', binding)
    write(root / 'frozen/schemas.json', schemas)
    write(root / 'frozen/source_manifest.json', files)
    write(root / 'frozen/input_manifest.json', input_manifest(v0))
    write(root / 'frozen/grant.json', grant)
    (root / 'frozen/formal_items.jsonl').write_bytes((v0 / 'registry/formal_items.jsonl').read_bytes())
    write(root / 'frozen/authority.json', {'execution': 'real_api', 'phase': 'V4',
        'authorization_reference': grant['authorization_reference'],
        'grant_digest': digest(grant), 'original_registry_modified': False,
        'credential_policy': 'Explicit provider only; credential never enters records or CPU tool environment.',
        'automatic_http_retries': 0, 'standalone_probes': 0})
    return binding


def _campaign(output, v0_root, *, binding, grant, credential_provider,
             through=26, resume_checkpoint=None, transport=None):
    root, v0 = Path(output).resolve(), Path(v0_root).resolve()
    validate_v4_grant(grant, binding=binding, campaign_id='sr-v2-formal-live-r1',
        ledger_path=root / 'budget/central.sqlite', lock_root=root.parent / 'budget_authority', v0_root=v0)
    if not callable(credential_provider):
        raise ValueError('V4_EXPLICIT_CREDENTIAL_PROVIDER_REQUIRED')
    expected_binding, _, _ = runtime_spec(v0)
    if binding != expected_binding:
        raise ValueError('V4_REVIEWED_RUNTIME_BINDING_CHANGED')
    registry_file = v0 / 'registry/formal_items.jsonl' 
    registry = [json.loads(line) for line in registry_file.read_text().splitlines() if line.strip()]
    scene_specs = read(v0 / 'registry/formal_scenes.json')['scenes']
    if resume_checkpoint is None:
        root.mkdir(parents=True, exist_ok=False)
        for name in ('db', 'files', 'exports', 'scenes', 'http', 'injections', 'audits', 'numerical', 'checkpoints', 'frozen'):
            (root / name).mkdir()
        binding = freeze_binding(root, v0, binding, grant)
        state = {'mode': 'real_api', 'campaign_id': 'sr-v2-formal-live-r1',
            'execution_id': root.parent.name + '/' + root.name,
            'run_namespace': hashlib.sha256(str(root).encode()).hexdigest()[:12],
            'registry_sha256': sha(registry_file), 'items': [{**r, 'status': 'not_started', 'run_count': 0,
                'started_at': None, 'finished_at': None, 'deadline_at': None,
                'physical_dispatch_ids': []} for r in registry], 'events': [],
            'scenes': [{**s, 'qualified': False, 'attempted': False, 'freeze_digest': None,
                        'branch_item_ids': s['ordered_branch_item_ids']} for s in scene_specs],
            'checkpoints': [], 'phase': 'V4', 'V4_started': True,
            'real_api_requests': 0, 'actual_api_cost_nano_usd': 0, 'gpu_used': False,
            'credential_storage': 'explicit provider only, not persisted', 'stop_reason': None}
    else:
        state = read(root / 'campaign_state.json')
        if state.get('stop_reason') or any(i['status'] == 'running' for i in state['items']):
            raise ValueError('UNQUIESCENT_CAMPAIGN_REQUIRES_MANUAL_RECONCILIATION')
        for item in state['items']:
            view = item.get('raw_export')
            if view and (view['state']['active_attempt_ids'] or view['state']['unsettled_call_ids']):
                raise ValueError('ACTIVE_WORKFLOW_ATTEMPT_REQUIRES_MANUAL_RECONCILIATION')
        if binding != read(root / 'frozen/binding.json') or grant != read(root / 'frozen/grant.json'):
            raise ValueError('V4_RESUME_BINDING_OR_GRANT_CHANGED')
        if sha(registry_file) != state['registry_sha256']:
            raise ValueError('ORIGINAL_REGISTRY_CHANGED')
        for relative, expected in read(root / 'frozen/source_manifest.json').items():
            if sha(Path(__file__).resolve().parents[2] / relative) != expected:
                raise ValueError('FROZEN_RUNTIME_SOURCE_CHANGED:' + relative)
        checkpoint = read(resume_checkpoint)
        if not state['checkpoints'] or checkpoint['checkpoint_digest'] != state['checkpoints'][-1]['budget_checkpoint_digest']:
            raise ValueError('LATEST_QUIESCENT_CHECKPOINT_REQUIRED')
    def event(kind, item=None, payload=None):
        state['events'].append({'seq': len(state['events']) + 1, 'event_id': 'v3.event.' + str(len(state['events']) + 1),
            'type': kind, 'item_id': item, 'timestamp': now(), 'payload': payload or {}})
    ledger_path = root / 'budget/central.sqlite'
    with DurableV4Budget(ledger_path, campaign_id=state['campaign_id'], binding=binding, grant=grant,
                         v0_root=v0, lock_root=root.parent / 'budget_authority',
                         resume_checkpoint=read(resume_checkpoint) if resume_checkpoint else None) as budget:
        counter = GLM53LocalTokenCounter.from_directory(v0 / 'environment/tokenizer_files')
        def sink(stage, record):
            write_http_evidence(root, stage, record)
        gateway = LiveV4Gateway(v0, binding=binding, grant=grant, budget=budget,
            transport=transport if transport is not None else BoundedHTTPSender(),
            credential_provider=credential_provider, token_counter=counter, evidence_sink=sink)
        items = {i['item_id']: i for i in state['items']}
        scenes = {s['scene_id']: s for s in state['scenes']}
        for registered in registry:
            ordinal, iid = registered['execution_ordinal'], registered['item_id']
            if ordinal > through:
                break
            row = items[iid]
            if row['status'] != 'not_started':
                continue
            scene = scenes.get(registered['scene_id'])
            if registered['kind'] == 'branch' and not scene['qualified']:
                row['status'] = 'not_run_blocked_prefix'
                budget.finalize_item(iid, row['status'], digest(row))
                event('item_blocked', iid, {'prefix_item_id': scene['prefix_item_id']})
                state['ledger'] = budget.snapshot()
                checkpoint = budget.make_checkpoint()
                cp_id = 'checkpoint.' + format(ordinal, '04d')
                path = root / 'checkpoints' / (cp_id + '.json')
                write(path, checkpoint)
                state['checkpoints'].append({'checkpoint_id': cp_id, 'event_seq': len(state['events']),
                    'started_item_ids': [i['item_id'] for i in state['items'] if i['run_count']],
                    'terminal_item_ids': [i['item_id'] for i in state['items'] if i['status'] not in ('not_started', 'running')],
                    'active_jobs': [], 'unsettled_dispatch_ids': [],
                    'next_item_id': registry[ordinal]['item_id'] if ordinal < 52 else None,
                    'resumable': True, 'budget_checkpoint_digest': checkpoint['checkpoint_digest'],
                    'budget_checkpoint_path': str(path), 'ledger_checkpoint': checkpoint,
                    'ledger_event_seq': budget.snapshot()['events'][-1]['seq']})
                event('checkpoint', payload={'checkpoint_id': cp_id})
                state['ledger'] = budget.snapshot()
                replace_json(root / 'campaign_state.json', state)
                continue
            store = None
            view = None
            error = None
            try:
                scope = 'pre_prefix' if registered['kind'] == 'prefix' else 'item'
                if registered['kind'] == 'branch' and all(items[b]['status'] == 'not_started' for b in scene['branch_item_ids']):
                    scope = 'scene'
                budget.check_admission(iid, scope)
                row.update(status='running', run_count=1, started_at=now())
                row['deadline_at'] = utc_format(utc_parse(row['started_at']) + timedelta(seconds=1800))
                event('item_started', iid)
                replace_json(root / 'campaign_state.json', state)
                if registered['kind'] == 'branch':
                    frozen = read(root / 'scenes' / (scene['scene_id'] + '.json'))
                    if digest(frozen) != scene['freeze_digest']:
                        raise ValueError('FROZEN_SCENE_DIGEST_CHANGED')
                    dag = read(v0 / ('dags/' + registered['domain'] + '.json'))
                    row['freeze_digest'] = scene['freeze_digest']
                    store = V4Store(root / 'db' / (iid + '.sqlite'), root / 'files', budget=budget)
                    store.create(frozen, dag, iid, registered['policy'])
                else:
                    # Public model messages never include N1/N2/N3 or strategy.
                    store = initial_store(registered, 'r4.' + state['run_namespace'] + '.' + format(ordinal, '04d'), v0, root, root / 'files', budget=budget)
                view = run_item(store, registered, v0, root, gateway)
                last_guard = view.get('last_guard')
                if last_guard and last_guard['classification'] in ('integrity_error', 'uncertain', 'source_drift'):
                    raise ValueError('ENGINEERING_GUARD_REFUSAL:' + last_guard['classification'])
                row['started_at'] = view['state']['started_at_utc']
                row['deadline_at'] = view['state']['deadline_utc']
                if registered['kind'] == 'prefix':
                    scene['attempted'] = True
                    fault_path = root / 'injections' / (iid + '.json')
                    fault = read(fault_path) if fault_path.is_file() else None
                    eligibility = qualify_prefix(view, registered['domain'], view['task'], fault)
                    write(root / 'audits' / (iid + '.eligibility.json'), eligibility)
                    scene.update(prefix_export=copy.deepcopy(view), fault_evidence=fault,
                                 eligibility_receipt=eligibility)
                    if eligibility['qualified'] and budget.snapshot()['status'] == 'active':
                        if registered['domain'] == 'macro':
                            numeric = numerical_check(view, v0, root / 'files', root, iid, prefix=True)
                            write(root / 'numerical' / (iid + '.json'), numeric)
                            if not numeric.get('response', {}).get('payload', {}).get('passed'):
                                raise ValueError('INDEPENDENT_PREFIX_NUMERICAL_CHECK_FAILED')
                        frozen = freeze(store, registered, v0, scene['scene_id'])
                        write(root / 'scenes' / (scene['scene_id'] + '.json'), frozen)
                        scene.update(qualified=True, freeze_digest=digest(frozen), scene_export=frozen)
                        event('scene_frozen', iid, {'freeze_digest': scene['freeze_digest']})
                        view = store.export()
                    if not scene['qualified'] and view['state']['status'] != 'terminal':
                        store.stop_without_dispatch('validation_rejected', 'V4_PREFIX_NOT_QUALIFIED', now())
                        view = store.export()
                    row['status'] = 'validation_rejected' if not view['state'].get('terminal_status') else view['state']['terminal_status']
                else:
                    row['status'] = view['state']['terminal_status'] or 'validation_rejected'
                    if registered['domain'] == 'macro' and row['status'] == 'completed_correct':
                        audit = audit_export(view, root / 'files', v0)
                        write(root / 'audits' / (iid + '.json'), audit)
                        numeric = numerical_check(view, v0, root / 'files', root, iid)
                        write(root / 'numerical' / (iid + '.json'), numeric)
                        if not audit['passed'] or not audit['business_correct'] or not numeric.get('response', {}).get('payload', {}).get('passed'):
                            raise ValueError('INDEPENDENT_COMPLETION_CHECK_FAILED')
                if budget.snapshot()['status'] != 'active':
                    raise ValueError('CENTRAL_LEDGER_STOPPED:' + str(budget.snapshot()['pause_reason']))
            except Exception as exc:
                error = {'code': getattr(exc, 'code', type(exc).__name__), 'message': str(exc), 'traceback': traceback.format_exc()}
                write(root / 'audits' / (iid + '.failure.json'), error)
                if store:
                    view = store.export()
                row['status'] = view['state'].get('terminal_status') if view else None
                row['status'] = row['status'] or 'uncertain'
                state['stop_reason'] = error
                budget.quarantine(None, 'V4_RUNNER_HARD_STOP:' + error['code'])
            finally:
                if store:
                    store.close()
            row['finished_at'] = now()
            row['error'] = error
            row['physical_dispatch_ids'] = [c['call_id'] for c in budget.calls() if c['item_id'] == iid and c['dispatched']]
            if view:
                export_path = root / 'exports' / (iid + '.json')
                write(export_path, view)
                row.update(raw_export=view, export_path=str(export_path.relative_to(root)), export_sha256=sha(export_path),
                           raw_export_digest=digest(view))
            if not any(c['item_id'] == iid and c['status'] != 'settled' for c in budget.calls()):
                budget.finalize_item(iid, row['status'], digest(row))
            event('item_finished', iid, {'status': row['status']})
            state['ledger'] = budget.snapshot()
            state['real_api_requests'] = state['ledger']['real_api_requests']
            state['actual_api_cost_nano_usd'] = state['ledger']['real_incremental_cost_nano_usd']
            if state['stop_reason'] is None:
                checkpoint = budget.make_checkpoint()
                cp_id = 'checkpoint.' + format(ordinal, '04d')
                path = root / 'checkpoints' / (cp_id + '.json')
                write(path, checkpoint)
                finished = [i['item_id'] for i in state['items'] if i['status'] not in ('not_started', 'running')]
                state['checkpoints'].append({'checkpoint_id': cp_id, 'event_seq': len(state['events']),
                    'started_item_ids': [i['item_id'] for i in state['items'] if i['run_count']],
                    'terminal_item_ids': finished, 'active_jobs': [], 'unsettled_dispatch_ids': [],
                    'next_item_id': registry[ordinal]['item_id'] if ordinal < 52 else None, 'resumable': True,
                    'budget_checkpoint_digest': checkpoint['checkpoint_digest'], 'budget_checkpoint_path': str(path)})
                state['checkpoints'][-1].update(ledger_checkpoint=checkpoint,
                    ledger_event_seq=budget.snapshot()['events'][-1]['seq'])
                event('checkpoint', payload={'checkpoint_id': cp_id})
                state['ledger'] = budget.snapshot()
            replace_json(root / 'campaign_state.json', state)
            print(json.dumps({'item_id': iid, 'status': row['status'], 'ordinal': ordinal,
                              'calls': len(row['physical_dispatch_ids']), 'stopped': bool(state['stop_reason'])}), flush=True)
            if state['stop_reason']:
                event('campaign_stopped', iid, state['stop_reason'])
                break
        state['ledger'] = budget.snapshot()
        state['real_api_requests'] = state['ledger']['real_api_requests']
        state['actual_api_cost_nano_usd'] = state['ledger']['real_incremental_cost_nano_usd']
        state['finished_at'] = now()
        state['all_items_processed'] = all(i['status'] != 'not_started' for i in state['items'])
        replace_json(root / 'campaign_state.json', state)
        audit = audit_campaign(state, v0, artifact_root=root)
        audit_path = root / ('audit.through' + str(through) + '.json')
        write(audit_path, audit)
        write(root / ('stage_acceptance.through' + str(through) + '.json'), {
            'passed': audit['passed'] and state['stop_reason'] is None,
            'through': through, 'record_audit_passed': audit['passed'],
            'campaign_state_sha256': sha(root / 'campaign_state.json'),
            'audit_sha256': sha(audit_path), 'binding_digest': digest(binding),
            'latest_budget_checkpoint_digest': state['checkpoints'][-1]['budget_checkpoint_digest']
                if state['checkpoints'] else None,
            'business_success_not_an_admission_filter': True})
        healthy = all(i['status'] == 'completed_correct' for i in state['items']
                      if i['run_count'] and i['kind'] in ('control', 'branch'))
        healthy = healthy and all(s['qualified'] for s in state['scenes'] if s['attempted'])
        return {'passed': audit['passed'] and state['stop_reason'] is None,
                'record_audit_passed': audit['passed'],
                'all_attempted_business_tasks_completed_correct': healthy,
                'audit': str(root / ('audit.through' + str(through) + '.json')),
                'all_items_processed': state['all_items_processed'], 'stop_reason': state['stop_reason'],
                'ledger': {k: v for k, v in state['ledger']['budget'].items() if k != 'item_counts'},
                'real_api_requests': state['real_api_requests'], 'actual_api_cost_nano_usd': state['actual_api_cost_nano_usd']}


def validate_stage_transition(output, v0_root, *, through, resume_checkpoint=None):
    """Formal admission is exactly fresh26 -> audited39 -> audited52."""
    root = Path(output).resolve()
    if through not in (26, 39, 52):
        raise ProtocolError('V4_FORMAL_STAGE_REQUIRED')
    if not root.exists():
        if through != 26 or resume_checkpoint is not None:
            raise ProtocolError('V4_FIRST_STAGE_MUST_BE_26')
        return
    previous = {39: 26, 52: 39}.get(through)
    if previous is None or resume_checkpoint is None:
        raise ProtocolError('V4_PREVIOUS_AUDITED_STAGE_REQUIRED')
    state = read(root / 'campaign_state.json')
    receipt = read(root / ('stage_acceptance.through' + str(previous) + '.json'))
    audit_path = root / ('audit.through' + str(previous) + '.json')
    checkpoint_path = root / 'checkpoints' / ('checkpoint.' + format(previous, '04d') + '.json')
    if (state.get('stop_reason') is not None or state.get('mode') != 'real_api'
            or state.get('campaign_id') != 'sr-v2-formal-live-r1'
            or receipt.get('passed') is not True or receipt.get('record_audit_passed') is not True
            or receipt.get('through') != previous
            or receipt.get('campaign_state_sha256') != sha(root / 'campaign_state.json')
            or receipt.get('audit_sha256') != sha(audit_path)
            or receipt.get('binding_digest') != digest(read(root / 'frozen/binding.json'))
            or Path(resume_checkpoint).resolve() != checkpoint_path.resolve()
            or not state['checkpoints']
            or state['checkpoints'][-1]['checkpoint_id'] != 'checkpoint.' + format(previous, '04d')
            or receipt.get('latest_budget_checkpoint_digest') != state['checkpoints'][-1]['budget_checkpoint_digest']
            or read(checkpoint_path)['checkpoint_digest'] != receipt.get('latest_budget_checkpoint_digest')):
        raise ProtocolError('V4_PREVIOUS_STAGE_EVIDENCE_MISMATCH')
    for row in state['items']:
        if row['execution_ordinal'] <= previous:
            if row['status'] in ('not_started', 'running'):
                raise ProtocolError('V4_PREVIOUS_STAGE_INCOMPLETE')
        elif row['status'] != 'not_started' or row['run_count']:
            raise ProtocolError('V4_STAGE_ORDER_VIOLATION')
    # Reconstruct the previous records. Business failures do not block a valid
    # stage; integrity, money, source or unresolved-work failures do.
    if read(audit_path).get('passed') is not True or not audit_campaign(
            state, Path(v0_root).resolve(), artifact_root=root).get('passed'):
        raise ProtocolError('V4_PREVIOUS_STAGE_AUDIT_FAILED')


def campaign(output, v0_root, *, binding, grant, credential_provider,
             through=26, resume_checkpoint=None, transport=None):
    root, v0 = Path(output).resolve(), Path(v0_root).resolve()
    validate_v4_grant(grant, binding=binding, campaign_id='sr-v2-formal-live-r1',
        ledger_path=root / 'budget/central.sqlite', lock_root=root.parent / 'budget_authority', v0_root=v0)
    validate_stage_transition(root, v0, through=through, resume_checkpoint=resume_checkpoint)
    return _campaign(root, v0, binding=binding, grant=grant, credential_provider=credential_provider,
        through=through, resume_checkpoint=resume_checkpoint, transport=transport)

