"""Read-only V4 evidence auditor; real records never masquerade as fixtures.

Business and scene reconstruction reuse pinned, mode-neutral V3 audit helpers.
Real authorization, wire evidence, usage and money are checked here without
importing a gateway, Store, ledger implementation, policy or runtime guard.
An auditable safe failure is separate from a successfully completed workload.
"""
from __future__ import annotations

import base64
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re

from sr_campaign_v3.checker import (
    _Audit, _digest, _rows, _utc, _load_item_export, _raw_result, _scenes,
    _checkpoints, _runner_events, _ledger_events, _input_projection, qualify_prefix,
)


CAMPAIGN = "sr-v2-formal-live-r1"
RESERVATION, BASE_KNOWN, BASE_HELD = 1_284_000, 90_998_300, 984_000
MAX_COST, BASE_CALLS = 1_000_000_000, 1605
TERMINAL = {"completed_correct", "validation_rejected", "permission_denied_safe", "conflict_safe",
            "tool_failed", "budget_or_time_stopped", "uncertain", "not_run_blocked_prefix", "not_run_stopped"}
UNSTARTED = {"not_started", "not_run_blocked_prefix", "not_run_stopped"}
GRANT_FIELDS = {"schema_version", "record_type", "grant_id", "campaign_id", "authorized",
    "execution_mode", "binding_digest", "registry_sha256", "baseline_sha256", "ledger_path",
    "lock_root", "max_new_physical_calls", "max_cumulative_cost_nano_usd", "authorization_reference"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _strict_json(data):
    def pairs(values):
        out = {}
        for key, value in values:
            if key in out:
                raise ValueError("duplicate JSON member")
            out[key] = value
        return out
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite JSON")))


def _within(root, relative):
    path = Path(relative)
    path = (root / path).resolve() if not path.is_absolute() else path.resolve()
    if path == root or root not in path.parents:
        raise ValueError("evidence path escapes campaign root")
    return path


def _usage(raw):
    if not isinstance(raw, dict):
        return None
    p, c, t = (raw.get(k) for k in ("prompt_tokens", "completion_tokens", "total_tokens"))
    pd, cd = raw.get("prompt_tokens_details") or {}, raw.get("completion_tokens_details") or {}
    if not isinstance(pd, dict) or not isinstance(cd, dict):
        return None
    cached, reasoning = pd.get("cached_tokens", 0), cd.get("reasoning_tokens", 0)
    if not all(type(v) is int and v >= 0 for v in (p, c, t, cached, reasoning)) or \
            t != p + c or cached > p or reasoning > c:
        return None
    return dict(prompt_tokens=p, completion_tokens=c, total_tokens=t,
                cached_input_tokens=cached, reasoning_tokens=reasoning)


def _schema_ok(schema, value):
    """Small independent validator for the frozen object/primitive contracts."""
    allowed = {"type", "properties", "required", "additionalProperties", "items", "minItems", "maxItems",
               "const", "enum", "minimum", "maximum", "minLength", "maxLength", "pattern", "title", "description"}
    if not isinstance(schema, dict) or not set(schema) <= allowed:
        return False
    kind = schema.get("type")
    valid_type = {"object": type(value) is dict, "array": type(value) is list,
        "string": type(value) is str, "integer": type(value) is int,
        "number": type(value) in (int, float) and math.isfinite(value),
        "boolean": type(value) is bool, "null": value is None}
    if kind is not None and not valid_type.get(kind, False):
        return False
    if "const" in schema and (value != schema["const"] or type(value) is not type(schema["const"])):
        return False
    if "enum" in schema and not any(value == x and type(value) is type(x) for x in schema["enum"]):
        return False
    if type(value) is dict:
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is not False or set(schema.get("required", [])) != set(props):
            return False
        if not set(schema.get("required", [])) <= set(value):
            return False
        if schema.get("additionalProperties") is False and not set(value) <= set(props):
            return False
        return all(_schema_ok(props[k], v) for k, v in value.items() if k in props)
    if type(value) is list:
        return len(value) >= schema.get("minItems", 0) and len(value) <= schema.get("maxItems", math.inf) and \
               all(_schema_ok(schema.get("items", {}), x) for x in value)
    if type(value) is str:
        return schema.get("minLength", 0) <= len(value) <= schema.get("maxLength", math.inf) and \
               ("pattern" not in schema or re.search(schema["pattern"], value) is not None)
    if type(value) in (int, float):
        return schema.get("minimum", -math.inf) <= value <= schema.get("maximum", math.inf)
    return True


def audit_campaign_path(path, v0_root, artifact_root=None, source_root=None):
    p = Path(path)
    try:
        value = _strict_json(p.read_text())
    except (OSError, ValueError) as exc:
        return {"passed": False, "checks": 1, "issues": [{"code": "V4_BUNDLE_UNREADABLE", "detail": str(exc)}]}
    return audit_campaign(value, v0_root, artifact_root or p.parent, source_root)


def audit_campaign(bundle, v0_root, artifact_root=None, source_root=None):
    a = _Audit()
    try:
        return _audit(bundle, Path(v0_root), Path(artifact_root).resolve() if artifact_root else None,
                      Path(source_root).resolve() if source_root else Path(__file__).resolve().parents[2], a)
    except (KeyError, TypeError, ValueError, OSError, IndexError, AttributeError, OverflowError) as exc:
        a.expect(False, "V4_MALFORMED_EVIDENCE", detail=f"{type(exc).__name__}: {exc}")
        return {"passed": False, "business_healthy": False, "checks": a.checks, "issues": a.issues,
                "statistics": {}, "limitations": ["Record audit failure does not authorize retries."]}


def _audit(bundle, v0, root, source, a):
    registry_path = v0 / "registry/formal_items.jsonl"
    registry = [_strict_json(l) for l in registry_path.read_text().splitlines() if l.strip()]
    specs = {r["item_id"]: r for r in registry}
    scene_specs = _strict_json((v0 / "registry/formal_scenes.json").read_text())["scenes"]
    a.expect(bundle.get("mode", bundle.get("execution_mode")) == "real_api" and bundle.get("phase") == "V4",
             "V4_EXPLICIT_REAL_MODE")
    a.expect(bundle.get("campaign_id") == CAMPAIGN, "V4_EXECUTION_CAMPAIGN_ID")
    a.expect(len(registry) == 52 and len(specs) == 52 and bundle.get("registry_sha256") == _sha(registry_path),
             "V4_ORIGINAL_52_REGISTRY")
    ledger = bundle["ledger"]
    accounting = _real_ledger(ledger, registry, v0, a)
    schemas = _source_pins(ledger, root, source, a, v0)
    items = _rows(bundle["items"])
    imap = {x["item_id"]: x for x in items}
    a.expect(len(items) == len(imap) == 52 and set(imap) == set(specs), "V4_ALL_UNEXECUTED_AND_EXECUTED_ROWS_RETAINED")
    calls = _rows(ledger.get("calls"))
    dispatched = {c["call_id"]: c for c in calls if c.get("dispatched")}
    by_item = {iid: [cid for cid, c in dispatched.items() if c["item_id"] == iid] for iid in specs}
    scenes = {s["scene_id"]: s for s in _rows(bundle.get("scenes"))}
    frozen_dags = {d: _strict_json((v0 / "dags" / (d + ".json")).read_text()) for d in ("micro", "macro")}
    raw, raw_calls, input_by_call = {}, {}, {}
    for iid, row in imap.items():
        if iid not in specs:
            continue
        spec = specs[iid]
        for key in ("domain", "kind", "task_id", "policy", "scene_id", "execution_ordinal"):
            if key in row:
                a.expect(row[key] == spec[key], "V4_REGISTERED_ITEM_UNMODIFIED", iid + ":" + key)
        status = row.get("status")
        a.expect(status in TERMINAL | {"not_started", "running"}, "V4_ITEM_STATUS", iid)
        touched = status not in UNSTARTED
        a.expect(row.get("run_count") == int(touched), "V4_NO_RESAMPLE_OR_RERUN", iid)
        ids = row.get("physical_dispatch_ids", [])
        a.expect(len(ids) == len(set(ids)) and set(ids) == set(by_item[iid]), "V4_ITEM_CENTRAL_DISPATCH_BIJECTION", iid)
        if not touched:
            a.expect(not ids and not row.get("raw_export"), "V4_UNSTARTED_ITEM_NO_NEW_WORK", iid)
            continue
        start, deadline = row.get("started_at", row.get("started_at_utc")), row.get("deadline_at", row.get("deadline_utc"))
        a.expect(bool(start) and bool(deadline) and (_utc(deadline) - _utc(start)).total_seconds() == 1800,
                 "V4_FIXED_ITEM_DEADLINE", iid)
        view = _load_item_export(row, root, a)
        if not a.expect(isinstance(view, dict), "V4_STARTED_ITEM_RAW_EXPORT_REQUIRED", iid):
            continue
        raw[iid] = view
        qualified = spec["kind"] == "prefix" and scenes.get(spec.get("scene_id"), {}).get("qualified") is True
        _raw_result(view, spec, status, a, frozen_dags[spec["domain"]], qualified)
        for result in _rows(view.get("results")):
            for cid in result.get("call_ids", []):
                snapshot = result.get("input_snapshot")
                if cid in input_by_call:
                    a.expect(input_by_call[cid] == snapshot, "V4_CLONED_CALL_ACTUAL_INPUT_IDENTICAL", cid)
                else: input_by_call[cid] = snapshot
        for call in _rows(view.get("calls")):
            cid = call["call_id"]
            a.expect(call.get("fixture_only") is False and call.get("mode") == "real" and call.get("request_sent") is True,
                     "V4_RAW_CALL_IS_REAL_INTENT_NOT_FIXTURE", cid)
            if cid in raw_calls:
                a.expect(raw_calls[cid] == call, "V4_PREFIX_COPIES_IDENTICAL", cid)
            else:
                raw_calls[cid] = call
    a.expect(set(raw_calls) == set(dispatched), "V4_RAW_CALL_LEDGER_BIJECTION")
    http = _http_calls(calls, raw_calls, ledger, root, a, schemas, input_by_call)
    matrix = _scenes(bundle, scene_specs, imap, raw, v0, a)
    checkpoints = _checkpoints(bundle, ledger, a)
    _runner_events(bundle.get("events", []), imap, specs, a)
    a.expect(bundle.get("real_api_requests") == len(dispatched), "V4_RUNNER_REAL_DISPATCH_COUNT")
    a.expect(bundle.get("actual_api_cost_nano_usd") == accounting["new_known_cost_nano_usd"], "V4_RUNNER_REAL_COST")
    attempted_scenes = [s for s in scenes.values() if s.get("attempted")]
    touched_rows = [r for r in items if r.get("status") not in UNSTARTED]
    healthy = all(r.get("status") == "completed_correct" if specs[r["item_id"]]["kind"] != "prefix"
                  else scenes.get(specs[r["item_id"]]["scene_id"], {}).get("qualified") is True for r in touched_rows)
    return {"passed": not a.issues, "business_healthy": healthy and bool(touched_rows),
        "checks": a.checks, "issues": a.issues, "accounting": accounting, "http": http,
        "matrix": matrix, "checkpoint_audit": checkpoints,
        "statistics": {"registered_items": 52, "started_items": len(touched_rows),
            "terminal_status_counts": dict(Counter(r["status"] for r in items)),
            "all_items_processed": all(r.get("status") in TERMINAL for r in items),
            "physical_live_dispatches": len(dispatched), "confirmed_provider_receipts": http["confirmed_provider_receipts"],
            "qualified_scenes": sum(s.get("qualified") is True for s in attempted_scenes)},
        "limitations": ["Real intent counts are conservative dispatch fences, not packet capture or a guarantee of provider billing.",
            "Catalog costs are reconstructed from provider usage, not independently verified account debits.",
            "A valid JSON grant is checked for binding; this auditor does not create or infer human authorization.",
            "Business helpers are reused by pinned source identity; runtime guard and policy are not independent oracles.",
            "Synthetic unit-test evidence cannot establish that a real network request occurred."]}


def _source_pins(ledger, root, source, a, v0=None):
    if root is None:
        a.expect(not any(c.get("dispatched") for c in ledger.get("calls", [])), "V4_DISPATCH_AUDIT_REQUIRES_FILES")
        return {}
    config, binding = ledger["config"], ledger["config"]["binding"]
    manifest_path, binding_path, schemas_path = (root / "frozen" / p for p in ("source_manifest.json", "binding.json", "schemas.json"))
    if not a.expect(all(p.is_file() for p in (manifest_path, binding_path, schemas_path)), "V4_FROZEN_BINDING_FILES_REQUIRED"):
        return {}
    manifest, frozen_binding, schemas = (_strict_json(p.read_text()) for p in (manifest_path, binding_path, schemas_path))
    a.expect(binding == frozen_binding and _digest(binding) == config.get("binding_digest"), "V4_FROZEN_REAL_BINDING")
    a.expect(_digest(manifest) == binding.get("source_manifest_digest") and _digest(schemas) == binding.get("schema_digest"),
             "V4_SOURCE_AND_SCHEMA_PINS")
    for relative, expected in manifest.items():
        path = _within(source, relative)
        a.expect(path.is_file() and _sha(path) == expected, "V4_ACTUAL_FROZEN_SOURCE_BYTES", relative)
    inputs_path = root / "frozen/input_manifest.json"
    if not a.expect(inputs_path.is_file() and v0 is not None, "V4_COMPLETE_INPUT_MANIFEST_REQUIRED"):
        return schemas
    inputs = _strict_json(inputs_path.read_text())
    if not a.expect(isinstance(inputs, dict), "V4_INPUT_MANIFEST_MAP_REQUIRED"):
        return schemas
    a.expect(_digest(inputs) == binding.get("input_manifest_digest"), "V4_FROZEN_INPUT_MANIFEST_DIGEST")
    # The trusted V0 root may be an external read-only release symlink. Keys
    # stay logical sr_v2/v0 paths, while bytes resolve only from the supplied
    # root's independently enumerated inventory, never from declared paths.
    input_root = Path(v0).resolve()
    inventory = {"sr_v2/v0/" + p.relative_to(input_root).as_posix(): p
                 for p in input_root.rglob("*") if p.is_file() and
                 not any(part.startswith("._") or part == "__pycache__"
                         for part in p.relative_to(input_root).parts)}
    a.expect(set(inputs) == set(inventory), "V4_COMPLETE_V0_INPUT_FILE_SET")
    for relative, expected in inputs.items():
        a.expect(relative in inventory and isinstance(expected, str) and
                 re.fullmatch(r"[0-9a-f]{64}", expected) is not None and _sha(inventory[relative]) == expected,
                 "V4_ACTUAL_FROZEN_INPUT_BYTES", relative)
    return schemas


def _real_ledger(ledger, registry, v0, a):
    config, binding = ledger["config"], ledger["config"]["binding"]
    a.expect(ledger.get("schema_version") == "sr-v4-budget-snapshot-v1" and ledger.get("execution_mode") == "real_api"
             and ledger.get("simulated") is False, "V4_REAL_LEDGER_REQUIRED")
    a.expect(ledger.get("campaign_id") == config.get("campaign_id") == CAMPAIGN and config.get("execution_mode") == "real_api",
             "V4_REAL_LEDGER_CAMPAIGN")
    fixed = dict(model="api-glm-5.3-flash", base_url="https://tritonai-api.ucsd.edu/v1", input_nano_usd_per_token=150,
        output_nano_usd_per_token=500, max_input_tokens=4000, max_output_tokens=768, financial_input_allowance=6000,
        financial_reservation_nano_usd_per_dispatch=RESERVATION, reasoning_effort="low", total_request_deadline_seconds=120,
        simulated=False, real_requests_authorized=True, automatic_http_retries=0, execution_mode="real_api")
    a.expect(all(binding.get(k) == v and type(binding.get(k)) is type(v) for k, v in fixed.items()), "V4_PINNED_REAL_BINDING")
    allowed_models = binding.get("allowed_response_models")
    a.expect(isinstance(allowed_models, list) and bool(allowed_models) and
             all(isinstance(m, str) for m in allowed_models) and
             set(allowed_models) <= {"api-glm-5.3-flash", "glm-5.3-flash"}, "V4_ALLOWED_RESPONSE_MODEL_BINDING")
    a.expect(_digest(binding) == config.get("binding_digest"), "V4_BINDING_DIGEST")
    registry_sha, baseline_sha = _sha(v0 / "registry/formal_items.jsonl"), _sha(v0 / "budget/historical_baseline.json")
    a.expect(ledger.get("registry") == registry and config.get("registry_sha256") == registry_sha, "V4_UNMODIFIED_CENTRAL_REGISTRY")
    grant = config.get("grant", {})
    authority = config.get("authority", {})
    a.expect(authority.get("execution_mode") == "real_api" and authority.get("baseline_sha256") == baseline_sha and
             all(isinstance(authority.get(k), str) and Path(authority[k]).is_absolute() for k in ("ledger_path", "lock_root")) and
             ledger.get("campaign_budget_ref") == authority.get("ledger_path"), "V4_REAL_AUTHORITY_IDENTITY")
    a.expect(set(grant) == GRANT_FIELDS and grant.get("schema_version") == "sr-v4-runtime-grant-v1" and
             grant.get("record_type") == "V4RuntimeGrant" and grant.get("authorized") is True and
             grant.get("execution_mode") == "real_api" and bool(grant.get("grant_id")) and
             isinstance(grant.get("authorization_reference"), str) and bool(grant["authorization_reference"].strip()), "V4_NEW_EXPLICIT_GRANT")
    for key, expected in dict(campaign_id=CAMPAIGN, binding_digest=_digest(binding), registry_sha256=registry_sha,
        baseline_sha256=baseline_sha, ledger_path=authority.get("ledger_path"), lock_root=authority.get("lock_root"),
        max_new_physical_calls=640, max_cumulative_cost_nano_usd=MAX_COST).items():
        a.expect(grant.get(key) == expected and type(grant.get(key)) is type(expected), "V4_GRANT_IDENTITY_BINDING", key)
    a.expect(_digest(grant) == config.get("grant_digest"), "V4_GRANT_DIGEST")
    cum = ledger["cumulative_budget"]
    a.expect(cum.get("baseline_calls") == BASE_CALLS and cum.get("baseline_known_cost_nano_usd") == BASE_KNOWN and
             cum.get("baseline_held_cost_nano_usd") == BASE_HELD and cum.get("old_unknown_reservation_released") is False,
             "V4_REAL_HISTORY_IMPORTED_ONCE")
    a.expect(ledger.get("baseline") == _strict_json((v0 / "budget/historical_baseline.json").read_text()),
             "V4_FROZEN_BASELINE_RECORD")
    initialization = [e for e in ledger.get("events", []) if e.get("kind") == "initialize"]
    a.expect(len(initialization) == 1 and initialization[0].get("seq") == 1 and
             initialization[0].get("body") == {"config": config, "baseline": ledger.get("baseline")},
             "V4_ORIGINAL_INITIALIZATION_BINDS_REAL_CONFIG")
    calls = _rows(ledger.get("calls")); cmap = {c["call_id"]: c for c in calls}; specs = {r["item_id"]: r for r in registry}
    a.expect(len(cmap) == len(calls) <= 640, "V4_UNIQUE_640_NEW_ATTEMPTS")
    a.expect(len({c["attempt_id"] for c in calls}) == len(calls), "V4_ONE_PHYSICAL_CALL_PER_ATTEMPT")
    known = held = dispatched = 0
    counts, domains = Counter(), Counter()
    hard = []
    for c in calls:
        cid, iid = c["call_id"], c["item_id"]
        if not a.expect(iid in specs, "V4_REGISTERED_CALL_OWNER", cid):
            continue
        s = specs[iid]; counts[iid] += 1; domains[s["domain"]] += 1; dispatched += int(c.get("dispatched") is True)
        a.expect(c.get("domain") == s["domain"] and c.get("kind") == s["kind"] and c.get("reserved_cost_nano_usd") == RESERVATION,
                 "V4_CALL_IDENTITY_AND_RESERVATION", cid)
        status, usage = c.get("status"), _usage(c.get("raw_usage"))
        if status == "settled":
            if a.expect(usage is not None, "V4_SETTLED_RAW_USAGE", cid):
                cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
                a.expect(c.get("usage") == usage and c.get("known_cost_nano_usd") == cost and c.get("held_cost_nano_usd") == 0,
                         "V4_EXACT_REAL_USAGE_COST_NO_CLIPPING", cid)
                if usage["prompt_tokens"] > 4000 or usage["completion_tokens"] > 768 or cost > RESERVATION:
                    hard.append(cid)
        else:
            a.expect(status in {"reserved", "dispatched", "uncertain"} and c.get("known_cost_nano_usd") == 0 and
                     c.get("held_cost_nano_usd") == RESERVATION, "V4_UNKNOWN_FULL_HOLD", cid)
            if status == "uncertain": hard.append(cid)
        known += c.get("known_cost_nano_usd", 0); held += c.get("held_cost_nano_usd", 0)
    for iid, count in counts.items():
        a.expect(count <= specs[iid]["limits"]["physical_llm_call_cap"], "V4_ITEM_CALL_CAP", iid)
    a.expect(all(n <= 320 for n in domains.values()), "V4_DOMAIN_CALL_CAP")
    budget = ledger["budget"]
    for key, expected in dict(calls_reserved_or_spent=len(calls), calls_dispatched=dispatched,
        known_cost_nano_usd=known, held_cost_nano_usd=held).items():
        a.expect(budget.get(key) == expected, "V4_CENTRAL_TOTAL_REBUILT", key)
    a.expect(Counter(budget.get("domain_counts", {})) == domains and Counter(budget.get("item_counts", {})) == counts,
             "V4_CENTRAL_DOMAIN_AND_ITEM_COUNTS")
    expected_kinds = {d: {k: sum(c.get("domain") == d and c.get("kind") == k for c in calls)
                         for k in ("control", "prefix", "branch")} for d in ("micro", "macro")}
    a.expect(budget.get("kind_counts") == expected_kinds, "V4_CENTRAL_KIND_COUNTS")
    a.expect(ledger.get("real_api_requests") == dispatched and ledger.get("real_incremental_cost_nano_usd") == known,
             "V4_REAL_DISPATCH_AND_COST_COUNTERS")
    for key, expected in dict(cumulative_calls=BASE_CALLS + dispatched, known_cost_nano_usd=BASE_KNOWN + known,
        held_cost_nano_usd=BASE_HELD + held, known_plus_held_nano_usd=BASE_KNOWN + BASE_HELD + known + held,
        max_cost_nano_usd=MAX_COST).items():
        a.expect(cum.get(key) == expected, "V4_CUMULATIVE_REAL_BUDGET", key)
    if hard:
        a.expect(ledger.get("status") == "quarantined" and bool(ledger.get("pause_reason")), "V4_HARD_ANOMALY_STOPS_BATCH", detail=hard)
    _late(ledger, cmap, a)
    event_stats = _ledger_events(ledger, cmap, a)
    return dict(new_physical_dispatches=dispatched, new_reserved_or_spent=len(calls), new_known_cost_nano_usd=known,
        new_unknown_hold_nano_usd=held, historical_known_cost_nano_usd=BASE_KNOWN,
        historical_unknown_hold_nano_usd=BASE_HELD, cumulative_known_plus_held_nano_usd=BASE_KNOWN + BASE_HELD + known + held,
        events=event_stats, provider_account_debit_verified=False)


def _late(ledger, calls, a):
    late = _rows(ledger.get("late_receipts")); maximum = {}
    a.expect(late == [dict(call_id=e.get("call_id"), receipt=e.get("body")) for e in ledger.get("events", [])
                     if e.get("kind") == "late_receipt"], "V4_LATE_ORIGINAL_RECEIPTS_PRESERVED")
    for row in late:
        cid, receipt = row["call_id"], row["receipt"]
        usage = _usage(receipt.get("raw_usage"))
        if usage:
            cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
            a.expect(receipt.get("exact_cost_nano_usd") == cost and receipt.get("manual_reconciliation_required") is True,
                     "V4_LATE_EXACT_COST", cid)
            maximum[cid] = max(maximum.get(cid, 0), cost)
    adjustment = 0
    for cid, call in calls.items():
        a.expect(call.get("late_known_exposure_nano_usd", 0) == maximum.get(cid, 0), "V4_LATE_EXPOSURE_REBUILT", cid)
        adjustment += max(0, maximum.get(cid, 0) - call.get("known_cost_nano_usd", 0) - call.get("held_cost_nano_usd", 0))
    cum = ledger["cumulative_budget"]
    risk = cum["known_plus_held_nano_usd"] + adjustment
    a.expect(cum.get("unsettled_exposure_adjustment_nano_usd", 0) == adjustment and
             cum.get("risk_adjusted_known_plus_held_nano_usd", risk) == risk and
             cum.get("risk_adjusted_overrun", risk > MAX_COST) is (risk > MAX_COST), "V4_RISK_EXPOSURE_REBUILT")


def _http_calls(calls, raw_calls, ledger, root, a, schemas=None, input_by_call=None):
    binding = ledger["config"]["binding"]; confirmed = 0; seen_ids = set()
    for call in calls:
        if not call.get("dispatched"):
            continue
        cid, request = call["call_id"], call["request"]
        evidence = call.get("evidence")
        stages = {}
        if root is not None:
            for stage in ("reserved", "dispatched", "response", "settled"):
                path = _within(root, Path("http") / cid / (stage + ".json"))
                if path.is_file(): stages[stage] = _strict_json(path.read_text())
            a.expect(set(stages) == {"reserved", "dispatched", "response", "settled"}, "V4_ALL_FOUR_HTTP_STAGES_RETAINED", cid)
            if "response" in stages:
                if evidence is not None:
                    unverified = {k: v for k, v in evidence.items() if k not in {"unknown_receipt_reason", "receipt_identity_unverified"}}
                    unknown_reason = evidence.get("unknown_receipt_reason")
                    unknown_metadata = call.get("status") == "uncertain" and isinstance(unknown_reason, str) and \
                        bool(unknown_reason.strip()) and evidence.get("receipt_identity_unverified") is \
                        (call.get("provider_request_id") is None)
                    a.expect(stages["response"] == evidence or (unknown_metadata and unverified == stages["response"]),
                        "V4_CENTRAL_RESPONSE_EQUALS_RAW_FILE", cid)
                evidence = stages["response"]
            for stage, record in stages.items():
                a.expect(record.get("call_id", record.get("sidecar", {}).get("call_id")) == cid, "V4_STAGE_CALL_IDENTITY", cid + ":" + stage)
        if not a.expect(isinstance(evidence, dict), "V4_RAW_HTTP_EVIDENCE_REQUIRED", cid): continue
        sidecar = call.get("sidecar", {})
        a.expect(evidence.get("request") == request and all(evidence.get(k) == v for k, v in sidecar.items()),
                 "V4_CENTRAL_SIDECAR_MATCHES_RESPONSE", cid)
        if {"reserved", "dispatched"} <= set(stages):
            a.expect(stages["dispatched"] == sidecar and stages["reserved"] ==
                     {**sidecar, "request": request, "input_snapshot": evidence.get("input_snapshot")},
                     "V4_PRE_DISPATCH_STAGES_EXACTLY_BOUND", cid)
        total_deadline = evidence.get("total_deadline_seconds")
        a.expect(type(total_deadline) in (int, float) and math.isfinite(total_deadline) and
                 0 < total_deadline <= 120, "V4_TOTAL_HTTP_DEADLINE_BOUND", cid)
        http = evidence.get("http_evidence", {})
        a.expect(http.get("simulated") is False and http.get("transport_intent_committed") is True and
                 http.get("method") == "POST" and http.get("url") == binding["base_url"] + "/chat/completions",
                 "V4_LIVE_HTTP_INTENT_FIXED_ENDPOINT", cid)
        body = base64.b64decode(http.get("request_body_b64", ""), validate=True)
        wire_request = _strict_json(body)
        a.expect(wire_request == request and hashlib.sha256(body).hexdigest() == http.get("request_digest") ==
                 evidence.get("request_digest") == _digest(request), "V4_REQUEST_WIRE_BYTES_BOUND", cid)
        fmt = request.get("response_format", {}); contract = fmt.get("json_schema", {})
        _strict_json(request["messages"][1]["content"])
        a.expect(request.get("model") == binding["model"] and request.get("n") == 1 and request.get("stream") is False and
                 request.get("reasoning_effort") == "low" and request.get("max_completion_tokens") == 768 and
                 fmt.get("type") == "json_schema" and contract.get("strict") is True and
                 _digest(contract.get("schema")) == evidence.get("schema_digest"), "V4_REAL_MODEL_REQUEST_CONTRACT", cid)
        if schemas is not None:
            a.expect(contract.get("schema") == schemas.get(call["domain"], {}).get(evidence.get("node_id")),
                     "V4_REQUEST_USES_FROZEN_NODE_SCHEMA", cid)
        snapshot = evidence.get("input_snapshot")
        if a.expect(isinstance(snapshot, dict), "V4_PRE_DISPATCH_FULL_SNAPSHOT_RETAINED", cid):
            if (input_by_call or {}).get(cid) is not None:
                a.expect(snapshot == input_by_call[cid], "V4_WIRE_SNAPSHOT_EQUALS_NODE_RESULT", cid)
            # Only model nodes reach the HTTP gateway; compact projection is
            # checked independently even if no NodeResult could be appended.
            _input_projection({"result_id": cid, "input_snapshot": snapshot,
                               "input_digest": evidence.get("input_digest")},
                              {"node_id": evidence.get("node_id"), "llm_calls_per_execution": 1}, a)
            a.expect(snapshot.get("rendered_messages") == request.get("messages") and
                     _digest(snapshot) == evidence.get("input_digest") == raw_calls.get(cid, {}).get("input_digest"),
                     "V4_REAL_WIRE_MATCHES_ACTUAL_NODE_INPUT", cid)
        a.expect(evidence.get("binding_digest") == ledger["config"]["binding_digest"] and evidence.get("simulated") is False and
                 evidence.get("grant_id") == ledger["config"]["grant"]["grant_id"], "V4_WIRE_GRANT_BINDING", cid)
        cleanup = http.get("cleanup_receipt")
        if a.expect(isinstance(cleanup, dict), "V4_TRANSPORT_CLEANUP_RECEIPT_REQUIRED", cid):
            a.expect(cleanup.get("unit_mocked_process") is not True, "V4_MOCK_TRANSPORT_EVIDENCE_FORBIDDEN", cid)
            a.expect(cleanup.get("simulated") is False and cleanup.get("reaped") is True and cleanup.get("cleanup_failed") is False and
                     cleanup.get("request_digest") == hashlib.sha256(body).hexdigest() and
                     0 < cleanup.get("timeout_s", 0) <= 120, "V4_LIVE_WORKER_REAPED_WITH_DEADLINE", cid)
            a.expect(cleanup.get("provider_cancelled") is False and http.get("provider_cancellation_confirmed") is False,
                     "V4_LOCAL_CANCELLATION_NOT_PROVIDER_GUARANTEE", cid)
        raw = None
        if http.get("response_body_b64") is not None:
            response = base64.b64decode(http["response_body_b64"], validate=True)
            a.expect(hashlib.sha256(response).hexdigest() == http.get("response_sha256"), "V4_ORIGINAL_RESPONSE_BYTES_SHA", cid)
            try: raw = _strict_json(response)
            except ValueError: raw = None
        a.expect(raw == evidence.get("raw_response"), "V4_PARSED_RESPONSE_MATCHES_ORIGINAL_BYTES", cid)
        headers = http.get("headers", {})
        a.expect(set(headers) <= {"x-litellm-call-id", "x-request-id", "request-id", "content-type"} and
                 all(isinstance(v, str) and len(v) <= 256 and "\r" not in v and "\n" not in v for v in headers.values()),
                 "V4_PUBLIC_HEADERS_ONLY", cid)
        def present(name):
            value = headers.get(name)
            return value if isinstance(value, str) and value.strip() else None
        provider_id = present("x-litellm-call-id") or present("x-request-id") or present("request-id")
        a.expect(http.get("request_id") == provider_id, "V4_PROVIDER_ID_PRECEDENCE", cid)
        a.expect(call.get("provider_request_id") == provider_id, "V4_CENTRAL_HEADER_ID_PRESERVED_EVEN_UNKNOWN", cid)
        parsed_usage = _usage(raw.get("usage")) if isinstance(raw, dict) else None
        if call["status"] == "settled":
            a.expect(bool(provider_id) and provider_id == call.get("provider_request_id") and provider_id not in seen_ids,
                     "V4_SETTLED_PROVIDER_RECEIPT_ID", cid); seen_ids.add(provider_id)
            a.expect(parsed_usage == call.get("usage") and parsed_usage is not None, "V4_WIRE_USAGE_MATCHES_LEDGER", cid)
            confirmed += 1
        raw_call = raw_calls.get(cid, {})
        wire_usage = raw.get("usage") if isinstance(raw, dict) else None
        expected_call_usage = {**parsed_usage, "raw": wire_usage} if parsed_usage is not None else None
        a.expect(raw_call.get("usage") == expected_call_usage and call.get("raw_usage") == wire_usage and
                 evidence.get("raw_usage") == (wire_usage if parsed_usage is not None else None),
                 "V4_ALL_ORIGINAL_USAGE_COPIES_BOUND", cid)
        a.expect(raw_call.get("cost_nano_usd") == call.get("known_cost_nano_usd") and
                 raw_call.get("provider_request_id") == provider_id, "V4_WORKFLOW_CALL_COST_AND_PROVIDER_ID", cid)
        a.expect(raw_call.get("attempt_id") == call["attempt_id"] == evidence.get("attempt_id") and
                 evidence.get("item_id") == call["item_id"] and evidence.get("call_id") == cid and
                 evidence.get("node_id") == raw_call.get("node_id") == contract.get("name"), "V4_WIRE_ATTEMPT_NODE_IDENTITY", cid)
        if evidence.get("status") == "completed":
            a.expect(isinstance(raw, dict) and raw.get("model") in binding["allowed_response_models"] and http.get("status") == 200,
                     "V4_SUCCESS_RESPONSE_MODEL_AND_STATUS", cid)
            choices = raw.get("choices", []) if isinstance(raw, dict) else []
            if a.expect(len(choices) == 1 and choices[0].get("finish_reason") == "stop" and choices[0].get("index") == 0,
                        "V4_SINGLE_COMPLETE_CHOICE", cid):
                message = choices[0].get("message", {})
                payload = _strict_json(message["content"])
                a.expect(message.get("role") == "assistant" and message.get("refusal") in (None, "") and
                         _schema_ok(contract["schema"], payload), "V4_SUCCESS_PAYLOAD_SCHEMA_INDEPENDENT", cid)
                a.expect(raw_call.get("raw_response_payload") == payload, "V4_ORIGINAL_MODEL_PAYLOAD_RETAINED", cid)
        if "settled" in stages:
            a.expect(stages["settled"].get("call_evidence") == raw_call and stages["settled"].get("request") == request and
                     stages["settled"].get("http_evidence") == http, "V4_FINAL_HTTP_STAGE_MATCHES_WORKFLOW", cid)
    return dict(physical_live_dispatches=sum(c.get("dispatched") is True for c in calls),
                confirmed_provider_receipts=confirmed, request_count_basis="durable live intent, not packet capture")
