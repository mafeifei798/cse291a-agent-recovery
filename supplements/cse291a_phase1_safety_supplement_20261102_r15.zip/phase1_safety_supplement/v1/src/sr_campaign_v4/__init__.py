"""Explicit live campaign integration; default entry never reads credentials."""
