"""Real V4 admission around the unchanged V3 SQLite transaction engine.

The V3 constructor is deliberately never called: it only admits fake HTTP.
V4 validates a new real binding and explicit runtime grant before opening an
authority. Reserve/dispatch/exact-settlement/unknown/late/cap operations are
inherited unchanged; no simulated flag is temporarily changed. This module has
no credential reader, transport or network code.
"""
from copy import deepcopy
import fcntl
import json
import os
from pathlib import Path
import sqlite3

from sr_campaign_v3 import budget as _engine
from sr_campaign_v3.budget import (DurableV3Budget, V3BudgetError, RESERVATION,
                                  MAX_COST, MAX_CALLS, _digest, _json, _sha, _require)


# Reusing the class preserves callers' stable .code exception contract.
V4BudgetError = V3BudgetError
ENGINE_SHA256 = "9db1385dc5eb67fa0fdb8c0990a572db346d5e88e53897baeafd1e522a494fdf"
GRANT_FIELDS = {"schema_version", "record_type", "grant_id", "campaign_id", "authorized",
    "execution_mode", "binding_digest", "registry_sha256", "baseline_sha256", "ledger_path",
    "lock_root", "max_new_physical_calls", "max_cumulative_cost_nano_usd", "authorization_reference"}


def _real_binding(binding):
    _require(isinstance(binding, dict), "V4_BINDING_INVALID")
    fixed = dict(model="api-glm-5.3-flash", base_url="https://tritonai-api.ucsd.edu/v1",
        input_nano_usd_per_token=150, output_nano_usd_per_token=500,
        max_input_tokens=4000, max_output_tokens=768, financial_input_allowance=6000,
        financial_reservation_nano_usd_per_dispatch=RESERVATION, reasoning_effort="low",
        total_request_deadline_seconds=120, simulated=False, real_requests_authorized=True,
        automatic_http_retries=0, execution_mode="real_api")
    _require(all(binding.get(k) == v and type(binding.get(k)) is type(v) for k,v in fixed.items()),
             "V4_BINDING_INVALID")
    allowed = binding.get("allowed_response_models")
    _require(isinstance(allowed,list) and allowed and all(isinstance(x,str) for x in allowed)
             and set(allowed) <= {"api-glm-5.3-flash", "glm-5.3-flash"}
             and binding.get("runtime_input_target",4000) == 4000
             and binding.get("cached_input_nano_usd_per_token") is None, "V4_BINDING_INVALID")
    # New full binding is mandatory; a historical P3/P4 grant cannot stand in
    # for the current prompt, schema, guard or correction contract.
    for name in ("template_digest", "schema_digest", "guard_digest", "correction_digest"):
        value = binding.get(name)
        _require(isinstance(value,str) and len(value)==64 and all(c in "0123456789abcdef" for c in value),
                 "V4_NEW_RUNTIME_BINDING_REQUIRED")
    return deepcopy(binding)


def grant_template(*, campaign_id, binding, ledger_path, lock_root, v0_root, grant_id,
                   authorization_reference="Awaiting explicit real runtime authorization"):
    """Produce a disabled, reviewable template; never infer permission."""
    _real_binding(binding)
    root=Path(v0_root).resolve()
    return dict(schema_version="sr-v4-runtime-grant-v1",record_type="V4RuntimeGrant",
        grant_id=grant_id,campaign_id=campaign_id,authorized=False,execution_mode="real_api",
        binding_digest=_digest(binding),registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()),lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640,max_cumulative_cost_nano_usd=MAX_COST,
        authorization_reference=authorization_reference)


def validate_v4_grant(grant, *, binding, budget=None, campaign_id=None, ledger_path=None,
                      lock_root=None, v0_root=None):
    """Validate a JSON capability against the actual immutable ledger identity.

    Gateways call this at construction and before every invoke with ``budget``.
    The budget constructor supplies explicit identity paths before opening DBs.
    No key or key path is accepted in the grant.
    """
    _real_binding(binding)
    if budget is not None:
        _require(budget.config.get("execution_mode")=="real_api", "V4_REAL_BUDGET_REQUIRED")
        campaign_id=budget.config["campaign_id"]
        ledger_path,lock_root,v0_root=budget.path,budget.lock_root,budget.v0_root
        _require(budget.config["binding_digest"]==_digest(binding), "V4_GRANT_BINDING_MISMATCH")
    _require(isinstance(grant,dict) and set(grant)==GRANT_FIELDS, "V4_GRANT_INVALID")
    _require(grant["schema_version"]=="sr-v4-runtime-grant-v1" and grant["record_type"]=="V4RuntimeGrant"
             and grant["execution_mode"]=="real_api", "V4_NEW_RUNTIME_GRANT_REQUIRED")
    _require(grant["authorized"] is True, "V4_REAL_REQUESTS_NOT_AUTHORIZED")
    _require(isinstance(grant["grant_id"],str) and grant["grant_id"]
             and isinstance(grant["authorization_reference"],str) and grant["authorization_reference"].strip(),
             "V4_GRANT_AUTHORIZATION_REFERENCE_REQUIRED")
    _require(all(x is not None for x in (campaign_id,ledger_path,lock_root,v0_root)), "V4_GRANT_IDENTITY_REQUIRED")
    root=Path(v0_root).resolve()
    expected=dict(campaign_id=campaign_id,binding_digest=_digest(binding),
        registry_sha256=_sha(root/"registry/formal_items.jsonl"),
        baseline_sha256=_sha(root/"budget/historical_baseline.json"),
        ledger_path=str(Path(ledger_path).resolve()),lock_root=str(Path(lock_root).resolve()),
        max_new_physical_calls=640,max_cumulative_cost_nano_usd=MAX_COST)
    _require(all(grant.get(k)==v and type(grant.get(k)) is type(v) for k,v in expected.items()),
             "V4_GRANT_BINDING_MISMATCH")
    if budget is not None:
        _require(_digest(grant)==budget.config["grant_digest"], "V4_GRANT_CHANGED")
    return deepcopy(grant)


class DurableV4Budget(DurableV3Budget):
    """Real-only constructor with an unchanged generic transaction engine."""
    def __init__(self,path,*,campaign_id,binding,v0_root,lock_root,grant,resume_checkpoint=None):
        self.path=Path(path).resolve()
        self.ref=str(self.path)
        self.lock_root,self.v0_root=Path(lock_root).resolve(),Path(v0_root).resolve()
        self.connection,self._lock_fd,self._failed=None,None,False
        _require(isinstance(campaign_id,str) and campaign_id, "CAMPAIGN_IDENTITY_MISMATCH")
        self.binding=_real_binding(binding)
        self.grant=validate_v4_grant(grant,binding=self.binding,campaign_id=campaign_id,
            ledger_path=self.path,lock_root=self.lock_root,v0_root=self.v0_root)
        _require(_sha(Path(_engine.__file__))==ENGINE_SHA256,"V4_TRANSACTION_ENGINE_CHANGED")
        bpath=self.v0_root/"budget/historical_baseline.json"
        cpath=self.v0_root/"budget/budget_contract.json"
        rpath=self.v0_root/"registry/formal_items.jsonl"
        self.baseline=json.loads(bpath.read_text())
        contract=json.loads(cpath.read_text())
        rc=json.loads((self.v0_root/"registry/registry_contract.json").read_text())
        rows=[json.loads(line) for line in rpath.read_text().splitlines() if line.strip()]
        _require(_sha(bpath)==contract["baseline_reference"]["sha256"]
                 and self.baseline["physical_calls"]==1605
                 and self.baseline["known_cost_nano_usd"]==90_998_300
                 and self.baseline["held_cost_nano_usd"]==984_000
                 and self.baseline["old_unknown_reservation_released"] is False,"HISTORICAL_BASELINE_MISMATCH")
        _require(contract["maximum_new_physical_calls"]==MAX_CALLS
                 and contract["maximum_cumulative_cost_nano_usd"]==MAX_COST
                 and contract["financial_reservation_nano_usd_per_new_dispatch"]==RESERVATION,"BUDGET_CONTRACT_MISMATCH")
        _require(_sha(rpath)==rc["formal_registry"]["sha256"] and len(rows)==52
                 and len({r["item_id"] for r in rows})==52
                 and [r["execution_ordinal"] for r in rows]==list(range(1,53)),"REGISTRY_MISMATCH")
        self.registry={r["item_id"]:r for r in rows}
        for domain in ("micro","macro"):
            for kind,number,cap in (("control",2,10),("prefix",6,5),("branch",18,15)):
                selected=[r for r in rows if r["domain"]==domain and r["kind"]==kind]
                _require(len(selected)==number and all(r["limits"]["physical_llm_call_cap"]==cap for r in selected),
                         "REGISTRY_MISMATCH")
        authority=dict(ledger_path=self.ref,lock_root=str(self.lock_root),baseline_sha256=_sha(bpath),execution_mode="real_api")
        self.config=dict(schema_version="sr-v4-budget-config-v1",campaign_id=campaign_id,authority=authority,
            binding=deepcopy(self.binding),binding_digest=_digest(self.binding),grant_digest=_digest(self.grant),
            grant=deepcopy(self.grant),registry_sha256=_sha(rpath),contract_sha256=_sha(cpath),
            transaction_engine="unchanged sr_campaign_v3.budget generic SQLite operations; V3 constructor not called",
            transaction_engine_sha256=ENGINE_SHA256,runtime_input_target=4000,financial_input_allowance=6000,
            output_token_cap=768,per_request_reservation_nano_usd=RESERVATION,new_physical_call_cap=640,
            domain_call_cap=320,domain_kind_call_caps=dict(control=20,prefix=30,branch=270),
            max_cost_nano_usd=MAX_COST,execution_mode="real_api")
        self.lock_root.mkdir(parents=True,exist_ok=True)
        # Same historical-budget lock filename as V3, not a new lock per DB.
        lockpath=self.lock_root/("sr-v3-"+authority["baseline_sha256"]+".lock")
        self._lock_fd=os.open(lockpath,os.O_CREAT|os.O_RDWR|os.O_CLOEXEC,0o600)
        try:
            try:
                fcntl.flock(self._lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                raise V4BudgetError("CAMPAIGN_LOCK_HELD")
            pinpath=self.lock_root/"authority.json"
            pin={**authority,"campaign_id":campaign_id,"config_digest":_digest(self.config)}
            existed=pinpath.exists()
            if existed:
                _require(json.loads(pinpath.read_text())==pin,"BUDGET_AUTHORITY_MISMATCH")
                _require(self.path.is_file(),"AUTHORITY_LEDGER_MISSING")
            else:
                fd=os.open(pinpath,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                with os.fdopen(fd,"w") as out:
                    out.write(_json(pin)+"\n");out.flush();os.fsync(out.fileno())
                dfd=os.open(self.lock_root,os.O_RDONLY)
                try: os.fsync(dfd)
                finally: os.close(dfd)
            self.path.parent.mkdir(parents=True,exist_ok=True)
            self.connection=sqlite3.connect(self.path,isolation_level=None,timeout=5)
            self.connection.row_factory=sqlite3.Row
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("PRAGMA journal_mode=DELETE")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS campaign(singleton INTEGER PRIMARY KEY CHECK(singleton=1),config TEXT NOT NULL,status TEXT NOT NULL,reason TEXT);
                CREATE TABLE IF NOT EXISTS calls(call_id TEXT PRIMARY KEY,attempt_id TEXT UNIQUE NOT NULL,item_id TEXT NOT NULL,body TEXT NOT NULL,request_digest TEXT NOT NULL,settlement_digest TEXT);
                CREATE TABLE IF NOT EXISTS items(item_id TEXT PRIMARY KEY,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,call_id TEXT,item_id TEXT,at TEXT NOT NULL,body TEXT NOT NULL,event_digest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS receipts(provider_request_id TEXT PRIMARY KEY,call_id TEXT UNIQUE NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS late_receipts(id INTEGER PRIMARY KEY,call_id TEXT NOT NULL,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS checkpoints(id INTEGER PRIMARY KEY,body TEXT NOT NULL);
            """)
            old=self.connection.execute("SELECT * FROM campaign").fetchone()
            if old:
                _require(old["config"]==_json(self.config),"BUDGET_AUTHORITY_MISMATCH")
                if any(c["status"]!="settled" for c in self.calls()) or any(i["status"]=="in_progress" for i in self.items()):
                    self.quarantine(None,"REOPEN_WITH_UNFINISHED_PROGRESS")
                elif old["status"]!="active":
                    pass
                elif self.calls() or self.items():
                    latest=self.connection.execute("SELECT body FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
                    _require(isinstance(resume_checkpoint,dict),"CHECKPOINT_REQUIRED")
                    _require(latest is not None and json.loads(latest[0])==resume_checkpoint
                             and self._checkpoint_body()==resume_checkpoint,"CHECKPOINT_MISMATCH")
                    with self._transaction():
                        self._event("reopen",body={"checkpoint_digest":resume_checkpoint["checkpoint_digest"]})
            else:
                _require(not existed,"AUTHORITY_LEDGER_STATE_MISSING")
                with self._transaction():
                    self.connection.execute("INSERT INTO campaign VALUES(1,?,'active',NULL)",(_json(self.config),))
                    self._event("initialize",body={"config":self.config,"baseline":self.baseline})
        except BaseException:
            self.close()
            raise

    def _active(self):
        # Permissions and binding are checked again before a fresh reserve or
        # dispatch. Settlement still works after a stop so known fees survive.
        try:
            validate_v4_grant(self.grant,binding=self.binding,budget=self)
        except V3BudgetError as exc:
            if self.connection is not None and not self.connection.in_transaction:
                self._reject(exc.code,evidence={"kind":"runtime_grant_validation_failed"})
            raise
        return super()._active()

    def _checkpoint_body(self):
        value=super()._checkpoint_body()
        value["schema_version"]="sr-v4-budget-checkpoint-v1"
        value.pop("checkpoint_digest")
        value["checkpoint_digest"]=_digest(value)
        return value

    def record_unknown_receipt(self,call_id,*,raw_usage,provider_request_id=None,evidence=None,reason="UNKNOWN_PROVIDER_RECEIPT"):
        """Keep observed identity/usage when either cannot form a valid receipt.

        This is one physical request, never a retry. The first retained receipt
        fences it without inventing a provider ID. A valid usage observation is
        then retained by the inherited late/unknown reconciliation path, which
        keeps the original hold and accounts only any extra risk exposure.
        """
        proof={**deepcopy(evidence or {}),"unknown_receipt_reason":reason,
               "receipt_identity_unverified":provider_request_id is None}
        result=super().settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                              evidence=proof,failure_reason=reason)
        try:
            _engine._parse_usage(raw_usage)
        except V3BudgetError:
            return result
        if result["status"]=="uncertain":
            result=super().settle(call_id,provider_request_id=provider_request_id,raw_usage=raw_usage,
                                  evidence=proof,failure_reason=reason)
        return result

    def snapshot(self):
        # The inherited method is a pure SQL aggregation, not fake execution.
        # Return a new real-mode projection; never alter any binding or event.
        value=super().snapshot()
        known=value["budget"]["known_cost_nano_usd"]
        return {**value,"schema_version":"sr-v4-budget-snapshot-v1","execution_mode":"real_api",
            "simulated":False,"real_api_requests":value["budget"]["calls_dispatched"],
            "real_incremental_cost_nano_usd":known,
            "provider_account_debit_verified":False,"provider_bill_guarantee":False,
            "cumulative_budget":{**value["cumulative_budget"],
                "basis":"provider usage times pinned catalog; account debit unverified"}}
