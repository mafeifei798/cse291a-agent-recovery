"""Derived V3 Store; original state transitions/checkpoints remain unchanged."""
import json
from pathlib import Path
import jsonschema

from sr_campaign_v3 import base_store
from sr_campaign_v3.store import V3Store
from sr_recovery_v2.common import ProtocolError
from .validation import SchemaValidatorCache, optimized_diagnose, _bound, _owned_snapshot


class _ValidationBaseStore(base_store.V2Store):
    # Execute the preserved method bodies with only their diagnose global bound
    # to the candidate. This is local to this subclass, not a module monkeypatch.
    _check_guard = _bound(base_store.V2Store._check_guard, {"diagnose": optimized_diagnose})
    admit_decision = _bound(base_store.V2Store.admit_decision, {"diagnose": optimized_diagnose})
    start_node = _bound(base_store.V2Store.start_node, {"diagnose": optimized_diagnose})
    finish_node = _bound(base_store.V2Store.finish_node, {"diagnose": optimized_diagnose})

    def _validate(self, record):
        if not hasattr(self, "_schema"):
            path = Path(base_store.__file__).resolve().parents[2] / "sr_v2/v0/contracts/records.schema.json"
            self._schema = _owned_snapshot(json.loads(path.read_text()))
        if not hasattr(self, "_validator_cache"):
            self._validator_cache = SchemaValidatorCache()
        try:
            self._validator_cache.validate_immutable(self._schema, record)
        except jsonschema.ValidationError as exc:
            raise ProtocolError("RECORD_SCHEMA_INVALID", str(exc.message)) from exc


class OptimizedV3Store(V3Store, _ValidationBaseStore):
    """All original V3 behavior, with single-invocation metadata digest reuse.

    The diamond MRO keeps V3's lifecycle overrides, then binds its super() calls
    to the derived V2 method bodies. No original producer source is edited.
    """

