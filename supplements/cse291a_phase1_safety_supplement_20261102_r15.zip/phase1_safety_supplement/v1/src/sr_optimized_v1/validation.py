"""Opt-in, invocation-local validation reuse; no guard outcome/file cache.

The preserved V3 guard code runs against an owned read-only JSON tree. Only
canonical digests of repeated references inside that one tree are memoized.
Every call/checkpoint takes a new tree and reads artifact bytes again. Compiled
schema validators are reusable; record validation results never are.
"""
from contextlib import contextmanager
from contextvars import ContextVar
import ast
import copy
import hashlib
import inspect
import time
from types import FunctionType

import jsonschema
from sr_campaign_v3 import guard as original_guard
from sr_recovery_v2 import common

_ORIGINAL_DIAGNOSE = original_guard.diagnose
_DIAGNOSTICS = ContextVar("sr_optimized_validation_diagnostics", default=None)


def _guard_view_fields(function):
    """Derive every direct view read; fail closed on future dynamic access."""
    source = inspect.getsource(function)
    tree = ast.parse(source)
    parents = {child: node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    fields = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Name) or node.id != "view":
            continue
        parent = parents.get(node)
        if isinstance(parent, ast.Subscript) and parent.value is node:
            key = parent.slice
        elif isinstance(parent, ast.Attribute) and parent.value is node and parent.attr == "get":
            call = parents.get(parent)
            if not isinstance(call, ast.Call) or call.func is not parent or not call.args:
                raise RuntimeError("OPTIMIZED_GUARD_DYNAMIC_VIEW_ACCESS")
            key = call.args[0]
        else:
            raise RuntimeError("OPTIMIZED_GUARD_DYNAMIC_VIEW_ACCESS")
        if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
            raise RuntimeError("OPTIMIZED_GUARD_DYNAMIC_VIEW_ACCESS")
        fields.add(key.value)
    return frozenset(fields), hashlib.sha256(source.encode()).hexdigest()


GUARD_VIEW_FIELDS, GUARD_SOURCE_SHA256 = _guard_view_fields(_ORIGINAL_DIAGNOSE)


def _count(name, value=1):
    target = _DIAGNOSTICS.get()
    if target is not None:
        target[name] = target.get(name, 0) + value


@contextmanager
def validation_diagnostics():
    """Optional counters/times only; they contain no reused success decisions."""
    values = {}
    token = _DIAGNOSTICS.set(values)
    try:
        yield values
    finally:
        _DIAGNOSTICS.reset(token)


def _immutable(*args, **kwargs):
    raise TypeError("OWNED_VALIDATION_SNAPSHOT_IS_IMMUTABLE")


class _FrozenDict(dict):
    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = __ior__ = _immutable
    def __deepcopy__(self, memo):
        memo[id(self)] = self
        return self


class _FrozenList(list):
    __setitem__ = __delitem__ = append = clear = extend = insert = pop = remove = reverse = sort = __iadd__ = __imul__ = _immutable
    def __deepcopy__(self, memo):
        memo[id(self)] = self
        return self


def _owned_snapshot(value, memo=None):
    """Private JSON copy, preserving aliases and keeping container types JSON-like."""
    memo = {} if memo is None else memo
    identity = id(value)
    if identity in memo:
        return memo[identity]
    if isinstance(value, dict):
        result = _FrozenDict()
        memo[identity] = result
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("VALIDATION_JSON_OBJECT_KEYS_REQUIRED")
            dict.__setitem__(result, key, _owned_snapshot(item, memo))
        return result
    if isinstance(value, list):
        result = _FrozenList()
        memo[identity] = result
        for item in value:
            list.append(result, _owned_snapshot(item, memo))
        return result
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError("VALIDATION_JSON_VALUE_REQUIRED")


class _InvocationDigests:
    def __init__(self):
        # Each value is strongly retained. A temporary object's recycled id can
        # never match a memo entry. Only the owned frozen containers can enter.
        self.entries = {}

    def digest(self, value):
        _count("digest_calls")
        owned = isinstance(value, (_FrozenDict, _FrozenList))
        cached = self.entries.get(id(value)) if owned else None
        if cached is not None and cached[0] is value:
            _count("digest_hits")
            _count("canonical_bytes_avoided", cached[2])
            return cached[1]
        raw = common.canonical(value).encode("utf-8")
        answer = hashlib.sha256(raw).hexdigest()
        _count("digest_sha_calls")
        _count("canonical_bytes_hashed", len(raw))
        if owned:
            self.entries[id(value)] = (value, answer, len(raw))
        return answer


def _bound(function, replacements):
    """New function object and globals; never mutate the original module."""
    globals_copy = dict(function.__globals__)
    globals_copy.update(replacements)
    result = FunctionType(function.__code__, globals_copy, function.__name__,
                          function.__defaults__, function.__closure__)
    result.__kwdefaults__ = function.__kwdefaults__
    result.__doc__ = function.__doc__
    result.__qualname__ = function.__qualname__
    return result


def optimized_diagnose(view, node_id, checkpoint="pre_dispatch", candidate=None,
                       full=False, artifact_root=None):
    """Identical V3 GuardEvidence with no reuse between calls or checkpoints."""
    _count("guard_calls")
    start = time.perf_counter_ns()
    owned = _owned_snapshot({"view": {key: view[key] for key in GUARD_VIEW_FIELDS if key in view},
                             "candidate": candidate})
    _count("snapshot_wall_ns", time.perf_counter_ns() - start)
    memo = _InvocationDigests()
    fingerprint = _bound(common.source_fingerprint, {"digest": memo.digest})
    graph = _bound(common.selected_graph_digest, {"digest": memo.digest})
    function = _bound(_ORIGINAL_DIAGNOSE, {"digest": memo.digest,
        "source_fingerprint": fingerprint, "selected_graph_digest": graph})
    # The unchanged original artifact_value closure always performs its fresh
    # read_bytes/size/SHA checks. No filesystem result enters the digest memo.
    return function(owned["view"], node_id, checkpoint=checkpoint,
                    candidate=owned["candidate"], full=full, artifact_root=artifact_root)


class SchemaValidatorCache:
    """Bounded single-schema cache of validators, never of validation outcomes."""
    def __init__(self):
        self._schema_sha = None
        self._validators = {}
        self._owned_key = None

    def validate(self, schema, record):
        _count("schema_validation_calls")
        start = time.perf_counter_ns()
        signature = hashlib.sha256(common.canonical(schema).encode("utf-8")).hexdigest()
        _count("schema_content_hash_wall_ns", time.perf_counter_ns() - start)
        self._validate_bound(schema, record, signature)

    def validate_immutable(self, schema, record):
        """Store-only path: a strong-held owned schema cannot change in place."""
        if not isinstance(schema, _FrozenDict):
            return self.validate(schema, record)
        _count("schema_validation_calls")
        if self._owned_key is None or self._owned_key[0] is not schema:
            start = time.perf_counter_ns()
            signature = hashlib.sha256(common.canonical(schema).encode("utf-8")).hexdigest()
            _count("schema_content_hash_wall_ns", time.perf_counter_ns() - start)
            self._owned_key = (schema, signature)
            _count("immutable_schema_key_builds")
        else:
            signature = self._owned_key[1]
            _count("immutable_schema_key_hits")
        self._validate_bound(schema, record, signature)

    def _validate_bound(self, schema, record, signature):
        if signature != self._schema_sha:
            self._schema_sha = signature
            self._validators = {}
            _count("schema_content_epochs")
        kind = record["record_type"]
        validator = self._validators.get(kind)
        if validator is None:
            # A private schema copy prevents later caller mutation from changing
            # a compiled entry while the full-content SHA names its old meaning.
            bound_schema = {**copy.deepcopy(schema), "oneOf": [{"$ref": "#/$defs/" + kind}]}
            validator = jsonschema.Draft202012Validator(bound_schema)
            self._validators[kind] = validator
            _count("schema_validator_builds")
        else:
            _count("schema_validator_hits")
        validator.validate(record)

