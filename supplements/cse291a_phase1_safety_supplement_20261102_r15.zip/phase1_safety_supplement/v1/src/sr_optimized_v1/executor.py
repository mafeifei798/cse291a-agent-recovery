"""Candidate V1 Linux supervisor: unchanged limits, targeted process discovery.

Derived from sr_campaign_v3.executor without modifying it. The direct child is
observed with waitid(WNOWAIT) until cleanup, preventing numeric PID/PGID reuse.
Normal polls discover the complete sampled owned tree via every thread's
children file. Races/unreadable metadata fall back to a full process scan.
This is a sampled RLIMIT_AS + group RSS supervisor, not a cgroup memory limit.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

from sr_recovery_v2.common import ProtocolError, canonical, utc_parse, utc_format
from . import pidfd

GIB = 1024 ** 3
MIB = 1024 ** 2
LIMITS = {'address_space_bytes': 8 * GIB, 'rss_monitor_bytes': 8 * GIB,
          'max_artifact_bytes': 128 * MIB, 'total_disk_bytes': 4 * GIB}
TOOLS = {'execute', 'profile', 'prepare', 'fit_lr', 'fit_rf', 'predict_lr', 'predict_rf',
         'summary_lr', 'summary_rf', 'publish', 'independent_check',
         'test_sleep', 'test_term_resistant', 'test_child', 'test_crash',
         'test_allocate', 'test_file'}


def now():
    return utc_format(datetime.now(timezone.utc))


def disk_usage(root):
    """All newly allocated files count, including failed staging and SQLite WAL.

    Shared immutable hardlinks count once physically. Logical bytes are also
    reported so sharing never makes the recorded outputs disappear.
    """
    seen, physical, logical, largest = set(), 0, 0, 0
    for path in Path(root).rglob('*'):
        if path.is_symlink() or not path.is_file():
            continue
        stat = path.stat()
        logical += stat.st_size
        largest = max(largest, stat.st_size)
        key = (stat.st_dev, stat.st_ino)
        if key not in seen:
            physical += stat.st_blocks * 512
            seen.add(key)
    return {'physical_bytes': physical, 'logical_bytes': logical, 'largest_file_bytes': largest}


def _members(pgid):
    found = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            raw = (path / 'stat').read_text()
            parts = raw[raw.rfind(')') + 2:].split()
            if int(parts[2]) != pgid:
                continue
            rss = int(parts[21]) * os.sysconf('SC_PAGE_SIZE')
            found.append({'pid': int(path.name), 'state': parts[0], 'rss_bytes': rss})
        except (OSError, ValueError, IndexError):
            continue
    return found


def _subreaper():
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        return libc.prctl(36, 1, 0, 0, 0) == 0  # PR_SET_CHILD_SUBREAPER
    except (OSError, AttributeError):
        return False


def _signal_group(pgid, sig):
    try:
        os.killpg(pgid, sig)
        return True
    except ProcessLookupError:
        return False


def _reap_adopted(pgid):
    while True:
        try:
            pid, _ = os.waitpid(-pgid, os.WNOHANG)
            if pid == 0:
                return
        except ChildProcessError:
            return


class ProcUnstable(RuntimeError):
    """A directional snapshot cannot safely establish the group's members."""


class ProcessTreeScanner:
    """Per-job discovery with original leader held unreaped during cleanup.

    `/proc/*/children` is sampled, not atomic. Two equal topology passes are
    required; every process is checked before and after reading all threads.
    Any instability falls back to the complete /proc scan for that poll.
    Known descendants remain owned even if they change session/process group.
    An untraceable, newly adopted process outside this group is never claimed
    or signalled: it makes the receipt uncertain instead of a false success.
    """
    def __init__(self, pgid, leader_start_ticks, *, subreaper, controller_pid=None,
                 proc_root='/proc', baseline_children=(), baseline_complete=True,
                 leader_held=False):
        self.pgid, self.leader_start_ticks = pgid, leader_start_ticks
        self.controller_pid = controller_pid if controller_pid is not None else os.getpid()
        self.proc_root = Path(proc_root)
        self.enabled = bool(subreaper and leader_start_ticks > 0 and baseline_complete)
        self.leader_held = leader_held
        self.known = {pgid: leader_start_ticks}
        self.pidfds, self.pidfd_failed = {}, set()
        self.baseline_children = set(baseline_children)
        self.escaped, self.ambiguous, self.hazards = {}, {}, []
        self.stats = dict(fast_polls=0, fallback_polls=0, full_scans=0,
                          group_absent_shortcuts=0, proc_stat_reads=0, children_reads=0,
                          pidfds_opened=0, pidfd_signals=0, pidfd_reaps=0, fallback_reasons={})

    def _stat(self, pid):
        self.stats['proc_stat_reads'] += 1
        raw = (self.proc_root / str(pid) / 'stat').read_text()
        parts = raw[raw.rfind(')') + 2:].split()
        if len(parts) < 22:
            raise ProcUnstable('TRUNCATED_PROC_STAT')
        return dict(pid=pid, state=parts[0], ppid=int(parts[1]), pgid=int(parts[2]),
                    sid=int(parts[3]), start_ticks=int(parts[19]),
                    rss_bytes=max(0, int(parts[21])) * os.sysconf('SC_PAGE_SIZE'))

    @staticmethod
    def _identity(row):
        return tuple(row[k] for k in ('pid', 'start_ticks', 'ppid', 'pgid', 'sid'))

    def _children(self, row):
        path = self.proc_root / str(row['pid']) / 'task'
        tasks = sorted(int(p.name) for p in path.iterdir() if p.name.isdigit())
        if not tasks:
            raise ProcUnstable('EMPTY_PROCESS_TASKS')
        found = set()
        for tid in tasks:
            self.stats['children_reads'] += 1
            text = (path / str(tid) / 'children').read_text()
            found.update(int(value) for value in text.split())
        after_tasks = sorted(int(p.name) for p in path.iterdir() if p.name.isdigit())
        after = self._stat(row['pid'])
        if tasks != after_tasks or self._identity(row) != self._identity(after):
            raise ProcUnstable('PROC_IDENTITY_OR_THREADS_CHANGED')
        return found

    def _group_exists(self):
        try:
            os.killpg(self.pgid, 0)
            return True
        except ProcessLookupError:
            return False
        # EPERM is evidence that the group may exist, never an empty group.
        except PermissionError as exc:
            raise ProcUnstable('GROUP_EXISTENCE_PERMISSION') from exc

    def _remember(self, row):
        previous = self.known.get(row['pid'])
        if previous is not None and previous != row['start_ticks']:
            self.hazards.append(dict(code='OWNED_PID_REUSED', pid=row['pid'],
                original_start_ticks=previous, observed_start_ticks=row['start_ticks']))
            raise ProcUnstable('OWNED_PID_REUSED')
        self.known[row['pid']] = row['start_ticks']
        if row['pid'] != self.pgid:
            self._pin_descendant(row)
        if row['pgid'] != self.pgid or row['sid'] != self.pgid:
            self.escaped[row['pid']] = row['start_ticks']

    def _pin_descendant(self, row):
        pid, ticks = row['pid'], row['start_ticks']
        if pid in self.pidfds or pid in self.pidfd_failed:
            return
        fd = None
        try:
            if not pidfd.available():
                raise ProcUnstable('PIDFD_UNAVAILABLE')
            fd = pidfd.open_pidfd(pid, 0)
            # Open first, then inspect the numeric PID. The retained descriptor
            # binds future signal/wait operations even if numeric reuse races
            # with a subsequent /proc read; no bare-PID kill/wait fallback.
            current = self._stat(pid)
            if current['start_ticks'] != ticks:
                raise ProcUnstable('PIDFD_IDENTITY_MISMATCH')
            self.pidfds[pid] = (fd, ticks)
            self.stats['pidfds_opened'] += 1
            fd = None
        except (OSError, ValueError, IndexError, ProcUnstable) as exc:
            self.pidfd_failed.add(pid)
            self.hazards.append(dict(code='DESCENDANT_PIDFD_UNCERTAIN', pid=pid,
                                     reason=str(exc) if isinstance(exc, ProcUnstable) else type(exc).__name__))
        finally:
            if fd is not None:
                os.close(fd)

    def _walk(self):
        controller = self._stat(self.controller_pid)
        adopted = self._children(controller)
        queue = list(self.known)
        for pid in sorted(adopted - self.baseline_children - set(self.known)):
            row = self._stat(pid)
            if row['pgid'] == self.pgid and row['sid'] == self.pgid:
                self._remember(row)
                queue.append(pid)
            else:
                # Could be an escaped double-fork or an unrelated concurrent
                # child. No ownership guess and no signal to an unknown PID.
                self.ambiguous[pid] = row
                raise ProcUnstable('UNATTRIBUTABLE_NEW_ADOPTED_CHILD')
        rows, edges = {}, set()
        while queue:
            pid = queue.pop()
            if pid in rows:
                continue
            row = self._stat(pid)
            self._remember(row)
            children = self._children(row)
            rows[pid] = row
            for child in children:
                edges.add((pid, child))
                child_row = self._stat(child)
                self._remember(child_row)
                queue.append(child)
        # Resample adoption after traversing the worker: a parent may have
        # exited while we read its descendants. Any changed adoption falls back.
        if adopted != self._children(self._stat(self.controller_pid)):
            raise ProcUnstable('CONTROLLER_ADOPTION_CHANGED')
        return rows, edges

    def full_members(self, *, exclude_leader=False):
        """Always enumerate /proc; final receipts never rely on a cached tree."""
        self.stats['full_scans'] += 1
        found, errors, all_rows = {}, [], {}
        for path in self.proc_root.iterdir():
            if not path.name.isdigit():
                continue
            try:
                row = self._stat(int(path.name))
            except (FileNotFoundError, ProcessLookupError):
                continue
            except (OSError, ValueError, IndexError, ProcUnstable) as exc:
                errors.append(dict(pid=int(path.name), type=type(exc).__name__))
                continue
            all_rows[row['pid']] = row
            original = self.known.get(row['pid'])
            if row['pid'] == self.pgid and row['start_ticks'] != self.leader_start_ticks:
                self.hazards.append(dict(code='LEADER_PID_REUSED', pid=row['pid']))
                continue
            if original is not None and row['start_ticks'] != original:
                self.hazards.append(dict(code='OWNED_PID_REUSED', pid=row['pid']))
                continue
            if row['pgid'] == self.pgid and row['sid'] == self.pgid or original is not None:
                try:
                    self._remember(row)
                except ProcUnstable:
                    continue
                found[row['pid']] = row
        # Even a leader that exits before its first live poll must not hide an
        # escaped child. Reconstruct any observable owned ancestry from this
        # full snapshot, plus new direct adoptions by the subreaper.
        children = {}
        for row in all_rows.values():
            children.setdefault(row['ppid'], []).append(row)
        queue, visited = list(found), set()
        while queue:
            parent = queue.pop()
            if parent in visited:
                continue
            visited.add(parent)
            for row in children.get(parent, []):
                try:
                    self._remember(row)
                except ProcUnstable:
                    continue
                found[row['pid']] = row
                queue.append(row['pid'])
        for row in children.get(self.controller_pid, []):
            if row['pid'] in self.baseline_children or row['pid'] in self.known:
                continue
            if row['sid'] == self.pgid:
                self._remember(row)
                found[row['pid']] = row
            else:
                self.ambiguous[row['pid']] = row
        # Reading somebody else's transient process is harmless only if the
        # original group is proven absent. Permission errors are not emptiness.
        if errors:
            try:
                exists = self._group_exists()
            except ProcUnstable:
                exists = True
            if exists:
                self.hazards.append(dict(code='INCOMPLETE_FULL_PROC_SCAN', errors=errors))
        for pid, row in list(self.ambiguous.items()):
            try:
                current = self._stat(pid)
            except (FileNotFoundError, ProcessLookupError):
                del self.ambiguous[pid]
                continue
            except (OSError, ValueError, IndexError, ProcUnstable):
                continue
            if current['start_ticks'] != row['start_ticks']:
                del self.ambiguous[pid]
        if exclude_leader:
            found.pop(self.pgid, None)
        return sorted(found.values(), key=lambda row: row['pid'])

    def members(self):
        if not self.enabled:
            self.stats['fallback_polls'] += 1
            reason = 'FAST_PATH_UNAVAILABLE'
            self.stats['fallback_reasons'][reason] = self.stats['fallback_reasons'].get(reason, 0) + 1
            return self.full_members()
        try:
            if not self._group_exists() and not self.escaped and not self.ambiguous:
                self.stats['group_absent_shortcuts'] += 1
                return []
            first, first_edges = self._walk()
            second, second_edges = self._walk()
            topology = lambda rows: {(pid, row['start_ticks'], row['ppid'], row['pgid'], row['sid']) for pid, row in rows.items()}
            if topology(first) != topology(second) or first_edges != second_edges:
                raise ProcUnstable('PROCESS_TREE_NOT_STABLE')
            self.stats['fast_polls'] += 1
            return sorted(second.values(), key=lambda row: row['pid'])
        except (OSError, ValueError, IndexError, ProcUnstable) as exc:
            self.stats['fallback_polls'] += 1
            reason = str(exc) if isinstance(exc, ProcUnstable) else type(exc).__name__
            self.stats['fallback_reasons'][reason] = self.stats['fallback_reasons'].get(reason, 0) + 1
            return self.full_members()

    def signal(self, sig):
        """Verify unreaped leader identity before group signals; verify escaped PIDs."""
        sent = False
        try:
            if not self.leader_held:
                raise ProcUnstable('LEADER_NOT_HELD')
            leader = self._stat(self.pgid)
            if leader['start_ticks'] != self.leader_start_ticks or leader['pgid'] != self.pgid or leader['sid'] != self.pgid:
                raise ProcUnstable('GROUP_OWNER_IDENTITY_CHANGED')
            sent = _signal_group(self.pgid, sig)
        except (OSError, ValueError, IndexError, ProcUnstable) as exc:
            self.hazards.append(dict(code='GROUP_SIGNAL_IDENTITY_UNCERTAIN', type=type(exc).__name__))
            if self.leader_held and self.leader_start_ticks == 0:
                # A failed initial /proc read must not strand the Popen child.
                # WNOWAIT verifies it remains our unreaped child, so its PID
                # cannot be recycled; no numerical PID ownership guess occurs.
                try:
                    _exited_without_reap(self.pgid)
                    sent = _signal_group(self.pgid, sig)
                except (ChildProcessError, ProcessLookupError, PermissionError):
                    pass
        for pid, ticks in list(self.escaped.items()):
            try:
                handle = self.pidfds.get(pid)
                if handle is None or handle[1] != ticks:
                    raise ProcUnstable('ESCAPED_PIDFD_REQUIRED')
                pidfd.send_signal(handle[0], sig)
                self.stats['pidfd_signals'] += 1
                sent = True
            except (FileNotFoundError, ProcessLookupError):
                continue
            except (OSError, ValueError, IndexError, ProcUnstable) as exc:
                self.hazards.append(dict(code='ESCAPED_SIGNAL_IDENTITY_UNCERTAIN', pid=pid, type=type(exc).__name__))
        return sent

    def reap_adopted(self):
        for pid, ticks in list(self.known.items()):
            if pid == self.pgid:
                continue  # The held leader is reaped only with wait4 for rusage.
            try:
                handle = self.pidfds.get(pid)
                if handle is None or handle[1] != ticks:
                    continue  # Uncertainty was already recorded during pinning.
                result = pidfd.wait(handle[0], os.WEXITED | os.WNOHANG)
                if result is not None:
                    self.stats['pidfd_reaps'] += 1
            except (FileNotFoundError, ProcessLookupError, ChildProcessError):
                continue
            except (OSError, ValueError, IndexError, ProcUnstable) as exc:
                self.hazards.append(dict(code='ADOPTED_REAP_IDENTITY_UNCERTAIN', pid=pid, type=type(exc).__name__))

    def close(self):
        handles, self.pidfds = list(self.pidfds.values()), {}
        for fd, _ in handles:
            try:
                os.close(fd)
            except OSError as exc:
                self.hazards.append(dict(code='PIDFD_CLOSE_ERROR', type=type(exc).__name__))

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def public_members(self, rows):
        result = [dict(pid=row['pid'], state=row['state'], rss_bytes=row['rss_bytes']) for row in rows]
        result.extend(dict(pid=row['pid'], state=row['state'], rss_bytes=row['rss_bytes'],
                           ownership_uncertain=True) for row in self.ambiguous.values()
                      if row['pid'] not in {r['pid'] for r in rows})
        return result


def _controller_children():
    """Snapshot only local threads; a failure disables the fast path."""
    root = Path('/proc') / str(os.getpid()) / 'task'
    try:
        tids = sorted(p.name for p in root.iterdir() if p.name.isdigit())
        children = set()
        for tid in tids:
            children.update(int(pid) for pid in (root / tid / 'children').read_text().split())
        if tids != sorted(p.name for p in root.iterdir() if p.name.isdigit()):
            return (), False
        return children, True
    except (OSError, ValueError):
        return (), False


def _exited_without_reap(pid):
    return os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is not None


def run_job(spec, campaign_root, timeout_seconds=120, limits=None, on_started=None):
    """Persisted attempt must already exist before invoking this function.

    Every child gets a fresh environment without inherited credentials. Limits
    apply before Python imports, model loading, computation and serialization.
    RSS is monitored, not advertised as a kernel-enforced whole-group RAM cap.
    """
    tool = spec['tool']
    if tool not in TOOLS:
        raise ProtocolError('CPU_TOOL_NOT_ALLOWED')
    campaign = Path(campaign_root).resolve()
    stage = Path(spec['output_dir']).resolve()
    if not stage.is_relative_to(campaign):
        raise ProtocolError('STAGING_PATH_ESCAPE')
    stage.mkdir(parents=True, exist_ok=True)
    budget = {**LIMITS, **(limits or {})}
    before_disk = disk_usage(campaign)
    # Reserve a conservative output envelope before starting work; never delete
    # old evidence to obtain more space. Reservation is a check, not a disk quota.
    reserve = int(spec.get('output_reservation_bytes', 64 * MIB))
    if before_disk['physical_bytes'] + reserve > budget['total_disk_bytes']:
        raise ProtocolError('V2_DISK_ADMISSION_STOP')
    if os.statvfs(campaign).f_bavail * os.statvfs(campaign).f_frsize < max(6 * GIB, reserve):
        raise ProtocolError('V2_FILESYSTEM_SPACE_STOP')
    began = now()
    remaining = (utc_parse(spec['deadline_utc']) - utc_parse(began)).total_seconds()
    duration = min(float(timeout_seconds), remaining)
    if duration <= 0:
        raise ProtocolError('FIXED_DEADLINE_EXPIRED')
    effective_deadline = spec['deadline_utc'] if remaining <= float(timeout_seconds) else utc_format(
        utc_parse(began) + __import__('datetime').timedelta(seconds=duration))
    spec = {**spec, 'limits': budget, 'deadline_utc': effective_deadline}
    spec_path, response_path = stage / 'job_spec.json', stage / 'job_response.json'
    spec_path.write_text(canonical(spec) + '\n')
    module = 'sr_campaign_v3.micro_worker' if tool == 'execute' else ('sr_cpu_v2.check_worker' if tool == 'independent_check' else (
        'sr_cpu_v2.resource_worker' if tool.startswith('test_') else 'sr_cpu_v2.worker'))
    source_root = Path(__file__).resolve().parents[2]
    source_path = source_root / 'src' / Path(*module.split('.')).with_suffix('.py')
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
           'PYTHONPATH': str(source_root / 'src'), 'PYTHONDONTWRITEBYTECODE': '1',
           'PYTHONNOUSERSITE': '1', 'CUDA_VISIBLE_DEVICES': '', 'HF_HUB_OFFLINE': '1',
           'TRANSFORMERS_OFFLINE': '1', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
           'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}

    def child_limits():
        resource.setrlimit(resource.RLIMIT_AS, (budget['address_space_bytes'], budget['address_space_bytes']))
        resource.setrlimit(resource.RLIMIT_FSIZE, (budget['max_artifact_bytes'], budget['max_artifact_bytes']))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        # A controller crash must not leave its trusted direct worker training.
        ctypes.CDLL(None).prctl(1, signal.SIGKILL, 0, 0, 0)  # PR_SET_PDEATHSIG

    subreaper = _subreaper()
    baseline_children, baseline_complete = _controller_children()
    wall_start = time.monotonic()
    cpu_start = time.process_time()
    stdout_path, stderr_path = stage / 'stdout.log', stage / 'stderr.log'
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        process = subprocess.Popen([sys.executable, '-B', '-m', module, '--spec', str(spec_path),
                                   '--response', str(response_path)], cwd=source_root, env=env,
                                   stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                   start_new_session=True, preexec_fn=child_limits)
        pid, pgid = process.pid, process.pid
        peak_rss, status, usage = 0, 'success', None
        term_sent = kill_sent = False
        reap_status = None
        identity = {'job_id': spec['job_id'], 'pid': pid, 'pgid': pgid,
            'process_start_ticks': 0, 'spec_path': str(spec_path),
            'started_at_utc': began, 'started_identity_path': str(stage / 'started_identity.json')}
        callback_error = None
        try:
            raw_stat = Path('/proc') / str(pid) / 'stat'
            stat_parts = raw_stat.read_text().rsplit(')', 1)[1].split()
            identity['process_start_ticks'] = int(stat_parts[19])
            with (stage / 'started_identity.tmp').open('w') as handle:
                handle.write(canonical(identity) + '\n')
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(stage / 'started_identity.tmp', stage / 'started_identity.json')
            if on_started is not None:
                on_started(identity)
        except BaseException as exc:
            callback_error = {'type': type(exc).__name__, 'message': str(exc)}
            status = 'uncertain'
        scanner = ProcessTreeScanner(pgid, identity['process_start_ticks'], subreaper=subreaper,
            baseline_children=baseline_children, baseline_complete=baseline_complete, leader_held=True)
        with scanner:
            leader_exited = False
            while True:
                if _exited_without_reap(pid):
                    leader_exited = True
                    break
                members = scanner.members()
                peak_rss = max(peak_rss, sum(x['rss_bytes'] for x in members))
                elapsed = time.monotonic() - wall_start
                if callback_error is not None:
                    status = 'uncertain'
                elif scanner.hazards or scanner.ambiguous or scanner.escaped:
                    status = 'uncertain'
                elif elapsed >= duration:
                    status = 'timeout'
                elif peak_rss > budget['rss_monitor_bytes']:
                    status = 'memory_exceeded'
                else:
                    used = disk_usage(campaign)
                    if used['physical_bytes'] > budget['total_disk_bytes']:
                        status = 'disk_exceeded'
                if status != 'success':
                    # Termination always starts from a fresh full scan. The held
                    # unreaped leader keeps its PGID identity valid through cleanup.
                    scanner.full_members()
                    term_sent = scanner.signal(signal.SIGTERM)
                    grace_end = time.monotonic() + .5
                    while time.monotonic() < grace_end:
                        if _exited_without_reap(pid):
                            leader_exited = True
                            break
                        time.sleep(.025)
                    if not leader_exited or scanner.full_members(exclude_leader=True):
                        kill_sent = scanner.signal(signal.SIGKILL)
                    break
                time.sleep(.04)
            # Even a normally exiting worker cannot leave descendants running.
            members = scanner.full_members(exclude_leader=True)
            peak_rss = max(peak_rss, sum(x['rss_bytes'] for x in members))
            if members:
                kill_sent = scanner.signal(signal.SIGKILL) or kill_sent
            cleanup_end = time.monotonic() + 3
            while members and time.monotonic() < cleanup_end:
                scanner.reap_adopted()
                members = [row for row in scanner.members() if row['pid'] != pid]
                if not members:
                    break
                time.sleep(.025)
            # Only now collect direct-child rusage. It could not be recycled while
            # any of the group signalling/reaping above was in progress.
            _, wait_status, usage = os.wait4(pid, 0)
            reap_status = wait_status
            process.returncode = os.waitstatus_to_exitcode(wait_status)
            scanner.leader_held = False
            # Final /proc scan is mandatory even if killpg(...,0) says absent.
            remaining_members = scanner.public_members(scanner.full_members(exclude_leader=True))
    finished = now()
    peak_rss = max(peak_rss, int(usage.ru_maxrss * 1024) if usage else 0)
    cpu_seconds = (usage.ru_utime + usage.ru_stime) if usage else 0
    if status == 'success' and process.returncode != 0:
        status = 'failed'
    if status == 'success' and utc_parse(finished) >= utc_parse(effective_deadline):
        status = 'timeout'
    if remaining_members or scanner.hazards or scanner.ambiguous or scanner.escaped:
        status = 'uncertain'
    artifacts = [p for p in stage.rglob('*') if p.is_file()]
    if any(p.stat().st_size > budget['max_artifact_bytes'] for p in artifacts):
        status = 'disk_exceeded'
    response = None
    if response_path.is_file() and response_path.stat().st_size <= 2 * MIB:
        try:
            response = json.loads(response_path.read_text())
        except (ValueError, UnicodeDecodeError):
            status = 'failed'
    if status == 'success' and (not isinstance(response, dict) or response.get('status', 'success') != 'success'):
        status = 'failed'
    execution = {'job_id': spec['job_id'], 'tool': tool, 'pid': pid, 'pgid': pgid,
        'started_at_utc': began, 'finished_at_utc': finished, 'deadline_utc': effective_deadline,
        'effective_timeout_seconds': duration, 'status': status, 'returncode': process.returncode,
        'worker_reaped': reap_status is not None and not remaining_members, 'timed_out': status == 'timeout',
        'peak_rss_bytes': peak_rss, 'cpu_seconds': cpu_seconds,
        'supervisor_cpu_seconds': time.process_time() - cpu_start,
        'wall_seconds': time.monotonic() - wall_start,
        'output_bytes': sum(p.stat().st_size for p in artifacts),
        'signal': -process.returncode if process.returncode and process.returncode < 0 else None,
        'termination': {'term_sent': term_sent, 'kill_sent': kill_sent}, 'limits': budget,
        'source_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
        'subreaper_enabled': subreaper, 'remaining_processes': remaining_members,
        'cpu_affinity': sorted(os.sched_getaffinity(0)),
        'memory_limit_mode': 'RLIMIT_AS_hard_limit_plus_group_RSS_monitor_not_cgroup_RAM_hard_limit',
        'inherited_credentials': False, 'worker_identity': identity, 'start_callback_error': callback_error}
    execution['process_discovery'] = {'implementation': 'sr-optimized-v1-directed-proc',
        'stats': scanner.stats, 'hazards': scanner.hazards,
        'pidfd_capabilities': pidfd.capabilities(),
        'confirmed_escaped_descendants': sorted(scanner.escaped),
        'unattributable_adopted_pids': sorted(scanner.ambiguous),
        'leader_held_unreaped_through_cleanup': True,
        'poll_seconds': .04, 'final_full_proc_scan': True}
    execution['supervisor_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    execution['code_manifest'] = {str(p.relative_to(source_root)): hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in ('src/sr_cpu_v2', 'src/sr_recovery_v2', 'src/sr_campaign_v3', 'src/sr_optimized_v1')
        for p in sorted((source_root / folder).glob('*.py'))}
    execution['code_manifest_sha256'] = hashlib.sha256(canonical(execution['code_manifest']).encode()).hexdigest()
    (stage / 'execution.json').write_text(json.dumps(execution, indent=2, sort_keys=True) + '\n')
    return {'execution': execution, 'response': response, 'spec': spec}
