"""Identity-safe pidfd operations, including an explicit Linux x86_64 shim.

The course server's Conda Python 3.10 lacks the open/send wrappers and P_PIDFD
constant although its Linux 5.15 kernel supports them. Its local UAPI headers
were checked before this shim was enabled:
  /usr/include/x86_64-linux-gnu/asm/unistd_64.h: open=434, send_signal=424
  /usr/include/linux/wait.h: P_PIDFD=3

No numeric-PID signal or wait fallback exists. We retain Python's waitid and
its native siginfo conversion, passing the kernel's integer idtype 3. An
unsupported runtime/kernel or a rejected waitid idtype raises an error.
See man7.org/linux/man-pages/man2/{pidfd_open,pidfd_send_signal,waitid}.2.html.
"""
import ctypes
import errno
import os
import platform
import signal
import sys

P_PIDFD = 3
SYS_PIDFD_OPEN_X86_64 = 434
SYS_PIDFD_SEND_SIGNAL_X86_64 = 424
_LIBC = None
_MAX_I32 = (1 << 31) - 1


def _shim_abi():
    return (sys.platform == 'linux' and platform.machine().lower() in ('x86_64', 'amd64')
            and ctypes.sizeof(ctypes.c_void_p) == 8 and sys.byteorder == 'little')


def capabilities():
    native_open = callable(getattr(os, 'pidfd_open', None))
    native_send = callable(getattr(signal, 'pidfd_send_signal', None))
    waitid = callable(getattr(os, 'waitid', None))
    abi = _shim_abi()
    return dict(native_pidfd_open=native_open, native_pidfd_send_signal=native_send,
        python_waitid=waitid, native_p_pidfd=getattr(os, 'P_PIDFD', None),
        shim_abi='linux-x86_64-lp64-le' if abi else None,
        available=waitid and ((native_open and native_send) or abi),
        open_backend='python' if native_open else 'libc-syscall-434' if abi else 'unavailable',
        signal_backend='python' if native_send else 'libc-syscall-424' if abi else 'unavailable',
        wait_backend='python-waitid-integer-P_PIDFD-3' if waitid else 'unavailable')


def available():
    return capabilities()['available']


def _unavailable(message):
    raise OSError(errno.ENOSYS, message)


def _libc():
    global _LIBC
    if not _shim_abi():
        _unavailable('pidfd syscall shim requires verified Linux x86_64 ABI')
    if _LIBC is None:
        library = ctypes.CDLL(None, use_errno=True)
        library.syscall.restype = ctypes.c_long
        _LIBC = library
    return _LIBC


def _syscall(number, *arguments):
    result = _libc().syscall(ctypes.c_long(number), *arguments)
    if result == -1:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    return int(result)


def open_pidfd(pid, flags=0):
    if type(pid) is not int or not 0 < pid <= _MAX_I32 or flags != 0:
        raise ValueError('PIDFD_OPEN_EXPLICIT_PID_FLAGS_ZERO')
    native = getattr(os, 'pidfd_open', None)
    if callable(native):
        return native(pid, flags)
    return _syscall(SYS_PIDFD_OPEN_X86_64, ctypes.c_int(pid), ctypes.c_uint(0))


def send_signal(fd, sig):
    if (type(fd) is not int or not 0 <= fd <= _MAX_I32
            or type(sig) is not int and not isinstance(sig, signal.Signals)
            or not 0 <= int(sig) < signal.NSIG):
        raise ValueError('PIDFD_SIGNAL_ARGUMENTS')
    native = getattr(signal, 'pidfd_send_signal', None)
    if callable(native):
        return native(fd, sig, None, 0)
    return _syscall(SYS_PIDFD_SEND_SIGNAL_X86_64, ctypes.c_int(fd), ctypes.c_int(int(sig)),
                    ctypes.c_void_p(None), ctypes.c_uint(0))


def wait(fd, options):
    if type(fd) is not int or not 0 <= fd <= _MAX_I32:
        raise ValueError('PIDFD_WAIT_DESCRIPTOR')
    native = getattr(os, 'waitid', None)
    if not callable(native):
        _unavailable('Python waitid is required; no raw-PID or guessed siginfo fallback')
    idtype = getattr(os, 'P_PIDFD', None)
    if idtype is None:
        if not _shim_abi():
            _unavailable('integer P_PIDFD fallback requires verified Linux x86_64 ABI')
        idtype = P_PIDFD
    return native(idtype, fd, options)
