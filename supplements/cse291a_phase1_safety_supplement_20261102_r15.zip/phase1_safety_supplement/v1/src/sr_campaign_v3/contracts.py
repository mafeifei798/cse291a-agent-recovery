"""The V3 model-visible contracts, separate from trusted control metadata."""
import copy
import json

from sr_recovery_v2.common import canonical
from sr_cpu_v2.adapter import _script


def _obj(properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}


def micro_schema(node):
    text = {'type': 'string', 'minLength': 1}
    integer = {'type': 'integer', 'minimum': 0}
    command = _obj({'dataset_id': text, 'purpose': text,
        'batch_size': {'type': 'integer', 'minimum': 1}, 'epochs': {'type': 'integer', 'minimum': 1},
        'requested_workers': integer, 'num_examples': integer, 'steps': integer, 'workers': integer,
        'allowed': {'type': 'boolean'}, 'policy_revision': {'type': 'integer', 'minimum': 1}})
    if node == 'read_metadata':
        return _obj({'dataset_id': text, 'num_examples': integer})
    if node == 'read_permission':
        return _obj({'dataset_id': text, 'purpose': text, 'allowed': {'type': 'boolean'},
                     'policy_revision': {'type': 'integer', 'minimum': 1}})
    if node == 'read_resources':
        return _obj({'max_workers': integer})
    if node == 'plan':
        return command
    if node == 'execute':
        return _obj({'action': {'const': 'commit_config_and_draft'}, 'config': command, 'command': command})
    raise ValueError('UNKNOWN_MICRO_NODE')


def model_schema(node, domain):
    if domain == 'micro':
        return micro_schema(node)
    from .gateway import schema_for_node
    schema = copy.deepcopy(schema_for_node(node))
    if node in ('report', 'publish'):
        report = schema if node == 'report' else schema['properties']['report']
        report['properties']['report_text']['pattern'] = r'^\S+(?:\s+\S+){0,119}\s*$'
    return schema


def render(snapshot):
    """Project only useful payloads to text; full read sets remain in snapshots."""
    body = {'node_id': snapshot['node_id'], 'request': copy.deepcopy(snapshot['request']),
        'parent_inputs': [{'node_id': p['node_id'], 'payload': copy.deepcopy(p['payload'])}
                          for p in snapshot['parent_inputs']],
        'direct_source_inputs': [{'object_key': s['object_key'], 'version': s['version'],
                                 'payload': copy.deepcopy(s['payload'])}
                                for s in snapshot['direct_source_inputs']]}
    if snapshot.get('repair_feedback'):
        body['repair_feedback'] = copy.deepcopy(snapshot['repair_feedback'])
    node = snapshot['node_id']
    guidance = {
        'read_metadata': 'Copy dataset_id and num_examples exactly from metadata.',
        'read_permission': 'Copy dataset_id, purpose, allowed and policy_revision exactly from permission.',
        'read_resources': 'Copy max_workers exactly from the resource policy.',
        'plan': 'Use the request and three reader payloads. Compute steps=ceil(num_examples/batch_size)*epochs and workers=min(requested_workers,max_workers). Keep all copied fields exact.',
        'execute': 'Copy the complete plan identically into config and command; action is commit_config_and_draft. Do not execute anything.',
        'inspect': 'Acknowledge the dataset and require preprocessing to fit training rows only.',
        'plan_lr': 'Copy the entire current LR parameters object and the LR matrix artifact ID from prepare. Do not tune.',
        'plan_rf': 'Copy the entire current RF parameters object and the RF matrix artifact ID from prepare. Do not tune.',
        'report': 'Compare the delivered summaries by validation average_precision; choose LR if LR+0.000001>=RF. Copy all chosen metrics and provenance exactly. report_text must be at most 120 English words.',
        'publish': 'Return action publish_manifest and copy the report object exactly, including report_artifact_id.',
    }
    return [{'role': 'system', 'content': 'Return only JSON matching the supplied schema. Use only the cited inputs. ' + guidance[node]},
            {'role': 'user', 'content': canonical(body)}]


def scripted_payload(snapshot):
    """A declared fake HTTP response source, never a fallback after a failure."""
    body = json.loads(snapshot['rendered_messages'][1]['content'])
    node = body['node_id']
    parents = {p['node_id']: p['payload'] for p in body['parent_inputs']}
    if node.startswith('read_'):
        return copy.deepcopy(body['direct_source_inputs'][0]['payload'])
    if node == 'plan':
        request = body['request']
        n = parents['read_metadata']['num_examples']
        return {**request, 'num_examples': n,
            'steps': ((n + request['batch_size'] - 1) // request['batch_size']) * request['epochs'],
            'workers': min(request['requested_workers'], parents['read_resources']['max_workers']),
            'allowed': parents['read_permission']['allowed'],
            'policy_revision': parents['read_permission']['policy_revision']}
    if node == 'execute':
        command = copy.deepcopy(parents['plan'])
        return {'action': 'commit_config_and_draft', 'config': command, 'command': copy.deepcopy(command)}
    # V2's deterministic macro emitter consumes exactly this serialized shape.
    return _script({'rendered_messages': snapshot['rendered_messages']})
