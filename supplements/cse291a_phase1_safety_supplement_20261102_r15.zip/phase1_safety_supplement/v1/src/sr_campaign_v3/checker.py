"""Independent, standard-library-only V3 campaign accounting auditor.

This code consumes durable exports, not runner/guard verdicts.  An audit pass
means the evidence is complete and internally consistent, including paid
failures and blocked rows.  It never turns fake HTTP usage into real spending.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


RESERVATION = 1_284_000
BASELINE_KNOWN = 90_998_300
BASELINE_HELD = 984_000
BASELINE_CALLS = 1605
MAX_COST = 1_000_000_000
MAX_CALLS = 640
_TERMINAL = {"completed_correct", "validation_rejected", "permission_denied_safe",
             "conflict_safe", "tool_failed", "budget_or_time_stopped", "uncertain",
             "not_run_blocked_prefix", "not_run_stopped"}
_UNSTARTED = {"not_started", "not_run_blocked_prefix", "not_run_stopped"}


def _json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def _digest(value: Any) -> str:
    return hashlib.sha256(_json(value)).hexdigest()


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return list(value.values())
    return []


def _utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class _Audit:
    def __init__(self) -> None:
        self.checks = 0
        self.issues: list[dict] = []

    def expect(self, condition: Any, code: str, ref: str = "", detail: Any = None) -> bool:
        self.checks += 1
        if not condition:
            self.issues.append({"code": code, "ref": ref, "detail": detail})
            return False
        return True


def qualify_prefix(view: dict, domain: str, task: dict | None = None,
                   fault_evidence: dict | None = None) -> dict:
    """Decide freeze eligibility using actual bad delivery and propagation.

    ``fault_evidence`` retains the raw producer payload and its delivered copy;
    it is not sufficient alone.  Source/tool receipts, the successful target,
    actual parent input bytes, the rejected candidate and absence of published
    output are checked independently.  No guard implementation is imported.
    """
    a = _Audit()
    target_id = None
    raw_target_already_incorrect = False
    try:
        results = _rows(view.get("results"))
        result_map = {x["result_id"]: x for x in results}
        if fault_evidence is None:
            injected = _rows(view.get("injection_events"))
            a.expect(len(injected) == 1, "PREFIX_EXACTLY_ONE_INJECTION")
            fault_evidence = injected[0] if len(injected) == 1 else {}
        a.expect(fault_evidence.get("injection_count", 1) == 1, "PREFIX_INJECTION_COUNT_ONE")
        target_id = fault_evidence.get("target_result_id", fault_evidence.get("result_id"))
        target = result_map.get(target_id, {})
        expected_node = "read_metadata" if domain == "micro" else "summary_lr"
        a.expect(target.get("node_id") == expected_node and target.get("execution_status") == "success",
                 "PREFIX_TARGET_SUCCESS", str(target_id))
        original = fault_evidence.get("raw_payload")
        delivered = fault_evidence.get("delivered_payload")
        a.expect(isinstance(original, dict) and isinstance(delivered, dict) and original != delivered,
                 "PREFIX_RAW_AND_BAD_DELIVERY_RETAINED", str(target_id))
        a.expect(target.get("payload") == delivered, "PREFIX_TARGET_MATCHES_DELIVERY", str(target_id))
        a.expect(sum(r.get("node_id") == expected_node for r in results) == 1,
                 "PREFIX_TARGET_EXECUTED_ONCE", str(target_id))
        if domain == "micro":
            before, after = dict(original or {}), dict(delivered or {})
            n, bad_n = before.pop("num_examples", None), after.pop("num_examples", None)
            request = (task or view.get("task", {})).get("request", (task or view.get("task", {})).get("public_request", {}))
            aliases = view.get("source_aliases", view.get("task", {}).get("resolved_source_aliases", {}))
            source_map = {s["object_key"]: s for s in _rows(view.get("sources"))}
            metadata = source_map.get(aliases.get("metadata"), {}).get("payload", {})
            authority_n = metadata.get("num_examples", metadata.get("n"))
            a.expect(before == after and type(n) is int and n > 0 and type(authority_n) is int and authority_n > 0 and
                     type(request.get("batch_size")) is int and bad_n == authority_n + request["batch_size"],
                     "PREFIX_ONLY_NUM_EXAMPLES_DELIVERY_CHANGED", str(target_id))
            raw_target_already_incorrect = type(n) is int and n != authority_n
            call_map = {c["call_id"]: c for c in _rows(view.get("calls"))}
            target_calls = [call_map[x] for x in target.get("call_ids", []) if x in call_map]
            a.expect(len(target_calls) == 1 and target_calls[0].get("raw_response_payload") == original,
                     "PREFIX_MICRO_RAW_CALL_PRESERVED", str(target_id))
        elif domain == "macro":
            before, after = json.loads(json.dumps(original or {})), json.loads(json.dumps(delivered or {}))
            raw_ap = before.get("metrics", {}).pop("average_precision", None)
            bad_ap = after.get("metrics", {}).pop("average_precision", None)
            a.expect(before == after and type(raw_ap) in (int, float) and math.isfinite(raw_ap) and
                     bad_ap == (0 if raw_ap >= 0.5 else 1),
                     "PREFIX_ONLY_LR_AP_DELIVERY_CHANGED", str(target_id))
            receipts = {r["receipt_id"]: r for r in _rows(view.get("tool_receipts"))}
            linked = [receipts[x] for x in target.get("tool_receipt_ids", []) if x in receipts]
            a.expect(len(linked) == 1 and linked[0].get("parameters", {}).get("unmodified_metrics") ==
                     (original or {}).get("metrics"), "PREFIX_RAW_TOOL_METRICS_MATCH", str(target_id))
        else:
            a.expect(False, "PREFIX_DOMAIN_VALID", domain)
        exposures = []
        for result in results:
            if result.get("result_id") == target_id:
                continue
            if target_id not in result.get("parent_result_ids", []):
                continue
            for parent in result.get("input_snapshot", {}).get("parent_inputs", []):
                if parent.get("result_id") == target_id and parent.get("payload") == delivered:
                    exposures.append(result["result_id"])
                    a.expect(bool(result.get("call_ids") or result.get("tool_receipt_ids")),
                             "PREFIX_PROPAGATION_EXECUTION_RECEIPT", result["result_id"])
        a.expect(bool(exposures), "PREFIX_BAD_VALUE_REACHED_ACTUAL_DOWNSTREAM_INPUT", str(target_id))
        guards = _rows(view.get("guards"))
        failed_precommit = [g for g in guards if g.get("checkpoint") == "precommit" and
                            g.get("classification") != "passed"]
        a.expect(bool(failed_precommit) and failed_precommit[0].get("classification") == "semantic",
                 "PREFIX_FIRST_PRECOMMIT_FAILURE_SEMANTIC")
        if failed_precommit:
            candidate_id = failed_precommit[0].get("candidate_result_id")
            candidate = result_map.get(candidate_id, {})
            a.expect(candidate.get("execution_status") in {"validation_rejected", "failed", "rejected"},
                     "PREFIX_CANDIDATE_REJECTED", str(candidate_id))
            candidate_inputs = candidate.get("input_snapshot", {}).get("parent_inputs", [])
            a.expect(bool(candidate_inputs) and bool(candidate.get("call_ids")),
                     "PREFIX_PRECOMMIT_ACTUALLY_EXECUTED", str(candidate_id))
        state = view.get("state", {})
        a.expect(not state.get("active_attempt_ids") and not state.get("unsettled_call_ids"),
                 "PREFIX_QUIESCENT")
        counters = state.get("counters", {})
        a.expect(counters.get("stale_used", 0) == 0 and counters.get("semantic_used", 0) == 0,
                 "PREFIX_NO_AUTOMATIC_CORRECTION")
        for call in _rows(view.get("calls")):
            a.expect(call.get("status") not in {"reserved", "dispatched", "uncertain", "in_flight"},
                     "PREFIX_ALL_CALLS_KNOWN", call.get("call_id", ""))
        for receipt in _rows(view.get("tool_receipts")):
            execution = receipt.get("parameters", {}).get("execution")
            if execution:
                a.expect(execution.get("worker_reaped") is True and not execution.get("remaining_processes"),
                         "PREFIX_WORKERS_REAPED", receipt.get("receipt_id", ""))
        objects = view.get("objects", {})
        a.expect(all(obj.get("payload") is None for obj in objects.values()), "PREFIX_NO_USABLE_PUBLISH")
    except (KeyError, ValueError, TypeError, OSError, OverflowError, AttributeError, IndexError) as exc:
        a.expect(False, "MALFORMED_PREFIX", detail=f"{type(exc).__name__}: {exc}")
        exposures = []
    return {"passed": not a.issues, "qualified": not a.issues, "checks": a.checks,
            "issues": a.issues, "faulty_result_id": target_id,
            "raw_target_already_incorrect": raw_target_already_incorrect,
            "actual_downstream_exposure_result_ids": exposures,
            "scope": "independent_raw_delivery_propagation_and_quiescence_not_guard_oracle"}


def audit_campaign_path(path: str | Path, v0_root: str | Path,
                        artifact_root: str | Path | None = None) -> dict:
    p = Path(path)
    try:
        data = json.loads(p.read_text())
    except (OSError, ValueError) as exc:
        return {"passed": False, "checks": 1, "issues": [{"code": "CAMPAIGN_UNREADABLE",
                "ref": str(p), "detail": str(exc)}], "statistics": {}}
    return audit_campaign(data, v0_root, artifact_root or p.parent)


def audit_campaign(export: dict, v0_root: str | Path,
                   artifact_root: str | Path | None = None) -> dict:
    """Audit a runner bundle containing items, ledger, events and checkpoints.

    The central ledger is the budget agent's raw ``snapshot()``.  Item rows can
    embed ``raw_export`` or name ``export_path`` with ``export_sha256``.  Paths
    must remain inside artifact_root.  Never silently skip a missing result.
    """
    a = _Audit()
    try:
        return _campaign(export, Path(v0_root),
                         Path(artifact_root).resolve() if artifact_root else None, a)
    except (KeyError, ValueError, TypeError, OSError, OverflowError, AttributeError, IndexError) as exc:
        a.expect(False, "MALFORMED_CAMPAIGN", detail=f"{type(exc).__name__}: {exc}")
        return {"passed": False, "checks": a.checks, "issues": a.issues,
                "statistics": {}, "accounting": {}, "matrix": {}, "checkpoint_audit": []}


def _campaign(bundle: dict, v0: Path, root: Path | None, a: _Audit) -> dict:
    registry_file = v0 / "registry/formal_items.jsonl"
    registered = [json.loads(x) for x in registry_file.read_text().splitlines() if x.strip()]
    registered_map = {x["item_id"]: x for x in registered}
    registered_scenes = json.loads((v0 / "registry/formal_scenes.json").read_text())["scenes"]
    expected_registry_hash = hashlib.sha256(registry_file.read_bytes()).hexdigest()
    a.expect(len(registered) == 52 and len(registered_map) == 52, "FROZEN_52_REGISTRY")
    a.expect(Counter((x["domain"], x["kind"]) for x in registered) ==
             Counter({("micro", "control"): 2, ("micro", "prefix"): 6, ("micro", "branch"): 18,
                      ("macro", "control"): 2, ("macro", "prefix"): 6, ("macro", "branch"): 18}),
             "FROZEN_DOMAIN_COUNTS")
    a.expect(bundle.get("execution_mode", bundle.get("mode")) == "offline_fake_http",
             "OFFLINE_MODE_EXPLICIT")
    a.expect(bundle.get("campaign_id") == "sr-v2-formal-r1", "CAMPAIGN_ID")
    a.expect(bundle.get("registry_sha256") == expected_registry_hash, "REGISTRY_SHA256")
    ledger = bundle["ledger"]
    accounting = _ledger(ledger, registered_map, a)
    a.expect(ledger.get("config", {}).get("registry_sha256") == expected_registry_hash,
             "LEDGER_REGISTRY_SHA256")
    if "registry" in ledger:
        a.expect(ledger["registry"] == registered, "LEDGER_REGISTRY_UNMODIFIED")
    items = _rows(bundle["items"])
    items_by_id = {x["item_id"]: x for x in items}
    a.expect(len(items) == 52 and set(items_by_id) == set(registered_map), "ALL_52_ROWS_RETAINED")
    a.expect(len(items_by_id) == len(items), "NO_DUPLICATE_ITEM_ROWS")
    calls = _rows(ledger.get("calls"))
    dispatched = {x["call_id"]: x for x in calls if x.get("dispatched")}
    by_item: dict[str, list[str]] = {}
    for cid, call in dispatched.items():
        by_item.setdefault(call["item_id"], []).append(cid)
    raw: dict[str, dict] = {}
    actual_calls: dict[str, dict] = {}
    terminal_counts = Counter()
    exported_scenes = {s["scene_id"]: s for s in _rows(bundle.get("scenes"))}
    frozen_dags = {domain: json.loads((v0 / "dags" / (domain + ".json")).read_text())
                   for domain in ("micro", "macro")}
    for iid, item in items_by_id.items():
        if iid not in registered_map:
            continue
        spec = registered_map[iid]
        for field in ("domain", "kind", "task_id", "policy", "scene_id", "execution_ordinal"):
            if field in item:
                a.expect(item[field] == spec[field], "ITEM_IDENTITY_UNMODIFIED", iid + ":" + field)
        status = item.get("status")
        a.expect(status in _TERMINAL | {"running", "not_started"}, "ITEM_STATUS_VALID", iid, status)
        terminal_counts[(spec["domain"], status)] += 1
        touched = status not in _UNSTARTED
        a.expect(item.get("run_count") == (1 if touched else 0), "NO_ITEM_RERUN_OR_REPLACEMENT", iid)
        declared = item.get("physical_dispatch_ids", item.get("call_ids", []))
        a.expect(len(declared) == len(set(declared)) and set(declared) == set(by_item.get(iid, [])),
                 "ITEM_CENTRAL_DISPATCH_BIJECTION", iid)
        a.expect(len(declared) <= spec["limits"]["physical_llm_call_cap"], "ITEM_PHYSICAL_CALL_CAP", iid)
        if not touched:
            a.expect(not declared, "UNSTARTED_ITEM_ZERO_CALLS", iid)
            continue
        start = item.get("started_at_utc", item.get("started_at"))
        deadline = item.get("deadline_utc", item.get("deadline_at"))
        if start or deadline:
            a.expect(bool(start) and bool(deadline) and
                     (_utc(deadline) - _utc(start)).total_seconds() == 1800,
                     "ITEM_FIXED_DEADLINE", iid)
        view = _load_item_export(item, root, a)
        if view is not None:
            raw[iid] = view
            qualified_prefix = spec["kind"] == "prefix" and \
                exported_scenes.get(spec.get("scene_id"), {}).get("qualified") is True
            _raw_result(view, spec, status, a, frozen_dags[spec["domain"]], qualified_prefix)
            for call in _rows(view.get("calls")):
                cid = call["call_id"]
                if cid in actual_calls:
                    a.expect(actual_calls[cid] == call, "COPIED_PREFIX_CALL_IDENTICAL", cid)
                else:
                    actual_calls[cid] = call
        elif status == "completed_correct":
            a.expect(False, "SUCCESS_REQUIRES_RAW_EXPORT", iid)
    # Exported call references are the physical attempts, including failed calls;
    # their immutable prefix copies must not create additional central charges.
    a.expect(set(actual_calls) == set(dispatched), "RAW_CALL_CENTRAL_BIJECTION",
             detail={"unaccounted_raw": sorted(set(actual_calls) - set(dispatched)),
                     "missing_raw": sorted(set(dispatched) - set(actual_calls))})
    scene_stats = _scenes(bundle, registered_scenes, items_by_id, raw, v0, a)
    for row in scene_stats["branch_measurements"]:
        owned = [c for c in calls if c.get("item_id") == row["item_id"]]
        row["new_physical_calls"] = sum(bool(c.get("dispatched")) for c in owned)
        row["simulated_catalog_cost_nano_usd"] = sum(c.get("known_cost_nano_usd", 0) for c in owned)
        row["unknown_hold_nano_usd"] = sum(c.get("held_cost_nano_usd", 0) for c in owned)
    checkpoint_stats = _checkpoints(bundle, ledger, a)
    _runner_events(bundle.get("events", []), items_by_id, registered_map, a)
    return {"passed": not a.issues, "checks": a.checks, "issues": a.issues,
            "statistics": {"registered_items": 52, "registered_scenes": 12,
                           "new_physical_dispatches": len(dispatched),
                           "raw_unique_calls": len(actual_calls),
                           "terminal_counts": [{"domain": d, "status": s, "count": n}
                                               for (d, s), n in sorted(terminal_counts.items())],
                           "actual_real_api_requests": 0,
                           "actual_real_incremental_cost_nano_usd": 0,
                           "all_registered_rows_terminal": all(i.get("status") in _TERMINAL for i in items),
                           "planned_execution_completed": all(i.get("status") in
                               _TERMINAL - {"not_run_stopped", "uncertain"} for i in items)},
            "accounting": accounting, "matrix": scene_stats,
            "checkpoint_audit": checkpoint_stats,
            "context_audit_trust_boundary": "The independent auditor reconstructs the complete user JSON projection and rejects extra messages. System prompt wording is bound by the frozen template digest and checked by the runtime guard; it is not derived from runtime render as an independent oracle."}


def _load_item_export(item: dict, root: Path | None, a: _Audit) -> dict | None:
    if isinstance(item.get("raw_export"), dict) and not item.get("export_path"):
        view = item["raw_export"]
        if item.get("raw_export_digest"):
            a.expect(_digest(view) == item["raw_export_digest"], "EMBEDDED_EXPORT_DIGEST", item["item_id"])
        return view
    path = item.get("export_path")
    if not path:
        return None
    if not a.expect(root is not None, "EXPORT_ALLOW_ROOT_REQUIRED", item["item_id"]):
        return None
    p = Path(path)
    p = (root / p).resolve() if not p.is_absolute() else p.resolve()
    if not a.expect(p == root or root in p.parents, "EXPORT_PATH_ESCAPE", item["item_id"]):
        return None
    if not a.expect(p.is_file(), "EXPORT_FILE_PRESENT", item["item_id"]):
        return None
    data = p.read_bytes()
    a.expect(hashlib.sha256(data).hexdigest() == item.get("export_sha256"),
             "RAW_EXPORT_SHA256", item["item_id"])
    loaded = json.loads(data)
    if isinstance(item.get("raw_export"), dict):
        a.expect(item["raw_export"] == loaded, "EMBEDDED_EXPORT_EQUALS_FILE", item["item_id"])
        if item.get("raw_export_digest"):
            a.expect(_digest(item["raw_export"]) == item["raw_export_digest"],
                     "EMBEDDED_EXPORT_DIGEST", item["item_id"])
    return loaded


def _ledger(ledger: dict, registered: dict[str, dict], a: _Audit) -> dict:
    a.expect(ledger.get("execution_mode") == "offline_fake_http", "LEDGER_OFFLINE")
    a.expect(ledger.get("real_api_requests") == 0 and ledger.get("real_incremental_cost_nano_usd") == 0,
             "NO_REAL_API_OR_COST")
    binding = ledger.get("config", {}).get("binding", {})
    fixed = {"model": "api-glm-5.3-flash", "input_nano_usd_per_token": 150,
             "output_nano_usd_per_token": 500, "max_input_tokens": 4000,
             "max_output_tokens": 768, "financial_input_allowance": 6000,
             "financial_reservation_nano_usd_per_dispatch": RESERVATION,
             "reasoning_effort": "low", "total_request_deadline_seconds": 120,
             "simulated": True, "real_requests_authorized": False, "automatic_http_retries": 0}
    a.expect(all(binding.get(k) == v and type(binding.get(k)) is type(v) for k, v in fixed.items()),
             "PINNED_OFFLINE_MODEL_AND_FINANCIAL_BINDING")
    a.expect(ledger.get("config", {}).get("binding_digest") == _digest(binding), "BINDING_DIGEST_REBUILT")
    cumulative = ledger["cumulative_budget"]
    a.expect(cumulative.get("baseline_calls") == BASELINE_CALLS and
             cumulative.get("baseline_known_cost_nano_usd") == BASELINE_KNOWN and
             cumulative.get("baseline_held_cost_nano_usd") == BASELINE_HELD,
             "HISTORICAL_BASELINE_IMPORTED_ONCE")
    calls = _rows(ledger.get("calls"))
    call_map = {c["call_id"]: c for c in calls}
    a.expect(len(call_map) == len(calls), "UNIQUE_CENTRAL_CALL_ID")
    a.expect(len(calls) <= MAX_CALLS, "GLOBAL_640_RESERVATION_CAP")
    counts, domains, kinds = Counter(), Counter(), Counter()
    known = held = dispatched_count = 0
    must_stop: list[str] = []
    for call in calls:
        cid, iid = call["call_id"], call["item_id"]
        if not a.expect(iid in registered, "CALL_REGISTERED_ITEM", cid):
            continue
        spec = registered[iid]
        counts[iid] += 1
        domains[spec["domain"]] += 1
        kinds[spec["kind"]] += 1
        a.expect(call.get("domain") == spec["domain"] and call.get("kind") == spec["kind"],
                 "CALL_REGISTERED_IDENTITY", cid)
        a.expect(call.get("reserved_cost_nano_usd") == RESERVATION, "PER_CALL_FINANCIAL_RESERVATION", cid)
        status = call.get("status")
        a.expect(status in {"reserved", "dispatched", "settled", "uncertain"}, "CALL_STATUS_VALID", cid)
        dispatched_count += int(bool(call.get("dispatched")))
        usage = call.get("usage")
        if status == "settled":
            a.expect(call.get("dispatched") is True, "SETTLED_CALL_WAS_DISPATCHED", cid)
            valid = isinstance(usage, dict) and all(type(usage.get(k)) is int and usage[k] >= 0
                     for k in ("prompt_tokens", "completion_tokens"))
            if a.expect(valid, "SETTLED_USAGE_PRESENT_RAW", cid):
                raw_usage = call.get("raw_usage")
                a.expect(isinstance(raw_usage, dict) and all(raw_usage.get(k) == usage[k]
                         for k in ("prompt_tokens", "completion_tokens")), "RAW_PROVIDER_USAGE_PRESERVED", cid)
                cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
                a.expect(call.get("known_cost_nano_usd") == cost, "EXACT_KNOWN_USAGE_COST", cid)
                a.expect(call.get("held_cost_nano_usd") == 0, "SETTLED_HOLD_RELEASED", cid)
                if "total_tokens" in usage:
                    a.expect(usage["total_tokens"] == usage["prompt_tokens"] + usage["completion_tokens"],
                             "USAGE_TOTAL_TOKENS", cid)
                if usage["prompt_tokens"] > 4000 or usage["completion_tokens"] > 768 or cost > RESERVATION:
                    must_stop.append(cid)
        elif status in {"uncertain", "dispatched", "reserved"}:
            a.expect(call.get("known_cost_nano_usd") == 0 and call.get("held_cost_nano_usd") == RESERVATION,
                     "UNSETTLED_FULL_HOLD_RETAINED", cid)
            if status == "uncertain":
                must_stop.append(cid)
            if call.get("late_receipts"):
                a.expect(status == "uncertain" and call.get("held_cost_nano_usd") == RESERVATION,
                         "LATE_RECEIPT_DOES_NOT_RELEASE_UNKNOWN_HOLD", cid)
        known += call.get("known_cost_nano_usd", 0)
        held += call.get("held_cost_nano_usd", 0)
        a.expect(call.get("request_sent", False) is False and
                 call.get("http_request_sent", False) is False, "CALL_NOT_REAL_NETWORK", cid)
    late_rows = _rows(ledger.get("late_receipts"))
    late_event_rows = [dict(call_id=e.get("call_id"), receipt=e.get("body")) for e in _rows(ledger.get("events"))
                       if e.get("kind") == "late_receipt"]
    a.expect(late_rows == late_event_rows, "ALL_LATE_RECEIPTS_PRESERVED")
    for late in late_rows:
        call = call_map.get(late.get("call_id"), {})
        a.expect(call.get("status") == "uncertain" and call.get("held_cost_nano_usd") == RESERVATION,
                 "LATE_RECEIPT_RETAINS_ORIGINAL_UNKNOWN_HOLD", late.get("call_id", ""))
    late_maximum: dict[str, int] = {}
    for late in late_rows:
        cid, receipt = late["call_id"], late["receipt"]
        usage = receipt.get("raw_usage")
        valid = isinstance(usage, dict) and all(type(usage.get(k)) is int and usage[k] >= 0
                for k in ("prompt_tokens", "completion_tokens", "total_tokens")) and \
                usage["total_tokens"] == usage["prompt_tokens"] + usage["completion_tokens"]
        if valid:
            pd, cd = usage.get("prompt_tokens_details") or {}, usage.get("completion_tokens_details") or {}
            cached, reasoning = pd.get("cached_tokens", 0), cd.get("reasoning_tokens", 0)
            valid = all(type(x) is int and x >= 0 for x in (cached, reasoning)) and \
                    cached <= usage["prompt_tokens"] and reasoning <= usage["completion_tokens"]
        if valid:
            cost = 150 * usage["prompt_tokens"] + 500 * usage["completion_tokens"]
            a.expect(receipt.get("exact_cost_nano_usd") == cost and
                     receipt.get("manual_reconciliation_required") is True,
                     "LATE_VALID_COST_EXACT_AND_REQUIRES_RECONCILIATION", cid)
            late_maximum[cid] = max(cost, late_maximum.get(cid, 0))
    for cid, call in call_map.items():
        a.expect(call.get("late_known_exposure_nano_usd", 0) == late_maximum.get(cid, 0),
                 "LATE_EXPOSURE_REBUILT", cid)
    adjustment = sum(max(0, late_maximum.get(c["call_id"], 0) - c.get("known_cost_nano_usd", 0) -
                         c.get("held_cost_nano_usd", 0)) for c in calls)
    for iid, count in counts.items():
        a.expect(count <= registered[iid]["limits"]["physical_llm_call_cap"], "ITEM_RESERVATION_CAP", iid)
    a.expect(all(n <= 320 for n in domains.values()), "DOMAIN_320_CAP")
    budget = ledger["budget"]
    totals = {"calls_reserved_or_spent": len(calls), "calls_dispatched": dispatched_count,
              "known_cost_nano_usd": known, "held_cost_nano_usd": held}
    for key, expected in totals.items():
        a.expect(budget.get(key) == expected, "NEW_BUDGET_REBUILT", key, expected)
    if "domain_counts" in budget:
        a.expect(Counter(budget["domain_counts"]) == domains, "BUDGET_COUNTS_REBUILT", "domain_counts")
    if "item_counts" in budget:
        a.expect(Counter(budget["item_counts"]) == counts, "BUDGET_COUNTS_REBUILT", "item_counts")
    if "kind_counts" in budget:
        nested = {d: {k: sum(c.get("domain") == d and c.get("kind") == k for c in calls)
                      for k in ("control", "prefix", "branch")} for d in ("micro", "macro")}
        a.expect(budget["kind_counts"] == nested, "BUDGET_COUNTS_REBUILT", "kind_counts")
    expected_cumulative = {"cumulative_calls": BASELINE_CALLS + dispatched_count,
                          "known_cost_nano_usd": BASELINE_KNOWN + known,
                          "held_cost_nano_usd": BASELINE_HELD + held,
                          "known_plus_held_nano_usd": BASELINE_KNOWN + BASELINE_HELD + known + held,
                          "max_cost_nano_usd": MAX_COST}
    for key, value in expected_cumulative.items():
        a.expect(cumulative.get(key) == value, "CUMULATIVE_BUDGET_REBUILT", key, value)
    risk_adjusted = expected_cumulative["known_plus_held_nano_usd"] + adjustment
    for key, value in (("unsettled_exposure_adjustment_nano_usd", adjustment),
                       ("risk_adjusted_known_plus_held_nano_usd", risk_adjusted),
                       ("risk_adjusted_overrun", risk_adjusted > MAX_COST)):
        if key in cumulative or late_rows:
            a.expect(cumulative.get(key) == value, "LATE_RISK_ADJUSTMENT_REBUILT", key, value)
    # Exact over-limit settlements are preserved; they stop continuation.  The
    # audit must not clip the bill merely to manufacture a USD1 pass.
    if expected_cumulative["known_plus_held_nano_usd"] > MAX_COST:
        must_stop.append("cumulative_cost")
    if must_stop:
        a.expect(ledger.get("status") in {"stopped", "paused", "quarantined"} and
                 bool(ledger.get("pause_reason", ledger.get("stop_reason"))),
                 "HARD_ANOMALY_STOPS_CAMPAIGN", detail=must_stop)
    event_stats = _ledger_events(ledger, call_map, a)
    return {**totals, **expected_cumulative, "historical_known_plus_held_nano_usd": 91_982_300,
            "new_budget_rebuilt": totals, "cumulative_budget_rebuilt": expected_cumulative,
            "simulated_catalog_cost_nano_usd": known,
            "simulated_unknown_hold_nano_usd": held, "must_stop_call_ids": must_stop,
            "unsettled_exposure_adjustment_nano_usd": adjustment,
            "risk_adjusted_known_plus_held_nano_usd": risk_adjusted,
            "actual_real_incremental_cost_nano_usd": 0, "events": event_stats}


def _ledger_events(ledger: dict, call_map: dict[str, dict], a: _Audit) -> dict:
    events = _rows(ledger.get("events"))
    seqs = [e["seq"] for e in events]
    a.expect(seqs == list(range(1, len(events) + 1)), "LEDGER_EVENT_SEQUENCE")
    last: dict[str, dict] = {}
    phase: dict[str, str] = {}
    started_items: set[str] = set()
    finalized_items: dict[str, dict] = {}
    item_insert_order: list[str] = []
    checkpoint_events = []
    first_stop_seq = None
    for event in events:
        seq, kind = event["seq"], event["kind"]
        if event.get("event_digest"):
            a.expect(event["event_digest"] == _digest({k: v for k, v in event.items() if k not in {"event_digest", "seq"}}),
                     "LEDGER_EVENT_DIGEST", str(seq))
        cid, body = event.get("call_id"), event.get("body", {})
        if kind == "quarantine":
            first_stop_seq = first_stop_seq or seq
            for row in body.get("calls", []):
                qid = row["call_id"]
                a.expect(qid in call_map and phase.get(qid) in {"reserved", "dispatched"},
                         "UNKNOWN_AFTER_STARTED_CALL", qid)
                phase[qid] = "uncertain"
                last[qid] = row
        elif kind in {"reserve", "dispatch", "settle"}:
            row = body.get("call", body)
            if not a.expect(cid in call_map and isinstance(row, dict) and row.get("call_id") == cid,
                            "CALL_EVENT_RESOLVES", str(seq)):
                continue
            a.expect(event.get("item_id") == row.get("item_id"), "CALL_EVENT_IDENTITY", cid)
            if kind == "reserve":
                a.expect(cid not in phase, "RESERVE_ONCE", cid)
                a.expect(first_stop_seq is None, "NO_DISPATCH_AFTER_HARD_STOP", cid)
                a.expect(all(p == "settled" for p in phase.values()), "NO_RESERVE_WHILE_UNSETTLED", cid)
                prior_known = sum(r.get("known_cost_nano_usd", 0) for r in last.values())
                prior_held = sum(r.get("held_cost_nano_usd", 0) for r in last.values())
                a.expect(BASELINE_KNOWN + BASELINE_HELD + prior_known + prior_held + RESERVATION <= MAX_COST,
                         "RESERVATION_ADMITTED_WITHIN_ONE_DOLLAR", cid)
                phase[cid] = "reserved"
                started_items.add(row["item_id"])
                if row["item_id"] not in item_insert_order:
                    item_insert_order.append(row["item_id"])
            elif kind == "dispatch":
                a.expect(phase.get(cid) == "reserved", "DISPATCH_ONCE_AFTER_RESERVE", cid)
                a.expect(first_stop_seq is None, "NO_DISPATCH_AFTER_HARD_STOP", cid)
                phase[cid] = "dispatched"
            elif kind == "settle":
                a.expect(phase.get(cid) == "dispatched", "SETTLE_ONCE_AFTER_DISPATCH", cid)
                phase[cid] = "settled"
                usage = row.get("usage") or {}
                if usage.get("prompt_tokens", 0) > 4000 or usage.get("completion_tokens", 0) > 768 or row.get("known_cost_nano_usd", 0) > RESERVATION:
                    first_stop_seq = first_stop_seq or seq
            last[cid] = row
        elif kind == "late_receipt":
            a.expect(phase.get(cid) == "uncertain", "LATE_AFTER_UNKNOWN_ONLY", cid or "")
        elif kind == "finalize_item":
            iid = event.get("item_id")
            a.expect(iid == body.get("item_id") and iid not in finalized_items,
                     "ITEM_FINALIZED_ONCE", iid or "")
            # finalize_item uses INSERT OR REPLACE: SQLite deletes an existing
            # row and appends the replacement at the end of rowid order.
            if iid in item_insert_order:
                item_insert_order.remove(iid)
            item_insert_order.append(iid)
            finalized_items[iid] = body
        elif kind == "checkpoint":
            d = body.get("checkpoint_digest")
            a.expect(d == _digest({k: v for k, v in body.items() if k != "checkpoint_digest"}),
                     "LEDGER_CHECKPOINT_DIGEST", str(seq))
            a.expect(all(v == "settled" for v in phase.values()) and started_items <= set(finalized_items),
                     "LEDGER_CHECKPOINT_DURABLY_QUIESCENT", str(seq))
            a.expect(body.get("calls_digest") == _digest(list(last.values())) and
                     body.get("items_digest") == _digest([finalized_items[i] for i in item_insert_order
                                                          if i in finalized_items]),
                     "LEDGER_CHECKPOINT_CONTENT_DIGEST", str(seq))
            formal_order = [r["item_id"] for r in ledger.get("registry", [])]
            completed = body.get("completed_item_ids", [])
            a.expect(completed == formal_order[:len(completed)] and set(completed) == set(finalized_items),
                     "LEDGER_CHECKPOINT_FORMAL_PREFIX", str(seq))
            a.expect(body.get("config_digest") == _digest(ledger.get("config", {})) and
                     body.get("authority") == ledger.get("config", {}).get("authority"),
                     "LEDGER_CHECKPOINT_AUTHORITY_BINDING", str(seq))
            checkpoint_events.append({"seq": seq, "checkpoint_digest": d,
                                      "completed_items": len(completed)})
        elif kind in {"stop", "pause"}:
            first_stop_seq = first_stop_seq or seq
    a.expect(set(last) == set(call_map), "ALL_CENTRAL_CALLS_HAVE_EVENT_HISTORY")
    for cid, call in call_map.items():
        if cid in last:
            for field in ("status", "dispatched", "known_cost_nano_usd", "held_cost_nano_usd", "item_id", "attempt_id"):
                a.expect(last[cid].get(field) == call.get(field), "EVENT_FINAL_CALL_MATCH", cid + ":" + field)
    return {"count": len(events), "first_hard_stop_seq": first_stop_seq,
            "reserved_calls_rebuilt": len(phase), "checkpoints": checkpoint_events}


def _raw_result(view: dict, spec: dict, terminal: str, a: _Audit,
                expected_dag: dict | None = None, qualified_prefix: bool = False) -> None:
    iid, state = spec["item_id"], view.get("state", {})
    task, actual_dag = view.get("task", {}), view.get("dag", {})
    a.expect(task.get("task_id") == spec["task_id"], "RAW_TASK_ID_MATCHES_REGISTERED_ITEM", iid)
    a.expect(actual_dag.get("workflow_id") == spec["workflow_id"],
             "RAW_WORKFLOW_ID_MATCHES_REGISTERED_ITEM", iid)
    if expected_dag is not None:
        a.expect(actual_dag == expected_dag, "RAW_DAG_EQUALS_FROZEN_DOMAIN_GRAPH", iid)
        a.expect(task.get("nodes") == expected_dag["nodes"], "RAW_TASK_NODES_MATCH_FROZEN_GRAPH", iid)
        declared_domain = "micro" if expected_dag["workflow_id"] == "sr-v2.micro.fixed-five" else "macro"
        a.expect(declared_domain == spec["domain"], "REGISTERED_DOMAIN_MATCHES_FROZEN_GRAPH", iid)
    results = _rows(view.get("results"))
    result_map = {x["result_id"]: x for x in results}
    a.expect(len(result_map) == len(results), "RAW_UNIQUE_RESULT_IDS", iid)
    node_definitions = {x["node_id"]: x for x in (expected_dag or actual_dag).get("nodes", [])}
    for result in results:
        node = node_definitions.get(result.get("node_id"))
        if a.expect(node is not None, "RAW_RESULT_NODE_IN_FROZEN_GRAPH", result.get("result_id", "")):
            _input_projection(result, node, a)
    if state.get("counters"):
        caps = spec["limits"]
        counters = state["counters"]
        a.expect(counters.get("physical_calls", 0) <= caps["physical_llm_call_cap"], "RAW_ITEM_CALL_CAP", iid)
        a.expect(counters.get("cpu_jobs", 0) <= caps["workflow_cpu_job_cap"], "RAW_ITEM_CPU_CAP", iid)
        for key, capkey in (("stale_used", "stale_correction_cap"), ("semantic_used", "semantic_correction_cap")):
            a.expect(0 <= counters.get(key, 0) <= caps[capkey], "RAW_CORRECTION_CAP", iid + ":" + key)
    if terminal in _TERMINAL and terminal != "uncertain":
        if spec["kind"] == "prefix" and qualified_prefix:
            a.expect(terminal == "validation_rejected" and state.get("status") == "paused" and
                     view.get("metadata", {}).get("prefix_frozen") is True,
                     "QUALIFIED_PREFIX_DURABLY_FROZEN_PAUSED", iid)
        else:
            a.expect(state.get("status") == "terminal" and state.get("terminal_status") == terminal,
                     "RAW_DURABLE_TERMINAL_MATCHES_ITEM_STATUS", iid)
        a.expect(not state.get("active_attempt_ids") and not state.get("unsettled_call_ids"), "TERMINAL_QUIESCENT", iid)
    selected = state.get("selected_by_node", {})
    success = terminal == "completed_correct"
    if not success:
        return
    a.expect(bool(results) and bool(selected), "SUCCESS_HAS_RESULT_CHAIN", iid)
    current = {x["object_key"]: x for x in _rows(view.get("sources"))}
    history = {(x["object_key"], x["version"]): x for x in _rows(view.get("source_history"))}
    for key, source in current.items():
        a.expect(source.get("payload_digest") == _digest(source.get("payload")), "SOURCE_BYTES_DIGEST_REBUILT", iid + ":" + key)
        a.expect(history.get((key, source.get("version"))) == source, "SOURCE_RESOLVES_IMMUTABLE_HISTORY", iid + ":" + key)
    dag = view.get("dag", {})
    nodes = {x["node_id"]: x for x in dag.get("nodes", [])}
    a.expect(bool(nodes) and set(selected) == set(dag.get("topological_order", [])),
             "SUCCESS_COMPLETE_FIXED_DAG", iid)
    call_map = {x["call_id"]: x for x in _rows(view.get("calls"))}
    receipt_map = {x["receipt_id"]: x for x in _rows(view.get("tool_receipts"))}
    for node, rid in selected.items():
        if not a.expect(rid in result_map, "SELECTED_RESULT_RESOLVES", iid + ":" + node):
            continue
        result = result_map[rid]
        a.expect(result.get("node_id") == node and result.get("execution_status") == "success", "SELECTED_SUCCESS", rid)
        for read in result.get("effective_reads", []):
            source = current.get(read["object_key"])
            a.expect(source is not None and read["version"] == source["version"], "FINAL_ANCESTRY_CURRENT", rid + ":" + read["object_key"])
        parents = result.get("parent_result_ids", [])
        if node in nodes:
            node_calls = result.get("call_ids", [])
            node_tools = result.get("tool_receipt_ids", [])
            a.expect(len(node_calls) == nodes[node]["llm_calls_per_execution"] and
                     all(c in call_map for c in node_calls), "FINAL_NODE_LLM_EXECUTION_EVIDENCE", rid)
            a.expect(len(node_tools) == nodes[node]["cpu_jobs_per_execution"] and
                     all(t in receipt_map for t in node_tools), "FINAL_NODE_CPU_EXECUTION_EVIDENCE", rid)
            for receipt_id in node_tools:
                receipt = receipt_map.get(receipt_id, {})
                execution = receipt.get("parameters", {}).get("execution", {})
                a.expect(execution.get("status") == "success" and execution.get("worker_reaped") is True and
                         not execution.get("remaining_processes") and execution.get("returncode") == 0,
                         "FINAL_CPU_TOOL_REAL_AND_REAPED", receipt_id)
                if execution.get("effective_timeout_seconds") is not None:
                    a.expect(0 < execution["effective_timeout_seconds"] <= 120 and
                             execution.get("peak_rss_bytes", 0) <= 8589934592,
                             "FINAL_CPU_RESOURCE_LIMITS", receipt_id)
            a.expect([result_map.get(p, {}).get("node_id") for p in parents] == nodes[node]["parents"], "FINAL_DAG_PARENT_ORDER", rid)
            a.expect(all(selected.get(result_map.get(p, {}).get("node_id")) == p for p in parents), "FINAL_CHAIN_PARENT_SELECTED", rid)
    if spec["domain"] == "micro":
        _micro_business(view, result_map, a, iid)
    else:
        _macro_business(view, result_map, a, iid)


def _input_projection(result: dict, node: dict, a: _Audit) -> None:
    """Reconstruct V3's compact model input without importing its renderer."""
    rid = result.get("result_id", "")
    snapshot = result.get("input_snapshot")
    if not a.expect(isinstance(snapshot, dict), "RAW_INPUT_SNAPSHOT_PRESENT", rid):
        return
    a.expect(_digest(snapshot) == result.get("input_digest"), "RAW_INPUT_DIGEST", rid)
    a.expect(snapshot.get("node_id") == node["node_id"], "SNAPSHOT_NODE_MATCHES_RESULT", rid)
    messages = snapshot.get("rendered_messages")
    if node["llm_calls_per_execution"] == 0:
        a.expect(messages == [], "CPU_NODE_HAS_NO_MODEL_CONTEXT", rid)
        return
    expected = {"node_id": snapshot["node_id"], "request": snapshot["request"],
                "parent_inputs": [{"node_id": p["node_id"], "payload": p["payload"]}
                                  for p in snapshot["parent_inputs"]],
                "direct_source_inputs": [{"object_key": s["object_key"], "version": s["version"],
                                          "payload": s["payload"]}
                                         for s in snapshot["direct_source_inputs"]]}
    if snapshot.get("repair_feedback"):
        expected["repair_feedback"] = snapshot["repair_feedback"]
    shape_ok = isinstance(messages, list) and len(messages) == 2 and \
        all(isinstance(m, dict) and set(m) == {"role", "content"} and isinstance(m["content"], str)
            for m in messages) and messages[0]["role"] == "system" and messages[1]["role"] == "user" and \
        bool(messages[0]["content"])
    if not a.expect(shape_ok, "EXACT_SYSTEM_USER_MESSAGES_NO_EXTRA_CONTEXT", rid):
        return
    try:
        actual = json.loads(messages[1]["content"])
    except (ValueError, TypeError) as exc:
        a.expect(False, "USER_CONTEXT_JSON_READABLE", rid, str(exc))
        return
    a.expect(actual == expected, "USER_CONTEXT_EQUALS_INDEPENDENT_COMPACT_PROJECTION", rid)


def _micro_business(view: dict, results: dict, a: _Audit, iid: str) -> None:
    request = view.get("task", {}).get("request", view.get("task", {}).get("public_request", {}))
    aliases = view.get("source_aliases", view.get("task", {}).get("resolved_source_aliases", {}))
    sources = {x["object_key"]: x["payload"] for x in _rows(view.get("sources"))}
    if not a.expect(all(k in aliases and aliases[k] in sources for k in ("metadata", "permission", "resources")), "MICRO_AUTHORITY_PRESENT", iid):
        return
    metadata, permission, resources = (sources[aliases[k]] for k in ("metadata", "permission", "resources"))
    n = metadata.get("num_examples", metadata.get("n"))
    expected = dict(request, num_examples=n,
                    allowed=permission["allowed"], policy_revision=permission["policy_revision"],
                    workers=min(request["requested_workers"], resources["max_workers"]),
                    steps=((n + request["batch_size"] - 1) // request["batch_size"]) * request["epochs"])
    a.expect(permission["allowed"] is True, "MICRO_SUCCESS_PERMISSION", iid)
    selected = view["state"]["selected_by_node"]
    plan = results.get(selected.get("plan"), {}).get("payload", {})
    execute = results.get(selected.get("execute"), {}).get("payload", {})
    a.expect(execute.get("action") == "commit_config_and_draft", "MICRO_EXECUTE_ACTION", iid)
    a.expect(execute.get("config") == execute.get("command"), "MICRO_COMMAND_CONFIG_EXACTLY_EQUAL", iid)
    for key, value in expected.items():
        a.expect(plan.get(key) == value, "MICRO_PLAN_BUSINESS_VALUE", iid + ":" + key)
        a.expect(execute.get("config", {}).get(key) == value and execute.get("command", {}).get(key) == value,
                 "MICRO_COMMAND_CONFIG_VALUE", iid + ":" + key)
    objects = view.get("objects", {})
    final_rid = selected.get("execute")
    for name in ("config", "draft"):
        obj = objects.get(name, {})
        a.expect(obj.get("owner_result_id") == final_rid and obj.get("payload") == expected,
                 "MICRO_ATOMIC_FINAL_OBJECT", iid + ":" + name)


def _macro_business(view: dict, results: dict, a: _Audit, iid: str) -> None:
    selected = view["state"]["selected_by_node"]
    report = results.get(selected.get("report"), {}).get("payload", {})
    summaries = {fam: results.get(selected.get("summary_" + fam), {}).get("payload", {}) for fam in ("lr", "rf")}
    tools = {x["receipt_id"]: x for x in _rows(view.get("tool_receipts"))}
    metrics = {}
    for fam, summary in summaries.items():
        metric = summary.get("average_precision", summary.get("metrics", {}).get("average_precision"))
        if a.expect(type(metric) in (int, float) and math.isfinite(metric), "MACRO_FINITE_VAL_AP", iid + ":" + fam):
            metrics[fam] = metric
        summary_result = results.get(selected.get("summary_" + fam), {})
        source_metrics = [tools[t].get("parameters", {}).get("unmodified_metrics")
                          for t in summary_result.get("tool_receipt_ids", []) if t in tools]
        if a.expect(len(source_metrics) == 1 and isinstance(source_metrics[0], dict),
                    "MACRO_RAW_METRICS_RECEIPT_PRESENT", iid + ":" + fam):
            for key in ("average_precision", "roc_auc", "accuracy", "f1"):
                actual, expected = summary.get("metrics", {}).get(key), source_metrics[0].get(key)
                a.expect(type(actual) in (int, float) and type(expected) in (int, float) and
                         math.isfinite(actual) and math.isfinite(expected) and abs(actual - expected) <= 1e-8,
                         "MACRO_FINAL_SUMMARY_MATCHES_RAW_TOOL", iid + ":" + fam + ":" + key)
    if len(metrics) == 2:
        request = view.get("task", {}).get("request", {})
        eps = request.get("tie_absolute_ap", 1e-6)
        chosen = "lr" if metrics["lr"] >= metrics["rf"] - eps else "rf"
        a.expect(str(report.get("chosen_family", report.get("selected_family"))).lower() == chosen, "MACRO_AP_MODEL_SELECTION", iid)
        reported_ap = {str(k).lower(): v for k, v in report.get("validation_average_precision", {}).items()}
        a.expect(set(reported_ap) == {"lr", "rf"} and all(type(reported_ap[f]) in (int, float) and
                 abs(reported_ap[f] - metrics[f]) <= 1e-8 for f in ("lr", "rf")),
                 "MACRO_REPORT_BOTH_VALIDATION_AP", iid)
        selected_summary = summaries[chosen]
        for key in ("model_artifact_id", "prediction_artifact_id", "validation_row_ids_digest", "metrics"):
            a.expect(report.get(key) == selected_summary.get(key), "MACRO_REPORT_SELECTED_ARTIFACT_METRICS", iid + ":" + key)
    objects = view.get("objects", {})
    # The macro Store publishes manifest + report index, never a bare success
    # marker.  Numerical sklearn checks remain separate CPU audit receipts.
    a.expect(bool(objects.get("manifest", objects.get("publish_manifest", {})).get("payload")) and
             bool(objects.get("report_index", {}).get("payload")), "MACRO_FINAL_PUBLISH_PRESENT", iid)
    manifest = objects.get("manifest", objects.get("publish_manifest", {})).get("payload", {})
    manifest = manifest.get("publish_manifest", manifest)
    for key in ("model_artifact_id", "prediction_artifact_id", "report_artifact_id", "validation_row_ids_digest", "metrics"):
        a.expect(manifest.get(key) == report.get(key), "MACRO_PUBLISHED_REPORT_BINDING", iid + ":" + key)
    a.expect(objects.get("report_index", {}).get("payload", {}).get("report_result_id") == selected.get("report"),
             "MACRO_PUBLISHED_REPORT_RESULT", iid)


def _scenes(bundle: dict, specs: list[dict], items: dict, raw: dict, v0: Path, a: _Audit) -> dict:
    scenes = _rows(bundle.get("scenes"))
    scene_map = {s["scene_id"]: s for s in scenes}
    a.expect(len(scenes) == 12 and {s["scene_id"] for s in specs} == set(scene_map), "ALL_12_SCENES_RETAINED")
    qualified = blocked = comparable = 0
    evidence_counts = {d: {n: 0 for n in ("N1", "N2", "N3")} for d in ("micro", "macro")}
    branch_measurements = []
    for spec in specs:
        sid = spec["scene_id"]
        scene = scene_map.get(sid, {})
        branches = spec["ordered_branch_item_ids"]
        a.expect(scene.get("prefix_item_id") == spec["prefix_item_id"] and
                 scene.get("branch_item_ids", scene.get("ordered_branch_item_ids")) == branches,
                 "SCENE_FIXED_IDENTITIES_AND_ORDER", sid)
        if scene.get("qualified"):
            qualified += 1
            prefix_view = scene.get("prefix_export", raw.get(spec["prefix_item_id"]))
            if a.expect(isinstance(prefix_view, dict), "QUALIFIED_PREFIX_RAW_REQUIRED", sid):
                eligibility = qualify_prefix(prefix_view, spec["domain"],
                                             fault_evidence=scene.get("fault_evidence"))
                a.expect(eligibility["qualified"], "INDEPENDENT_PREFIX_ELIGIBILITY", sid,
                         eligibility["issues"])
            freeze = scene.get("freeze_digest")
            a.expect(isinstance(freeze, str) and len(freeze) == 64, "QUALIFIED_SCENE_FREEZE_DIGEST", sid)
            frozen_view = scene.get("scene_export")
            if a.expect(isinstance(frozen_view, dict), "QUALIFIED_FROZEN_SCENE_REQUIRED", sid):
                a.expect(_digest(frozen_view) == freeze, "FROZEN_SCENE_DIGEST_REBUILT", sid)
                run_state = frozen_view.get("run_state", {})
                a.expect(run_state.get("lifecycle") == "frozen_recoverable" and
                         not run_state.get("active_attempt_ids") and not run_state.get("unsettled_call_ids"),
                         "FROZEN_RECOVERABLE_QUIESCENT", sid)
                authority = json.loads((v0 / "tasks/authority" / (spec["task_id"] + ".sources.json")).read_text())["sources"]
                condition = spec["condition"]
                def expected_version(key):
                    if spec["domain"] == "micro":
                        return 2 if condition == "N3" or condition == "N2" and key.startswith("resource_policy:") else 1
                    return 2 if condition == "N2" and key == "recipe:rf" or condition == "N3" and key == "data:train" else 1
                expected_sources = {s["object_key"]: s for s in authority
                                    if s["version"] == expected_version(s["object_key"])}
                frozen_sources = {s["object_key"]: s for s in _rows(frozen_view.get("current_sources"))}
                a.expect(frozen_sources == expected_sources, "FROZEN_SOURCES_MATCH_REGISTERED_CONDITION", sid)
                if prefix_view:
                    before_results = {x["result_id"]: x for x in _rows(prefix_view.get("results"))}
                    after_results = {x["result_id"]: x for x in _rows(frozen_view.get("results"))}
                    a.expect(before_results == after_results, "FREEZE_PRESERVES_ALL_PREFIX_RESULTS", sid)
            for iid in branches:
                item = items.get(iid, {})
                if item.get("status") not in _UNSTARTED:
                    a.expect(item.get("freeze_digest") == freeze, "THREE_STRATEGIES_SAME_FREEZE", iid)
                    if iid in raw:
                        a.expect(raw[iid].get("prefix_digest") == freeze, "RAW_PREFIX_MATCHES_SCENE", iid)
                        if frozen_view:
                            a.expect(raw[iid].get("initial_snapshot") == frozen_view,
                                     "BRANCH_INITIAL_SNAPSHOT_IDENTICAL", iid)
                            a.expect({s["object_key"]: s for s in _rows(raw[iid].get("sources"))} ==
                                     {s["object_key"]: s for s in _rows(frozen_view.get("current_sources"))},
                                     "NO_POST_FREEZE_SOURCE_DRIFT", iid)
                        old = {r["result_id"]: r for r in _rows((frozen_view or {}).get("results"))}
                        selected = raw[iid].get("state", {}).get("selected_by_node", {})
                        reused = [{"node_id": node, "result_id": rid}
                                  for node, rid in selected.items() if rid in old]
                        if items[iid].get("status") == "completed_correct":
                            if items[iid].get("policy", iid.rsplit(".", 1)[-1]) == "FULL":
                                a.expect(not reused, "FULL_DOES_NOT_REUSE_PREFIX_RESULTS", iid)
                            for entry in reused:
                                actual_result = next((r for r in _rows(raw[iid].get("results"))
                                                      if r["result_id"] == entry["result_id"]), None)
                                a.expect(actual_result == old[entry["result_id"]], "ACTUAL_REUSED_RESULT_IMMUTABLE", iid)
                        branch_measurements.append(dict(item_id=iid, scene_id=sid,
                            status=items[iid].get("status"), actual_reused_results=reused,
                            reused_model_count=sum(r["node_id"] in {"fit_lr", "fit_rf"} for r in reused)))
            if all(items.get(i, {}).get("status") in _TERMINAL - {"not_run_stopped", "not_run_blocked_prefix"} for i in branches):
                comparable += 1
                evidence_counts[spec["domain"]][spec["condition"]] += 1
        else:
            pstatus = items.get(spec["prefix_item_id"], {}).get("status")
            if pstatus not in _UNSTARTED and pstatus is not None:
                blocked += 1
                for iid in branches:
                    item = items.get(iid, {})
                    a.expect(item.get("status") == "not_run_blocked_prefix" and item.get("run_count") == 0 and
                             not item.get("physical_dispatch_ids", item.get("call_ids", [])),
                             "FAILED_PREFIX_BLOCKS_ALL_THREE_NO_RESAMPLE", iid)
    return {"planned_scenes": 12, "qualified_scenes": qualified,
            "blocked_prefix_scenes": blocked, "complete_auditable_triplets": comparable,
            "complete_triplets_by_domain_condition": evidence_counts,
            "all_conditions_have_comparable_evidence": all(n > 0 for d in evidence_counts.values() for n in d.values()),
            "branch_measurements": branch_measurements}


def _checkpoints(bundle: dict, ledger: dict, a: _Audit) -> list[dict]:
    checkpoints = _rows(bundle.get("checkpoints"))
    ids = [x["checkpoint_id"] for x in checkpoints]
    a.expect(len(ids) == len(set(ids)), "UNIQUE_CHECKPOINT_ID")
    out = []
    for cp in checkpoints:
        cid = cp["checkpoint_id"]
        if cp.get("resumable"):
            a.expect(not cp.get("active_jobs") and not cp.get("unsettled_dispatch_ids"), "RESUMABLE_CHECKPOINT_QUIESCENT", cid)
            a.expect(set(cp.get("started_item_ids", [])) <= set(cp.get("terminal_item_ids", [])), "RESUMABLE_STARTED_ALL_TERMINAL", cid)
        ledger_cp = cp.get("ledger_checkpoint")
        if ledger_cp is not None:
            matches = [e for e in _rows(ledger.get("events")) if e.get("kind") == "checkpoint" and e.get("body") == ledger_cp]
            a.expect(len(matches) == 1, "RUNNER_CHECKPOINT_BINDS_CENTRAL_CHECKPOINT", cid)
            if matches and cp.get("ledger_event_seq") is not None:
                a.expect(cp["ledger_event_seq"] == matches[0]["seq"], "RUNNER_CHECKPOINT_LEDGER_EVENT_SEQ", cid)
        out.append({"checkpoint_id": cid, "resumable": bool(cp.get("resumable"))})
    return out


def _runner_events(events: list[dict], items: dict, specs: dict, a: _Audit) -> None:
    if not events:
        return
    seqs = [e["seq"] for e in events]
    a.expect(seqs == list(range(1, len(events) + 1)), "RUNNER_EVENT_SEQUENCE")
    starts, seen = [], set()
    for event in events:
        kind = event.get("type", event.get("kind"))
        if kind in {"item_started", "start_item"}:
            iid = event["item_id"]
            a.expect(iid in specs and iid not in seen, "RUNNER_ITEM_START_ONCE", iid)
            seen.add(iid)
            if iid in specs:
                starts.append(specs[iid]["execution_ordinal"])
    a.expect(starts == sorted(starts), "RUNNER_FROZEN_EXECUTION_ORDER")
    touched = {iid for iid, row in items.items() if row.get("status") not in _UNSTARTED}
    a.expect(seen == touched, "RUNNER_START_EVENT_ITEM_BIJECTION")
