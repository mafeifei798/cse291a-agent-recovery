"""Formal-order V3 offline campaign, with durable quiescent checkpoints."""
import argparse
import copy
from datetime import timedelta
import hashlib
import json
from pathlib import Path
import traceback

from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from sr_cpu_v2.adapter import numerical_check
from sr_cpu_v2.checker import audit_export
from sr_recovery_v2.common import canonical, digest, utc_parse, utc_format
from .budget import DurableV3Budget
from .checker import audit_campaign, qualify_prefix
from .contracts import model_schema, scripted_payload
from .executor import now
from .gateway import FakeHTTPClient, OfflineV3Gateway, fake_response, offline_binding, schema_for_node
from .runtime import initial_store, run_item, freeze, write
from .store import V3Store


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def replace_json(path, value):
    path = Path(path)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')
    with tmp.open('rb') as handle:
        __import__('os').fsync(handle.fileno())
    tmp.replace(path)


def write_http_evidence(root, stage, record):
    top = record.get('call_id')
    nested = record.get('sidecar', {}).get('call_id')
    if top and nested and top != nested:
        raise ValueError('HTTP_EVIDENCE_CALL_ID_CONFLICT')
    identity = top or nested
    if not isinstance(identity, str) or not identity or '/' in identity or '\\' in identity:
        raise ValueError('HTTP_EVIDENCE_CALL_ID_MISSING_OR_INVALID')
    write(Path(root) / 'http' / identity / (stage + '.json'), record)


def freeze_binding(root, v0):
    source = Path(__file__).resolve().parents[2]
    schemas = {domain: {n['node_id']: model_schema(n['node_id'], domain)
                        for n in read(v0 / ('dags/' + domain + '.json'))['nodes'] if n['llm_calls_per_execution']}
               for domain in ('micro', 'macro')}
    files = {str(p.relative_to(source)): sha(p) for folder in ('src/sr_campaign_v3', 'src/sr_cpu_v2', 'src/sr_recovery_v2')
             for p in sorted((source / folder).glob('*.py'))}
    binding = {**offline_binding(v0), 'schema_digest': digest(schemas),
        'template_digest': sha(source / 'src/sr_campaign_v3/contracts.py'),
        'guard_digest': sha(source / 'src/sr_campaign_v3/guard.py'),
        'correction_digest': sha(source / 'src/sr_recovery_v2/policy.py'),
        'source_manifest_digest': digest(files), 'identifier_conditions_blinded': True}
    write(root / 'frozen/binding.json', binding)
    write(root / 'frozen/schemas.json', schemas)
    write(root / 'frozen/source_manifest.json', files)
    raw = (v0 / 'registry/formal_items.jsonl').read_bytes()
    (root / 'frozen/formal_items.jsonl').write_bytes(raw)
    write(root / 'frozen/authority.json', {'execution': 'offline_fake_http', 'real_requests_authorized': False,
        'cloud_resources_authorized': False, 'server_cpu_authorized': True,
        'user_authorization': 'Explicit reply: allow entering V3 and running server CPU.',
        'original_registry_modified': False})
    return binding


def campaign(output, v0_root, *, through=52, resume_checkpoint=None):
    root, v0 = Path(output).resolve(), Path(v0_root).resolve()
    registry_file = v0 / 'registry/formal_items.jsonl'
    registry = [json.loads(line) for line in registry_file.read_text().splitlines() if line.strip()]
    scene_specs = read(v0 / 'registry/formal_scenes.json')['scenes']
    if resume_checkpoint is None:
        root.mkdir(parents=True, exist_ok=False)
        for name in ('db', 'files', 'exports', 'scenes', 'http', 'injections', 'audits', 'numerical', 'checkpoints', 'frozen'):
            (root / name).mkdir()
        binding = freeze_binding(root, v0)
        state = {'mode': 'offline_fake_http', 'campaign_id': 'sr-v2-formal-r1',
            'rehearsal_id': root.parent.name + '/' + root.name,
            'run_namespace': hashlib.sha256(str(root).encode()).hexdigest()[:12],
            'registry_sha256': sha(registry_file), 'items': [{**r, 'status': 'not_started', 'run_count': 0,
                'started_at': None, 'finished_at': None, 'deadline_at': None,
                'physical_dispatch_ids': []} for r in registry], 'events': [],
            'scenes': [{**s, 'qualified': False, 'attempted': False, 'freeze_digest': None,
                        'branch_item_ids': s['ordered_branch_item_ids']} for s in scene_specs],
            'checkpoints': [], 'phase': 'V3', 'V4_started': False,
            'real_api_requests': 0, 'actual_api_cost_nano_usd': 0, 'gpu_used': False,
            'cloud_resources_started': False, 'stop_reason': None}
    else:
        state = read(root / 'campaign_state.json')
        if state.get('stop_reason') or any(i['status'] == 'running' for i in state['items']):
            raise ValueError('UNQUIESCENT_CAMPAIGN_REQUIRES_MANUAL_RECONCILIATION')
        for item in state['items']:
            view = item.get('raw_export')
            if view and (view['state']['active_attempt_ids'] or view['state']['unsettled_call_ids']):
                raise ValueError('ACTIVE_WORKFLOW_ATTEMPT_REQUIRES_MANUAL_RECONCILIATION')
        binding = read(root / 'frozen/binding.json')
        if sha(registry_file) != state['registry_sha256']:
            raise ValueError('ORIGINAL_REGISTRY_CHANGED')
        for relative, expected in read(root / 'frozen/source_manifest.json').items():
            if sha(Path(__file__).resolve().parents[2] / relative) != expected:
                raise ValueError('FROZEN_RUNTIME_SOURCE_CHANGED:' + relative)
        checkpoint = read(resume_checkpoint)
        if not state['checkpoints'] or checkpoint['checkpoint_digest'] != state['checkpoints'][-1]['budget_checkpoint_digest']:
            raise ValueError('LATEST_QUIESCENT_CHECKPOINT_REQUIRED')
    def event(kind, item=None, payload=None):
        state['events'].append({'seq': len(state['events']) + 1, 'event_id': 'v3.event.' + str(len(state['events']) + 1),
            'type': kind, 'item_id': item, 'timestamp': now(), 'payload': payload or {}})
    ledger_path = root / 'budget/central.sqlite'
    with DurableV3Budget(ledger_path, campaign_id=state['campaign_id'], binding=binding,
                         v0_root=v0, lock_root=root.parent / 'budget_authority',
                         resume_checkpoint=read(resume_checkpoint) if resume_checkpoint else None) as budget:
        counter = GLM53LocalTokenCounter.from_directory(v0 / 'environment/tokenizer_files')
        def fake_builder(request):
            payload = scripted_payload({'rendered_messages': request['messages']})
            tokens = counter.estimate_request(request).to_dict()['prompt_tokens']
            visible = len(counter._encoder(canonical(payload)))
            return fake_response(payload, request_id='fixture.' + budget.calls()[-1]['call_id'],
                prompt_tokens=tokens, completion_tokens=visible + 16, reasoning_tokens=16)
        def sink(stage, record):
            write_http_evidence(root, stage, record)
        gateway = OfflineV3Gateway(v0, client=FakeHTTPClient(response_builder=fake_builder), budget=budget,
                                   token_counter=counter, binding=binding, evidence_sink=sink)
        items = {i['item_id']: i for i in state['items']}
        scenes = {s['scene_id']: s for s in state['scenes']}
        for registered in registry:
            ordinal, iid = registered['execution_ordinal'], registered['item_id']
            if ordinal > through:
                break
            row = items[iid]
            if row['status'] != 'not_started':
                continue
            scene = scenes.get(registered['scene_id'])
            if registered['kind'] == 'branch' and not scene['qualified']:
                row['status'] = 'not_run_blocked_prefix'
                budget.finalize_item(iid, row['status'], digest(row))
                event('item_blocked', iid, {'prefix_item_id': scene['prefix_item_id']})
                state['ledger'] = budget.snapshot()
                checkpoint = budget.make_checkpoint()
                cp_id = 'checkpoint.' + format(ordinal, '04d')
                path = root / 'checkpoints' / (cp_id + '.json')
                write(path, checkpoint)
                state['checkpoints'].append({'checkpoint_id': cp_id, 'event_seq': len(state['events']),
                    'started_item_ids': [i['item_id'] for i in state['items'] if i['run_count']],
                    'terminal_item_ids': [i['item_id'] for i in state['items'] if i['status'] not in ('not_started', 'running')],
                    'active_jobs': [], 'unsettled_dispatch_ids': [],
                    'next_item_id': registry[ordinal]['item_id'] if ordinal < 52 else None,
                    'resumable': True, 'budget_checkpoint_digest': checkpoint['checkpoint_digest'],
                    'budget_checkpoint_path': str(path), 'ledger_checkpoint': checkpoint,
                    'ledger_event_seq': budget.snapshot()['events'][-1]['seq']})
                event('checkpoint', payload={'checkpoint_id': cp_id})
                state['ledger'] = budget.snapshot()
                replace_json(root / 'campaign_state.json', state)
                continue
            store = None
            view = None
            error = None
            try:
                scope = 'pre_prefix' if registered['kind'] == 'prefix' else 'item'
                if registered['kind'] == 'branch' and all(items[b]['status'] == 'not_started' for b in scene['branch_item_ids']):
                    scope = 'scene'
                budget.check_admission(iid, scope)
                row.update(status='running', run_count=1, started_at=now())
                row['deadline_at'] = utc_format(utc_parse(row['started_at']) + timedelta(seconds=1800))
                event('item_started', iid)
                replace_json(root / 'campaign_state.json', state)
                if registered['kind'] == 'branch':
                    frozen = read(root / 'scenes' / (scene['scene_id'] + '.json'))
                    if digest(frozen) != scene['freeze_digest']:
                        raise ValueError('FROZEN_SCENE_DIGEST_CHANGED')
                    dag = read(v0 / ('dags/' + registered['domain'] + '.json'))
                    store = V3Store(root / 'db' / (iid + '.sqlite'), root / 'files')
                    store.create(frozen, dag, iid, registered['policy'])
                else:
                    # Public model messages never include N1/N2/N3 or strategy.
                    store = initial_store(registered, 'r3.' + state['run_namespace'] + '.' + format(ordinal, '04d'), v0, root, root / 'files')
                view = run_item(store, registered, v0, root, gateway)
                last_guard = view.get('last_guard')
                if last_guard and last_guard['classification'] in ('integrity_error', 'uncertain', 'source_drift'):
                    raise ValueError('ENGINEERING_GUARD_REFUSAL:' + last_guard['classification'])
                row['started_at'] = view['state']['started_at_utc']
                row['deadline_at'] = view['state']['deadline_utc']
                if registered['kind'] == 'prefix':
                    scene['attempted'] = True
                    fault_path = root / 'injections' / (iid + '.json')
                    fault = read(fault_path) if fault_path.is_file() else None
                    eligibility = qualify_prefix(view, registered['domain'], view['task'], fault)
                    write(root / 'audits' / (iid + '.eligibility.json'), eligibility)
                    scene.update(prefix_export=copy.deepcopy(view), fault_evidence=fault,
                                 eligibility_receipt=eligibility)
                    if eligibility['qualified'] and budget.snapshot()['status'] == 'active':
                        if registered['domain'] == 'macro':
                            numeric = numerical_check(view, v0, root / 'files', root, iid, prefix=True)
                            write(root / 'numerical' / (iid + '.json'), numeric)
                            if not numeric.get('response', {}).get('payload', {}).get('passed'):
                                raise ValueError('INDEPENDENT_PREFIX_NUMERICAL_CHECK_FAILED')
                        frozen = freeze(store, registered, v0, scene['scene_id'])
                        write(root / 'scenes' / (scene['scene_id'] + '.json'), frozen)
                        scene.update(qualified=True, freeze_digest=digest(frozen), scene_export=frozen)
                        event('scene_frozen', iid, {'freeze_digest': scene['freeze_digest']})
                        view = store.export()
                    row['status'] = 'validation_rejected' if not view['state'].get('terminal_status') else view['state']['terminal_status']
                else:
                    row['status'] = view['state']['terminal_status'] or 'validation_rejected'
                    if registered['domain'] == 'macro' and row['status'] == 'completed_correct':
                        audit = audit_export(view, root / 'files', v0)
                        write(root / 'audits' / (iid + '.json'), audit)
                        numeric = numerical_check(view, v0, root / 'files', root, iid)
                        write(root / 'numerical' / (iid + '.json'), numeric)
                        if not audit['passed'] or not audit['business_correct'] or not numeric.get('response', {}).get('payload', {}).get('passed'):
                            raise ValueError('INDEPENDENT_COMPLETION_CHECK_FAILED')
                if budget.snapshot()['status'] != 'active':
                    raise ValueError('CENTRAL_LEDGER_STOPPED:' + str(budget.snapshot()['pause_reason']))
            except Exception as exc:
                error = {'code': getattr(exc, 'code', type(exc).__name__), 'message': str(exc), 'traceback': traceback.format_exc()}
                write(root / 'audits' / (iid + '.failure.json'), error)
                if store:
                    view = store.export()
                row['status'] = view['state'].get('terminal_status') if view else None
                row['status'] = row['status'] or 'uncertain'
                state['stop_reason'] = error
                budget.quarantine(None, 'V3_RUNNER_HARD_STOP:' + error['code'])
            finally:
                if store:
                    store.close()
            row['finished_at'] = now()
            row['error'] = error
            row['physical_dispatch_ids'] = [c['call_id'] for c in budget.calls() if c['item_id'] == iid and c['dispatched']]
            if view:
                export_path = root / 'exports' / (iid + '.json')
                write(export_path, view)
                row.update(raw_export=view, export_path=str(export_path.relative_to(root)), export_sha256=sha(export_path),
                           raw_export_digest=digest(view))
            if not any(c['item_id'] == iid and c['status'] != 'settled' for c in budget.calls()):
                budget.finalize_item(iid, row['status'], digest(row))
            event('item_finished', iid, {'status': row['status']})
            state['ledger'] = budget.snapshot()
            if state['stop_reason'] is None:
                checkpoint = budget.make_checkpoint()
                cp_id = 'checkpoint.' + format(ordinal, '04d')
                path = root / 'checkpoints' / (cp_id + '.json')
                write(path, checkpoint)
                finished = [i['item_id'] for i in state['items'] if i['status'] not in ('not_started', 'running')]
                state['checkpoints'].append({'checkpoint_id': cp_id, 'event_seq': len(state['events']),
                    'started_item_ids': [i['item_id'] for i in state['items'] if i['run_count']],
                    'terminal_item_ids': finished, 'active_jobs': [], 'unsettled_dispatch_ids': [],
                    'next_item_id': registry[ordinal]['item_id'] if ordinal < 52 else None, 'resumable': True,
                    'budget_checkpoint_digest': checkpoint['checkpoint_digest'], 'budget_checkpoint_path': str(path)})
                state['checkpoints'][-1].update(ledger_checkpoint=checkpoint,
                    ledger_event_seq=budget.snapshot()['events'][-1]['seq'])
                event('checkpoint', payload={'checkpoint_id': cp_id})
                state['ledger'] = budget.snapshot()
            replace_json(root / 'campaign_state.json', state)
            print(json.dumps({'item_id': iid, 'status': row['status'], 'ordinal': ordinal,
                              'calls': len(row['physical_dispatch_ids']), 'stopped': bool(state['stop_reason'])}), flush=True)
            if state['stop_reason']:
                event('campaign_stopped', iid, state['stop_reason'])
                break
        state['ledger'] = budget.snapshot()
        state['finished_at'] = now()
        state['all_items_processed'] = all(i['status'] != 'not_started' for i in state['items'])
        replace_json(root / 'campaign_state.json', state)
        audit = audit_campaign(state, v0, artifact_root=root)
        write(root / ('audit.through' + str(through) + '.json'), audit)
        healthy = all(i['status'] == 'completed_correct' for i in state['items']
                      if i['run_count'] and i['kind'] in ('control', 'branch'))
        healthy = healthy and all(s['qualified'] for s in state['scenes'] if s['attempted'])
        return {'passed': audit['passed'] and state['stop_reason'] is None and healthy,
                'record_audit_passed': audit['passed'],
                'healthy_rehearsal_business_expectations_met': healthy,
                'audit': str(root / ('audit.through' + str(through) + '.json')),
                'all_items_processed': state['all_items_processed'], 'stop_reason': state['stop_reason'],
                'ledger': {k: v for k, v in state['ledger']['budget'].items() if k != 'item_counts'},
                'real_api_requests': 0, 'actual_api_cost_nano_usd': 0}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--v0-root', type=Path, default=Path(__file__).resolve().parents[2] / 'sr_v2/v0')
    p.add_argument('--through', type=int, default=52)
    p.add_argument('--resume-checkpoint', type=Path)
    args = p.parse_args()
    if not 1 <= args.through <= 52:
        raise SystemExit('Invalid registered ordinal')
    result = campaign(args.output, args.v0_root, through=args.through, resume_checkpoint=args.resume_checkpoint)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
