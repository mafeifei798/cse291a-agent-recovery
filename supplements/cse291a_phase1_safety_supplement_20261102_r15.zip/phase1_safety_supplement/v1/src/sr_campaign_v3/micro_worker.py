"""The fixed micro CPU tool: stage two JSON candidates, never run commands."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

from sr_recovery_v2.common import REV, canonical


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--spec', type=Path, required=True)
    p.add_argument('--response', type=Path, required=True)
    args = p.parse_args()
    def offline(event, values):
        if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system'):
            raise RuntimeError('MICRO_TOOL_NETWORK_AND_EXEC_DISABLED')
    sys.addaudithook(offline)
    spec = json.loads(args.spec.read_text())
    if spec['tool'] != 'execute':
        raise ValueError('FIXED_MICRO_TOOL_ONLY')
    output = Path(spec['output_dir']).resolve()
    root = Path(spec['artifact_root']).resolve()
    if not output.is_relative_to(root):
        raise ValueError('PATH_ESCAPE')
    payload = spec['inputs']['candidate']
    if set(payload) != {'action', 'config', 'command'} or payload['action'] != 'commit_config_and_draft':
        raise ValueError('FIXED_MICRO_ACTION_ONLY')
    artifacts = []
    for label in ('config', 'draft'):
        value = {'command': payload['command']}
        path = output / (label + '.json')
        raw = (canonical(value) + '\n').encode()
        with path.open('xb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        path.chmod(0o444)
        artifacts.append({'record_type': 'Artifact', 'revision': REV, 'fixture_only': False,
            'artifact_id': spec['result_id'] + '.' + label,
            'producer_result_id': spec['result_id'], 'uri': str(path.relative_to(root)),
            'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw), 'media_type': 'application/json'})
    response = {'status': 'success', 'payload': payload, 'artifacts': artifacts,
        'parameters': {'fixed_tool': 'stage_config_and_draft', 'commands_executed': 0,
                       'commit_owner': 'Store atomic transaction'}, 'warnings': []}
    temporary = args.response.with_suffix('.tmp')
    with temporary.open('x') as handle:
        handle.write(canonical(response) + '\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, args.response)


if __name__ == '__main__':
    main()
