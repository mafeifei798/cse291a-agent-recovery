"""V3 adds only lifecycle commands around the preserved V2 Store."""
import copy
from .base_store import V2Store
from sr_recovery_v2.common import ProtocolError, digest


class V3Store(V2Store):
    def bind_item(self, item, ledger_ref, now):
        def mutate(doc):
            domain = 'micro' if 'read_metadata' in doc['dag']['topological_order'] else 'macro'
            if (item['task_id'] != doc['task']['task_id'] or item['domain'] != domain
                    or item['workflow_id'] != doc['dag']['workflow_id']):
                raise ProtocolError('REGISTERED_WORKFLOW_IDENTITY_MISMATCH')
            doc['domain'] = item['domain']
            doc['metadata']['v3_item_id'] = item['item_id']
            doc['metadata']['v3_item_kind'] = item['kind']
            doc['metadata']['v3_budget_ref'] = ledger_ref
            doc['metadata']['implementation'] = 'V3-offline-fake-HTTP-r1'
            return {'item_id': item['item_id'], 'balance_cloned': False}, None
        return self._apply('v3.bind.' + item['item_id'], 'v3_bind_item',
                           {'item': item, 'ledger_ref': ledger_ref}, now, mutate)

    def enable_control_repair(self, now):
        def mutate(doc):
            if doc['metadata'].get('v3_item_kind') != 'control' or not doc['metadata'].get('initial_mode'):
                raise ProtocolError('CONTROL_INITIAL_ONLY')
            if not doc['last_guard'] or doc['last_guard']['classification'] != 'semantic':
                raise ProtocolError('CONTROL_SEMANTIC_REFUSAL_REQUIRED')
            if doc['state']['active_attempt_ids'] or doc['state']['unsettled_call_ids']:
                raise ProtocolError('ACTIVE_OR_UNSETTLED_WORK')
            # Keep the original fixed deadline, counters and active plan. The
            # existing pure policy will admit exactly one semantic correction.
            doc['metadata']['initial_mode'] = False
            return {'first_failure_preserved': True, 'notice_created': False}, None
        return self._apply('v3.control.repair', 'v3_control_repair', {}, now, mutate)

    def admit_decision(self, output, now_utc, guard_evidence=None):
        view = self.snapshot()
        if view['metadata'].get('v3_item_kind') == 'control' and output.get('correction_kind') == 'stale':
            raise ProtocolError('CONTROL_SOURCE_CHANGE_FORBIDDEN')
        result = super().admit_decision(output, now_utc, guard_evidence)
        if output['kind'] == 'admit_correction' and output['correction_kind'] == 'semantic':
            feedback = [{k: copy.deepcopy(issue[k]) for k in ('code', 'field_path', 'evidence_refs') if k in issue}
                        for issue in guard_evidence['issues'][:12]]
            def mutate(doc):
                doc['metadata']['repair_feedback'] = feedback
                return {'feedback_digest': digest(feedback), 'contains_expected_answer': False}, None
            self._apply('v3.feedback.' + output['decision_id'], 'v3_feedback', {'feedback': feedback}, now_utc, mutate)
        return result

    def stop_without_dispatch(self, status, reason, now):
        def mutate(doc):
            state = doc['state']
            if state['active_attempt_ids'] or state['unsettled_call_ids']:
                raise ProtocolError('ACTIVE_ATTEMPT_REQUIRES_ABORT')
            state.update(status='terminal', terminal_status=status)
            doc['pending_decision'] = None
            return {'status': status, 'reason': reason, 'new_dispatch': False}, None
        return self._apply('v3.stop.' + digest({'status': status, 'reason': reason})[:20],
            'v3_stop_no_dispatch', {'status': status, 'reason': reason}, now, mutate, allow_expired=True)

    def abort_http_attempt(self, attempt_id, call, reason, now):
        """Close a failed model call without inventing a CPU execution receipt."""
        def mutate(doc):
            state = doc['state']
            attempt = next(a for a in doc['attempts'] if a['attempt_id'] == attempt_id)
            if attempt['status'] != 'running':
                raise ProtocolError('ATTEMPT_ALREADY_SETTLED')
            self._validate(call)
            if call['attempt_id'] != attempt_id or call['call_id'] != attempt_id + '.call':
                raise ProtocolError('HTTP_IDENTITY_MISMATCH')
            doc['calls'].append(copy.deepcopy(call))
            attempt.update(status='completed', finished_at_utc=now, http_failed=True,
                           cpu_dispatched=False, worker_reaped=True, failure_code=reason)
            state['active_attempt_ids'].remove(attempt_id)
            state['unsettled_call_ids'].remove(call['call_id'])
            if call.get('usage') is None or not call.get('provider_request_id'):
                terminal = 'uncertain'
            elif 'TIMEOUT' in reason or 'DEADLINE' in reason:
                terminal = 'budget_or_time_stopped'
            else:
                terminal = 'tool_failed'
            state.update(status='terminal', terminal_status=terminal)
            return {'call_id': call['call_id'], 'cpu_receipt_invented': False, 'reason': reason}, None
        return self._apply('v3.abort.' + attempt_id, 'v3_abort_http', {'call': call, 'reason': reason}, now,
                           mutate, allow_expired=True)

    def freeze_prefix(self, *args, **kwargs):
        scene = super().freeze_prefix(*args, **kwargs)
        scene['domain'] = self.snapshot()['domain']
        return scene
