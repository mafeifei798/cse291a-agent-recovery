"""V3's explicit, socket-free GLM wire rehearsal.

The request has the future model's exact JSON/low-reasoning contract, while
the only accepted client is a finite fake HTTP client. This module has no
credential provider and cannot enable a live sender. Provider usage in these
fixtures is simulated accounting, never a claim about an account debit.
"""
from __future__ import annotations

import base64
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
from time import monotonic

from agent_recovery.glm53_tokenizer import GLM53LocalTokenCounter
from agent_recovery.p3_deadline import BoundedHTTPSender, WireRecipe
from agent_recovery.p3_transport import (
    HTTPRequest, HTTPResponse, P3HTTPError, fixture_binding, parse_p3_usage,
)
from sr_recovery_v2.common import REV, ProtocolError, canonical, digest

MODEL = "api-glm-5.3-flash"
BASE_URL = "https://tritonai-api.ucsd.edu/v1"
_HEADERS = {"x-litellm-call-id", "x-request-id", "request-id", "content-type"}


def _require(condition, code):
    if not condition:
        raise ProtocolError(code)


def _object(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


def _text():
    return {"type": "string", "minLength": 1}


def schema_for_node(node_id):
    """New macro output contract; V0's synthetic fixture schemas stay intact."""
    metrics = _object({name: {"type": "number", "minimum": 0, "maximum": 1}
                       for name in ("average_precision", "roc_auc", "accuracy", "f1")})
    report = _object({
        "chosen_family": {"enum": ["LR", "RF"]},
        "selected_family": {"enum": ["LR", "RF"]},
        "validation_average_precision": _object({f: {"type": "number", "minimum": 0, "maximum": 1}
                                                  for f in ("LR", "RF")}),
        "metrics": metrics, "model_artifact_id": _text(),
        "prediction_artifact_id": _text(), "validation_row_ids_digest": _text(),
        "report_text": {"type": "string", "minLength": 1, "maxLength": 1024},
    })
    if node_id == "inspect":
        return _object({"status": {"const": "ready"},
                        "fit_preprocessing_on": {"const": "training_rows_only"},
                        "dataset_id": {"enum": ["adult", "bank"]}})
    if node_id in ("plan_lr", "plan_rf"):
        family = node_id[-2:]
        # V2's CPU fitter binds the entire sklearn get_params shape, not only
        # the few parameters printed in the synthetic V0 fixture examples.
        sample = ({"C": 1, "class_weight": None, "dual": False, "fit_intercept": True,
                   "intercept_scaling": 1, "l1_ratio": None, "max_iter": 1000,
                   "multi_class": "auto", "n_jobs": None, "penalty": "l2",
                   "random_state": 291, "solver": "liblinear", "tol": .0001,
                   "verbose": 0, "warm_start": False}
                  if family == "lr" else
                  {"bootstrap": True, "ccp_alpha": 0., "class_weight": None,
                   "criterion": "gini", "max_depth": 8, "max_features": "sqrt",
                   "max_leaf_nodes": None, "max_samples": None,
                   "min_impurity_decrease": 0., "min_samples_leaf": 5,
                   "min_samples_split": 2, "min_weight_fraction_leaf": 0.,
                   "n_estimators": 100, "n_jobs": 1, "oob_score": False,
                   "random_state": 291, "verbose": 0, "warm_start": False})
        kinds = {str: "string", int: "integer", float: "number", bool: "boolean", type(None): "null"}
        props = {key: {"type": kinds[type(value)]} for key, value in sample.items()}
        return _object({"family": {"const": family}, "parameters": _object(props),
                        "matrix_artifact_id": _text()})
    if node_id == "report":
        return report
    if node_id == "publish":
        with_artifact = deepcopy(report)
        with_artifact["properties"]["report_artifact_id"] = _text()
        with_artifact["required"].append("report_artifact_id")
        return _object({"action": {"const": "publish_manifest"}, "report": with_artifact})
    raise ProtocolError("V3_UNKNOWN_MACRO_MODEL_NODE")


def offline_binding(v0_root):
    """Bind historical frozen prices without claiming newly checked prices."""
    spec = json.loads((Path(v0_root) / "budget/model_binding_spec.json").read_text())
    _require(spec["model"] == MODEL and spec["base_url"] == BASE_URL
             and spec["input_nano_usd_per_token"] == 150
             and spec["output_nano_usd_per_token"] == 500
             and spec["automatic_http_retries"] == 0
             and spec["financial_reservation_nano_usd_per_dispatch"] == 1284000
             and spec["request_parameters"]["reasoning_effort"] == "low"
             and spec["total_request_deadline_seconds"] == 120,
             "V3_FROZEN_MODEL_BINDING_CHANGED")
    return {"model": MODEL, "allowed_response_models": deepcopy(spec["allowed_response_models"]),
            "base_url": BASE_URL, "input_nano_usd_per_token": 150,
            "output_nano_usd_per_token": 500, "max_input_tokens": 4000,
            "max_output_tokens": 768, "financial_input_allowance": 6000,
            "financial_reservation_nano_usd_per_dispatch": 1284000,
            "reasoning_effort": "low", "total_request_deadline_seconds": 120,
            "simulated": True, "real_requests_authorized": False,
            "automatic_http_retries": 0, "execution_mode": "offline_fake_http",
            "price_evidence": spec["price_evidence"], "source_spec_digest": digest(spec)}


def _strict_json(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            _require(key not in out, "V3_DUPLICATE_JSON_KEY")
            out[key] = value
        return out
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))


def _validate_schema(schema):
    import jsonschema
    _require(isinstance(schema, dict), "V3_OUTPUT_SCHEMA_REQUIRED")
    pending = [schema]
    while pending:
        item = pending.pop()
        if isinstance(item, dict):
            _require(not ({"$ref", "$dynamicRef", "$recursiveRef"} & set(item)),
                     "V3_SCHEMA_REFERENCE_FORBIDDEN")
            if item.get("type") == "object" or "properties" in item:
                _require(item.get("additionalProperties") is False
                         and set(item.get("required", [])) == set(item.get("properties", {})),
                         "V3_NON_STRICT_OBJECT_SCHEMA")
            pending.extend(item.values())
        elif isinstance(item, list):
            pending.extend(item)
    try:
        jsonschema.Draft202012Validator.check_schema(schema)
    except jsonschema.SchemaError:
        raise ProtocolError("V3_OUTPUT_SCHEMA_INVALID") from None


def build_request(node_id, messages, output_schema, binding):
    _require(isinstance(node_id, str) and node_id
             and isinstance(messages, list) and len(messages) == 2
             and all(isinstance(m, dict) and set(m) == {"role", "content"}
                     and isinstance(m["content"], str) for m in messages),
             "V3_MESSAGE_CONTRACT")
    _require([m["role"] for m in messages] == ["system", "user"], "V3_MESSAGE_CONTRACT")
    _validate_schema(output_schema)
    return {"model": binding["model"], "messages": deepcopy(messages), "n": 1,
            "stream": False, "max_completion_tokens": 768, "reasoning_effort": "low",
            "response_format": {"type": "json_schema", "json_schema": {
                "name": node_id, "strict": True, "schema": deepcopy(output_schema)}}}


def fake_response(payload, *, request_id="fixture-v3-call", model=MODEL,
                  prompt_tokens=100, completion_tokens=50, reasoning_tokens=0,
                  status=200, headers=None, finish_reason="stop", raw=None):
    if raw is None:
        raw = {"id": "fixture-body-" + request_id, "model": model,
               "choices": [{"index": 0, "finish_reason": finish_reason,
                            "message": {"role": "assistant", "content": canonical(payload)}}],
               "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens,
                         "total_tokens": prompt_tokens + completion_tokens,
                         "completion_tokens_details": {"reasoning_tokens": reasoning_tokens}}}
    return HTTPResponse(status, headers if headers is not None else {
        "content-type": "application/json", "x-litellm-call-id": request_id},
        canonical(raw).encode("utf-8"))


class FakeHTTPClient:
    """Finite byte fixtures or an explicit pure fixture builder, never sockets.

    The old P3 process supervisor is reused only in its socket-free recipe mode.
    A body is published only after that worker has exited and been reaped.
    """
    simulated = True
    real_request_count = 0

    def __init__(self, responses=None, *, response_builder=None):
        _require((responses is not None) != (response_builder is not None),
                 "V3_EXPLICIT_FAKE_CLIENT_REQUIRED")
        _require(response_builder is None or callable(response_builder), "V3_FAKE_BUILDER_INVALID")
        _require(responses is None or isinstance(responses, (tuple, list)), "V3_FAKE_RESPONSES_INVALID")
        self._responses = list(responses) if responses is not None else None
        self.response_builder = response_builder
        self.request_count = 0
        self.requests, self.receipts = [], []
        self.fenced = False

    def exchange(self, request, *, deadline_monotonic):
        _require(not self.fenced, "V3_FAKE_WORKER_FENCED")
        if self._responses is not None:
            _require(bool(self._responses), "V3_FAKE_RESPONSES_EXHAUSTED")
            fixture = self._responses.pop(0)
        else:
            fixture = self.response_builder(deepcopy(request))
        _require(type(fixture) in (HTTPResponse, WireRecipe), "V3_FAKE_RESPONSE_TYPE")
        recipe = fixture if type(fixture) is WireRecipe else WireRecipe("response", fixture)
        # Only these fixture recipes are admitted. There is no recipes=None path.
        sender = BoundedHTTPSender(recipes=[recipe], terminate_grace_s=.1, cleanup_timeout_s=1)
        self.requests.append(deepcopy(request))
        self.request_count += 1
        remaining = deadline_monotonic - monotonic()
        wire = HTTPRequest("POST", BASE_URL + "/chat/completions", canonical(request).encode(),
                           max(.000001, min(120., remaining)))
        try:
            return sender.send(wire, binding=fixture_binding(),
                               deadline_monotonic=deadline_monotonic, intent_committed=True)
        finally:
            if sender.last_receipt is not None:
                self.receipts.append(sender.last_receipt)
            self.fenced = sender.fenced


class OfflineV3Gateway:
    def __init__(self, v0_root, *, client, budget, token_counter=None,
                 binding=None, evidence_sink=None):
        _require(type(client) is FakeHTTPClient, "V3_OFFLINE_CLIENT_REQUIRED")
        self.v0_root, self.client, self.budget = Path(v0_root), client, budget
        expected = offline_binding(v0_root)
        self.binding = deepcopy(binding if binding is not None else expected)
        _require(all(self.binding.get(k) == v for k, v in expected.items()), "V3_GATEWAY_BINDING_MISMATCH")
        self.binding_digest = digest(self.binding)
        self.token_counter = token_counter or GLM53LocalTokenCounter.from_directory(
            self.v0_root / "environment/tokenizer_files")
        _require(isinstance(self.token_counter, GLM53LocalTokenCounter), "V3_LOCAL_COUNTER_REQUIRED")
        _require(evidence_sink is None or callable(evidence_sink), "V3_EVIDENCE_SINK_INVALID")
        self.evidence_sink = evidence_sink
        self.records = {}
        self._fingerprints = {}

    def _persist(self, stage, record):
        if self.evidence_sink:
            self.evidence_sink(stage, deepcopy(record))

    def invoke(self, *, call_id, item_id, branch_id, attempt_id, node_id,
               input_snapshot, output_schema, remaining_seconds=120, before_dispatch=None):
        started = monotonic()
        _require(type(remaining_seconds) in (int, float) and math.isfinite(remaining_seconds)
                 and 0 < remaining_seconds <= 120, "V3_TOTAL_DEADLINE_INVALID")
        deadline = started + remaining_seconds
        _require(all(isinstance(v, str) and v for v in (call_id, item_id, branch_id, attempt_id, node_id))
                 and isinstance(input_snapshot, dict)
                 and isinstance(input_snapshot.get("run_id"), str) and input_snapshot["run_id"]
                 and (before_dispatch is None or callable(before_dispatch)), "V3_CALL_IDENTITY_INVALID")
        fingerprint = digest({"call_id": call_id, "item_id": item_id, "branch_id": branch_id,
                              "attempt_id": attempt_id, "node_id": node_id,
                              "input_snapshot": input_snapshot, "output_schema": output_schema})
        if call_id in self.records:
            _require(self._fingerprints[call_id] == fingerprint, "V3_CALL_ID_REUSE_MISMATCH")
            return deepcopy(self.records[call_id])
        messages = input_snapshot.get("rendered_messages")
        request = build_request(node_id, messages, output_schema, self.binding)
        estimate = self.token_counter.estimate_request(request).to_dict()
        _require(estimate["prompt_tokens"] <= 4000, "V3_LOCAL_CONTEXT_CAP")
        _require(monotonic() < deadline, "V3_TOTAL_DEADLINE_EXPIRED_BEFORE_RESERVATION")
        request_digest = digest(request)
        sidecar = {"call_id": call_id, "item_id": item_id, "branch_id": branch_id,
                   "attempt_id": attempt_id, "node_id": node_id, "input_digest": digest(input_snapshot),
                   "request_digest": request_digest, "schema_digest": digest(output_schema),
                   "binding_digest": self.binding_digest, "token_estimate": estimate,
                   "total_deadline_seconds": remaining_seconds, "simulated": True}
        reserve = {"call_id": call_id, "attempt_id": attempt_id, "item_id": item_id,
                   "input_tokens_estimate": estimate["prompt_tokens"], "request": request,
                   "sidecar": sidecar}
        reservation = self.budget.reserve(deepcopy(reserve))
        _require(not (isinstance(reservation, dict) and reservation.get("reservation_replayed")),
                 "V3_EXISTING_CALL_REQUIRES_RECONCILIATION")
        self._fingerprints[call_id] = fingerprint
        raw, payload, usage, response, code, provider_id = None, None, None, None, None, None
        receipt = None
        dispatched = False
        try:
            self._persist("reserved", {**sidecar, "request": request})
            _require(monotonic() < deadline, "V3_TOTAL_DEADLINE_EXPIRED_BEFORE_DISPATCH")
            if before_dispatch is not None:
                before_dispatch()
            _require(monotonic() < deadline, "V3_TOTAL_DEADLINE_EXPIRED_BEFORE_DISPATCH")
            # Durable dispatch is the idempotence fence, before the process starts.
            self.budget.mark_dispatched(call_id)
            dispatched = True
            self._persist("dispatched", sidecar)
            before_receipts = len(self.client.receipts)
            try:
                response = self.client.exchange(request, deadline_monotonic=deadline)
            except Exception as exc:
                code = exc.code if isinstance(exc, (ProtocolError, P3HTTPError)) else "V3_FAKE_CLIENT_ERROR"
            if len(self.client.receipts) > before_receipts:
                receipt = deepcopy(self.client.receipts[-1])
            http = {"call_id": call_id, "simulated": True, "real_request_sent": False,
                    "method": "POST", "url": BASE_URL + "/chat/completions",
                    "request_digest": request_digest, "request_body_b64": base64.b64encode(canonical(request).encode()).decode(),
                    "status": None, "headers": {}, "response_sha256": None,
                    "response_body_b64": None, "gateway_call_id": None,
                    "provider_request_id": None, "request_id": None,
                    "body_response_id": None, "cleanup_receipt": receipt}
            if response is not None:
                _require(type(response.status) is int and 100 <= response.status <= 599
                         and isinstance(response.headers, dict) and isinstance(response.body, bytes),
                         "V3_HTTP_ENVELOPE_INVALID")
                headers = {str(k).lower(): v for k, v in response.headers.items()
                           if str(k).lower() in _HEADERS and isinstance(v, str)}
                def header(name):
                    value = headers.get(name)
                    return value if value and value.strip() and len(value) <= 256 and "\n" not in value and "\r" not in value else None
                gateway_id, upstream = header("x-litellm-call-id"), header("x-request-id") or header("request-id")
                provider_id = gateway_id or upstream
                http.update(status=response.status, headers=headers, gateway_call_id=gateway_id,
                            provider_request_id=upstream, request_id=provider_id,
                            response_sha256=hashlib.sha256(response.body).hexdigest(),
                            response_body_b64=base64.b64encode(response.body).decode())
                try:
                    raw = _strict_json(response.body.decode("utf-8"))
                    _require(isinstance(raw, dict), "V3_HTTP_JSON_OBJECT_REQUIRED")
                    http["body_response_id"] = raw.get("id")
                except Exception:
                    code = "V3_HTTP_JSON_INVALID"
                if isinstance(raw, dict):
                    try:
                        usage = parse_p3_usage(raw)
                    except Exception:
                        code = code or "V3_USAGE_UNKNOWN"
                    if usage is not None and (usage["prompt_tokens"] > 4000 or usage["completion_tokens"] > 768):
                        code = code or "V3_USAGE_LIMIT"
                    if raw.get("model") not in self.binding["allowed_response_models"]:
                        code = code or "V3_RESPONSE_MODEL_MISMATCH"
                    if not isinstance(raw.get("id"), str) or not raw["id"] or provider_id is None:
                        code = code or "V3_RESPONSE_ID_UNKNOWN"
                    if "error" in raw:
                        code = code or "V3_PROVIDER_ERROR"
                    if response.status != 200:
                        code = "V3_HTTP_AUTH" if response.status in (401, 403) else "V3_HTTP_RATE_LIMIT" if response.status == 429 else "V3_HTTP_STATUS_ERROR"
                    if code is None:
                        try:
                            choices = raw["choices"]
                            _require(isinstance(choices, list) and len(choices) == 1
                                     and type(choices[0]["index"]) is int and choices[0]["index"] == 0
                                     and choices[0]["finish_reason"] == "stop"
                                     and choices[0]["message"]["role"] == "assistant"
                                     and choices[0]["message"].get("refusal") in (None, ""), "V3_MODEL_RESPONSE_UNUSABLE")
                            payload = _strict_json(choices[0]["message"]["content"])
                            import jsonschema
                            jsonschema.Draft202012Validator(output_schema).validate(payload)
                        except Exception:
                            payload, code = None, "V3_MODEL_SCHEMA_ERROR"
            if monotonic() >= deadline:
                payload, code = None, "V3_TOTAL_DEADLINE_EXPIRED"
            evidence = {**sidecar, "request": request, "http_evidence": http,
                        "raw_response": raw, "raw_usage": deepcopy(usage["raw"]) if usage else None,
                        "response_model": raw.get("model") if isinstance(raw, dict) else None,
                        "status": "completed" if code is None else "failed", "error_code": code}
            self._persist("response", evidence)
            if usage is not None and provider_id is not None:
                fatal = code if code not in (None, "V3_MODEL_SCHEMA_ERROR") else None
                settled = self.budget.settle(call_id, provider_request_id=provider_id,
                                             raw_usage=usage["raw"], evidence=evidence, failure_reason=fatal)
                if isinstance(settled, dict) and settled.get("status") != "settled":
                    payload, code = None, "V3_SETTLEMENT_NOT_ACCEPTED"
            else:
                self.budget.quarantine(call_id, code or "V3_USAGE_OR_ID_UNKNOWN")
            if hasattr(self.budget, "snapshot") and self.budget.snapshot().get("status") != "active":
                payload, code = None, code or "V3_CAMPAIGN_QUARANTINED"
            call = {"record_type": "CallEvidence", "revision": REV, "fixture_only": True,
                    "call_id": call_id, "run_id": input_snapshot["run_id"],
                    "node_id": node_id, "attempt_id": attempt_id, "mode": "fixture",
                    "status": "completed" if code is None else "failed", "provider_request_id": provider_id,
                    "usage": deepcopy(usage), "cost_nano_usd": 0, "input_digest": digest(input_snapshot),
                    "request_sent": False, "http_status": response.status if response is not None else None,
                    "endpoint": BASE_URL, "model": MODEL,
                    "worker_started": bool(receipt and receipt.get("worker_started")),
                    "evidence_kind": "offline_fake_http_with_process_deadline",
                    "raw_response_payload": deepcopy(payload) if isinstance(payload, dict) else {},
                    "note": "Socket-free HTTP fixture. Usage/cost in the central ledger is simulated; actual API cost is zero."}
            result = {"status": "completed" if code is None else "failed", "error_code": code,
                      "payload": deepcopy(payload) if code is None else None,
                      "call_evidence": call, "http_evidence": http, "request": request,
                      "token_estimate": estimate, "sidecar": sidecar,
                      "duration_seconds": monotonic() - started}
            self.records[call_id] = deepcopy(result)
            self._persist("settled", result)
            return result
        except Exception:
            # An intent/persistence/settlement exception cannot authorize replay.
            self.budget.quarantine(call_id, "V3_GATEWAY_DURABILITY_OR_SETTLEMENT_ERROR" if dispatched else "V3_GATEWAY_PRE_DISPATCH_ABORT")
            raise
