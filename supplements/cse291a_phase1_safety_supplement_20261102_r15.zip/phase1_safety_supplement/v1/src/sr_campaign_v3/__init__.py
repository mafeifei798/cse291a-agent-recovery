"""V3 offline campaign integration; live execution remains separately gated."""
