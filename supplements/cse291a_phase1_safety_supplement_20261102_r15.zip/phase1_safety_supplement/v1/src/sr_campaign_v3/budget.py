"""One durable, exclusive, *simulated* V3 campaign ledger.

No credential or network code lives here.  Cloned workflow databases receive a
reference to this authority, never a balance.  Old cumulative costs are imported
once from the frozen V0 baseline, not summed across overlapping old exports.
"""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3


RESERVATION = 1_284_000
MAX_COST = 1_000_000_000
MAX_CALLS = 640
TERMINAL = {"completed_correct", "validation_rejected", "permission_denied_safe",
            "conflict_safe", "tool_failed", "budget_or_time_stopped", "uncertain",
            "not_run_blocked_prefix"}


class V3BudgetError(ValueError):
    def __init__(self, code, message=None):
        self.code = code
        super().__init__(message or code)


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode()).hexdigest()


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _require(ok, code, message=None):
    if not ok:
        raise V3BudgetError(code, message)


def _int(value):
    return type(value) is int and value >= 0


def _parse_usage(raw):
    _require(isinstance(raw, dict), "MISSING_PROVIDER_USAGE")
    prompt, completion, total = (raw.get(k) for k in
                                  ("prompt_tokens", "completion_tokens", "total_tokens"))
    pd, cd = raw.get("prompt_tokens_details") or {}, raw.get("completion_tokens_details") or {}
    _require(isinstance(pd, dict) and isinstance(cd, dict), "INVALID_PROVIDER_USAGE")
    cached, reasoning = pd.get("cached_tokens", 0), cd.get("reasoning_tokens", 0)
    _require(all(_int(v) for v in (prompt, completion, total, cached, reasoning))
             and total == prompt + completion and cached <= prompt and reasoning <= completion,
             "INVALID_PROVIDER_USAGE")
    return dict(prompt_tokens=prompt, completion_tokens=completion, total_tokens=total,
                cached_input_tokens=cached, reasoning_tokens=reasoning)


class DurableV3Budget:
    """SQLite authority held under an OS lock for its whole open lifetime.

    ``lock_root`` must be shared by every consumer of the same cumulative $1
    budget.  Its durable authority pin also prevents a second database starting
    afresh after the first process exits.  An existing database copied elsewhere
    is rejected because its absolute authority identity is part of its config.
    """
    def __init__(self, path, *, campaign_id, binding, v0_root, lock_root,
                 resume_checkpoint=None):
        self.path = Path(path).resolve()
        self.ref = str(self.path)
        self.lock_root = Path(lock_root).resolve()
        self.v0_root = Path(v0_root).resolve()
        self.connection = None
        self._lock_fd = None
        self._failed = False
        _require(isinstance(campaign_id, str) and bool(campaign_id), "CAMPAIGN_IDENTITY_MISMATCH")
        _require(isinstance(binding, dict), "BINDING_INVALID")
        exact = {"model": "api-glm-5.3-flash", "input_nano_usd_per_token": 150,
                 "base_url": "https://tritonai-api.ucsd.edu/v1",
                 "output_nano_usd_per_token": 500, "max_input_tokens": 4000,
                 "max_output_tokens": 768, "financial_input_allowance": 6000,
                 "financial_reservation_nano_usd_per_dispatch": RESERVATION,
                 "reasoning_effort": "low", "total_request_deadline_seconds": 120,
                 "simulated": True, "real_requests_authorized": False,
                 "automatic_http_retries": 0}
        _require(all(binding.get(k) == v and type(binding.get(k)) is type(v)
                     for k, v in exact.items()), "BINDING_INVALID")
        _require(binding.get("runtime_input_target", 4000) == 4000
                 and binding.get("execution_mode", "offline_fake_http") == "offline_fake_http"
                 and binding.get("cached_input_nano_usd_per_token") is None,
                 "BINDING_INVALID")
        allowed_models = binding.get("allowed_response_models")
        _require(isinstance(allowed_models, list) and allowed_models
                 and all(isinstance(m, str) for m in allowed_models)
                 and set(allowed_models) <= {"api-glm-5.3-flash", "glm-5.3-flash"},
                 "BINDING_INVALID")
        baseline_path = self.v0_root / "budget/historical_baseline.json"
        contract_path = self.v0_root / "budget/budget_contract.json"
        registry_path = self.v0_root / "registry/formal_items.jsonl"
        registry_contract = json.loads((self.v0_root / "registry/registry_contract.json").read_text())
        baseline = json.loads(baseline_path.read_text())
        contract = json.loads(contract_path.read_text())
        registry = [json.loads(line) for line in registry_path.read_text().splitlines() if line.strip()]
        _require(_sha(baseline_path) == contract["baseline_reference"]["sha256"],
                 "HISTORICAL_BASELINE_MISMATCH")
        _require(baseline["physical_calls"] == 1605
                 and baseline["known_cost_nano_usd"] == 90_998_300
                 and baseline["held_cost_nano_usd"] == 984_000
                 and baseline["old_unknown_reservation_released"] is False,
                 "HISTORICAL_BASELINE_MISMATCH")
        _require(contract["maximum_new_physical_calls"] == MAX_CALLS
                 and contract["financial_reservation_nano_usd_per_new_dispatch"] == RESERVATION
                 and contract["maximum_cumulative_cost_nano_usd"] == MAX_COST,
                 "BUDGET_CONTRACT_MISMATCH")
        _require(len(registry) == 52 and len({r["item_id"] for r in registry}) == 52
                 and [r["execution_ordinal"] for r in registry] == list(range(1, 53))
                 and sum(r["limits"]["physical_llm_call_cap"] for r in registry) == 640,
                 "REGISTRY_MISMATCH")
        _require(_sha(registry_path) == registry_contract["formal_registry"]["sha256"],
                 "REGISTRY_MISMATCH")
        self.registry = {r["item_id"]: r for r in registry}
        for domain in ("micro", "macro"):
            rows = [r for r in registry if r["domain"] == domain]
            _require(len(rows) == 26, "REGISTRY_MISMATCH")
            for kind, number, cap in (("control", 2, 10), ("prefix", 6, 5), ("branch", 18, 15)):
                selected = [r for r in rows if r["kind"] == kind]
                _require(len(selected) == number and all(
                    r["limits"]["physical_llm_call_cap"] == cap for r in selected),
                    "REGISTRY_MISMATCH")
        self.baseline = baseline
        self.binding = deepcopy(binding)
        authority = dict(ledger_path=str(self.path), lock_root=str(self.lock_root),
                         baseline_sha256=_sha(baseline_path), execution_mode="offline_fake_http")
        self.config = dict(schema_version="sr-v3-budget-config-v1", campaign_id=campaign_id,
                           authority=authority, binding=deepcopy(binding), binding_digest=_digest(binding),
                           registry_sha256=_sha(registry_path), contract_sha256=_sha(contract_path),
                           runtime_input_target=4000, financial_input_allowance=6000,
                           output_token_cap=768, per_request_reservation_nano_usd=RESERVATION,
                           new_physical_call_cap=640, domain_call_cap=320,
                           domain_kind_call_caps=dict(control=20, prefix=30, branch=270),
                           max_cost_nano_usd=MAX_COST, execution_mode="offline_fake_http")
        self.lock_root.mkdir(parents=True, exist_ok=True)
        lockpath = self.lock_root / ("sr-v3-" + authority["baseline_sha256"] + ".lock")
        self._lock_fd = os.open(lockpath, os.O_CREAT | os.O_RDWR | os.O_CLOEXEC, 0o600)
        try:
            try:
                fcntl.flock(self._lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise V3BudgetError("CAMPAIGN_LOCK_HELD")
            pin_path = self.lock_root / "authority.json"
            pin = {**authority, "campaign_id": campaign_id, "config_digest": _digest(self.config)}
            pin_existed = pin_path.exists()
            if pin_existed:
                _require(json.loads(pin_path.read_text()) == pin, "BUDGET_AUTHORITY_MISMATCH")
                _require(self.path.is_file(), "AUTHORITY_LEDGER_MISSING")
            else:
                fd = os.open(pin_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(fd, "w") as out:
                    out.write(_json(pin) + "\n")
                    out.flush()
                    os.fsync(out.fileno())
                dfd = os.open(self.lock_root, os.O_RDONLY)
                try:
                    os.fsync(dfd)
                finally:
                    os.close(dfd)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.connection = sqlite3.connect(self.path, isolation_level=None, timeout=5)
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("PRAGMA journal_mode=DELETE")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS campaign(singleton INTEGER PRIMARY KEY CHECK(singleton=1),
                    config TEXT NOT NULL, status TEXT NOT NULL, reason TEXT);
                CREATE TABLE IF NOT EXISTS calls(call_id TEXT PRIMARY KEY, attempt_id TEXT UNIQUE NOT NULL,
                    item_id TEXT NOT NULL, body TEXT NOT NULL, request_digest TEXT NOT NULL,
                    settlement_digest TEXT);
                CREATE TABLE IF NOT EXISTS items(item_id TEXT PRIMARY KEY, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL, call_id TEXT, item_id TEXT, at TEXT NOT NULL,
                    body TEXT NOT NULL, event_digest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS receipts(provider_request_id TEXT PRIMARY KEY,
                    call_id TEXT UNIQUE NOT NULL, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS late_receipts(id INTEGER PRIMARY KEY, call_id TEXT NOT NULL,
                    body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS checkpoints(id INTEGER PRIMARY KEY, body TEXT NOT NULL);
            """)
            old = self.connection.execute("SELECT * FROM campaign").fetchone()
            if old:
                _require(old["config"] == _json(self.config), "BUDGET_AUTHORITY_MISMATCH")
                pending = any(c["status"] != "settled" for c in self.calls())
                active_items = any(i["status"] == "in_progress" for i in self.items())
                if pending or active_items:
                    self.quarantine(None, "REOPEN_WITH_UNFINISHED_PROGRESS")
                elif old["status"] != "active":
                    pass  # Read-only inspection of a stopped ledger is safe.
                elif self.calls() or self.items():
                    _require(isinstance(resume_checkpoint, dict), "CHECKPOINT_REQUIRED")
                    latest = self.connection.execute("SELECT body FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
                    _require(latest is not None and json.loads(latest[0]) == resume_checkpoint
                             and self._checkpoint_body() == resume_checkpoint, "CHECKPOINT_MISMATCH")
                    with self._transaction():
                        self._event("reopen", body={"checkpoint_digest": resume_checkpoint["checkpoint_digest"]})
            else:
                _require(not pin_existed, "AUTHORITY_LEDGER_STATE_MISSING")
                with self._transaction():
                    self.connection.execute("INSERT INTO campaign VALUES(1,?,'active',NULL)", (_json(self.config),))
                    self._event("initialize", body={"config": self.config, "baseline": baseline})
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None
        if self._lock_fd is not None:
            fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
            os.close(self._lock_fd)
            self._lock_fd = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    @contextmanager
    def _transaction(self):
        try:
            self.connection.execute("BEGIN IMMEDIATE")
            yield
            self.connection.commit()
        except BaseException as exc:
            if self.connection.in_transaction:
                self.connection.rollback()
            if isinstance(exc, sqlite3.Error):
                self._failed = True
            raise

    def _event(self, kind, *, call_id=None, item_id=None, body=None):
        at = _now()
        content = dict(kind=kind, call_id=call_id, item_id=item_id, at=at, body=deepcopy(body or {}))
        self.connection.execute("INSERT INTO events(kind,call_id,item_id,at,body,event_digest) VALUES(?,?,?,?,?,?)",
            (kind, call_id, item_id, at, _json(content["body"]), _digest(content)))

    def _active(self):
        row = self.connection.execute("SELECT status FROM campaign").fetchone()
        _require(not self._failed and row[0] == "active", "CAMPAIGN_PAUSED")

    def calls(self):
        return [json.loads(r[0]) for r in self.connection.execute("SELECT body FROM calls ORDER BY rowid")]

    def items(self):
        return [json.loads(r[0]) for r in self.connection.execute("SELECT body FROM items ORDER BY rowid")]

    def _call(self, call_id):
        row = self.connection.execute("SELECT * FROM calls WHERE call_id=?", (call_id,)).fetchone()
        _require(row is not None, "UNKNOWN_CALL")
        return row, json.loads(row["body"])

    def _write_call(self, body, settlement_digest=None):
        self.connection.execute("UPDATE calls SET body=?,settlement_digest=COALESCE(?,settlement_digest) WHERE call_id=?",
                                (_json(body), settlement_digest, body["call_id"]))

    def _fence_tx(self, reason):
        self.connection.execute("UPDATE campaign SET status='quarantined',reason=?", (reason,))
        updated = []
        for body in self.calls():
            if body["status"] in ("reserved", "dispatched"):
                body.update(status="uncertain", held_cost_nano_usd=RESERVATION,
                            uncertainty_reason=reason)
                self._write_call(body)
                updated.append(body)
        self._event("quarantine", body={"reason": reason, "calls": updated})

    def _reject(self, code, *, call_id=None, evidence=None):
        with self._transaction():
            self._event("conflict", call_id=call_id, body={"reason": code, "evidence": evidence})
            self._fence_tx(code)
        raise V3BudgetError(code)

    def quarantine(self, call_id, reason):
        _require(isinstance(reason, str) and bool(reason), "MISSING_QUARANTINE_REASON")
        if call_id is not None:
            self._call(call_id)
        with self._transaction():
            self._fence_tx(reason)
        return self.snapshot()

    def check_admission(self, item_id, scope="item"):
        """Read-only envelope check; reserves no money and changes no counters."""
        self._active()
        _require(item_id in self.registry, "REGISTRY_IDENTITY_MISMATCH")
        _require(not any(c["status"] != "settled" for c in self.calls()), "UNKNOWN_SETTLEMENT")
        row = self.registry[item_id]
        if scope == "item":
            ids = [item_id]
        elif scope in ("scene", "pre_prefix"):
            _require(row["scene_id"] is not None, "SCENE_ADMISSION_MISMATCH")
            ids = [r["item_id"] for r in self.registry.values() if r["scene_id"] == row["scene_id"]
                   and (r["kind"] == "branch" or scope == "pre_prefix")]
        else:
            raise V3BudgetError("SCENE_ADMISSION_MISMATCH")
        calls = self.calls()
        # Admission is for unstarted slots, never for replacement trials.
        _require(not any(i["item_id"] in ids for i in self.items()), "ITEM_ALREADY_STARTED")
        required = sum(self.registry[i]["limits"]["physical_llm_call_cap"] for i in ids)
        current = self.snapshot()
        _require(len(calls) + required <= MAX_CALLS, "CALL_CAP_EXCEEDED")
        domain = row["domain"]
        _require(sum(c["domain"] == domain for c in calls) + required <= 320, "DOMAIN_CALL_CAP_EXCEEDED")
        _require(current["cumulative_budget"]["known_plus_held_nano_usd"] + required * RESERVATION <= MAX_COST,
                 "MONEY_CAP_EXCEEDED")
        return dict(item_id=item_id, scope=scope, checked_item_ids=ids,
                    required_call_capacity=required, checked_cost_nano_usd=required * RESERVATION,
                    additional_hold_created=False, passed=True)

    def reserve(self, record):
        _require(isinstance(record, dict), "CALL_RECORD_INVALID")
        required = ("call_id", "attempt_id", "item_id", "input_tokens_estimate", "request", "sidecar")
        _require(all(k in record for k in required), "CALL_RECORD_INVALID")
        _require(all(isinstance(record[k], str) and record[k] for k in required[:3]), "CALL_RECORD_INVALID")
        _require(record["item_id"] in self.registry, "REGISTRY_IDENTITY_MISMATCH")
        _require(type(record["input_tokens_estimate"]) is int and 0 < record["input_tokens_estimate"] <= 4000,
                 "RUNTIME_INPUT_TARGET_EXCEEDED")
        _require(isinstance(record["request"], dict) and isinstance(record["sidecar"], dict), "CALL_RECORD_INVALID")
        owned = {"domain", "kind", "status", "dispatched", "known_cost_nano_usd", "held_cost_nano_usd",
                 "reserved_cost_nano_usd", "usage", "raw_usage", "provider_request_id", "evidence"}
        _require(not (owned & set(record)), "LEDGER_OWNED_FIELD")
        fingerprint = _digest(record)
        call_id, item_id = record["call_id"], record["item_id"]
        old = self.connection.execute("SELECT * FROM calls WHERE call_id=?", (call_id,)).fetchone()
        if old:
            if old["request_digest"] != fingerprint:
                self._reject("IDEMPOTENCY_MISMATCH", call_id=call_id, evidence=record)
            return {**json.loads(old["body"]), "reservation_replayed": True}
        self._active()
        if (record["sidecar"].get("binding_digest", self.config["binding_digest"]) != self.config["binding_digest"]
                or record["request"].get("model", self.binding["model"]) != self.binding["model"]):
            self._reject("PRICE_OR_MODEL_BINDING_MISMATCH", call_id=call_id, evidence=record)
        calls, row = self.calls(), self.registry[item_id]
        if any(c["status"] != "settled" for c in calls):
            self._reject("UNKNOWN_SETTLEMENT")
        tests = [(len(calls) < 640, "CALL_CAP_EXCEEDED"),
                 (sum(c["domain"] == row["domain"] for c in calls) < 320, "DOMAIN_CALL_CAP_EXCEEDED"),
                 (sum(c["domain"] == row["domain"] and c["kind"] == row["kind"] for c in calls)
                  < self.config["domain_kind_call_caps"][row["kind"]], "KIND_CALL_CAP_EXCEEDED"),
                 (sum(c["item_id"] == item_id for c in calls) < row["limits"]["physical_llm_call_cap"],
                  "ITEM_CALL_CAP_EXCEEDED"),
                 (self.snapshot()["cumulative_budget"]["known_plus_held_nano_usd"] + RESERVATION <= MAX_COST,
                  "MONEY_CAP_EXCEEDED")]
        for ok, code in tests:
            if not ok:
                self._reject(code)
        existing_item = next((i for i in self.items() if i["item_id"] == item_id), None)
        if existing_item and existing_item["status"] != "in_progress":
            self._reject("FINALIZED_ITEM_REENTRY", evidence={"item_id": item_id})
        if self.connection.execute("SELECT 1 FROM calls WHERE attempt_id=?", (record["attempt_id"],)).fetchone():
            self._reject("ATTEMPT_ALREADY_HAS_PHYSICAL_CALL", call_id=call_id, evidence=record)
        body = {**deepcopy(record), "domain": row["domain"], "kind": row["kind"], "status": "reserved",
                "dispatched": False, "input_tokens_reserved": 6000, "output_tokens_reserved": 768,
                "reserved_cost_nano_usd": RESERVATION, "known_cost_nano_usd": 0,
                "held_cost_nano_usd": RESERVATION, "usage": None, "raw_usage": None,
                "provider_request_id": None, "reserved_at": _now(), "dispatched_at": None,
                "settled_at": None, "uncertainty_reason": None, "evidence": None,
                "late_known_exposure_nano_usd": 0}
        with self._transaction():
            self._active()
            self.connection.execute("INSERT INTO calls VALUES(?,?,?,?,?,NULL)",
                (call_id, record["attempt_id"], item_id, _json(body), fingerprint))
            if not existing_item:
                item = dict(item_id=item_id, status="in_progress", evidence_digest=None, started_at=_now())
                self.connection.execute("INSERT INTO items VALUES(?,?)", (item_id, _json(item)))
            self._event("reserve", call_id=call_id, item_id=item_id, body=body)
        return {**deepcopy(body), "reservation_replayed": False}

    def mark_dispatched(self, call_id):
        self._active()
        _, body = self._call(call_id)
        if body["status"] != "reserved" or body["dispatched"]:
            self._reject("CALL_ALREADY_DISPATCHED", call_id=call_id)
        body.update(status="dispatched", dispatched=True, dispatched_at=_now())
        with self._transaction():
            self._active()
            self._write_call(body)
            self._event("dispatch", call_id=call_id, item_id=body["item_id"], body=body)
        return deepcopy(body)

    def settle(self, call_id, *, provider_request_id, raw_usage, evidence=None, failure_reason=None):
        _require(evidence is None or isinstance(evidence, dict), "CALL_EVIDENCE_INVALID")
        row, body = self._call(call_id)
        receipt = dict(provider_request_id=provider_request_id, raw_usage=deepcopy(raw_usage),
                       evidence=deepcopy(evidence), failure_reason=failure_reason)
        fingerprint = _digest(receipt)
        if row["settlement_digest"]:
            if row["settlement_digest"] != fingerprint:
                self._reject("CONFLICTING_PROVIDER_RECEIPT", call_id=call_id, evidence=receipt)
            return deepcopy(body)
        _require(body["dispatched"], "RECEIPT_BEFORE_DISPATCH")
        state = self.connection.execute("SELECT status FROM campaign").fetchone()[0]
        if state != "active" or body["status"] != "dispatched":
            late = {**receipt, "parsed_usage": None, "exact_cost_nano_usd": None,
                    "manual_reconciliation_required": True}
            try:
                late_usage = _parse_usage(raw_usage)
            except V3BudgetError:
                pass
            else:
                late_cost = late_usage["prompt_tokens"] * 150 + late_usage["completion_tokens"] * 500
                late.update(parsed_usage=late_usage, exact_cost_nano_usd=late_cost)
                body["late_known_exposure_nano_usd"] = max(body.get("late_known_exposure_nano_usd", 0), late_cost)
            with self._transaction():
                self._write_call(body)
                self.connection.execute("INSERT INTO late_receipts(call_id,body) VALUES(?,?)", (call_id, _json(late)))
                self._event("late_receipt", call_id=call_id, item_id=body["item_id"], body=late)
                self._fence_tx("LATE_PROVIDER_RECEIPT")
            return deepcopy(body)
        reason = None
        try:
            usage = _parse_usage(raw_usage)
            _require(isinstance(provider_request_id, str) and provider_request_id, "MISSING_PROVIDER_RECEIPT")
            duplicate = self.connection.execute("SELECT call_id FROM receipts WHERE provider_request_id=?",
                                                 (provider_request_id,)).fetchone()
            _require(duplicate is None, "CONFLICTING_PROVIDER_RECEIPT")
        except V3BudgetError as exc:
            with self._transaction():
                # Raw failure evidence survives even when no amount is trusted.
                body.update(raw_usage=deepcopy(raw_usage), provider_request_id=provider_request_id,
                            evidence=deepcopy(evidence))
                self._write_call(body)
                self._event("invalid_receipt", call_id=call_id, item_id=body["item_id"], body=receipt)
                self._fence_tx(exc.code)
            return self._call(call_id)[1]
        cost = usage["prompt_tokens"] * 150 + usage["completion_tokens"] * 500
        if usage["prompt_tokens"] > 4000 or usage["completion_tokens"] > 768:
            reason = "ACTUAL_TOKEN_CAP_EXCEEDED"
        if cost > RESERVATION:
            reason = "ACTUAL_COST_EXCEEDS_RESERVATION"
        if evidence and evidence.get("response_model") is not None and evidence["response_model"] not in self.binding["allowed_response_models"]:
            reason = "RESPONSE_MODEL_MISMATCH"
        if evidence and evidence.get("binding_digest") is not None and evidence["binding_digest"] != self.config["binding_digest"]:
            reason = "PRICE_OR_MODEL_BINDING_MISMATCH"
        if failure_reason:
            _require(isinstance(failure_reason, str), "CALL_EVIDENCE_INVALID")
            reason = failure_reason
        body.update(status="settled", raw_usage=deepcopy(raw_usage), usage=usage,
                    provider_request_id=provider_request_id, known_cost_nano_usd=cost,
                    held_cost_nano_usd=0, settled_at=_now(), evidence=deepcopy(evidence),
                    failure_reason=failure_reason)
        with self._transaction():
            self._write_call(body, fingerprint)
            self.connection.execute("INSERT INTO receipts VALUES(?,?,?)", (provider_request_id, call_id, _json(receipt)))
            self._event("settle", call_id=call_id, item_id=body["item_id"], body=body)
            if reason:
                self._fence_tx(reason)
        return deepcopy(body)

    def finalize_item(self, item_id, status, evidence_digest):
        _require(item_id in self.registry and status in TERMINAL, "ITEM_FINALIZATION_INVALID")
        _require(isinstance(evidence_digest, str) and len(evidence_digest) == 64
                 and all(c in "0123456789abcdef" for c in evidence_digest), "ITEM_FINALIZATION_INVALID")
        _require(not any(c["item_id"] == item_id and c["status"] != "settled" for c in self.calls()),
                 "UNKNOWN_SETTLEMENT")
        old = next((i for i in self.items() if i["item_id"] == item_id), None)
        if old and old["status"] != "in_progress":
            _require(old["status"] == status and old["evidence_digest"] == evidence_digest,
                     "ITEM_FINALIZATION_CONFLICT")
            return old
        body = dict(item_id=item_id, status=status, evidence_digest=evidence_digest,
                    started_at=old["started_at"] if old else None, finalized_at=_now())
        with self._transaction():
            self.connection.execute("INSERT OR REPLACE INTO items VALUES(?,?)", (item_id, _json(body)))
            self._event("finalize_item", item_id=item_id, body=body)
        return deepcopy(body)

    def _checkpoint_body(self):
        self._active()
        calls, items = self.calls(), self.items()
        _require(all(c["status"] == "settled" for c in calls)
                 and all(i["status"] in TERMINAL for i in items), "CHECKPOINT_UNFINISHED_PROGRESS")
        completed = {i["item_id"] for i in items}
        _require(completed == set(list(self.registry)[:len(completed)]), "CHECKPOINT_NOT_REGISTRY_PREFIX")
        body = dict(schema_version="sr-v3-budget-checkpoint-v1", campaign_id=self.config["campaign_id"],
                    authority=deepcopy(self.config["authority"]), config_digest=_digest(self.config),
                    calls_digest=_digest(calls), items_digest=_digest(items),
                    completed_item_ids=list(self.registry)[:len(completed)],
                    all_calls_settled=True, no_active_items=True)
        body["checkpoint_digest"] = _digest(body)
        return body

    def make_checkpoint(self):
        body = self._checkpoint_body()
        with self._transaction():
            self.connection.execute("INSERT INTO checkpoints(body) VALUES(?)", (_json(body),))
            self._event("checkpoint", body=body)
        return body

    def snapshot(self):
        row = self.connection.execute("SELECT status,reason FROM campaign").fetchone()
        calls, items = self.calls(), self.items()
        known = sum(c["known_cost_nano_usd"] for c in calls)
        held = sum(c["held_cost_nano_usd"] for c in calls)
        dispatched = sum(c["dispatched"] for c in calls)
        cumulative_known = self.baseline["known_cost_nano_usd"] + known
        cumulative_held = self.baseline["held_cost_nano_usd"] + held
        exposure_adjustment = sum(max(0, c.get("late_known_exposure_nano_usd", 0)
                                      - c["known_cost_nano_usd"] - c["held_cost_nano_usd"])
                                  for c in calls)
        risk_adjusted = cumulative_known + cumulative_held + exposure_adjustment
        events = []
        for r in self.connection.execute("SELECT * FROM events ORDER BY seq"):
            events.append({**dict(r), "body": json.loads(r["body"])})
        return dict(schema_version="sr-v3-budget-snapshot-v1", execution_mode="offline_fake_http",
                    campaign_budget_ref=self.ref, campaign_id=self.config["campaign_id"],
                    authority=deepcopy(self.config["authority"]), config=deepcopy(self.config),
                    baseline=deepcopy(self.baseline), registry=deepcopy(list(self.registry.values())),
                    status=row["status"], pause_reason=row["reason"], calls=calls, items=items, events=events,
                    late_receipts=[dict(call_id=r[0], receipt=json.loads(r[1])) for r in self.connection.execute(
                        "SELECT call_id,body FROM late_receipts ORDER BY id")],
                    budget=dict(calls_reserved_or_spent=len(calls), calls_dispatched=dispatched,
                        calls_remaining=max(0, 640-len(calls)), known_cost_nano_usd=known,
                        held_cost_nano_usd=held, domain_counts={d: sum(c["domain"] == d for c in calls)
                            for d in ("micro", "macro")},
                        kind_counts={d: {k: sum(c["domain"] == d and c["kind"] == k for c in calls)
                            for k in ("control", "prefix", "branch")} for d in ("micro", "macro")},
                        item_counts={i: sum(c["item_id"] == i for c in calls) for i in self.registry}),
                    cumulative_budget=dict(baseline_calls=1605, baseline_known_cost_nano_usd=90_998_300,
                        baseline_held_cost_nano_usd=984_000, cumulative_calls=1605+dispatched,
                        known_cost_nano_usd=cumulative_known, held_cost_nano_usd=cumulative_held,
                        known_plus_held_nano_usd=cumulative_known+cumulative_held,
                        unsettled_exposure_adjustment_nano_usd=exposure_adjustment,
                        risk_adjusted_known_plus_held_nano_usd=risk_adjusted,
                        risk_adjusted_overrun=risk_adjusted > MAX_COST,
                        max_cost_nano_usd=MAX_COST,
                        remaining_after_known_and_held_nano_usd=max(0, MAX_COST-cumulative_known-cumulative_held),
                        old_unknown_reservation_released=False,
                        basis="simulation of provider usage times pinned catalog; account debit unverified"),
                    simulated=True, real_api_requests=0, real_incremental_cost_nano_usd=0)
