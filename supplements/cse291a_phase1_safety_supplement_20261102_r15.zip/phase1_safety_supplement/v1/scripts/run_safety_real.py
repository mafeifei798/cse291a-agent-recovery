"""CLI for the independent safety API campaign (no work on import)."""
from safety_real.launch import main

if __name__=="__main__":
    raise SystemExit(main())
