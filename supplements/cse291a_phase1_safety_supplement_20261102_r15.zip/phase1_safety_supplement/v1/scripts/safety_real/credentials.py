"""Bounded anonymous-pipe handoff; no environment or credential file lookup."""


def pipe_bytes(value):
    if (type(value) is not str or not 0<len(value)<=4096
            or not all(33<=ord(char)<=126 for char in value)):
        raise PermissionError("CREDENTIAL_PIPE_INVALID")
    return value.encode("ascii")


def consume_parent_pipe(stream):
    data=stream.read(4097)
    try:value=data.decode("ascii")
    except (UnicodeError,AttributeError):
        raise PermissionError("CREDENTIAL_PIPE_INVALID") from None
    pipe_bytes(value)
    return value
