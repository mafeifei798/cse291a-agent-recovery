"""One durable authority across nine small P3 ledgers; unknown blocks stay held."""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
import fcntl
import os
from pathlib import Path
import sqlite3
import time

from .protocol import LIMITS, canonical, digest, read, sha, write


@contextmanager
def campaign_lock(output):
    path = Path(output)/"campaign.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+") as stream:
        try: fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError("CAMPAIGN_ALREADY_RUNNING") from None
        stream.seek(0);stream.truncate();stream.write(canonical(dict(pid=os.getpid())));stream.flush()
        try: yield
        finally: fcntl.flock(stream, fcntl.LOCK_UN)


def admit_worker(output,frozen,batch_id):
    """Internal CLI cannot skip the parent's durable reservation or lock."""
    import json
    output=Path(output)
    if not (output/"authority.sqlite").is_file() or not (output/"campaign.lock").is_file():
        raise PermissionError("WORKER_REQUIRES_PARENT_RESERVATION")
    owner=read(output/"campaign.lock")
    if owner["pid"]!=os.getppid():raise PermissionError("WORKER_REQUIRES_OWNED_PARENT")
    with (output/"campaign.lock").open("r+") as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:pass
        else:
            fcntl.flock(lock,fcntl.LOCK_UN)
            raise PermissionError("WORKER_REQUIRES_ACTIVE_PARENT_LOCK")
    with sqlite3.connect((output/"authority.sqlite").resolve().as_uri()+"?mode=ro&immutable=1",uri=True) as con:
        config=json.loads(con.execute("SELECT body FROM config").fetchone()[0])
        batches=[json.loads(r[0]) for r in con.execute("SELECT body FROM batches ORDER BY rowid")]
        if config!=frozen or con.execute("SELECT 1 FROM stop").fetchone():raise PermissionError("WORKER_AUTHORITY_FENCED")
        pending=[b for b in batches if b["status"]!="completed"]
        if len(pending)!=1 or pending[0]["batch_id"]!=batch_id or pending[0]["status"]!="reserved":
            raise PermissionError("WORKER_BATCH_NOT_RESERVED")
        batch=next(b for b in frozen["registration"]["batches"] if b["batch_id"]==batch_id)
        if pending[0]["block_nano"]!=batch["worst_reservation_nano"]:raise PermissionError("WORKER_BLOCK_CHANGED")
        if frozen["registration"]["batches"][len(batches)-1]!=batch:raise PermissionError("WORKER_BATCH_ORDER")
    return True


class Authority:
    def __init__(self, output, frozen):
        self.output, self.frozen = Path(output), frozen
        self.output.mkdir(parents=True,exist_ok=True)
        self.path = self.output/"authority.sqlite"
        self.con = sqlite3.connect(self.path)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA journal_mode=DELETE")
        self.con.execute("PRAGMA synchronous=FULL")
        self.con.executescript("""
            CREATE TABLE IF NOT EXISTS config(singleton INTEGER PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS batches(batch_id TEXT PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS checkpoints(seq INTEGER PRIMARY KEY, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS stop(singleton INTEGER PRIMARY KEY, reason TEXT NOT NULL);
        """)
        old = self.con.execute("SELECT body FROM config").fetchone()
        import json
        if old and json.loads(old[0]) != frozen: raise RuntimeError("AUTHORITY_CONFIG_CHANGED")
        if not old:
            self.con.execute("INSERT INTO config VALUES(1,?)", (canonical(frozen),))
            self.con.commit()

    def close(self): self.con.close()

    def snapshot(self):
        import json
        batches = [json.loads(r[0]) for r in self.con.execute("SELECT body FROM batches ORDER BY rowid")]
        checks = [json.loads(r[0]) for r in self.con.execute("SELECT body FROM checkpoints ORDER BY seq")]
        stop = self.con.execute("SELECT reason FROM stop").fetchone()
        known = sum(b.get("known_nano", 0) for b in batches)
        held = sum(b.get("held_nano", b["block_nano"]) for b in batches)
        return dict(frozen_digest=digest(self.frozen), mode=self.frozen["mode"],
            status="hard_stopped" if stop else "completed" if len(checks)==9 else "ready",
            stop_reason=stop[0] if stop else None, batches=batches, checkpoints=checks,
            completed_batches=len(checks), study_known_nano=known, study_held_nano=held,
            study_total_nano=known+held,
            historical_known_nano=self.frozen["history"]["known_nano"],
            historical_held_nano=self.frozen["history"]["held_nano"],
            project_total_nano=self.frozen["history"]["total_nano"]+known+held,
            limits=LIMITS, provider_account_debit_verified=False,
            fake_usage_is_projected_not_real_spending=self.frozen["mode"]=="fake-http")

    def halt(self, reason):
        self.con.execute("INSERT OR IGNORE INTO stop VALUES(1,?)", (str(reason),))
        self.con.commit()

    def reserve_batch(self, batch):
        self.con.execute("BEGIN IMMEDIATE")
        try:
            s = self.snapshot()
            if s["status"] == "hard_stopped": raise RuntimeError("CAMPAIGN_HARD_STOPPED")
            if any(b["status"] != "completed" for b in s["batches"]):
                raise RuntimeError("PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
            expected = self.frozen["registration"]["batches"][len(s["checkpoints"])]
            if batch != expected: raise RuntimeError("BATCH_ORDER_OR_DUPLICATE")
            block = batch["worst_reservation_nano"]
            limits = self.frozen["registration"]["limits"]
            for ok, code in (
                (block <= limits["batch_nano"], "BATCH_BUDGET_CAP"),
                (s["study_total_nano"]+block <= limits["study_nano"], "STUDY_BUDGET_CAP"),
                (s["project_total_nano"]+block <= limits["project_nano"], "PROJECT_BUDGET_CAP")):
                if not ok: raise RuntimeError(code)
            record = dict(batch_id=batch["batch_id"], status="reserved", block_nano=block,
                held_nano=block, known_nano=0, reserved_unix=time.time(),
                predecessor_digest=digest(s["checkpoints"][-1]) if s["checkpoints"] else digest(self.frozen["history"]),
                input_project_total_nano=s["project_total_nano"], input_study_total_nano=s["study_total_nano"])
            self.con.execute("INSERT INTO batches VALUES(?,?)", (batch["batch_id"], canonical(record)))
            self.con.commit()
            return record
        except BaseException:
            self.con.rollback()
            raise

    def finalize(self, batch, checked, ledger_path):
        """Replace the block once, after independent reconciliation, including stops."""
        import json
        self.con.execute("BEGIN IMMEDIATE")
        try:
            old = self.con.execute("SELECT body FROM batches WHERE batch_id=?", (batch["batch_id"],)).fetchone()
            if old is None: raise RuntimeError("UNRESERVED_BATCH")
            record = json.loads(old[0])
            if record["status"] != "reserved": raise RuntimeError("FINALIZE_ALREADY_DONE")
            if not checked["passed"]: raise RuntimeError("INDEPENDENT_CHECK_FAILED")
            if checked["known_nano"]+checked["held_nano"] > record["block_nano"]:
                raise RuntimeError("BLOCK_OVERRUN")
            halt = checked.get("hard_stop_reason")
            record.update(status="halted" if halt else "completed", known_nano=checked["known_nano"],
                held_nano=checked["held_nano"], ledger_sha256=sha(ledger_path),
                check_digest=digest(checked), completed_slots=checked["slot_ids"],
                call_ids=checked["call_ids"], finished_unix=time.time())
            self.con.execute("UPDATE batches SET body=? WHERE batch_id=?", (canonical(record), batch["batch_id"]))
            if halt:
                self.con.execute("INSERT OR IGNORE INTO stop VALUES(1,?)", (halt,))
            else:
                s = self.snapshot()
                checkpoint = dict(batch_id=batch["batch_id"], ordinal=len(s["checkpoints"])+1,
                    predecessor_digest=record["predecessor_digest"], batch_record_digest=digest(record),
                    completed_slots=[sid for b in s["batches"] for sid in b["completed_slots"]],
                    calls=[cid for b in s["batches"] for cid in b["call_ids"]],
                    known_nano=s["study_known_nano"], held_nano=s["study_held_nano"],
                    project_total_nano=s["project_total_nano"])
                if len(checkpoint["calls"]) != len(set(checkpoint["calls"])):
                    raise RuntimeError("PHYSICAL_CALL_REUSE_ACROSS_BATCHES")
                self.con.execute("INSERT INTO checkpoints VALUES(?,?)", (checkpoint["ordinal"], canonical(checkpoint)))
            self.con.commit()
        except BaseException:
            self.con.rollback()
            raise


def quality_stop(checks, completed_batch):
    """Result-driven gates; a model failure is never silently replaced."""
    if completed_batch == "B01":
        clean = [r for r in checks if r["scenario"] == "S01" and r["repeat"] == 1]
        if len(clean)==4 and not any(r["valid_completion"] for r in clean): return "NO_CLEAN_COMPLETION"
    if completed_batch == "B03":
        for scene in ("S03", "S04", "S05", "S06", "S07", "S08"):
            group = [r for r in checks if r["scenario"]==scene and r["repeat"]==1]
            if len(group)!=4 or not any(r["effective_target_reach"] for r in group):
                return "NO_EFFECTIVE_REACH:"+scene
    return None


def stop_from_run(check, campaign, cleanup=()):
    if not check["passed"]: return "INDEPENDENT_CHECK_FAILED"
    if check.get("partial_write"): return "PARTIAL_WRITE"
    if check.get("guard_enabled") and check["unauthorized_commits"]: return "GUARDED_UNSAFE_WRITE"
    if check.get("commit_unknown"): return "UNKNOWN_COMMIT_OUTCOME"
    if any(not r.get("reaped", False) or r.get("cleanup_failed") for r in cleanup): return "UNREAPED_HTTP_WORKER"
    if campaign["status"] != "active": return campaign["pause_reason"] or "LEDGER_PAUSED"
    for code in check.get("model_error_codes", []):
        if code not in ("MODEL_ERROR", "MODEL_SCHEMA_ERROR"): return code
    if check.get("memory_limit_exceeded"): return "RSS_LIMIT"
    if check.get("wall_limit_exceeded"): return "WALL_LIMIT"
    return None
