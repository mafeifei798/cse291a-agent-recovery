"""Unchanged five-step workflow, real-response delivery hook, serial batches."""
from __future__ import annotations

from copy import deepcopy
import json
import os
from pathlib import Path
import resource
import sys
import threading
import time

from .protocol import ROOT, LIMITS, STEPS, canonical, digest, read, write, sha


def install_offline_fence(output):
    root = Path(output).resolve()
    state = dict(installed=True, sockets_allowed=False, credential_provider_installed=False, blocked=[])

    def audit(event, args):
        block = event.startswith("socket.") or event in {"os.system", "subprocess.Popen", "os.fork", "os.posix_spawn"}
        if event=="open" and args and isinstance(args[0], (str, bytes)):
            p = Path(os.fsdecode(args[0])).resolve()
            block |= p.name.startswith(".env") or p.name in {"credentials", "credentials.json"} or any(
                name in p.parts for name in (".ssh", ".aws"))
            mode, flags = args[1:3]
            writing = (isinstance(mode, str) and any(x in mode for x in "wax+")) or (
                isinstance(flags, int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing and p!=root and root not in p.parents: block = True
        if event=="sqlite3.connect" and args and isinstance(args[0], str) and not args[0].startswith("file:"):
            p = Path(args[0]).resolve()
            if p!=root and root not in p.parents: block = True
        if block:
            state["blocked"].append(event)
            raise PermissionError("SAFETY_OFFLINE_FENCE")
    sys.addaudithook(audit)
    return state


class Journal:
    def __init__(self, path):
        self.rows, self.began = [], time.monotonic()
        self.stream = Path(path).open("x")

    def add(self, phase, store=None, **data):
        row = dict(seq=len(self.rows)+1, phase=phase, elapsed_s=time.monotonic()-self.began, **deepcopy(data))
        if store: row["db_seq"] = store.connection.execute("SELECT event_seq FROM runs").fetchone()[0]
        self.rows.append(row)
        self.stream.write(canonical(row)+"\n")
        self.stream.flush()

    def close(self): self.stream.close()


def normal_payload(request):
    supplied = json.loads(request["messages"][1]["content"])
    step, bundle = supplied["step_id"], supplied["input"]
    if step.startswith("read_"): return deepcopy(bundle["tool_snapshots"][0]["payload"])
    if step=="plan":
        m, p, r = [v["payload"] for v in bundle["parents"]]
        req = bundle["request"]
        return dict(dataset_id=req["dataset_id"], purpose=req["purpose"], batch_size=req["batch_size"],
            epochs=req["epochs"], num_examples=m["num_examples"],
            steps=((m["num_examples"]+req["batch_size"]-1)//req["batch_size"])*req["epochs"],
            workers=min(req["requested_workers"], r["max_workers"]), permission_allowed=p["allowed"])
    return dict(action="save_job", arguments=deepcopy(bundle["parents"][0]["payload"]))


def fake_sender(binding, fault=None):
    """Provider-like raw bytes; controlled study injections happen AFTER this."""
    from agent_recovery.contracts import new_id
    from agent_recovery.p3_transport import FakeHTTPSender, fake_http_response, HTTPResponse
    namespace, seen = new_id(), []

    def respond(wire):
        req = json.loads(wire.body)
        supplied = json.loads(req["messages"][1]["content"])
        step = supplied["step_id"]
        payload = normal_payload(req)
        seen.append(dict(step_id=step, request=req, supplied=supplied, normal_output=deepcopy(payload)))
        selected = fault and fault.get("step", "read_metadata")==step
        kind = fault.get("kind") if selected else None
        if kind=="timeout": raise TimeoutError("fake transport deadline")
        if kind=="already_incorrect": payload[fault["field"]] = fault["value"]
        if kind=="natural_business_error": payload["num_examples"] += 1
        response = fake_http_response(payload, model=binding.model, request_id=f"fake-sr-{namespace}-{len(seen)}",
            prompt_tokens=111+len(seen), completion_tokens=57+len(seen))
        raw = json.loads(response.body)
        if kind in ("auth401", "auth403", "rate429", "quota"):
            status = {"auth401":401, "auth403":403, "rate429":429, "quota":400}[kind]
            return HTTPResponse(status, response.headers, canonical(dict(error=dict(
                message="fake quota exceeded" if kind=="quota" else "fake HTTP rejection", type=kind))).encode())
        if kind=="missing_usage": raw.pop("usage")
        if kind=="usage_overflow":
            raw["usage"]["prompt_tokens"] = 5000
            raw["usage"]["total_tokens"] = 5000+raw["usage"]["completion_tokens"]
        if kind=="model_mismatch": raw["model"] = "fixture-unexpected-model"
        if kind=="schema_error": raw["choices"][0]["message"]["content"] = "not json"
        if kind=="refusal": raw["choices"][0]["message"]["refusal"] = "fixture refusal"
        if kind=="truncated": raw["choices"][0]["finish_reason"] = "length"
        if kind=="late_result":
            # Gateway uses the same monotonic deadline; shortened only in this diagnostic.
            time.sleep(fault.get("delay_s", 0.025))
        return HTTPResponse(response.status, response.headers, canonical(raw).encode())

    return FakeHTTPSender([respond]*5), seen


def run_flow(dest, spec, binding, budget, *, credential_provider=None, permit=None, fault=None):
    from agent_recovery.business_guard import BusinessGuardMixin
    from agent_recovery.contracts import PARENTS, new_id, validate_task
    from agent_recovery.p1_delivery import P1DeliveryHooks, VerificationStopped
    from agent_recovery.p3_gateway import P3Store, P3ModelGateway
    from agent_recovery.p3_transport import P3HTTPClient, BoundTokenCounter
    from agent_recovery.p3_deadline import BoundedHTTPSender
    from agent_recovery.workflow import Workflow
    if not binding.simulated and fault is not None:
        raise PermissionError("FAKE_DIAGNOSTICS_CANNOT_MODIFY_LIVE_TRANSPORT")
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=False)
    validate_task(spec["task"])
    write(dest/"slot.json", spec)
    journal, proposals = Journal(dest/"journal.jsonl"), []
    sampler_done = threading.Event()
    began = time.monotonic()

    def sample():
        with (dest/"rss_samples.jsonl").open("x") as stream:
            while True:
                raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
                peak = int(raw if sys.platform=="darwin" else raw*1024)
                stream.write(canonical(dict(elapsed_s=time.monotonic()-began, peak_rss_bytes=peak))+"\n")
                stream.flush()
                if peak > LIMITS["rss_bytes"]: os._exit(137)
                if sampler_done.wait(0.05): break
    sampler = threading.Thread(target=sample, daemon=True)
    sampler.start()
    if binding.simulated:
        sender, fixtures = fake_sender(binding, fault)
        counter = None
    else:
        sender, fixtures = BoundedHTTPSender(), []
        counter = BoundTokenCounter(binding.token_admission_evidence, lambda _:4000)
    client = P3HTTPClient(binding, sender, token_counter=counter,
                          credential_provider=credential_provider, runtime_permit=permit)
    gateway = P3ModelGateway(client, budget, trial_key=spec["slot_id"], branch_id=new_id(), token_counter=counter)
    public = dict(task_id=spec["task"]["case_id"], request=spec["task"]["request"],
        benign_notes=dict(source_note="Dataset facts are in the captured snapshot.",
                          handoff_note="Use the supplied inputs without changing their facts."))

    class CaptureCommit:
        def commit_execution(self, attempt_token, result, command, expected_outputs, operation_id):
            row = dict(operation_id=operation_id, attempt_token=attempt_token, candidate=deepcopy(result),
                       command=deepcopy(command), expected_outputs=deepcopy(expected_outputs))
            proposals.append(row)
            journal.add("commit_proposed", self, result_id=result["result_id"], operation_id=operation_id, command=command)
            import sqlite3
            with sqlite3.connect(dest/"precommit.sqlite") as copy:
                self.connection.backup(copy)
            if fault and fault.get("kind")=="commit_unknown":
                self.quarantine("fixture unknown commit; no write attempted")
                raise RuntimeError("fixture commit response unknown")
            start = time.monotonic()
            response = super().commit_execution(attempt_token, result, command, expected_outputs, operation_id)
            row.update(response=deepcopy(response), elapsed_ms=(time.monotonic()-start)*1000)
            journal.add("commit_returned", self, result_id=result["result_id"], operation_id=operation_id, response=response)
            return response

    class Original(CaptureCommit, P3Store): pass
    class Guarded(CaptureCommit, BusinessGuardMixin, P3Store): pass

    class Hooks(P1DeliveryHooks):
        def __init__(self):
            super().__init__(public, gateway, condition="CLEAN", policy="VERIFY_STOP" if spec["verify_enabled"] else "BASE")
            self.injections = []

        def after_capture(self, store, attempt, step, bundle):
            if time.monotonic()-began >= LIMITS["flow_seconds"]: raise TimeoutError("FLOW_WALL_LIMIT")
            super().after_capture(store, attempt, step, bundle)
            journal.add("capture", store, step_id=step, result_id=attempt["result_id"], bundle=bundle)

        def before_publish(self, store, attempt, result):
            inj = spec["scenario_spec"].get("injection")
            if not inj or result["step_id"]!=inj["step"] or result["execution_status"]!="success":
                return result, []
            raw = deepcopy(result["payload"])
            delivered = deepcopy(result)
            delivered["payload"][inj["field"]] = inj["value"]
            changed = canonical(raw) != canonical(delivered["payload"])
            other_fields = {k:v for k,v in raw.items() if k!=inj["field"]}
            for call in delivered["model_calls"]: call["delivered_output"] = deepcopy(delivered["payload"])
            event = dict(event_id=new_id(), event_digest=digest(inj), kind="corrupt_result", target_result_id=result["result_id"])
            evidence = dict(result_id=result["result_id"], call_id=result["model_calls"][0]["call_id"], step_id=inj["step"],
                raw_payload=raw, delivered_payload=deepcopy(delivered["payload"]), changed=changed,
                target_was_already_incorrect=not changed, unchanged_other_fields=other_fields, publication_event=event)
            self.injections.append(evidence)
            journal.add("response_injected", store, **evidence)
            return delivered, [event]

        def after_publish(self, store, attempt, result):
            journal.add("published", store, step_id=result["step_id"], result_id=result["result_id"])
            n = len(self.verifier_receipts)
            try: return super().after_publish(store, attempt, result)
            finally:
                if len(self.verifier_receipts)>n:
                    journal.add("verification", store, receipt=self.verifier_receipts[-1])
    hooks = Hooks()
    report = dict(status="running", selected={}, log_complete=False)
    selected = report["selected"]
    with (Guarded if spec["guard_enabled"] else Original)(dest/"run.sqlite") as store:
        store.initialize_run(spec["task"])
        store.bind_p3(binding, budget.ref)
        write(dest/"initial_snapshot.json", store.snapshot_run())
        flow = Workflow(store, gateway, hooks=hooks)
        try:
            for step in STEPS:
                result = flow.run_step(step, [selected[p] for p in PARENTS[step]])
                if result["execution_status"]!="success":
                    report.update(status="failed", failure=result)
                    break
                selected[step] = result["result_id"]
                journal.add("adopted", store, step_id=step, result_id=result["result_id"])
                update = spec["scenario_spec"].get("update")
                if update and update["after"]==step:
                    key = "permission:safety_eval:train" if update["source"]=="permission" else "resource_policy:default"
                    before = store.read_objects([key])[0]
                    payload = deepcopy(before["payload"])
                    if update["source"]=="permission": payload["allowed"] = False
                    else: payload["max_workers"] = 2
                    receipt = store.apply_external_update(new_id(), key, before["version"], payload, digest(update))
                    journal.add("source_updated", store, after_step=step, trigger_result_id=result["result_id"],
                                before=before, after=store.read_objects([key])[0], receipt=receipt)
            else: report.update(status="completed")
        except VerificationStopped as exc:
            report.update(status="verifier_rejected", verifier_receipt=exc.receipt)
        except Exception as exc:
            store.quarantine("Safety study outcome needs offline reconciliation")
            report.update(status="failed_uncertain", error_type=type(exc).__name__)
            journal.add("uncertain", store, error_type=type(exc).__name__)
        if report["status"]!="failed_uncertain":
            store.finish_run(store.runtime_view()["run_id"])
            report["log_complete"] = True
        journal.add("finished", store, status=report["status"])
        write(dest/"snapshot.json", store.snapshot_run())
        write(dest/"accounting.json", store.model_accounting_snapshot())
    journal.close()
    sampler_done.set(); sampler.join(timeout=1)
    rawrss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    peak = int(rawrss if sys.platform=="darwin" else rawrss*1024)
    for name, value in dict(report=report, gateway_records=gateway.records, verifier_receipts=hooks.verifier_receipts,
        injections=hooks.injections, proposals=proposals, fake_responses=fixtures, binding=binding.to_dict(),
        runtime=dict(simulated=binding.simulated, actual_provider_tokens=0 if binding.simulated else None,
            real_api_requests=client.real_request_count, fake_calls=client.request_count if binding.simulated else 0,
            elapsed_s=time.monotonic()-began, peak_rss_bytes=peak, automatic_retries=0, recovery_rounds=0,
            training_or_prediction_calls=0, cloud_resources_started=0, cleanup_receipts=getattr(sender,"cleanup_receipts",[]),
            financial_usage_is_synthetic=binding.simulated, counter_kind="financial_allowance_not_calibrated",
            sampler_reaped=not sampler.is_alive())).items(): write(dest/(name+".json"), value)
    write(dest/"artifacts.json", {p.name:dict(sha256=sha(p), bytes=p.stat().st_size) for p in dest.iterdir() if p.is_file()})
    return dict(slot_id=spec["slot_id"], status=report["status"])


def run_batch(output, batch_id, *, credential_provider=None, permit=None, fault=None):
    from agent_recovery.p3_transport import P3Binding
    from agent_recovery.p3_budget import DurableP3Budget
    from .checker import check_run,previous_checks
    from .budget import stop_from_run, quality_stop
    output = Path(output)
    frozen = read(output/"protocol/frozen.json")
    batch = next(b for b in frozen["registration"]["batches"] if b["batch_id"]==batch_id)
    dest = output/"batches"/batch_id
    dest.mkdir(parents=True, exist_ok=False)
    binding = P3Binding.from_dict(frozen["binding"])
    limit = batch["call_cap"]
    limits = dict(call_cap=limit, slot_call_cap=5, logical_call_cap=5, input_token_cap=limit*4000,
                  output_token_cap=limit*768, max_cost_nano_usd=batch["worst_reservation_nano"])
    checks, began, halt = [], time.monotonic(), None
    rows = {r["slot_id"]:r for r in frozen["registration"]["rows"]}
    with DurableP3Budget(dest/"ledger.sqlite", campaign_id=f"{frozen['registration']['study_id']}-{batch_id}",
                         binding=binding.to_dict(), limits=limits) as budget:
        for sid in batch["slots"]:
            if time.monotonic()-began >= LIMITS["batch_seconds"]:
                halt="BATCH_WALL_LIMIT"; break
            spec = rows[sid]
            run_flow(dest/sid, spec, binding, budget, credential_provider=credential_provider, permit=permit,
                     fault=fault if not fault or fault.get("slot_id", sid)==sid else None)
            campaign = budget.snapshot()
            write(dest/sid/"ledger_at_finish.json", campaign)
            checked = check_run(dest/sid, frozen, campaign)
            checks.append(checked)
            write(dest/(sid+".check.json"), checked)
            cleanup = read(dest/sid/"runtime.json")["cleanup_receipts"]
            halt = stop_from_run(checked, campaign, cleanup)
            if not halt and batch_id=="B01": halt=quality_stop(checks,batch_id)
            if halt: break
        write(dest/"ledger.json", budget.snapshot())
    if not halt:
        earlier = previous_checks(output,batch_id)
        halt = quality_stop(earlier+checks, batch_id)
    report = dict(batch_id=batch_id, slot_ids=[r["slot_id"] for r in checks], checks=checks,
                  hard_stop_reason=halt, elapsed_s=time.monotonic()-began,
                  real_requests_authorized=binding.real_requests_authorized)
    write(dest/"worker_report.json", report)
    return report
