"""Independent entry, pre-key permission gate and one-batch continuation."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from .protocol import ROOT, LIMITS, prepare, read, write, digest, validate_grant
from .budget import Authority, campaign_lock, admit_worker


def live_preflight(frozen, output, grant, *, credential_reader=None, now=None):
    """Reject before calling any credential reader or constructing a live sender."""
    validate_grant(frozen, output, grant, time.time() if now is None else now)
    if credential_reader is None: return True
    return credential_reader()


def worker(output, batch_id, grant_path=None):
    from .runner import run_batch, install_offline_fence
    sys.path.insert(0, str(ROOT/"src"))
    frozen = read(Path(output)/"protocol/frozen.json")
    # Recheck current producer and historical pins before any source is adopted.
    prepare(output,frozen["mode"])
    admit_worker(output,frozen,batch_id)
    import resource
    resource.setrlimit(resource.RLIMIT_CPU,(1800,1800))
    if hasattr(os,"sched_setaffinity"):
        os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
    secret=[]
    permit=None
    if frozen["mode"]=="fake-http":
        if grant_path is not None: raise PermissionError("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
        fence=install_offline_fence(output)
    else:
        if grant_path is None: raise PermissionError("SAFETY_LIVE_DISABLED")
        grant=read(grant_path)
        from agent_recovery.p3_transport import LiveRuntimePermit
        from .credentials import consume_parent_pipe
        live_preflight(frozen,output,grant)
        secret.append(consume_parent_pipe(sys.stdin.buffer))
        permit=LiveRuntimePermit(True,digest(frozen["binding"]),grant["authorization_reference"])
        fence=dict(installed=False,credential_received_via_anonymous_parent_pipe=True,
                   worker_credential_files_or_environment_read=False)
    try:
        def credential_provider():
            live_preflight(frozen,output,grant)
            return secret[0]
        report=run_batch(output,batch_id,credential_provider=credential_provider if secret else None,permit=permit)
        write(Path(output)/"batches"/batch_id/"entry_receipt.json",dict(
            mode=frozen["mode"],offline_fence=fence,credential_reads=len(secret),
            real_transport_constructed=frozen["mode"]=="live",retries=0))
        print(json.dumps(dict(batch_id=batch_id,rows=len(report["slot_ids"]),hard_stop=report["hard_stop_reason"])))
    finally:
        secret.clear()


def supervise(output,batch_id,grant_path=None,*,wall_seconds=None,key=None):
    frozen=read(Path(output)/"protocol/frozen.json")
    if frozen["mode"]=="fake-http" and key is not None:
        raise PermissionError("FAKE_CANNOT_RECEIVE_CREDENTIAL")
    if frozen["mode"]=="live" and (grant_path is None or key is None):
        raise PermissionError("LIVE_PARENT_CREDENTIAL_REQUIRED")
    logdir=Path(output)/"controller"/batch_id
    logdir.mkdir(parents=True,exist_ok=False)
    command=[sys.executable,"-B",str(ROOT/"scripts/run_safety_real.py"),"_worker","--output",str(output),"--batch",batch_id]
    if grant_path:command += ["--grant",str(Path(grant_path).resolve())]
    # No inherited API keys, proxies, cloud credentials or PYTHONPATH.
    env=dict(PATH="/usr/bin:/bin:/usr/sbin:/sbin",LANG="en_US.UTF-8",PYTHONDONTWRITEBYTECODE="1",
             OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",CUDA_VISIBLE_DEVICES="")
    started=time.monotonic();reason=None;peak=0
    with (logdir/"stdout.log").open("x") as stdout,(logdir/"stderr.log").open("x") as stderr:
        process=subprocess.Popen(command,stdin=subprocess.PIPE if key is not None else subprocess.DEVNULL,
            stdout=stdout,stderr=stderr,env=env,start_new_session=True)
        try:
            if key is not None:
                from .credentials import pipe_bytes
                try:
                    process.stdin.write(pipe_bytes(key))
                    process.stdin.flush()
                finally:
                    process.stdin.close()
                    key=None
            deadline=started+(LIMITS["batch_seconds"] if wall_seconds is None else wall_seconds)
            while process.poll() is None:
                if time.monotonic()>=deadline:reason="BATCH_WALL_LIMIT";break
                for p in (Path(output)/"batches"/batch_id).glob("*/rss_samples.jsonl"):
                    lines=p.read_text().splitlines()
                    for line in lines[-2:]:
                        try:
                            sample=json.loads(line);peak=max(peak,sample["peak_rss_bytes"])
                            if sample["elapsed_s"]>=LIMITS["flow_seconds"]:reason="FLOW_WALL_LIMIT"
                        except json.JSONDecodeError: pass
                if peak>LIMITS["rss_bytes"]:reason="RSS_LIMIT"
                if reason:break
                time.sleep(0.02)
        finally:
            if process.poll() is None:
                try:os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    try:os.killpg(process.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
            exit_code=process.wait(timeout=5)
            # multiprocessing's resource tracker is part of this same group.
            try:
                os.killpg(process.pid,0)
                os.killpg(process.pid,signal.SIGTERM)
                time.sleep(0.05)
            except ProcessLookupError:pass
            try:os.killpg(process.pid,0);gone=False
            except ProcessLookupError:gone=True
    receipt=dict(exit_code=exit_code,reason=reason,reaped=True,process_group_gone=gone,
                 elapsed_s=time.monotonic()-started,peak_rss_bytes=peak,
                 environment_keys=list(env),credential_environment_forwarded=False)
    write(logdir/"watchdog.json",receipt)
    return receipt


def advance(output,grant_path=None):
    output=Path(output).resolve()
    frozen=read(output/"protocol/frozen.json")
    prepare(output,frozen["mode"])
    if frozen["mode"]=="live":
        if grant_path is None:raise PermissionError("SAFETY_LIVE_DISABLED")
        live_preflight(frozen,output,read(grant_path))
    elif grant_path is not None:raise PermissionError("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
    with campaign_lock(output):
        authority=Authority(output,frozen)
        try:
            before=authority.snapshot()
            if before["status"]=="completed":return before
            if before["status"]=="hard_stopped":raise RuntimeError("CAMPAIGN_HARD_STOPPED")
            # Verify sealed predecessors on every fresh-process continuation.
            from .checker import check_campaign,check_batch
            if before["batches"]:
                if any(b["status"]!="completed" for b in before["batches"]):
                    raise RuntimeError("PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
                prior=check_campaign(output)
                if not prior["passed"]:
                    authority.halt("PREDECESSOR_AUDIT_FAILED")
                    raise RuntimeError("PREDECESSOR_AUDIT_FAILED")
            batch=frozen["registration"]["batches"][before["completed_batches"]]
            authority.reserve_batch(batch)
            secret=[]
            try:
                if frozen["mode"]=="live":
                    from agent_recovery.p3_launch import read_hidden_api_key
                    secret.append(live_preflight(frozen,output,read(grant_path),credential_reader=read_hidden_api_key))
                receipt=supervise(output,batch["batch_id"],grant_path,key=secret[0] if secret else None)
            finally:secret.clear()
            if receipt["exit_code"]!=0 or receipt["reason"] or not receipt["process_group_gone"]:
                authority.halt(receipt["reason"] or "WORKER_OR_PROCESS_CLEANUP_FAILED")
                write(output/"STATUS.json",authority.snapshot(),replace=True)
                return authority.snapshot()
            check=check_batch(output,batch["batch_id"])
            write(output/"checks"/(batch["batch_id"]+".json"),check)
            if not check["passed"]:
                authority.halt("INDEPENDENT_CHECK_FAILED")
            else:
                authority.finalize(batch,check,output/"batches"/batch["batch_id"]/"ledger.sqlite")
            state=authority.snapshot()
            write(output/"STATUS.json",state,replace=True)
            return state
        finally:authority.close()


def main(argv=None):
    parser=argparse.ArgumentParser(description="Separate safety study; live grants are disabled by default.")
    parser.add_argument("action",choices=("prepare","advance","audit","_worker"))
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--mode",choices=("fake-http","live"),default="fake-http")
    parser.add_argument("--batch")
    parser.add_argument("--grant",type=Path)
    args=parser.parse_args(argv)
    try:
        if args.action=="prepare":
            result=prepare(args.output,args.mode)
            print(json.dumps(dict(prepared=True,mode=result["mode"],rows=96,batches=9,real_requests=0)))
        elif args.action=="advance":
            result=advance(args.output,args.grant)
            print(json.dumps({k:result[k] for k in ("status","completed_batches","project_total_nano","study_total_nano")}))
            return 2 if result["status"]=="hard_stopped" else 0
        elif args.action=="audit":
            from .checker import check_campaign
            result=check_campaign(args.output)
            write(args.output/"checks/final_audit.json",result)
            print(json.dumps({k:result[k] for k in ("passed","errors","runs","calls","actual_new_real_api_requests")}))
            return 0 if result["passed"] else 2
        else:worker(args.output,args.batch,args.grant)
        return 0
    except Exception as exc:
        # Never log arbitrary exception strings from a credential/HTTP implementation.
        code=str(exc) if type(exc) in (RuntimeError,ValueError,PermissionError) and str(exc).isupper() else type(exc).__name__
        print(json.dumps(dict(stopped=True,code=code)),file=sys.stderr)
        return 2
