"""Separate safety API campaign. Importing this package performs no I/O."""
