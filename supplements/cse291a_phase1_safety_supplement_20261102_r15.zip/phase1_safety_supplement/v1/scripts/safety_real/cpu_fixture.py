"""Socket-free deadline test adapter for macOS sandboxes denying os.nice.

Only scheduling priority setup is stubbed in this diagnostic child. The
original timeout, terminate, kill, IPC and reap implementation is exercised.
This function rejects live payloads before reaching the existing worker.
"""
from agent_recovery.p3_deadline import _worker as _original_wire_worker


def priority_neutral_fake_worker(connection,payload,recipe):
    if (recipe is None or payload.get("authorization") is not None or payload.get("permit") is not None
            or payload.get("binding",{}).get("simulated") is not True):
        raise PermissionError("CPU_FIXTURE_REJECTS_LIVE")
    import os
    original=getattr(os,"nice",None)
    if original is not None:os.nice=lambda _:19
    try:return _original_wire_worker(connection,payload,recipe)
    finally:
        if original is not None:os.nice=original
