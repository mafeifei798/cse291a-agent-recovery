"""Bounded process-group supervision shared by real entry and pipe fixtures."""
from __future__ import annotations

import os
from pathlib import Path
import signal
import subprocess
import time

from safety_real.credentials import pipe_bytes
from safety_real.protocol import read, write


def group_exists(pid):
    try:os.killpg(pid,0);return True
    except ProcessLookupError:return False


def reap_group(process):
    if group_exists(process.pid):
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:process.wait(timeout=1)
    except subprocess.TimeoutExpired:pass
    # The leader may have exited while another member is still running.
    if group_exists(process.pid):
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
    exit_code=process.wait(timeout=5)
    end=time.monotonic()+2
    while group_exists(process.pid) and time.monotonic()<end:time.sleep(0.02)
    return dict(exit_code=exit_code,reaped=True,process_group_gone=not group_exists(process.pid))


def supervise_command(command,logdir,*,env,key=None,wall_seconds=1800,sample_root=None,
                      flow_seconds=660,rss_bytes=1024**3):
    """The only credential IPC is stdin; never log command payloads or secrets."""
    if "OPENAI_API_KEY" in env:raise PermissionError("CREDENTIAL_ENVIRONMENT_FORWARDING_DENIED")
    data=None if key is None else pipe_bytes(key)
    key=None
    logdir=Path(logdir);logdir.mkdir(parents=True,exist_ok=False)
    began=time.monotonic();reason=None;peak=0;sent=False;interrupted=False
    with (logdir/"stdout.log").open("x") as stdout,(logdir/"stderr.log").open("x") as stderr:
        process=subprocess.Popen(command,stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,
            stdout=stdout,stderr=stderr,env=env,start_new_session=True)
        try:
            if data is not None:
                try:
                    process.stdin.write(data);process.stdin.flush();sent=True
                finally:process.stdin.close();data=None
            deadline=began+wall_seconds
            while process.poll() is None:
                if time.monotonic()>=deadline:reason="BATCH_WALL_LIMIT";break
                if sample_root is not None:
                    for path in Path(sample_root).glob("*/rss_samples.jsonl"):
                        for line in path.read_text().splitlines()[-2:]:
                            import json
                            try:
                                sample=json.loads(line);peak=max(peak,sample["peak_rss_bytes"])
                                if sample["elapsed_s"]>=flow_seconds:reason="FLOW_WALL_LIMIT"
                            except json.JSONDecodeError:pass
                if peak>rss_bytes:reason="RSS_LIMIT"
                if reason:break
                time.sleep(0.02)
        except BaseException:
            interrupted=True;reason="PARENT_INTERRUPTED_OR_HANDOFF_FAILED"
            raise
        finally:
            data=None
            if process.stdin is not None and not process.stdin.closed:process.stdin.close()
            receipt=reap_group(process)
            receipt.update(reason=reason,elapsed_s=time.monotonic()-began,peak_rss_bytes=peak,
                credential_sent_via_stdin=sent,credential_environment_forwarded=False,
                environment_keys=sorted(env),parent_interrupted=interrupted)
            write(logdir/"watchdog.json",receipt)
    return receipt


def child_environment(frozen):
    env=dict(PATH="/usr/bin:/bin:/usr/sbin:/sbin",LANG="en_US.UTF-8",PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",CUDA_VISIBLE_DEVICES="")
    if frozen["mode"]=="live":
        # These two non-secret markers come from the already-validated configuration.
        env.update(JUPYTERHUB_USER=frozen["deployment"]["hub_user"],
                   JUPYTERHUB_SERVICE_PREFIX=frozen["deployment"]["service_prefix"])
    return env
