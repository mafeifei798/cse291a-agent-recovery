"""Synthetic-only child for validating actual pipe IPC and forced termination."""
from __future__ import annotations

import json
import os
import signal
import sys
import time

SYNTHETIC = "SYNTHETIC_DATAHUB_PIPE_ONLY_20261022"


def main():
    if len(sys.argv)!=2 or sys.argv[1] not in ("normal","term_resistant","close_pipe"):
        raise PermissionError("PIPE_FIXTURE_MODE")
    mode=sys.argv[1]
    # No arbitrary key values, environment lookups or network sender are accepted.
    def offline(event,args):
        if event.startswith("socket.") or event=="http.client.connect":
            raise PermissionError("PIPE_FIXTURE_NO_NETWORK")
    sys.addaudithook(offline)
    if mode=="close_pipe":return
    if mode=="term_resistant":signal.signal(signal.SIGTERM,signal.SIG_IGN)
    from safety_real.credentials import consume_parent_pipe
    value=consume_parent_pipe(sys.stdin.buffer)
    if value!=SYNTHETIC:raise PermissionError("PIPE_FIXTURE_SYNTHETIC_ONLY")
    from agent_recovery.p3_transport import FakeHTTPSender, HTTPRequest, fake_http_response
    sender=FakeHTTPSender([fake_http_response({"fixture":True},model="fixture-glm-5.3-flash",
        request_id="fixture-pipe-call",prompt_tokens=10,completion_tokens=2)])
    response=sender.send(HTTPRequest("POST","https://fixture.invalid/no-network",b"{}",1),authorization=value)
    del value
    result=dict(synthetic_pipe_received=True,fake_http_calls=sender.request_count,
        real_api_requests=sender.real_request_count,status=response.status,
        credential_in_environment="OPENAI_API_KEY" in os.environ,
        authorization_not_captured=all("Authorization" not in getattr(r,"headers",{}) for r in sender.requests))
    print(json.dumps(result),flush=True)
    if mode=="term_resistant":time.sleep(30)


if __name__=="__main__":main()
