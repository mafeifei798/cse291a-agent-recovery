"""Offline acceptance inside a disposable copy, with synthetic credentials only."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import time

from safety_real.protocol import read, write, digest, sha, binding_dict
from safety_real.budget import Authority, campaign_lock
from safety_real.checker import check_campaign, check_history
from .protocol import ROOT, LIVE_RELATIVE, TARGET_FIELDS, LIMITS, prepare, disabled_grant, validate_grant, validate_target
from .environment import read_datahub_key, check_environment
from .launch import verify_package, advance
from .processes import supervise_command, child_environment
from .pipe_fixture import SYNTHETIC


def need(condition,code):
    if not condition:raise AssertionError(code)


class SyntheticEnvironment:
    def __init__(self,values):self.values=dict(values);self.key_reads=0
    def get(self,name,default=None):
        if name=="OPENAI_API_KEY":self.key_reads+=1
        return self.values.get(name,default)


def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,required=True)
    out=parser.parse_args(argv).output.resolve()
    if not (ROOT/"OFFLINE_CAPSULE_TEST_ONLY").is_file():
        raise PermissionError("ACCEPTANCE_REQUIRES_DISPOSABLE_CAPSULE")
    out.mkdir(parents=True,exist_ok=False);rows=[];network=[]
    def fence(event,args):
        if event.startswith("socket.") or event=="http.client.connect":
            network.append(event);raise PermissionError("ACCEPTANCE_NETWORK_DENIED")
    sys.addaudithook(fence)
    def case(name,fn):
        began=time.monotonic()
        try:detail=fn();r=dict(name=name,passed=True,detail=detail)
        except Exception as exc:r=dict(name=name,passed=False,error_type=type(exc).__name__,error=str(exc))
        r["elapsed_s"]=time.monotonic()-began;rows.append(r);write(out/"cases"/(name+".json"),r)
    def rejected(fn,code):
        try:fn()
        except Exception as exc:
            need(str(exc)==code,"UNEXPECTED_REJECTION");return code
        raise AssertionError("EXPECTED_REJECTION")
    case("portable_package_hashes",lambda:verify_package())
    fake=prepare(out/"fake_protocol")
    case("historical_ledger_independent",lambda:need(check_history(fake,ROOT)["passed"],"HISTORY"))
    case("registration_unchanged_96_9",lambda:need(len(fake["registration"]["rows"])==96 and
         len(fake["registration"]["batches"])==9,"REGISTRATION"))
    target=dict(TARGET_FIELDS,deployment_root=str(ROOT),hub_user="synthetic-user",service_prefix="/user/synthetic-user/")
    live=deepcopy(fake);live.update(mode="live",binding=binding_dict("live"),deployment=target)
    liveout=ROOT/LIVE_RELATIVE
    grant=disabled_grant(live,liveout)
    grant.update(authorized=True,pricing_and_model_confirmed=True,course_cpu_profile_confirmed=True,
        authorization_reference="SYNTHETIC_FIXTURE_ONLY_NO_USER_OR_NETWORK_PERMISSION",expires_unix=time.time()+3600)
    values=dict(JUPYTERHUB_USER=target["hub_user"],JUPYTERHUB_SERVICE_PREFIX=target["service_prefix"],OPENAI_API_KEY=SYNTHETIC)
    case("target_rejects_extra_credential_fields",lambda:rejected(
        lambda:validate_target(dict(target,api_key="SYNTHETIC_FIELD_MUST_NOT_BE_SERIALIZED")),
        "DATAHUB_TARGET_SCOPE_MISMATCH"))
    def get_key(g=grant,env=None,system="Linux",batch="B01"):
        return read_datahub_key(live,liveout,g,batch,environ=env or SyntheticEnvironment(values),system=system)
    for name,value,code in (("authorized",False,"DATAHUB_LIVE_DISABLED"),
            ("credential_source","hidden_terminal","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("credential_variable","ANOTHER_API_KEY","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("campaign_root",str(out),"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("frozen_digest","changed","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("binding_digest","changed","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("history_digest","changed","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("deployment_digest","changed","DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("pricing_and_model_confirmed",False,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("course_cpu_profile_confirmed",False,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("expires_unix",0,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("expires_unix",time.time()+172800,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("max_new_calls",61,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("max_new_calls",60.0,"DATAHUB_LIVE_SCOPE_MISMATCH"),
            ("limits",dict(LIMITS,project_nano=50000000000),"DATAHUB_LIVE_SCOPE_MISMATCH")):
        def denied(name=name,value=value,code=code):
            env=SyntheticEnvironment(values);g=dict(grant);g[name]=value
            rejected(lambda:get_key(g,env),code);need(env.key_reads==0,"EARLY_CREDENTIAL_READ")
        case("deny_before_key_"+name+str(len(rows)),denied)
    def target_denied(system=None,field=None,value=None,batch="B01",code="DATAHUB_ENVIRONMENT_MISMATCH"):
        env=SyntheticEnvironment(dict(values,**({field:value} if field else {})))
        rejected(lambda:get_key(env=env,system=system or "Linux",batch=batch),code)
        need(env.key_reads==0,"EARLY_CREDENTIAL_READ")
    case("wrong_os_before_key",lambda:target_denied(system="Darwin"))
    case("wrong_hub_user_before_key",lambda:target_denied(field="JUPYTERHUB_USER",value="another"))
    case("wrong_service_prefix_before_key",lambda:target_denied(field="JUPYTERHUB_SERVICE_PREFIX",value=None))
    case("b02_not_authorized_by_b01_grant",lambda:target_denied(batch="B02",code="DATAHUB_BATCH_NOT_PERMITTED"))
    def unreserved():
        env=SyntheticEnvironment(values)
        rejected(lambda:get_key(env=env),"CREDENTIAL_REQUIRES_RESERVED_BATCH")
        need(env.key_reads==0,"EARLY_CREDENTIAL_READ")
    case("no_key_before_budget_reservation",unreserved)
    liveout.mkdir(parents=True,exist_ok=False)
    authority=Authority(liveout,live)
    try:
        with campaign_lock(liveout):
            def active_unreserved():
                env=SyntheticEnvironment(values)
                rejected(lambda:get_key(env=env),"CREDENTIAL_RESERVATION_MISMATCH")
                need(env.key_reads==0,"EARLY_CREDENTIAL_READ")
            case("active_lock_alone_cannot_read_key",active_unreserved)
            authority.reserve_batch(live["registration"]["batches"][0])
            def positive():
                env=SyntheticEnvironment(values)
                key=get_key(env=env)
                need(key==SYNTHETIC and env.key_reads==1,"PROVIDER_HANDOFF")
                return dict(synthetic_reads=env.key_reads,reserved_nano=authority.snapshot()["study_held_nano"])
            case("exact_named_env_once_after_all_gates",positive)
            for name,value,code in (("missing",None,"DATAHUB_CREDENTIAL_MISSING"),
                ("newline","SYNTHETIC\nBAD","CREDENTIAL_PIPE_INVALID"),
                ("nonascii","测试","CREDENTIAL_PIPE_INVALID"),
                ("oversize","X"*4097,"CREDENTIAL_PIPE_INVALID"),
                ("not_string",123,"CREDENTIAL_PIPE_INVALID")):
                def malformed(value=value,code=code):
                    env=SyntheticEnvironment(dict(values,OPENAI_API_KEY=value))
                    rejected(lambda:get_key(env=env),code);need(env.key_reads==1,"LOOKUP_COUNT")
                case("credential_"+name,malformed)
            def expired():
                env=SyntheticEnvironment(values);g=dict(grant,expires_unix=0)
                rejected(lambda:get_key(g,env),"DATAHUB_LIVE_SCOPE_MISMATCH")
                need(env.key_reads==0,"EXPIRED_KEY_READ")
            case("expired_after_reservation_does_not_read",expired)
        def unlocked():
            env=SyntheticEnvironment(values)
            rejected(lambda:get_key(env=env),"CREDENTIAL_REQUIRES_ACTIVE_LOCK")
            need(env.key_reads==0,"UNLOCKED_KEY_READ")
        case("unlocked_ledger_cannot_read_key",unlocked)
        def retained():
            state=authority.snapshot()
            need(state["historical_known_nano"]==149897450 and state["historical_held_nano"]==2268000,
                "HISTORICAL_HOLD_DROPPED")
            need(state["project_total_nano"]==211205450 and state["study_held_nano"]==59040000,"RESERVATION")
            rejected(lambda:authority.reserve_batch(live["registration"]["batches"][0]),
                "PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
            return dict(project_total_nano=state["project_total_nano"],held_nano=state["study_held_nano"])
        case("pending_batch_keeps_history_and_full_block",retained)
    finally:authority.close()
    def caps():
        details=[]
        for cap,code in (("project_nano","PROJECT_BUDGET_CAP"),("study_nano","STUDY_BUDGET_CAP"),
                         ("batch_nano","BATCH_BUDGET_CAP")):
            f=deepcopy(fake);f["registration"]["limits"][cap]=1
            a=Authority(out/("cap_"+cap),f)
            try:
                rejected(lambda:a.reserve_batch(f["registration"]["batches"][0]),code)
                need(not a.snapshot()["batches"],"FAILED_RESERVATION_WROTE_BATCH")
                details.append(code)
            finally:a.close()
        return details
    case("all_three_caps_before_dispatch",caps)
    fixture_command=[sys.executable,"-B","-m","safety_datahub.pipe_fixture"]
    fixture_env=child_environment(fake)
    # Only the known module directories are added; no parent environment is copied.
    fixture_env["PYTHONPATH"]=str(ROOT/"scripts")+os.pathsep+str(ROOT/"src")
    def pipe(mode):
        env=SyntheticEnvironment(values)
        # Use the provider's actual return value, after checking a durable reservation.
        with campaign_lock(liveout):
            key=get_key(env=env)
            try:
                r=supervise_command(fixture_command+[mode],out/"pipe"/mode,env=fixture_env,
                    key=key,wall_seconds=1 if mode=="term_resistant" else 10)
            finally:key=None
        need(env.key_reads==1,"PROVIDER_PIPE_LOOKUP_COUNT")
        need(r["reaped"] and r["process_group_gone"],"CHILD_NOT_REAPED")
        if mode=="normal":
            result=json.loads((out/"pipe"/mode/"stdout.log").read_text())
            need(result["synthetic_pipe_received"] and result["fake_http_calls"]==1 and
                result["real_api_requests"]==0 and not result["credential_in_environment"]
                and result["authorization_not_captured"],"PIPE_FAKE_HTTP")
        else:need(r["reason"]=="BATCH_WALL_LIMIT" and r["exit_code"]<0,"KILL_REQUIRED")
        return r
    case("anonymous_pipe_to_fake_http_without_env_or_args",lambda:pipe("normal"))
    case("term_resistant_group_killed_and_reaped",lambda:pipe("term_resistant"))
    case("credential_env_forwarding_denied",lambda:rejected(lambda:supervise_command(
        fixture_command+["normal"],out/"invalid_env",env=dict(fixture_env,OPENAI_API_KEY=SYNTHETIC),key=SYNTHETIC),
        "CREDENTIAL_ENVIRONMENT_FORWARDING_DENIED"))
    def continuation():
        path=out/"two_batch_fake"
        prepare(path)
        a=advance(path);first=read(path/"checks/B01.json")
        b=advance(path);checked=check_campaign(path)
        need(checked["passed"] and checked["completed_batches"]==2 and checked["runs"]==24,"CONTINUATION")
        need(checked["historical_held_nano"]==2268000 and checked["actual_new_real_api_requests"]==0,"HISTORY_RESET")
        need(sha(path/"batches/B01/ledger.sqlite")==a["batches"][0]["ledger_sha256"],"B01_REWRITTEN")
        need(checked["calls"]==len({cid for c in checked["checks"] for cid in c["call_ids"]}),"DUPLICATE_CALLS")
        write(out/"two_batch_audit.json",checked)
        return dict(rows=checked["runs"],fake_calls=checked["calls"],completed_batches=b["completed_batches"],
            historical_held_nano=checked["historical_held_nano"],actual_new_real_api_requests=0)
    case("fresh_process_b01_b02_same_ledger_independent_audit",continuation)
    def deadline(kind):
        sys.path.insert(0,str(ROOT/"src"))
        from agent_recovery.p3_transport import P3Binding,P3HTTPClient,P3HTTPError,fake_http_response
        from agent_recovery.p3_deadline import BoundedHTTPSender,WireRecipe
        from agent_recovery import p3_deadline
        from safety_real.cpu_fixture import priority_neutral_fake_worker
        from unittest.mock import patch
        run=next((out/"two_batch_fake/batches/B01").glob("*/gateway_records.json"))
        request=read(run)[0]["request"]
        binding=P3Binding.from_dict(dict(fake["binding"],timeout_s=1))
        response=fake_http_response({"unused":True},model=binding.model,request_id="fixture-late",prompt_tokens=1,completion_tokens=1)
        recipe=WireRecipe(kind=kind,delay_s=2,response=None if kind=="dns_hang" else response)
        sender=BoundedHTTPSender(recipes=[recipe]);client=P3HTTPClient(binding,sender)
        with patch.object(p3_deadline,"_worker",priority_neutral_fake_worker):
            try:client.create(request,timeout_s=1)
            except P3HTTPError:pass
            else:raise AssertionError("LATE_RESULT_ACCEPTED")
        r=sender.last_receipt
        need(r["timed_out"] and r["reaped"] and sender.real_request_count==0,"HTTP_CHILD_REAP")
        write(out/(kind+"_cleanup.json"),r);return r
    for kind in ("dns_hang","slow_headers","late_success"):
        case("bounded_"+kind+"_no_late_adoption",lambda kind=kind:deadline(kind))
    def no_leak():
        leaks=[]
        for p in out.rglob("*"):
            if p.is_file() and p.suffix in (".json",".jsonl",".log",".csv") and SYNTHETIC.encode() in p.read_bytes():
                leaks.append(str(p.relative_to(out)))
        need(not leaks,"SYNTHETIC_CREDENTIAL_LEAK");return dict(credential_leaks=leaks,network_events=network)
    case("no_credential_in_logs_and_no_network_attempt",no_leak)
    result=dict(passed=all(r["passed"] for r in rows),tests=len(rows),passed_tests=sum(r["passed"] for r in rows),
        failures=[r["name"] for r in rows if not r["passed"]],credential_source="injected_synthetic_mapping_only",
        real_key_reads=0,real_api_requests=0,cloud_starts=0,training_or_prediction_calls=0,
        network_attempts=network,fixture_only=True,cases=rows)
    write(out/"RESULTS.json",result)
    print(json.dumps({k:result[k] for k in ("passed","tests","passed_tests","failures","real_key_reads","real_api_requests")}))
    return 0 if result["passed"] else 2


if __name__=="__main__":raise SystemExit(main())
