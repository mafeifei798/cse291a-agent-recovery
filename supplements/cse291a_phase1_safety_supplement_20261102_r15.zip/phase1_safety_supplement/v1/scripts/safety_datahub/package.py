"""Explicit-file portable package; never include home files, keys or old results."""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import zipfile

from .protocol import ROOT, code_hashes, read, write, sha, HISTORY_PATHS


def build(destination):
    destination=Path(destination).resolve();destination.mkdir(parents=True,exist_ok=False)
    files=set(code_hashes()) | set(HISTORY_PATHS.values())
    files.add("docs/SAFETY_DATAHUB_RUNBOOK.md")
    for rel in sorted(files):
        source=ROOT/rel
        if source.is_symlink() or not source.is_file():raise PermissionError("PACKAGE_SOURCE_INVALID")
        target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    manifest=dict(schema_version="safety-datahub-package-v1",live_enabled=False,
        credentials_included=False,original_results_included=False,
        files={rel:sha(destination/rel) for rel in sorted(files)})
    write(destination/"PACKAGE_MANIFEST.json",manifest)
    archive=destination.with_suffix(".zip")
    with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(destination.rglob("*")):
            if p.is_file():z.write(p,str(p.relative_to(destination)))
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad is not None:raise RuntimeError("PACKAGE_CRC_FAILED")
    return dict(package=str(destination),archive=str(archive),files=len(files),archive_sha256=sha(archive),
                archive_bytes=archive.stat().st_size,live_enabled=False,credentials_included=False)


def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument("--destination",type=Path,required=True)
    result=build(p.parse_args(argv).destination)
    print(__import__("json").dumps(result))


if __name__=="__main__":main()
