"""Three bounded read-only checks inside DataHub; no generation or raw-key output."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
from decimal import Decimal
import http.client
import json
import math
import os
from pathlib import Path
import re
import signal
import ssl
import subprocess
import sys
import time

HOST="tritonai-api.ucsd.edu"
MODEL="api-glm-5.3-flash"
MAX_BODY=2*1024*1024


def request(path,key=None):
    connection=http.client.HTTPSConnection(HOST,timeout=20,context=ssl.create_default_context())
    try:
        headers={"Accept":"application/json"}
        if key is not None:headers["Authorization"]="Bearer "+key
        connection.request("GET",path,headers=headers)
        response=connection.getresponse();status=response.status
        body=response.read(MAX_BODY+1)
        if len(body)>MAX_BODY:raise RuntimeError("READ_ONLY_BODY_LIMIT")
        if status!=200:raise RuntimeError("READ_ONLY_HTTP_"+str(status))
        return json.loads(body)
    finally:connection.close()


def worker():
    key=None
    try:
        if (sys.platform!="linux" or not os.environ.get("JUPYTERHUB_USER")
            or not os.environ.get("JUPYTERHUB_SERVICE_PREFIX","").startswith("/user/")):
            raise RuntimeError("DATAHUB_CONTEXT_REQUIRED")
        base=os.environ.get("OPENAI_BASE_URL","").rstrip("/")
        if base!="https://"+HOST+"/v1":raise RuntimeError("BASE_URL_MISMATCH")
        catalog=request("/public/model_hub")
        selected=[m for m in catalog if m.get("model_group")==MODEL]
        if len(selected)!=1:raise RuntimeError("PUBLIC_MODEL_NOT_UNIQUE")
        model=selected[0]
        if (Decimal(str(model.get("input_cost_per_token")))*10**9!=150
            or Decimal(str(model.get("output_cost_per_token")))*10**9!=500):
            raise RuntimeError("PRICE_CHANGED")
        needed={"response_format","reasoning_effort","max_completion_tokens"}
        if not needed.issubset(set(model.get("supported_openai_params",[]))):
            raise RuntimeError("MODEL_PARAMETERS_NOT_ADVERTISED")
        key=os.environ.get("OPENAI_API_KEY")
        if not isinstance(key,str) or not 0<len(key)<=4096 or not all(33<=ord(c)<=126 for c in key):
            raise RuntimeError("KEY_MISSING_OR_INVALID")
        models=request("/v1/models",key)
        accessible=any(m.get("id")==MODEL for m in models.get("data",[]))
        if not accessible:raise RuntimeError("MODEL_NOT_ACCESSIBLE")
        info=request("/key/info",key).get("info",{})
        spend,maximum=info.get("spend"),info.get("max_budget")
        if any(type(x) not in (int,float) or not math.isfinite(x) for x in (spend,maximum)):
            raise RuntimeError("QUOTA_NOT_NUMERIC")
        remaining=maximum-spend
        if spend<0 or remaining<.10:raise RuntimeError("INSUFFICIENT_VISIBLE_KEY_QUOTA")
        expiry=info.get("expires")
        if expiry and datetime.fromisoformat(expiry.replace("Z","+00:00")).timestamp()<=time.time()+1800:
            raise RuntimeError("KEY_EXPIRY_TOO_SOON")
        safe=dict(passed=True,checked_at_utc=datetime.now(timezone.utc).isoformat(),
            read_only_gets=3,generation_requests=0,key_value_exported=False,
            base_url_matches=True,model=MODEL,model_accessible=accessible,
            input_nano_usd_per_token=150,output_nano_usd_per_token=500,
            supported_openai_params=sorted(needed),strict_schema_not_proven_by_catalog=True,
            key_spend_usd=spend,key_max_budget_usd=maximum,key_visible_remaining_usd=remaining,
            key_expires=expiry,budget_duration=info.get("budget_duration"),budget_reset_at=info.get("budget_reset_at"),
            membership_budget_visibility=False,provider_total_project_debit_verified=False)
        if key in json.dumps(safe):raise RuntimeError("SECRET_ECHO_REJECTED")
        return safe
    except Exception as exc:
        code=str(exc) if type(exc) is RuntimeError and str(exc).isupper() else type(exc).__name__
        return dict(passed=False,hard_stop=True,code=code,generation_requests=0,key_value_exported=False)
    finally:key=None


def run(output):
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists():raise RuntimeError("PREFLIGHT_ALREADY_EXISTS_NO_REQUERY")
    process=subprocess.Popen([sys.executable,"-B",str(Path(__file__).resolve()),"_worker"],
        stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,start_new_session=True)
    try:
        try:raw,_=process.communicate(timeout=120)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=1)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
            result=dict(passed=False,hard_stop=True,code="READ_ONLY_TOTAL_DEADLINE",generation_requests=0)
        else:
            if process.returncode or len(raw)>16384:result=dict(passed=False,hard_stop=True,code="PREFLIGHT_WORKER_FAILED",generation_requests=0)
            else:result=json.loads(raw)
        result["worker_reaped"]=process.poll() is not None
        output.write_text(json.dumps(result,indent=2)+"\n")
        print(json.dumps(result));return 0 if result["passed"] else 2
    finally:
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)


if __name__=="__main__":
    if sys.argv[1:]==["_worker"]:print(json.dumps(worker()));raise SystemExit(0)
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,required=True)
    raise SystemExit(run(parser.parse_args().output))
