"""Explicit, bounded environment provider; never enumerate or print credentials."""
from __future__ import annotations

import fcntl
import json
import os
import platform
from pathlib import Path
import sqlite3

from safety_real.credentials import pipe_bytes
from safety_real.protocol import read
from .protocol import KEY_VARIABLE, LIMITS, validate_grant


def check_environment(frozen, output, grant, batch_id=None, *, environ=None, system=None):
    # A denied/expired/mismatched grant cannot even inspect the target environment.
    validate_grant(frozen,output,grant,batch_id)
    env=os.environ if environ is None else environ
    target=frozen["deployment"]
    if ((platform.system() if system is None else system)!="Linux"
        or env.get("JUPYTERHUB_USER")!=target["hub_user"]
        or env.get("JUPYTERHUB_SERVICE_PREFIX")!=target["service_prefix"]):
        raise PermissionError("DATAHUB_ENVIRONMENT_MISMATCH")
    return dict(target="ucsd-datahub",system="Linux",hub_user=target["hub_user"],
        service_prefix=target["service_prefix"],credential_values_read=0,
        course_profile_is_operator_confirmed=True,
        markers_are_scope_checks_not_cryptographic_attestation=True)


def require_parent_reservation(output,frozen,batch_id):
    output=Path(output)
    if not (output/"authority.sqlite").is_file() or not (output/"campaign.lock").is_file():
        raise PermissionError("CREDENTIAL_REQUIRES_RESERVED_BATCH")
    if read(output/"campaign.lock").get("pid")!=os.getpid():
        raise PermissionError("CREDENTIAL_REQUIRES_OWNED_LOCK")
    with (output/"campaign.lock").open("r+") as stream:
        try: fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: pass
        else:
            fcntl.flock(stream,fcntl.LOCK_UN)
            raise PermissionError("CREDENTIAL_REQUIRES_ACTIVE_LOCK")
    with sqlite3.connect((output/"authority.sqlite").resolve().as_uri()+"?mode=ro&immutable=1",uri=True) as con:
        saved=json.loads(con.execute("SELECT body FROM config").fetchone()[0])
        batches=[json.loads(r[0]) for r in con.execute("SELECT body FROM batches ORDER BY rowid")]
        if saved!=frozen or con.execute("SELECT 1 FROM stop").fetchone():
            raise PermissionError("CREDENTIAL_AUTHORITY_FENCED")
    pending=[b for b in batches if b["status"]!="completed"]
    wanted=next(b for b in frozen["registration"]["batches"] if b["batch_id"]==batch_id)
    total=sum(b["known_nano"]+b["held_nano"] for b in batches)
    if (len(pending)!=1 or pending[0]["batch_id"]!=batch_id or pending[0]["status"]!="reserved"
        or pending[0]["block_nano"]!=wanted["worst_reservation_nano"]
        or pending[0]["held_nano"]!=wanted["worst_reservation_nano"]
        or wanted["worst_reservation_nano"]>LIMITS["batch_nano"]
        or total>LIMITS["study_nano"] or frozen["history"]["total_nano"]+total>LIMITS["project_nano"]):
        raise PermissionError("CREDENTIAL_RESERVATION_MISMATCH")
    return True


def read_datahub_key(frozen,output,grant,batch_id,*,environ=None,system=None):
    """Only call after admission; injected mappings keep offline tests key-free."""
    check_environment(frozen,output,grant,batch_id,environ=environ,system=system)
    require_parent_reservation(output,frozen,batch_id)
    env=os.environ if environ is None else environ
    try:
        value=env.get(KEY_VARIABLE)
    except Exception:
        raise PermissionError("DATAHUB_CREDENTIAL_UNAVAILABLE") from None
    if value is None: raise PermissionError("DATAHUB_CREDENTIAL_MISSING")
    pipe_bytes(value)
    return value
