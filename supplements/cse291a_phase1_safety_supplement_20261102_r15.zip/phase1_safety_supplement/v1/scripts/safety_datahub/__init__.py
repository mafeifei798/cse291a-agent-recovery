"""DataHub launch adapter. Importing this package performs no credential lookup."""
