"""One-batch DataHub entry: permission, target, budget, key, pipe, then execution."""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sqlite3
import sys
import time

from safety_real.protocol import read, write, digest, sha
from safety_real.budget import Authority, campaign_lock, admit_worker
from .protocol import ROOT, LIMITS, TARGET_FIELDS, LIVE_RELATIVE, prepare, validate_grant
from .environment import check_environment, read_datahub_key
from .processes import supervise_command, child_environment


def verify_package(root=ROOT):
    root=Path(root).resolve();path=root/"PACKAGE_MANIFEST.json"
    if not path.is_file():raise PermissionError("PACKAGE_MANIFEST_REQUIRED")
    manifest=read(path)
    if manifest.get("schema_version")!="safety-datahub-package-v1":raise PermissionError("PACKAGE_SCHEMA")
    for rel,pin in manifest["files"].items():
        p=root/rel
        if (Path(rel).is_absolute() or ".." in Path(rel).parts or not p.is_file()
                or p.is_symlink() or root not in p.resolve().parents or sha(p)!=pin):
            raise PermissionError("PACKAGE_FILE_CHANGED")
    return dict(passed=True,files=len(manifest["files"]),manifest_sha256=sha(path))


def runtime_info():
    dependencies={}
    for name in ("jsonschema","attrs","jsonschema-specifications","referencing","rpds-py"):
        try:dependencies[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:dependencies[name]=None
    expected={line.split("==")[0]:line.split("==")[1] for line in
              (ROOT/"configs/safety_datahub/requirements.lock").read_text().splitlines() if line}
    return dict(python=platform.python_version(),system=platform.system(),machine=platform.machine(),
        sqlite=sqlite3.sqlite_version,dependencies=dependencies,
        dependencies_match=dependencies==expected,
        python_supported=sys.version_info>=(3,10),sqlite_supported=sqlite3.sqlite_version_info>=(3,37),
        credential_values_read=0,real_api_requests=0)


def require_runtime():
    info=runtime_info()
    if not all(info[k] for k in ("dependencies_match","python_supported","sqlite_supported")):
        raise PermissionError("TARGET_RUNTIME_NOT_READY")
    return info


def worker(output,batch_id,grant_path=None):
    from safety_real.runner import run_batch, install_offline_fence
    output=Path(output).resolve();frozen=read(output/"protocol/frozen.json")
    prepare(output,frozen["mode"],frozen["deployment"])
    admit_worker(output,frozen,batch_id)
    import resource
    resource.setrlimit(resource.RLIMIT_CPU,(1800,1800))
    if hasattr(os,"sched_setaffinity"):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
    secret=[];permit=None
    if frozen["mode"]=="fake-http":
        if grant_path is not None:raise PermissionError("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
        fence=install_offline_fence(output)
    else:
        if grant_path is None:raise PermissionError("DATAHUB_LIVE_DISABLED")
        verify_package();require_runtime()
        grant=read(grant_path)
        check_environment(frozen,output,grant,batch_id)
        from safety_real.credentials import consume_parent_pipe
        from agent_recovery.p3_transport import LiveRuntimePermit
        secret.append(consume_parent_pipe(sys.stdin.buffer))
        permit=LiveRuntimePermit(True,digest(frozen["binding"]),grant["authorization_reference"])
        fence=dict(installed=False,credential_received_via_anonymous_parent_pipe=True,
                   worker_credential_files_or_environment_read=False)
    try:
        def provider():
            validate_grant(frozen,output,grant,batch_id)
            return secret[0]
        report=run_batch(output,batch_id,credential_provider=provider if secret else None,permit=permit)
        write(output/"batches"/batch_id/"entry_receipt.json",dict(mode=frozen["mode"],offline_fence=fence,
            credential_reads=len(secret),real_transport_constructed=frozen["mode"]=="live",retries=0))
        print(json.dumps(dict(batch_id=batch_id,rows=len(report["slot_ids"]),hard_stop=report["hard_stop_reason"])))
    finally:secret.clear()


def advance(output,grant_path=None):
    output=Path(output).resolve();frozen=read(output/"protocol/frozen.json")
    prepare(output,frozen["mode"],frozen["deployment"])
    grant=None
    if frozen["mode"]=="live":
        if grant_path is None:raise PermissionError("DATAHUB_LIVE_DISABLED")
        grant=read(grant_path)
        validate_grant(frozen,output,grant)
        verify_package();require_runtime()
        check_environment(frozen,output,grant)
    elif grant_path is not None:raise PermissionError("FAKE_CANNOT_ACCEPT_LIVE_GRANT")
    with campaign_lock(output):
        authority=Authority(output,frozen)
        try:
            state=authority.snapshot()
            if state["status"]=="completed":return state
            if state["status"]=="hard_stopped":raise RuntimeError("CAMPAIGN_HARD_STOPPED")
            from safety_real.checker import check_campaign,check_batch
            if state["batches"]:
                if any(b["status"]!="completed" for b in state["batches"]):
                    raise RuntimeError("PENDING_BATCH_REQUIRES_OFFLINE_RECONCILIATION")
                if not check_campaign(output)["passed"]:
                    authority.halt("PREDECESSOR_AUDIT_FAILED");raise RuntimeError("PREDECESSOR_AUDIT_FAILED")
            batch=frozen["registration"]["batches"][state["completed_batches"]]
            if grant is not None:validate_grant(frozen,output,grant,batch["batch_id"])
            authority.reserve_batch(batch)
            secret=[]
            try:
                if grant is not None:
                    secret.append(read_datahub_key(frozen,output,grant,batch["batch_id"]))
                command=[sys.executable,"-B",str(ROOT/"scripts/run_safety_datahub.py"),"_worker",
                    "--output",str(output),"--batch",batch["batch_id"]]
                if grant_path:command += ["--grant",str(Path(grant_path).resolve())]
                receipt=supervise_command(command,output/"controller"/batch["batch_id"],
                    env=child_environment(frozen),key=secret[0] if secret else None,
                    wall_seconds=LIMITS["batch_seconds"],sample_root=output/"batches"/batch["batch_id"])
            except BaseException:
                authority.halt("CREDENTIAL_OR_WORKER_LAUNCH_FAILED")
                write(output/"STATUS.json",authority.snapshot(),replace=True)
                raise
            finally:secret.clear()
            if receipt["exit_code"]!=0 or receipt["reason"] or not receipt["process_group_gone"]:
                authority.halt(receipt["reason"] or "WORKER_OR_PROCESS_CLEANUP_FAILED")
            else:
                checked=check_batch(output,batch["batch_id"])
                write(output/"checks"/(batch["batch_id"]+".json"),checked)
                if not checked["passed"]:authority.halt("INDEPENDENT_CHECK_FAILED")
                else:authority.finalize(batch,checked,output/"batches"/batch["batch_id"]/"ledger.sqlite")
            state=authority.snapshot();write(output/"STATUS.json",state,replace=True)
            return state
        finally:authority.close()


def main(argv=None):
    p=argparse.ArgumentParser(description="DataHub safety study; one batch per advance; no automatic API probes.")
    p.add_argument("action",choices=("runtime","verify-package","configure-target","prepare","advance","audit","_worker"))
    p.add_argument("--output",type=Path);p.add_argument("--target",type=Path)
    p.add_argument("--mode",choices=("fake-http","live"),default="fake-http")
    p.add_argument("--batch");p.add_argument("--grant",type=Path)
    args=p.parse_args(argv)
    try:
        if args.action=="runtime":result=runtime_info()
        elif args.action=="verify-package":result=verify_package()
        elif args.action=="configure-target":
            if args.target is None:raise ValueError("TARGET_PATH_REQUIRED")
            target=dict(TARGET_FIELDS,deployment_root=str(ROOT.resolve()),
                hub_user=os.environ.get("JUPYTERHUB_USER"),
                service_prefix=os.environ.get("JUPYTERHUB_SERVICE_PREFIX"))
            from .protocol import validate_target
            validate_target(target)
            if platform.system()!="Linux":raise PermissionError("DATAHUB_ENVIRONMENT_MISMATCH")
            write(args.target,target)
            result=dict(configured=True,credential_values_read=0,live_authorized=False)
        else:
            if args.output is None:raise ValueError("OUTPUT_REQUIRED")
            if args.action=="prepare":
                if args.mode=="live":verify_package();require_runtime()
                frozen=prepare(args.output,args.mode,read(args.target) if args.target else None)
                result=dict(prepared=True,mode=frozen["mode"],rows=96,batches=9,live_authorized=False)
            elif args.action=="advance":result=advance(args.output,args.grant)
            elif args.action=="audit":
                from safety_real.checker import check_campaign
                checked=check_campaign(args.output)
                write(args.output/"checks/datahub_audit.json",checked)
                result={k:checked[k] for k in ("passed","errors","runs","calls","actual_new_real_api_requests")}
            else:worker(args.output,args.batch,args.grant);return 0
        print(json.dumps(result))
        return 2 if result.get("passed") is False or result.get("status")=="hard_stopped" else 0
    except Exception as exc:
        code=str(exc) if type(exc) in (RuntimeError,ValueError,PermissionError) and str(exc).isupper() else type(exc).__name__
        print(json.dumps(dict(stopped=True,code=code)),file=sys.stderr);return 2
