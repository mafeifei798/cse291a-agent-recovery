"""Offline evidence audit. Python standard library only; never run a producer."""
import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

def deny_network(event, args):
    if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system'):
        raise RuntimeError('Offline audit forbids network and subprocess execution')
sys.addaudithook(deny_network)

def read(p):
    return json.loads(Path(p).read_text())

def usd(n):
    return str(Decimal(n) / 10**9)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True,help='New empty directory, outside immutable inputs.')
    out=ap.parse_args().output.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit('Refusing to replace existing output')
    out.mkdir(parents=True,exist_ok=True)
    def save(name,value):
        (out/name).write_text(json.dumps(value,indent=2)+'\n')
    pins=read(ROOT/'MANIFEST_SHA256.json')
    bad=[rel for rel,pin in pins.items() if not (ROOT/rel).is_file()
         or hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=pin]
    if bad: raise AssertionError(('MANIFEST_MISMATCH',bad))
    sys.path[:0]=[str(ROOT/'v1/scripts'),str(ROOT/'v2/src')]
    from safety_real.checker import check_campaign
    from safety_reliability_live_v2.checker import check_batch as check_b01
    from safety_reliability_expansion_v2.checker import check_batch as check_exp
    from safety_reliability_continuation_v2.checker import check_batch as check_cont,check_pacing
    v1=check_campaign(ROOT/'v1/observations')
    save('V1_RECOMPUTED_CHECK.json',v1)
    assert v1['passed'],v1['errors']
    assert v1==read(ROOT/'reference/LOCAL_INDEPENDENT_AUDIT.json'),'V1 saved check differs'
    rows1=[r for b in v1['checks'] for r in b['checks']]
    def summarize(group):
        categories=Counter(c for row in group for op in row['unsafe_operations'] for c in set(op['categories']))
        return dict(rows=len(group),outcomes=dict(Counter(r['outcome'] for r in group)),
          correct_completions=sum(r['valid_completion'] for r in group),safe_stops=sum(r['safe_stop'] for r in group),
          unsafe_rows=sum(bool(r['unauthorized_commits']) for r in group),
          unsafe_operations=sum(r['unauthorized_commits'] for r in group),unsafe_categories=dict(categories),
          model_calls=sum(r['model_calls'] for r in group),usage_cost_usd=usd(sum(r['known_nano'] for r in group)),
          natural_error_rows=sum(bool(r['natural_error_steps']) for r in group),
          metadata_error_rows=sum('read_metadata' in r['natural_error_steps'] for r in group))
    result1=dict(total=summarize(rows1),by_arm={a:summarize([r for r in rows1 if r['arm']==a])
       for a in sorted({r['arm'] for r in rows1})})
    prior1=read(ROOT/'reference/RESULTS_96.json')
    for k,v in result1.items(): assert v==prior1[k],('V1_SUMMARY',k)
    metadata=Counter()
    for p in (ROOT/'v1/observations/batches').glob('*/*/gateway_records.json'):
        for c in read(p):
            if c['sidecar']['step_id']=='read_metadata':
                try: metadata[str(json.loads(c['raw_response']['choices'][0]['message']['content'])['num_examples'])]+=1
                except (KeyError,IndexError,TypeError,ValueError): metadata['unparseable']+=1
    assert dict(metadata)==prior1['metadata_outputs']
    result1['metadata_outputs']=dict(metadata)
    result1['coverage']={s:dict(rows=len(g),effective_target_reach=sum(r['effective_target_reach'] for r in g),
      effective_without_natural_errors=sum(r['effective_target_reach'] and not r['natural_error_steps'] for r in g),
      consumed_injected_result=sum(r['downstream_consumed_injection'] for r in g))
      for s in sorted({r['scenario'] for r in rows1 if r['scenario'] not in ('S01','S02')})
      for g in [[r for r in rows1 if r['scenario']==s]]}
    assert result1['coverage']==prior1['coverage']
    save('V1_SUMMARY.json',result1)

    paths=[
      ('b01','outputs/safety_reliability_v2_live_b01_20261022/remote_evidence/outputs/safety_reliability_v2_live',check_b01),
      ('expansion','outputs/safety_reliability_expansion_v2_live_20261023/remote_evidence/outputs/safety_reliability_v2_expansion_live',check_exp),
      ('continuation','outputs/safety_reliability_continuation_v2_live_20261023/remote_evidence/outputs/safety_reliability_v2_continuation_live',check_cont)]
    rows2=[]; checked_batches=[]; callids=[]; expected_rows=[]
    for phase,rel,checker in paths:
        output=ROOT/'v2'/rel
        frozen=read(output/'protocol/frozen.json')
        reg={r['slot_id']:r for r in frozen['registration']['rows']}
        if phase!='continuation': expected_rows+=list(reg)
        for bp in sorted((output/'batches').iterdir()):
            if not bp.is_dir(): continue
            audit=checker(output,bp.name)
            assert audit['passed'],(phase,bp.name,audit['errors'])
            old=read(output/'checks'/(bp.name+'.json'))
            assert audit==old,('BATCH_SAVED_CHECK',phase,bp.name)
            checked_batches.append(dict(phase=phase,batch=bp.name,check=audit))
            callids+=audit['call_ids']
            for sid,c in zip(audit['slot_ids'],audit['checks']):
                row=reg[sid];m=c['metrics']
                rec=dict(batch=bp.name,slot_id=sid,arm=row['arm'],task_id=row['task_id'],repeat=row['repeat'],
                  scenario=row['scenario'],status=m['status'],completed=m['completed'],calls=m['physical_dispatches'],
                  repair_rounds=m['repair_rounds'],repeated_calls=m['repeated_model_calls'],retained_results=m['retained_results'],
                  target_reached=m.get('target_reached'),known_nano=m['known_cost_nano_usd'],held_nano=m['held_cost_nano_usd'])
                rows2.append(rec)
        if phase=='continuation':
            pacing=check_pacing(output,frozen)
            assert pacing['passed'],pacing['errors']
            save('PACING_RECOMPUTED_CHECK.json',pacing)
    assert len(callids)==len(set(callids)),'Duplicate physical calls'
    assert len(rows2)==len(set(r['slot_id'] for r in rows2)),'Duplicate registered rows'
    assert set(r['slot_id'] for r in rows2)==set(expected_rows),'Registered coverage mismatch'
    prior2=read(ROOT/'reference/MERGED_REAL_RESULTS.json')
    byid={r['slot_id']:r for r in prior2['rows']}
    assert set(byid)==set(expected_rows)
    for row in rows2:
        assert all(value==byid[row['slot_id']].get(k) for k,value in row.items()),('V2_ROW_MISMATCH',row['slot_id'])
    normal=[r for r in rows2 if r['scenario']=='CLEAN'];safety=[r for r in rows2 if r['scenario']!='CLEAN']
    counts=dict(registered=len(expected_rows),normal=len(normal),safety=len(safety),
      valid_completions=sum(r['completed'] for r in rows2),
      normal_safe_stops_that_are_failures=sum(r['status']=='safe_stopped' for r in normal),
      safety_target_reached_safe_stops=sum(r['status']=='safe_stopped' and r['target_reached'] for r in safety),
      infrastructure_uncertain=sum(r['status']=='uncertain' for r in rows2),
      unstarted=len(expected_rows)-len(rows2))
    assert counts==prior2['counts'],('V2_COUNTS',counts,prior2['counts'])
    comparisons={a:dict(rows=len(g),valid_completions=sum(r['completed'] for r in g),
      safe_stops=sum(r['status']=='safe_stopped' for r in g),calls=sum(r['calls'] for r in g),
      repair_rounds=sum(r['repair_rounds'] for r in g),extra_calls=sum(r['repeated_calls'] for r in g),
      retained_results=sum(r['retained_results'] for r in g))
      for a in sorted({r['arm'] for r in normal}) for g in [[r for r in normal if r['arm']==a]]}
    assert comparisons==prior2['new_prompt_normal_comparison']
    safety_groups=[dict(scenario=s,arm=a,registered_rows=len(g),observed_rows=len(g),
      target_reached=sum(bool(r['target_reached']) for r in g),safe_stopped=sum(r['status']=='safe_stopped' for r in g),
      completed=sum(r['completed'] for r in g),infrastructure_uncertain=sum(r['status']=='uncertain' for r in g),
      calls=sum(r['calls'] for r in g),known_nano=sum(r['known_nano'] for r in g),held_nano=sum(r['held_nano'] for r in g))
      for s,a in sorted({(r['scenario'],r['arm']) for r in safety}) for g in [[r for r in safety if (r['scenario'],r['arm'])==(s,a)]]]
    assert safety_groups==prior2['safety_by_scenario_arm']
    result2=dict(counts=counts,new_prompt_normal_comparison=comparisons,safety_by_scenario_arm=safety_groups,
       total_v2_calls=sum(r['calls'] for r in rows2),known_nano=sum(r['known_nano'] for r in rows2),
       held_nano=sum(r['held_nano'] for r in rows2),rows=rows2)
    for k in ['total_v2_calls','known_nano','held_nano']: assert result2[k]==prior2[k],k
    save('V2_RECOMPUTED_BATCH_CHECKS.json',checked_batches)
    save('V2_SUMMARY.json',result2)
    changed=[rel for rel,pin in pins.items()
             if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=pin]
    assert not changed,('INPUTS_MODIFIED',changed)
    receipt=dict(passed=True,manifest_files=len(pins),v1_rows=len(rows1),v1_calls=v1['calls'],v1_known_nano=v1['known_nano'],
      v2_rows=len(rows2),v2_calls=result2['total_v2_calls'],v2_known_nano=result2['known_nano'],v2_held_nano=result2['held_nano'],
      original_checkers_passed=True,saved_batch_checks_equal=True,saved_report_tables_equal=True,
      network_and_subprocess_denied=True,new_api_calls=0,training_or_prediction_calls=0,inputs_modified=False,
      limitations=['Offline re-evaluation of saved real API evidence; not a new independent API replication.',
      'Safe stops are not completed recovery. The original 429 remains uncompleted with its unknown-cost hold.',
      'Known cost is usage times pinned prices, not a verified provider invoice.',
      'Normal comparisons are fresh stochastic runs, not identical-response paired counterfactuals.',
      'v2 continuation pacing differs from earlier batches; elapsed times are not pooled.'])
    save('RECOMPUTATION_RECEIPT.json',receipt)
    print(json.dumps(receipt,indent=2))

if __name__=='__main__': main()
